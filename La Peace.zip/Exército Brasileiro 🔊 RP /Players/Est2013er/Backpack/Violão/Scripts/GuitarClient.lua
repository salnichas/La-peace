-- https://lua.expert/
local v1 = script.Parent.Parent
local Guitar = v1:WaitForChild("Events"):WaitForChild("Guitar")
local LocalPlayer = game.Players.LocalPlayer
local RunService = game:GetService("RunService")
local Animations = v1.Animations
local v2 = nil
local v3 = nil
local v4 = false
local v5 = false
local v6 = nil
local v7 = 1

local function StopAll() --[[ StopAll | Line: 23 | Upvalues: v2 (ref), v3 (ref), v6 (ref), v5 (ref) ]]
	if v2 then
		v2:Stop()
	end

	if v3 then
		v3:Stop()
	end

	if v6 then
		v6:Disconnect()
		v6 = nil
	end

	v5 = false
end

local t = {}
local v8 = 0
local v9 = 0

local function StartBeatSync() --[[ StartBeatSync | Line: 45 | Upvalues: LocalPlayer (copy), t (ref), v6 (ref), RunService (copy), v3 (ref), v7 (ref), v8 (ref), v9 (ref) ]]
	local Character = LocalPlayer.Character

	if not Character then
		return
	end

	local GuitarMesh = Character:FindFirstChild("GuitarMesh")

	if not GuitarMesh then
		return
	end

	local Sound = GuitarMesh:FindFirstChildOfClass("Sound")

	if Sound then
		t = {}
		v6 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 58 | Upvalues: v3 (ref), Sound (copy), t (ref), v7 (ref), v8 (ref), v9 (ref) ]]
			if not v3 then
				return
			end

			if not Sound.IsPlaying then
				return
			end

			local PlaybackLoudness = Sound.PlaybackLoudness

			table.insert(t, PlaybackLoudness)

			if #t > 12 then
				table.remove(t, 1)
			end

			local sum = 0

			for i, v in ipairs(t) do
				sum = sum + v
			end

			v7 = v7 + (math.clamp(PlaybackLoudness / 230, 0.9, 2.4) - v7) * 0.22

			local v32 = v7

			if sum / #t * 1.32 < PlaybackLoudness and v8 <= 0 then
				v9 = tick()
				v8 = 0.09
			end

			if v8 > 0 then
				v8 = v8 - p1
			end

			if tick() - v9 < 0.11 then
				v32 = math.clamp(v7 * 2.9, 1, 4)
			end

			v3:AdjustSpeed(v32)
		end)
	end
end

v1.Equipped:Connect(function() --[[ Line: 105 | Upvalues: LocalPlayer (copy), v2 (ref), Animations (copy), v3 (ref), v4 (ref), Guitar (copy) ]]
	local Character = LocalPlayer.Character

	if not Character then
		return
	end

	local Humanoid = Character:FindFirstChildOfClass("Humanoid")

	if not Humanoid then
		return
	end

	local Animator = Humanoid:FindFirstChildOfClass("Animator")

	if Animator then
		v2 = Animator:LoadAnimation(Animations.Idle)
		v3 = Animator:LoadAnimation(Animations.Playing)
		v2.Looped = true
		v3.Looped = true
		v2:Play()
		v4 = true
		Guitar:FireServer("Equip")
	end
end)
v1.Unequipped:Connect(function() --[[ Line: 130 | Upvalues: v4 (ref), v2 (ref), v3 (ref), v6 (ref), v5 (ref), Guitar (copy) ]]
	v4 = false

	if v2 then
		v2:Stop()
	end

	if v3 then
		v3:Stop()
	end

	if not v6 then
		v5 = false
		Guitar:FireServer("Unequip")

		return
	end

	v6:Disconnect()
	v6 = nil
	v5 = false
	Guitar:FireServer("Unequip")
end)

local v10 = false

v1.Activated:Connect(function() --[[ Line: 142 | Upvalues: v10 (ref), v4 (ref), v5 (ref), v2 (ref), v3 (ref), v6 (ref), StartBeatSync (copy) ]]
	if v10 then
		return
	end

	if not v4 then
		return
	end

	v10 = true

	if v5 then
		if v2 then
			v2:Stop()
		end

		if v3 then
			v3:Stop()
		end

		if v6 then
			v6:Disconnect()
			v6 = nil
		end

		v5 = false

		if not v2 then
			task.delay(1.75, function() --[[ Line: 169 | Upvalues: v10 (ref) ]]
				v10 = false
			end)

			return
		end

		v2:Play()
	else
		if v2 then
			v2:Stop()
		end

		if v3 then
			v3:Play()
		end

		v5 = true
		task.delay(0.15, StartBeatSync)
	end

	task.delay(1.75, function() --[[ Line: 169 | Upvalues: v10 (ref) ]]
		v10 = false
	end)
end)