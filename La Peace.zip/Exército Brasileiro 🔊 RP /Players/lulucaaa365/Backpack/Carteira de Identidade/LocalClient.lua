-- https://lua.expert/
local v1 = script.Parent
local GetInfo = v1:WaitForChild("GetInfo")

v1.Equipped:Connect(function() --[[ Line: 4 | Upvalues: GetInfo (copy) ]]
	local LocalPlayer = game.Players.LocalPlayer

	GetInfo:FireServer({
		Name = LocalPlayer.Name,
		UserId = LocalPlayer.UserId,
		AccountAge = LocalPlayer.AccountAge
	})
end)