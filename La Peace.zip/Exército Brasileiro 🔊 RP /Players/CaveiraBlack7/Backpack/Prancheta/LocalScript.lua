-- https://lua.expert/
script.Parent.Equipped:Connect(function() --[[ Line: 1 ]]
	game.Players.LocalPlayer.PlayerGui.Prancheta.Enabled = true
end)
script.Parent.Unequipped:Connect(function() --[[ Line: 5 ]]
	game.Players.LocalPlayer.PlayerGui.Prancheta.Enabled = false
end)