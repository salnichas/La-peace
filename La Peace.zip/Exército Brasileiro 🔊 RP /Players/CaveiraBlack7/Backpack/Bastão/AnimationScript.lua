-- https://lua.expert/
local function WaitForChild(p1, p2) --[[ WaitForChild | Line: 2 ]]
	while not p1:FindFirstChild(p2) do
		p1.ChildAdded:wait()
	end

	return p1[p2]
end

local v1 = script.Parent
local t = {}
local v2 = nil
local v3 = nil

local function PlayAnimation(p1) --[[ PlayAnimation | Line: 14 | Upvalues: t (copy) ]]
	if not t[p1] then
		return
	end

	t[p1]:Play()
end

local function StopAnimation(p1) --[[ StopAnimation | Line: 20 | Upvalues: t (copy) ]]
	if not t[p1] then
		return
	end

	t[p1]:Stop()
end

function OnEquipped(p1) --[[ OnEquipped | Line: 27 | Upvalues: v3 (ref), v1 (copy), v2 (ref), WaitForChild (copy), t (copy) ]]
	v3 = v1.Parent
	v2 = WaitForChild(v3, "Humanoid")

	if v2 then
		t.EquipAnim = v2:LoadAnimation((WaitForChild(v1, "EquipAnim5")))
		t.IdleAnim = v2:LoadAnimation((WaitForChild(v1, "IdleAnim3")))
		t.OverheadAnim = v2:LoadAnimation((WaitForChild(v1, "OverheadAnim2")))
		t.SlashAnim = v2:LoadAnimation((WaitForChild(v1, "SlashAnim2")))
		t.ThrustAnim = v2:LoadAnimation((WaitForChild(v1, "ThrustAnim2")))
		t.UnequipAnim = v2:LoadAnimation((WaitForChild(v1, "UnequipAnim2")))
	end

	if t.EquipAnim then
		t.EquipAnim:Play()
	end

	if not t.IdleAnim then
		return
	end

	t.IdleAnim:Play()
end
function OnUnequipped() --[[ OnUnequipped | Line: 42 | Upvalues: t (copy) ]]
	for k, v in pairs(t) do
		if t[k] then
			t[k]:Stop()
		end
	end
end
v1.Equipped:connect(OnEquipped)
v1.Unequipped:connect(OnUnequipped)
WaitForChild(v1, "PlaySlash").Changed:connect(function(p1) --[[ Line: 52 | Upvalues: t (copy) ]]
	if not t.SlashAnim then
		return
	end

	t.SlashAnim:Play()
end)
WaitForChild(v1, "PlayThrust").Changed:connect(function(p1) --[[ Line: 61 | Upvalues: t (copy) ]]
	if not t.ThrustAnim then
		return
	end

	t.ThrustAnim:Play()
end)
WaitForChild(v1, "PlayOverhead").Changed:connect(function(p1) --[[ Line: 70 | Upvalues: t (copy) ]]
	if not t.OverheadAnim then
		return
	end

	t.OverheadAnim:Play()
end)