-- https://lua.expert/
local v1 = script.Parent

enabled = true
function onButton1Down(p1) --[[ onButton1Down | Line: 4 ]]
	if enabled then
		enabled = false
		p1.Icon = "rbxasset://textures\\GunWaitCursor.png"
		wait(1)
		p1.Icon = "rbxasset://textures\\GunCursor.png"
		enabled = true
	end
end
function onEquippedLocal(p1) --[[ onEquippedLocal | Line: 18 ]]
	if p1 == nil then
		print("Mouse not found")
	else
		p1.Icon = "rbxasset://textures\\GunCursor.png"
		p1.Button1Down:connect(function() --[[ Line: 26 | Upvalues: p1 (copy) ]]
			onButton1Down(p1)
		end)
	end
end
v1.Equipped:connect(onEquippedLocal)