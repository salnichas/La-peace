-- https://lua.expert/
local v1 = script.Parent
local Knit = require(game.ReplicatedStorage.Modules.Packages.Knit)
local LocalPlayer = game.Players.LocalPlayer
local v2 = LocalPlayer:GetMouse()
local PrisonGui = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("PrisonGui")
local UserInputService = game:GetService("UserInputService")

Knit.OnStart():expect()

local UtilityService = Knit.GetService("UtilityService")
local v3 = nil

local function handleArrest(p1) --[[ handleArrest | Line: 15 | Upvalues: LocalPlayer (copy), v3 (ref), UtilityService (copy), PrisonGui (copy) ]]
	local v1 = game.Players:FindFirstChild(p1.Name)

	if not (v1 and p1:FindFirstChild("Humanoid")) then
		return
	end

	if LocalPlayer:GetAttribute("Arrested") then
		warn("Voc\195\170 est\195\161 algemado e n\195\163o pode algemar outros jogadores.")

		return
	end

	local v2 = LocalPlayer:GetAttribute("Patente") or 0

	if v2 < (v1:GetAttribute("Patente") or 0) then
		warn("Voc\195\170 n\195\163o pode algemar um jogador com patente maior que a sua.")

		return
	end

	if v3 and v3 ~= v1 then
		return
	end

	if v1:GetAttribute("Arrested") then
		UtilityService:Arrest(p1, "Unarrest")
		v3 = nil
		PrisonGui.Enabled = false

		return
	end

	if not UtilityService:Arrest(p1, "Arrest") then
		return
	end

	v3 = v1

	if LocalPlayer.Team and (LocalPlayer.Team.Name ~= "[CI] Cidad\195\163o" and v2 >= 16) then
		PrisonGui.Enabled = true
		PrisonGui.Main.User.Value = p1.Name
		PrisonGui.Main.Title.Text = ("Jogador algemado: %* "):format(p1.Name)
	end

	task.defer(function() --[[ Line: 62 | Upvalues: LocalPlayer (ref), v1 (copy), p1 (copy), v3 (ref) ]]
		local Character = LocalPlayer.Character

		if not (Character and Character:FindFirstChild("HumanoidRootPart")) then
			return
		end

		local HumanoidRootPart = Character.HumanoidRootPart

		while v1:GetAttribute("Arrested") and p1:FindFirstChild("HumanoidRootPart") do
			p1.HumanoidRootPart.CFrame = HumanoidRootPart.CFrame * CFrame.new(0, 0, -5)
			task.wait()
		end

		if v3 ~= v1 then
			return
		end

		v3 = nil
	end)
end

UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 78 | Upvalues: UserInputService (copy), v1 (copy), LocalPlayer (copy), v3 (ref), UtilityService (copy), v2 (copy), handleArrest (copy) ]]
	if p2 then
		return
	end

	if UserInputService.PreferredInput ~= Enum.PreferredInput.KeyboardAndMouse then
		return
	end

	if p1.UserInputType ~= Enum.UserInputType.MouseButton1 or v1.Parent ~= LocalPlayer.Character then
		return
	end

	if v3 then
		local Character = v3.Character

		if Character then
			UtilityService:Arrest(Character, "Unarrest")
		end

		v3 = nil
	else
		local Target = v2.Target

		if not Target then
			return
		end

		local v12 = Target:FindFirstAncestorWhichIsA("Model")

		if not v12 then
			return
		end

		if workspace:GetAttribute("LiveEventStarted") then
			return
		end

		handleArrest(v12)
	end
end)

local v4 = nil

v1.Equipped:Connect(function(p1) --[[ Line: 125 | Upvalues: UserInputService (copy), v4 (ref), v3 (ref), UtilityService (copy), v2 (copy), handleArrest (copy) ]]
	if UserInputService.PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
		return
	end

	if v4 then
		v4:Disconnect()
	end

	v4 = p1.Button1Down:Connect(function() --[[ Line: 133 | Upvalues: v3 (ref), UtilityService (ref), v2 (ref), handleArrest (ref) ]]
		if v3 then
			local Character = v3.Character

			if not Character then
				v3 = nil

				return
			end

			UtilityService:Arrest(Character, "Unarrest")
			v3 = nil
		else
			local Target = v2.Target

			if not Target then
				return
			end

			local v1 = Target:FindFirstAncestorWhichIsA("Model")

			if not v1 then
				return
			end

			if workspace:GetAttribute("LiveEventStarted") then
				return
			end

			handleArrest(v1)
		end
	end)
end)
v1.Unequipped:Connect(function() --[[ Line: 169 | Upvalues: v3 (ref), UtilityService (copy), PrisonGui (copy) ]]
	if not v3 then
		return
	end

	local Character = v3.Character

	if Character then
		UtilityService:Arrest(Character, "Unarrest")
	end

	v3 = nil
	PrisonGui.Enabled = false
end)

while task.wait(0.2) do
	if v3 then
		local Character = v3.Character

		if v3.Parent == game.Players and (Character and Character.Parent) then
			continue
		end

		v3 = nil
		PrisonGui.Enabled = false
	elseif PrisonGui.Enabled then
		PrisonGui.Enabled = false
	else
		continue
	end
end