-- https://lua.expert/
local LocalPlayer = game:GetService("Players").LocalPlayer
local Humanoid = (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("Humanoid")
local v2 = script.Parent
local Base = v2:WaitForChild("Base")
local Animator = Humanoid:WaitForChild("Animator")
local v3 = Animator:LoadAnimation((v2:WaitForChild("Segurar")))
local v4 = Animator:LoadAnimation((v2:WaitForChild("Cortar")))
local Cortar = Base:WaitForChild("Cortar")
local Gramas = workspace:WaitForChild("Map"):WaitForChild("Sistemas"):WaitForChild("Jobs"):WaitForChild("Cortar Grama"):WaitForChild("Gramas")

local function Ativar(p1) --[[ Ativar | Line: 27 | Upvalues: Gramas (copy) ]]
	for v1, v2 in Gramas:GetChildren() do
		local Highlight = v2:FindFirstChildOfClass("Highlight")

		if Highlight then
			Highlight.Enabled = p1
		end
	end
end

for v5, v6 in Gramas:GetChildren() do
	local ProximityPrompt = v6:FindFirstChildOfClass("ProximityPrompt")

	if ProximityPrompt then
		ProximityPrompt.Triggered:Connect(function() --[[ Line: 49 | Upvalues: v4 (copy), Cortar (copy) ]]
			v4:Play()
			Cortar:Play()
		end)
	end
end

v2.Equipped:Connect(function() --[[ Line: 60 | Upvalues: v3 (copy), Ativar (copy) ]]
	if v3 then
		v3.Priority = Enum.AnimationPriority.Action4
		v3:Play()
	end

	Ativar(true)
end)
v2.Unequipped:Connect(function() --[[ Line: 73 | Upvalues: v3 (copy), Ativar (copy) ]]
	if not v3 then
		Ativar(false)

		return
	end

	v3:Stop()
	Ativar(false)
end)