-- https://lua.expert/
local UserInputService = game:GetService("UserInputService")
local DeviceEvent = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("Events"):WaitForChild("Dispositivo"):WaitForChild("DeviceEvent")
local v1 = "PC"

if UserInputService.PreferredInput == Enum.PreferredInput.Touch then
	v1 = "Mobile"
elseif UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
	v1 = "Console"
end

DeviceEvent:FireServer(v1)

local RunService = game:GetService("RunService")

game:GetService("AvatarEditorService")

local function getServerType() --[[ getServerType | Line: 20 | Upvalues: RunService (copy) ]]
	if RunService:IsStudio() then
		return "Studio"
	end

	if game.PrivateServerId == "" then
		return "Public"
	end

	if game.PrivateServerOwnerId == 0 then
		return "Reserved"
	end

	return "VIP"
end