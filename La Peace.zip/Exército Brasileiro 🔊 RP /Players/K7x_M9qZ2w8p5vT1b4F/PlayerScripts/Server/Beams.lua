-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")

ReplicatedStorage.Remotes.Events.Beams.CreateBeam.OnClientEvent:Connect(function(p1, p2) --[[ Line: 3 | Upvalues: ReplicatedStorage (copy) ]]
	local ArrowBeam = workspace:FindFirstChild("ArrowBeam")
	local v1

	if ArrowBeam then
		ArrowBeam:Destroy()
	end

	v1 = ReplicatedStorage.Assets.Beams.ArrowBeam:Clone()
	v1.Parent = workspace
	v1.Attachment0 = game.Players.LocalPlayer.Character:WaitForChild("PegarCaixa"):WaitForChild("Attachment")
	v1.Attachment1 = p2
end)