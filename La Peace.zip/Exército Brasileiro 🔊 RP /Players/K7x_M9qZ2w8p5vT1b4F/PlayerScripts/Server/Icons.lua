-- https://lua.expert/
local Icon = require(game:GetService("ReplicatedStorage").Modules.Utils.Icon)
local Knit = require(game:GetService("ReplicatedStorage").Modules.Packages.Knit)
local Players = game:GetService("Players")

game:GetService("TextChatService")
game:GetService("ReplicatedStorage")
game:GetService("SocialService")
game:GetService("StarterGui")
game:GetService("VoiceChatService")
game:GetService("RunService")
game:GetService("TweenService")

local LocalPlayer = Players.LocalPlayer
local PlayerGui = LocalPlayer.PlayerGui
local v1 = false
local v2 = false
local v3 = false
local v4 = false

LocalPlayer:SetAttribute("MuteNotifications", v2)
Knit.OnStart():expect()
Knit.GetService("EconomyService")

local UtilityService = Knit.GetService("UtilityService")
local v5 = false

local function createRadioIcon() --[[ createRadioIcon | Line: 35 | Upvalues: v5 (ref), Icon (copy), LocalPlayer (copy) ]]
	if not v5 then
		v5 = true
		Icon.new():setImage(6227979000):setCaption("Gamepass de r\195\161dio"):autoDeselect(false):bindEvent("selected", function(p1) --[[ Line: 43 | Upvalues: LocalPlayer (ref) ]]
			LocalPlayer.PlayerGui.RadioGui.Enabled = true
			p1:setLabel("Fechar")
		end):bindEvent("deselected", function(p1) --[[ Line: 47 | Upvalues: LocalPlayer (ref) ]]
			LocalPlayer.PlayerGui.RadioGui.Enabled = false
			p1:setLabel("")
		end)
	end
end

local Gamepasses = LocalPlayer:WaitForChild("Gamepasses", 60)

if Gamepasses:GetAttribute("RADIO") then
	createRadioIcon()
end

Gamepasses.AttributeChanged:Connect(function() --[[ Line: 58 | Upvalues: Gamepasses (copy), createRadioIcon (copy) ]]
	if not Gamepasses:GetAttribute("RADIO") then
		return
	end

	createRadioIcon()
end)

local v6 = nil

local function stopRadioSound() --[[ stopRadioSound | Line: 66 | Upvalues: LocalPlayer (copy), v6 (ref) ]]
	local Character = LocalPlayer.Character

	if not Character then
		return
	end

	local Radio = Character:FindFirstChild("Radio")

	if not (Radio and Radio:FindFirstChild("Handle")) then
		return
	end

	local Sound = Radio.Handle:FindFirstChild("Sound")

	if not (Sound and Sound.IsPlaying) then
		return
	end

	v6 = Sound.SoundId
	Sound:Pause()
end

local function resumeLastRadioSound() --[[ resumeLastRadioSound | Line: 79 | Upvalues: LocalPlayer (copy) ]]
	local Character = LocalPlayer.Character

	if not Character then
		return
	end

	local Radio = Character:FindFirstChild("Radio")

	if not (Radio and Radio:FindFirstChild("Handle")) then
		return
	end

	local Sound = Radio.Handle:FindFirstChild("Sound")

	if not Sound then
		return
	end

	local v1 = LocalPlayer:GetAttribute("RadioSoundId")
	local v2 = LocalPlayer:GetAttribute("RadioStartTime")

	if v1 and v2 then
		local v3 = tick() - v2

		Sound.SoundId = "rbxassetid://" .. tostring(v1)
		Sound.Looped = true
		Sound.TimePosition = v3
		Sound:Play()
	end
end

local function sendMuteToggle() --[[ sendMuteToggle | Line: 96 | Upvalues: v1 (ref), UtilityService (copy) ]]
	if v1 then
		UtilityService.PlayAudio:Fire("__MUTE_ALL__")
	else
		UtilityService.PlayAudio:Fire("__UNMUTE_ALL__")
	end
end

local v7 = Icon.new():setImage(256294290):setCaption("Configura\195\167\195\181es e desempenho"):autoDeselect(false)
local v8 = Icon.new():setImage(10653372143):setLabel("Logs de mortes"):bindEvent("selected", function(p1) --[[ Line: 121 | Upvalues: v3 (ref), LocalPlayer (copy) ]]
	v3 = not v3
	LocalPlayer.PlayerGui.ServerLogs.Enabled = v3
	p1:setLabel(if v3 then "Fechar Logs" else "Logs de mortes")
	p1:deselect()
end)
local v9 = Icon.new():setImage(90332761263250):setLabel("Silenciar R\195\161dio"):bindEvent("selected", function(p1) --[[ Line: 131 | Upvalues: v1 (ref), stopRadioSound (copy), resumeLastRadioSound (copy), UtilityService (copy) ]]
	v1 = not v1

	if v1 then
		stopRadioSound()
	else
		resumeLastRadioSound()
	end

	if v1 then
		UtilityService.PlayAudio:Fire("__MUTE_ALL__")
	else
		UtilityService.PlayAudio:Fire("__UNMUTE_ALL__")
	end

	p1:setLabel(if v1 then "Desilenciar R\195\161dio" else "Silenciar R\195\161dio")
	p1:deselect()
end)
local v10 = Icon.new():setImage(90332761263250):setLabel("Desativar Avisos"):bindEvent("selected", function(p1) --[[ Line: 142 | Upvalues: v2 (ref), LocalPlayer (copy) ]]
	v2 = not v2
	LocalPlayer:SetAttribute("MuteNotifications", v2)
	p1:setLabel(if v2 then "Ativar Avisos" else "Desativar Avisos")
	p1:deselect()
end)
local v11 = Icon.new():setImage(111704740561400):setLabel("Deletar Detalhes"):bindEvent("selected", function(p1) --[[ Line: 152 | Upvalues: v4 (ref) ]]
	local Map = workspace:FindFirstChild("Map")
	local v1 = if Map then Map:FindFirstChild("ConfigurationFolder") else Map
	local v2 = if v1 then v1:FindFirstChild("Detalhes") else v1

	if not v2 then
		p1:setLabel("Erro ao localizar")
		p1:deselect()

		return
	end

	if v4 then
		v2:Destroy()
		p1:setLabel("Apagado")
		task.wait(1.5)
		p1:destroy()
	else
		v4 = true
		p1:setLabel("Tem certeza?")
		p1:deselect()
	end
end)
local v12 = Icon.new():setImage(90332761263250):setLabel("Desativar Treinos")
local v13 = true

v12:bindEvent("selected", function(p1) --[[ Line: 203 | Upvalues: v13 (ref), v12 (copy) ]]
	local GlobalEvent = game.ReplicatedStorage.Remotes.Events.Global.GlobalEvent

	if v13 then
		GlobalEvent:FireServer({
			action = "remover_aviso"
		})
		v12:setLabel("Ativar Treinos")
		v13 = false
	else
		GlobalEvent:FireServer({
			action = "ativar_aviso"
		})
		v12:setLabel("Desativar Treinos")
		v13 = true
	end
end)
v7:setDropdown({
	v8,
	v9,
	v10,
	v12,
	v11,
	(Icon.new():setImage(120920004878419):setLabel("Modo desempenho"):bindEvent("selected", function(p1) --[[ Line: 223 ]]
		for i, v in ipairs(workspace:GetDescendants()) do
			if v:IsA("Texture") or (v:IsA("Decal") or (v:IsA("SurfaceAppearance") or (v:IsA("ParticleEmitter") or (v:IsA("Trail") or v:IsA("Beam"))))) then
				pcall(function() --[[ Line: 227 | Upvalues: v (copy) ]]
					v:Destroy()
				end)

				continue
			end

			if v:IsA("BasePart") then
				v.Material = Enum.Material.Plastic
			end
		end

		local Lighting = game:GetService("Lighting")

		Lighting.FogStart = 1000000
		Lighting.FogEnd = 1000001
		Lighting.GlobalShadows = false
		Lighting.Brightness = 1
		workspace.Terrain.WaterReflectance = 0
		workspace.Terrain.WaterTransparency = 1
		workspace.Terrain.WaterWaveSize = 0
		workspace.Terrain.WaterWaveSpeed = 0
		p1:setLabel("Ativado")
		p1:deselect()
	end))
})
Icon.new():setImage(14849189975):setCaption("Ative os polichinelos"):setLabel("Ativar JJs"):autoDeselect(false):bindEvent("selected", function(p1) --[[ Line: 265 | Upvalues: LocalPlayer (copy) ]]
	LocalPlayer:SetAttribute("Polichinelos", true)
	p1:setLabel("Desativar")
end):bindEvent("deselected", function(p1) --[[ Line: 269 | Upvalues: LocalPlayer (copy) ]]
	LocalPlayer:SetAttribute("Polichinelos", false)
	p1:setLabel("Ativar JJs")
end)
Icon.new():setImage(140013014943385):setCaption("C\195\179digos de dinheiro"):bindEvent("selected", function(p1) --[[ Line: 279 | Upvalues: LocalPlayer (copy) ]]
	LocalPlayer.PlayerGui.CodesGui.Enabled = true
	p1:setLabel("Fechar")
end):bindEvent("deselected", function(p1) --[[ Line: 283 | Upvalues: LocalPlayer (copy) ]]
	LocalPlayer.PlayerGui.CodesGui.Enabled = false
	p1:setLabel("")
end)
Icon.new():setImage(124894064439256):setCaption("Vers\195\163o"):setLabel("v" .. game.PlaceVersion):setRight():lock()

while not LocalPlayer:GetAttribute("RanksAndRolesLoaded") do
	LocalPlayer:GetAttributeChangedSignal("RanksAndRolesLoaded"):Wait()
end

local PlayerInfos = LocalPlayer:WaitForChild("PlayerInfos", 30)

if not (PlayerInfos and PlayerInfos:GetAttribute("DeltaAdmin")) then
	return
end

Icon.new():setImage(72597324329563):setCaption("Delta Admin"):setRight():oneClick():bindEvent("selected", function(p1) --[[ Line: 311 | Upvalues: PlayerGui (copy) ]]
	local DeltaAdmin = PlayerGui:FindFirstChild("DeltaAdmin")

	if not DeltaAdmin then
		DeltaAdmin = PlayerGui:WaitForChild("DeltaAdmin", 30)
	end

	if DeltaAdmin then
		DeltaAdmin.Enabled = not DeltaAdmin.Enabled
	else
		warn("Delta Admin n\195\163o conseguiu carregar corretamente!")
		p1:Destroy()
	end
end)