-- https://lua.expert/
local v1 = Random.new()
local t = {
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h",
	"i",
	"j",
	"k",
	"l",
	"m",
	"n",
	"o",
	"p",
	"q",
	"r",
	"s",
	"t",
	"u",
	"v",
	"w",
	"x",
	"y",
	"z"
}

local function getRandomLetter() --[[ getRandomLetter | Line: 4 | Upvalues: t (copy), v1 (copy) ]]
	return t[v1:NextInteger(1, #t)]
end

local function getRandomString(p1, p2) --[[ getRandomString | Line: 8 | Upvalues: t (copy), v1 (copy) ]]
	local v12 = ""

	for i = 1, p1 or 10 do
		local v2 = t[v1:NextInteger(1, #t)]

		if p2 and v1:NextNumber() > 0.5 then
			v2 = string.upper(v2)
		end

		v12 = v12 .. v2
	end

	return v12
end

script.Name = getRandomString(10, true)

local LocalPlayer = game.Players.LocalPlayer

local function monitorHumanoid(p1) --[[ monitorHumanoid | Line: 30 | Upvalues: LocalPlayer (copy) ]]
	p1:GetPropertyChangedSignal("WalkSpeed"):Connect(function() --[[ Line: 32 | Upvalues: p1 (copy), LocalPlayer (ref) ]]
		if not (p1.WalkSpeed > 30) then
			return
		end

		p1.WalkSpeed = 16
		LocalPlayer:Kick("Velocidade suspeita detectada.")
	end)
	p1:GetPropertyChangedSignal("JumpPower"):Connect(function() --[[ Line: 40 | Upvalues: p1 (copy), LocalPlayer (ref) ]]
		if not (p1.JumpPower > 50) then
			return
		end

		p1.JumpPower = 50
		LocalPlayer:Kick("Pulo suspeito detectado.")
	end)
end

local function onCharacterAdded(p1) --[[ onCharacterAdded | Line: 49 | Upvalues: monitorHumanoid (copy) ]]
	monitorHumanoid((p1:WaitForChild("Humanoid")))
end

LocalPlayer.CharacterAppearanceLoaded:Connect(onCharacterAdded)

if not LocalPlayer.Character then
	return
end

monitorHumanoid((LocalPlayer.Character:WaitForChild("Humanoid")))