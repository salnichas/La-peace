-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextBox = Players.LocalPlayer.PlayerGui:WaitForChild("HDAdminGUIs").CmdBar.SearchFrame.TextBox

TextBox:FindFirstAncestor("CmdBar").Changed:Connect(function() --[[ Line: 7 | Upvalues: TextBox (copy), ReplicatedStorage (copy) ]]
	if TextBox:FindFirstAncestor("CmdBar").Visible ~= false or not (#string.split(TextBox.Text, " ") >= 2) then
		return
	end

	ReplicatedStorage.Remotes.Events.Admin.LoggerEvent:FireServer(string.split(TextBox.Text, " "))
end)