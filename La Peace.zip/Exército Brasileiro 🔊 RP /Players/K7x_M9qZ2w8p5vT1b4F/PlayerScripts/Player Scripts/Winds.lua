-- https://lua.expert/
game:GetService("RunService")

local WindLines = require(script:WaitForChild("WindLines"))
local WindShake = require(script:WaitForChild("WindShake"))

WindLines:Init({
	Direction = Vector3.new(1, 0, 0.3),
	Speed = 30,
	Lifetime = 1.5,
	SpawnRate = 30
})
WindShake:SetDefaultSettings({
	WindSpeed = 30,
	WindDirection = Vector3.new(1, 0, 0.3),
	WindPower = 0.9
})
WindShake:Init()