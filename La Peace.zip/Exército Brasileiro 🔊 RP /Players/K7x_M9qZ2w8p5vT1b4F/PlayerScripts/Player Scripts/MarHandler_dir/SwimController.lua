-- https://lua.expert/
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Maid = require(script.Maid)

local function InPart(p1, p2, p3) --[[ InPart | Line: 9 ]]
	local v1 = p1.CFrame:PointToObjectSpace(p2)
	local Size = p1.Size

	if not (math.abs(v1.x) <= Size.x / 2) then
		return false
	end

	if not (math.abs(v1.y) <= Size.y / 2 + (p3 or 0)) then
		return false
	end

	if math.abs(v1.z) <= Size.z / 2 then
		return true
	end

	return false
end

local t = {}

for i, v in ipairs(Enum.Material:GetEnumItems()) do
	t[v] = PhysicalProperties.new(v).Density
end

local LocalPlayer = Players.LocalPlayer

return {
	Swimming = false,
	ClampSurfaceMovement = true,
	ProcessWeldedParts = true,
	DragForceMultiplier = 9.85,
	SurfaceDepth = 0.35,
	MaxJumpDepth = 2,
	Zones = {},
	InvalidStartStates = {
		Enum.HumanoidStateType.Seated,
		Enum.HumanoidStateType.PlatformStanding,
		Enum.HumanoidStateType.Dead,
		Enum.HumanoidStateType.Physics,
		Enum.HumanoidStateType.Swimming
	},
	DisabledStates = { Enum.HumanoidStateType.GettingUp, Enum.HumanoidStateType.Jumping },
	AddZone = function(p1, p2) --[[ AddZone | Line: 53 ]]
		if table.find(p1.Zones, p2) then
			return
		end

		table.insert(p1.Zones, p2)
	end,
	Start = function(p1) --[[ Start | Line: 60 | Upvalues: Maid (copy), LocalPlayer (copy), RunService (copy), InPart (copy) ]]
		p1._maid = Maid.new()
		p1._stateMaid = Maid.new()
		p1._recalcMaid = Maid.new()
		LocalPlayer:GetPropertyChangedSignal("Character"):Connect(function() --[[ Line: 66 | Upvalues: p1 (copy), LocalPlayer (ref) ]]
			p1:_setCharacter(LocalPlayer.Character)
		end)

		if LocalPlayer.Character then
			task.defer(p1._setCharacter, p1, LocalPlayer.Character)
		end

		RunService.Heartbeat:connect(function(p12) --[[ Line: 74 | Upvalues: p1 (copy), InPart (ref) ]]
			if not p1.Character then
				return
			end

			debug.profilebegin("PartSwimming")

			local v1 = p1.Humanoid:GetState()
			local Position = p1.RootPart.Position
			local v2 = nil

			for k, v in pairs(p1.Zones) do
				local v3, v4, v5

				if p1._didJump then
					v3 = -p1.SurfaceDepth - p1.MaxJumpDepth

					if v3 then
						v4 = v
						v5 = Position
					else
						v4 = v
						v5 = Position
						v3 = 0
					end
				else
					v4 = v
					v5 = Position
					v3 = 0
				end

				if InPart(v4, v5, v3) then
					v2 = v

					break
				end
			end

			if p1.LastInZone ~= v2 then
				p1.LastInZone = v2

				if v2 then
					p1:_startSwimming(v2)
				else
					p1:_stopSwimming()
				end
			end

			if p1.Swimming then
				if p1.Swimming and v1 == Enum.HumanoidStateType.Swimming then
					if not p1._inSwimmingState then
						p1._inSwimmingState = true
						p1.Humanoid:ChangeState(Enum.HumanoidStateType.Swimming)

						for i2, v in ipairs(p1.DisabledStates) do
							p1.Humanoid:SetStateEnabled(v, false)
						end

						p1._stateMaid:Add(function() --[[ Line: 121 | Upvalues: p1 (ref) ]]
							for i2, v in ipairs(p1.DisabledStates) do
								p1.Humanoid:SetStateEnabled(v, true)
							end
						end)
						p1._stateMaid:Add(game:GetService("UserInputService").JumpRequest:Connect(function() --[[ Line: 128 | Upvalues: p1 (ref) ]]
							p1._didJump = true
						end))

						if p1.ClampSurfaceMovement then
							p1._stateMaid:Add(p1.Humanoid:GetPropertyChangedSignal("MoveDirection"):Connect(function() --[[ Line: 133 | Upvalues: p1 (ref) ]]
								local MoveDirection = p1.Humanoid.MoveDirection

								if not (p1._nearSurface and MoveDirection.Y > 0.1) then
									return
								end

								local v1 = workspace.CurrentCamera.CFrame
								local Y = v1:VectorToObjectSpace(MoveDirection).Y

								if not (math.abs(Y) < 0.01) then
									return
								end

								local LookVector = v1.LookVector
								local v2 = Vector3.new(LookVector.X, 0, LookVector.Z)

								p1.Humanoid:Move(CFrame.fromAxisAngle(LookVector:Cross(v2), (math.acos((math.clamp(LookVector:Dot(v2), -1, 1))))) * MoveDirection)
							end))
						end
					end
				elseif table.find(p1.InvalidStartStates, v1) then
					if p1._inSwimmingState then
						p1._inSwimmingState = false
						p1._stateMaid:Cleanup()
					end
				elseif not p1._inSwimmingState then
					p1._inSwimmingState = true
					p1.Humanoid:ChangeState(Enum.HumanoidStateType.Swimming)

					for i2, v in ipairs(p1.DisabledStates) do
						p1.Humanoid:SetStateEnabled(v, false)
					end

					p1._stateMaid:Add(function() --[[ Line: 121 | Upvalues: p1 (ref) ]]
						for i2, v in ipairs(p1.DisabledStates) do
							p1.Humanoid:SetStateEnabled(v, true)
						end
					end)
					p1._stateMaid:Add(game:GetService("UserInputService").JumpRequest:Connect(function() --[[ Line: 128 | Upvalues: p1 (ref) ]]
						p1._didJump = true
					end))

					if p1.ClampSurfaceMovement then
						p1._stateMaid:Add(p1.Humanoid:GetPropertyChangedSignal("MoveDirection"):Connect(function() --[[ Line: 133 | Upvalues: p1 (ref) ]]
							local MoveDirection = p1.Humanoid.MoveDirection

							if not (p1._nearSurface and MoveDirection.Y > 0.1) then
								return
							end

							local v1 = workspace.CurrentCamera.CFrame
							local Y = v1:VectorToObjectSpace(MoveDirection).Y

							if not (math.abs(Y) < 0.01) then
								return
							end

							local LookVector = v1.LookVector
							local v2 = Vector3.new(LookVector.X, 0, LookVector.Z)

							p1.Humanoid:Move(CFrame.fromAxisAngle(LookVector:Cross(v2), (math.acos((math.clamp(LookVector:Dot(v2), -1, 1))))) * MoveDirection)
						end))
					end
				end
			end

			if not p1.Swimming then
				debug.profileend()

				return
			end

			local AssemblyLinearVelocity = p1.RootPart.AssemblyLinearVelocity

			if p1._shouldRecalculateForces or p1._assemblyMass ~= p1.RootPart.AssemblyMass then
				p1:_recalculateForces()
			end

			local v7 = AssemblyLinearVelocity * p1._dragMultiplier
			local _antigravForce = p1._antigravForce
			local v8 = p1.SurfaceY - p1.SurfaceDepth - Position.Y

			p1._didJump = false

			local v9 = p1

			v9._nearSurface = v8 < 2

			local v11 = if p1._nearSurface then _antigravForce + math.clamp(math.min(1, v8) * 12 - AssemblyLinearVelocity.y, -10, 100) * 5 * p1._assemblyMass else _antigravForce + p1._buoyancyForce

			p1._vectorForce.Force = Vector3.new(0, 1, 0) * v11 - v7
			debug.profileend()
		end)
	end,
	_recalculateForces = function(p1) --[[ _recalculateForces | Line: 194 | Upvalues: t (copy) ]]
		if not (p1.Character and p1.Swimming) then
			return
		end

		p1._recalcMaid:Cleanup()
		p1._shouldRecalculateForces = false

		local AssemblyMass = p1.RootPart.AssemblyMass
		local Gravity = workspace.Gravity
		local sum = 0
		local sum2 = -AssemblyMass * Gravity

		for i, v in ipairs(p1.RootPart:GetConnectedParts(true)) do
			if (if v.Parent == p1.Character then if p1.Humanoid:GetBodyPartR15(v) == Enum.BodyPartR15.Unknown then if p1.Humanoid:GetLimb(v) == Enum.Limb.Unknown then false else true else true else false) or p1.ProcessWeldedParts then
				p1._recalcMaid:Add(v:GetPropertyChangedSignal("CanCollide"):Connect(function() --[[ Line: 218 | Upvalues: p1 (copy) ]]
					p1._shouldRecalculateForces = true
				end))

				if v.CanCollide then
					local Mass = v.Mass

					if Mass == 0 and v.Massless then
						v.Massless = false
						Mass = v.Mass
						v.Massless = true
					end

					if Mass ~= 0 then
						local CustomPhysicalProperties = v.CustomPhysicalProperties
						local v3 = Mass / (if CustomPhysicalProperties then CustomPhysicalProperties.Density else t[v.Material] or 1)

						sum = sum + v3
						sum2 = sum2 + v3 * Gravity
					end
				end
			end
		end

		p1._recalcMaid:Add(workspace:GetPropertyChangedSignal("Gravity"):Connect(function() --[[ Line: 244 | Upvalues: p1 (copy) ]]
			p1._shouldRecalculateForces = true
		end))
		p1._assemblyMass = AssemblyMass
		p1._dragMultiplier = sum * p1.DragForceMultiplier
		p1._antigravForce = AssemblyMass * Gravity
		p1._buoyancyForce = sum2
	end,
	_setCharacter = function(p1, p2) --[[ _setCharacter | Line: 257 | Upvalues: LocalPlayer (copy) ]]
		if p2 == p1.Character then
			return
		end

		p1:_stopSwimming()
		p1.Character = nil
		p1.RootPart = nil
		p1.Humanoid = nil

		if not p2 then
			return
		end

		local HumanoidRootPart = p2:WaitForChild("HumanoidRootPart", 60)
		local Humanoid = p2:WaitForChild("Humanoid", 60)

		if not HumanoidRootPart or (not Humanoid or p2 ~= LocalPlayer.Character) then
			return
		end

		p1.Character = p2
		p1.RootPart = HumanoidRootPart
		p1.Humanoid = Humanoid
	end,
	_stopSwimming = function(p1) --[[ _stopSwimming | Line: 280 ]]
		if p1.Swimming then
			p1.Swimming = false
			p1._inSwimmingState = false
			p1._nearSurface = false
			p1._didJump = false
			p1._maid:Cleanup()
			p1._stateMaid:Cleanup()
			p1._recalcMaid:Cleanup()
		end
	end,
	_startSwimming = function(p1, p2) --[[ _startSwimming | Line: 295 | Upvalues: RunService (copy) ]]
		p1.SurfaceY = p2.Position.y + p2.Size.y / 2

		if not p1.Swimming then
			p1.Swimming = true

			local SwimAttachment = Instance.new("Attachment", p1.RootPart)

			SwimAttachment.Name = "SwimAttachment"

			local VectorForce = Instance.new("VectorForce", SwimAttachment)

			VectorForce.Attachment0 = SwimAttachment
			VectorForce.RelativeTo = Enum.ActuatorRelativeTo.World
			VectorForce.Force = Vector3.new(0, 0, 0)
			p1._vectorForce = VectorForce
			p1._maid:Add(VectorForce, SwimAttachment)
			p1._shouldRecalculateForces = true
			p1._maid:Add(p1.Humanoid.StateChanged:Connect(function() --[[ Line: 319 | Upvalues: RunService (ref), p1 (copy) ]]
				RunService.Stepped:Wait()
				p1._shouldRecalculateForces = true
			end))
		end
	end
}