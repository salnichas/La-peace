-- https://lua.expert/
return function(p1) --[[ Symbol | Line: 2 ]]
	local v1 = newproxy(true)

	getmetatable(v1).__tostring = function() --[[ __tostring | Line: 5 | Upvalues: p1 (copy) ]]
		return p1
	end

	return v1
end