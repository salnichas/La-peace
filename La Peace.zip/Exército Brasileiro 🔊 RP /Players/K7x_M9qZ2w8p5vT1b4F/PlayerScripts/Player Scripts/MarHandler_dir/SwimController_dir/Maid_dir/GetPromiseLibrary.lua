-- https://lua.expert/
local ReplicatedFirst = game:GetService("ReplicatedFirst")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")
local ServerStorage = game:GetService("ServerStorage")
local t = {
	script.Parent.Parent,
	ReplicatedFirst,
	ReplicatedStorage,
	ServerScriptService,
	ServerStorage
}

local function FindFirstDescendantWithNameAndClassName(p1, p2, p3) --[[ FindFirstDescendantWithNameAndClassName | Line: 9 ]]
	for i, v in ipairs(p1:GetDescendants()) do
		if v:IsA(p3) and v.Name == p2 then
			return v
		end
	end

	return nil
end

return function() --[[ GetPromiseLibrary | Line: 19 | Upvalues: FindFirstDescendantWithNameAndClassName (copy), t (copy) ]]
	local v1 = script:FindFirstAncestorOfClass("Plugin")

	if v1 then
		local v2 = FindFirstDescendantWithNameAndClassName(v1, "Promise", "ModuleScript")

		if v2 then
			return true, require(v2)
		end

		return false
	end

	local v3 = nil

	for i, v in ipairs(t) do
		local v4 = FindFirstDescendantWithNameAndClassName(v, "Promise", "ModuleScript")

		v3 = v4

		if v4 then
			break
		end
	end

	if v3 then
		return true, require(v3)
	end

	return false
end