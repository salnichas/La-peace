-- https://lua.expert/
local GetPromiseLibrary = require(script.GetPromiseLibrary)
local Symbol = require(script.Symbol)
local v1, v2 = GetPromiseLibrary()
local v3 = Symbol("IndicesReference")
local v4 = Symbol("LinkToInstanceIndex")
local t = {
	ClassName = "Janitor",
	CurrentlyCleaning = true,
	[v3] = nil
}

t.__index = t

local t2 = {
	["function"] = true,
	RBXScriptConnection = "Disconnect"
}

function t.Is(p1) --[[ Is | Line: 42 | Upvalues: t (copy) ]]
	return if type(p1) == "table" then getmetatable(p1) == t else false
end
function t._Add(p1, p2, p3, p4) --[[ _Add | Line: 80 | Upvalues: v3 (copy), t2 (copy) ]]
	if p4 then
		p1:Remove(p4)

		local v1 = p1[v3]

		if not v1 then
			v1 = {}
			p1[v3] = v1
		end

		v1[p4] = p2
	end

	local v2 = if p3 then p3 else t2[typeof(p2)] or "Destroy"

	if type(p2) ~= "function" and not p2[v2] then
		warn(string.format("Object %s doesn\'t have method %s, are you sure you want to add it? Traceback: %s", tostring(p2), tostring(v2), debug.traceback(nil, 2)))
	end

	p1[p2] = v2

	return p2
end
function t.Add(p1, ...) --[[ Add | Line: 101 ]]
	for k, v in pairs({ ... }) do
		p1:_Add(v)
	end
end
function t.AddPromise(p1, p2) --[[ AddPromise | Line: 129 | Upvalues: v1 (copy), v2 (copy) ]]
	if not v1 then
		return p2
	end

	if not v2.is(p2) then
		error(string.format("Invalid argument #1 to \'Janitor:AddPromise\' (Promise expected, got %s (%s))", typeof(p2), (tostring(p2))))
	end

	if p2:getStatus() == v2.Status.Started then
		local v12 = newproxy(false)
		local v22 = p1:_Add(v2.new(function(p1, p22, p3) --[[ Line: 137 | Upvalues: p2 (copy) ]]
			if not p3(function() --[[ Line: 138 | Upvalues: p2 (ref) ]]
				p2:cancel()
			end) then
				p1(p2)
			end
		end), "cancel", v12)

		v22:finallyCall(p1.Remove, p1, v12)

		return v22
	end

	return p2
end
function t.Remove(p1, p2) --[[ Remove | Line: 178 | Upvalues: v3 (copy) ]]
	local v1 = p1[v3]

	if v1 then
		local v2 = v1[p2]

		if v2 then
			local v32 = p1[v2]

			if v32 then
				if v32 == true then
					v2()
				else
					local v4 = v2[v32]

					if v4 then
						v4(v2)
					end
				end

				p1[v2] = nil
			end

			v1[p2] = nil
		end
	end

	return p1
end
function t.Get(p1, p2) --[[ Get | Line: 226 | Upvalues: v3 (copy) ]]
	local v1 = p1[v3]

	if v1 then
		return v1[p2]
	end

	return nil
end

local function GetFenv(p1) --[[ GetFenv | Line: 235 | Upvalues: v3 (copy) ]]
	return function() --[[ Line: 236 | Upvalues: p1 (copy), v3 (ref) ]]
		for k2, v in pairs(p1) do
			if k2 ~= v3 then
				return k2, v
			end
		end
	end
end

function t.Cleanup(p1) --[[ Cleanup | Line: 258 | Upvalues: v3 (copy) ]]
	if p1.CurrentlyCleaning then
		return
	end

	p1.CurrentlyCleaning = nil

	local function f1() --[[ Line: 236 | Upvalues: p1 (copy), v3 (ref) ]]
		for k2, v in pairs(p1) do
			if k2 ~= v3 then
				return k2, v
			end
		end
	end

	local v2, v32 = f1()

	while v2 and v32 do
		if v32 == true then
			v2()
		else
			local v4 = v2[v32]

			if v4 then
				v4(v2)
			end
		end

		p1[v2] = nil

		local v5, v6 = f1()

		v2, v32 = v5, v6
	end

	local v7 = p1[v3]

	if v7 then
		table.clear(v7)
		p1[v3] = {}
	end

	p1.CurrentlyCleaning = false
end
function t.Destroy(p1) --[[ Destroy | Line: 296 ]]
	p1:Cleanup()
	table.clear(p1)
	setmetatable(p1, nil)
end
t.__call = t.Cleanup

local t3 = {
	Connected = true
}

t3.__index = t3
function t3.Disconnect(p1) --[[ Disconnect | Line: 317 ]]
	if not p1.Connected then
		return
	end

	p1.Connected = false
	p1.Connection:Disconnect()
end
function t3._new(p1) --[[ _new | Line: 324 | Upvalues: t3 (copy) ]]
	return setmetatable({
		Connection = p1
	}, t3)
end
function t3.__tostring(p1) --[[ __tostring | Line: 330 ]]
	return "RbxScriptConnection<" .. tostring(p1.Connected) .. ">"
end
function t.LinkToInstance(p1, p2, p3) --[[ LinkToInstance | Line: 375 | Upvalues: v4 (copy), t3 (copy) ]]
	local v1 = nil
	local v2 = p3 and newproxy(false) or v4
	local v3 = if p2.Parent == nil then true else false
	local v5 = setmetatable({}, t3)

	local function ChangedFunction(p12, p2) --[[ ChangedFunction | Line: 381 | Upvalues: v5 (copy), v3 (ref), v1 (ref), p1 (copy) ]]
		if not v5.Connected then
			return
		end

		v3 = p2 == nil

		if not v3 then
			return
		end

		task.defer(function() --[[ Line: 387 | Upvalues: v5 (ref), v1 (ref), p1 (ref), v3 (ref) ]]
			if not v5.Connected then
				return
			end

			if not v1.Connected then
				p1:Cleanup()

				return
			end

			while v3 and (v1.Connected and v5.Connected) do
				task.wait()
			end

			if not (v5.Connected and v3) then
				return
			end

			p1:Cleanup()
		end)
	end

	v1 = p2.AncestryChanged:Connect(ChangedFunction)
	v5.Connection = v1

	if v3 then
		local v6 = p2.Parent

		if v5.Connected then
			v3 = if v6 == nil then true else false

			if v3 then
				task.defer(function() --[[ Line: 387 | Upvalues: v5 (copy), v1 (ref), p1 (copy), v3 (ref) ]]
					if not v5.Connected then
						return
					end

					if not v1.Connected then
						p1:Cleanup()

						return
					end

					while v3 and (v1.Connected and v5.Connected) do
						task.wait()
					end

					if not (v5.Connected and v3) then
						return
					end

					p1:Cleanup()
				end)
			end
		end
	end

	return p1:_Add(v5, "Disconnect", v2)
end
function t.LinkToInstances(p1, ...) --[[ LinkToInstances | Line: 423 | Upvalues: t (copy) ]]
	local v1 = t.new()

	for i, v in ipairs({ ... }) do
		v1:_Add(p1:LinkToInstance(v, true), "Disconnect")
	end

	return v1
end
function t.new() --[[ new | Line: 436 | Upvalues: v3 (copy), t (copy) ]]
	return setmetatable({
		CurrentlyCleaning = false,
		[v3] = nil
	}, t)
end

return t