-- https://lua.expert/
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local SoundService = game:GetService("SoundService")
local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui")
local ClickSound = Instance.new("Sound")

ClickSound.SoundId = "rbxassetid://103866342467024"
ClickSound.Volume = 1
ClickSound.Name = "ClickSound"
ClickSound.Parent = SoundService

local function animateButton(p1) --[[ animateButton | Line: 16 | Upvalues: ClickSound (copy), TweenService (copy) ]]
	if p1:IsA("GuiButton") then
		local Size = p1.Size
		local Position = p1.Position

		p1.MouseButton1Click:Connect(function() --[[ Line: 23 | Upvalues: ClickSound (ref), TweenService (ref), p1 (copy), Size (copy), Position (copy) ]]
			ClickSound:Play()
			TweenService:Create(p1, TweenInfo.new(0), {
				Size = Size,
				Position = Position
			}):Play()

			local v1 = TweenService:Create(p1, TweenInfo.new(0.08), {
				Size = Size - UDim2.new(0, 4, 0, 4),
				Position = Position + UDim2.new(0, 2, 0, 2)
			})
			local v2 = TweenService:Create(p1, TweenInfo.new(0.08), {
				Size = Size,
				Position = Position
			})

			v1:Play()
			v1.Completed:Connect(function() --[[ Line: 42 | Upvalues: v2 (copy) ]]
				v2:Play()
			end)
		end)
	end
end

local function scanForButtons(p1) --[[ scanForButtons | Line: 49 | Upvalues: ClickSound (copy), TweenService (copy) ]]
	for i, v in ipairs(p1:GetDescendants()) do
		if v:IsA("GuiButton") and v:IsA("GuiButton") then
			local Size = v.Size
			local Position = v.Position

			v.MouseButton1Click:Connect(function() --[[ Line: 23 | Upvalues: ClickSound (ref), TweenService (ref), v (copy), Size (copy), Position (copy) ]]
				ClickSound:Play()
				TweenService:Create(v, TweenInfo.new(0), {
					Size = Size,
					Position = Position
				}):Play()

				local v1 = TweenService:Create(v, TweenInfo.new(0.08), {
					Size = Size - UDim2.new(0, 4, 0, 4),
					Position = Position + UDim2.new(0, 2, 0, 2)
				})
				local v2 = TweenService:Create(v, TweenInfo.new(0.08), {
					Size = Size,
					Position = Position
				})

				v1:Play()
				v1.Completed:Connect(function() --[[ Line: 42 | Upvalues: v2 (copy) ]]
					v2:Play()
				end)
			end)
		end
	end
end

PlayerGui.ChildAdded:Connect(scanForButtons)

for i, v in ipairs(PlayerGui:GetChildren()) do
	scanForButtons(v)
end