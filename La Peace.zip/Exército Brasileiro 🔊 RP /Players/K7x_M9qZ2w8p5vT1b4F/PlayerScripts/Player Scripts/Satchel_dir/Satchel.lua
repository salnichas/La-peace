-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local TextChatService = game:GetService("TextChatService")
local UserInputService = game:GetService("UserInputService")
local StarterGui = game:GetService("StarterGui")
local GuiService = game:GetService("GuiService")
local RunService = game:GetService("RunService")
local VRService = game:GetService("VRService")
local Players = game:GetService("Players")
local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui")
local t = {
	OpenClose = nil,
	IsOpen = false,
	StateChanged = Instance.new("BindableEvent"),
	ModuleName = "Backpack",
	KeepVRTopbarOpen = true,
	VRIsExclusive = true,
	VRClosesNonExclusive = true,
	BackpackEmpty = Instance.new("BindableEvent")
}

t.BackpackEmpty.Name = "BackpackEmpty"
t.BackpackItemAdded = Instance.new("BindableEvent")
t.BackpackItemAdded.Name = "BackpackAdded"
t.BackpackItemRemoved = Instance.new("BindableEvent")
t.BackpackItemRemoved.Name = "BackpackRemoved"

local v1 = script
local v2 = GuiService.PreferredTransparency or 1
local v3 = not v1:GetAttribute("OutlineEquipBorder") or false
local v4 = v1:GetAttribute("InsetIconPadding")
local v5 = v1:GetAttribute("BackgroundTransparency") or 0.3
local v6 = v5 * v2
local v7 = UDim.new(0, 8)
local v8 = v1:GetAttribute("BackgroundColor3") or Color3.new(25/255, 27/255, 29/255)
local v9 = v1:GetAttribute("EquipBorderColor3") or Color3.new(0/255, 162/255, 255/255)
local v10 = v1:GetAttribute("BackgroundTransparency") or 0.3
local v11 = v10 * v2
local v12 = v1:GetAttribute("EquipBorderSizePixel") or 5
local v13 = v1:GetAttribute("CornerRadius") or UDim.new(0, 8)
local v14 = Color3.new(255/255, 255/255, 255/255)
local v15 = v13 - UDim.new(0, 5) or UDim.new(0, 3)
local v16 = v1:GetAttribute("BackgroundColor3") or Color3.new(25/255, 27/255, 29/255)
local v17 = v1:GetAttribute("TextColor3") or Color3.new(255/255, 255/255, 255/255)
local v18 = v1:GetAttribute("TextStrokeTransparency") or 0.5
local v19 = v1:GetAttribute("TextStrokeColor3") or Color3.new(0/255, 0/255, 0/255)
local v20 = Color3.new(25/255, 27/255, 29/255)
local v21 = v2 * 0.2
local v22 = Color3.new(255/255, 255/255, 255/255)
local v23 = UDim.new(0, 3)
local v24 = v1:GetAttribute("FontFace") or Font.new("rbxasset://fonts/families/BuilderSans.json")
local v25 = v1:GetAttribute("TextSize") or 16
local Backspace = Enum.KeyCode.Backspace.Value
local Zero = Enum.KeyCode.Zero.Value
local t2 = {
	[Enum.UserInputType.MouseButton1] = true,
	[Enum.UserInputType.MouseButton2] = true,
	[Enum.UserInputType.MouseButton3] = true,
	[Enum.UserInputType.MouseMovement] = true,
	[Enum.UserInputType.MouseWheel] = true
}
local t3 = {
	[Enum.UserInputType.Gamepad1] = true,
	[Enum.UserInputType.Gamepad2] = true,
	[Enum.UserInputType.Gamepad3] = true,
	[Enum.UserInputType.Gamepad4] = true,
	[Enum.UserInputType.Gamepad5] = true,
	[Enum.UserInputType.Gamepad6] = true,
	[Enum.UserInputType.Gamepad7] = true,
	[Enum.UserInputType.Gamepad8] = true
}
local v26 = true
local v27 = require(script.Packages:WaitForChild("topbarplus")).new():setName("Inventory"):setImage("rbxasset://textures/ui/TopBar/inventoryOn.png", "Selected"):setImage("rbxasset://textures/ui/TopBar/inventoryOff.png", "Deselected"):setImageScale(1):setCaption("Inventory"):bindToggleKey(Enum.KeyCode.Backquote):autoDeselect(false):setOrder(-1)

v27.toggled:Connect(function() --[[ Line: 169 | Upvalues: GuiService (copy), t (copy) ]]
	if GuiService.MenuIsOpen then
		return
	end

	t.OpenClose()
end)

local BackpackGui = Instance.new("ScreenGui")

BackpackGui.DisplayOrder = 120
BackpackGui.IgnoreGuiInset = true
BackpackGui.ResetOnSpawn = false
BackpackGui.Name = "BackpackGui"
BackpackGui.Parent = PlayerGui

local v28 = GuiService:IsTenFootInterface()
local v29

if v28 then
	v25 = 24
	v29 = 100
else
	v29 = 60
end

local v30 = false
local v31 = UserInputService.TouchEnabled and workspace.CurrentCamera.ViewportSize.X < 1024
local LocalPlayer = Players.LocalPlayer
local Backpack = nil
local Hotbar = nil
local Inventory = nil
local VRInventorySelector = nil
local ScrollingFrame = nil
local UIGridFrame = nil
local v32 = nil
local v33 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
local Humanoid = v33:WaitForChild("Humanoid")
local Backpack2 = LocalPlayer:WaitForChild("Backpack")
local t4 = {}
local v34 = nil
local t5 = {}
local t6 = {}
local t7 = {}
local v35 = 0
local v36 = nil
local v37 = false
local v38 = false
local v39 = false
local v40 = false
local t8 = {}
local v41 = false
local VREnabled = VRService.VREnabled
local v42 = if VREnabled then 6 elseif v31 then 6 else 10
local v43 = if VREnabled then 3 elseif v31 then 2 else 4
local v44 = nil

local function EvaluateBackpackPanelVisibility(p1) --[[ EvaluateBackpackPanelVisibility | Line: 232 | Upvalues: v27 (copy), v26 (ref), VRService (copy) ]]
	return if p1 then v27.enabled and (v26 and VRService.VREnabled) else p1
end

local function ShowVRBackpackPopup() --[[ ShowVRBackpackPopup | Line: 236 ]] end

local function FindLowestEmpty() --[[ FindLowestEmpty | Line: 242 | Upvalues: v42 (copy), t4 (copy) ]]
	for i = 1, v42 do
		local v1 = t4[i]

		if not v1.Tool then
			return v1
		end
	end

	return nil
end

function t.IsInventoryEmpty() --[[ isInventoryEmpty | Line: 252 | Upvalues: v42 (copy), t4 (copy) ]]
	for i = v42 + 1, #t4 do
		local v1 = t4[i]

		if v1 and v1.Tool then
			return false
		end
	end

	return true
end

local function UseGazeSelection() --[[ UseGazeSelection | Line: 264 ]]
	return false
end

local function AdjustHotbarFrames() --[[ AdjustHotbarFrames | Line: 268 | Upvalues: Inventory (ref), v42 (copy), v35 (ref), t4 (copy) ]]
	local Visible = Inventory.Visible
	local v1 = Inventory.Visible and v42 or v35
	local count = 0

	for i = 1, v42 do
		local v2 = t4[i]

		if v2.Tool or Visible then
			count = count + 1
			v2:Readjust(count, v1)
			v2.Frame.Visible = true

			continue
		end

		v2.Frame.Visible = false
	end
end

local function UpdateScrollingFrameCanvasSize() --[[ UpdateScrollingFrameCanvasSize | Line: 285 | Upvalues: ScrollingFrame (ref), v29 (ref), UIGridFrame (ref) ]]
	local v2 = math.floor(ScrollingFrame.AbsoluteSize.X / (v29 + 5))

	ScrollingFrame.CanvasSize = UDim2.new(0, 0, 0, math.ceil((#UIGridFrame:GetChildren() - 1) / v2) * (v29 + 5) + 5)
end

local function AdjustInventoryFrames() --[[ AdjustInventoryFrames | Line: 292 | Upvalues: v42 (copy), t4 (copy), UpdateScrollingFrameCanvasSize (copy) ]]
	for i = v42 + 1, #t4 do
		local v1 = t4[i]

		v1.Frame.LayoutOrder = v1.Index
		v1.Frame.Visible = v1.Tool ~= nil
	end

	UpdateScrollingFrameCanvasSize()
end

local function UpdateBackpackLayout() --[[ UpdateBackpackLayout | Line: 301 | Upvalues: Hotbar (ref), v42 (copy), v29 (ref), Inventory (ref), v43 (copy), VREnabled (copy), ScrollingFrame (ref), AdjustHotbarFrames (copy), AdjustInventoryFrames (copy) ]]
	Hotbar.Size = UDim2.new(0, v42 * (v29 + 5) + 5, 0, v29 + 5 + 5)
	Hotbar.Position = UDim2.new(0.5, -Hotbar.Size.X.Offset / 2, 1, -Hotbar.Size.Y.Offset)
	Inventory.Size = UDim2.new(0, Hotbar.Size.X.Offset, 0, Hotbar.Size.Y.Offset * v43 + 40 + (if VREnabled then 80 else 0))
	Inventory.Position = UDim2.new(0.5, -Inventory.Size.X.Offset / 2, 1, Hotbar.Position.Y.Offset - Inventory.Size.Y.Offset)
	ScrollingFrame.Size = UDim2.new(1, ScrollingFrame.ScrollBarThickness + 1, 1, -40 - (if VREnabled then 80 else 0))
	ScrollingFrame.Position = UDim2.new(0, 0, 0, 40 + (if VREnabled then 40 else 0))
	AdjustHotbarFrames()
	AdjustInventoryFrames()
end

local function Clamp(p1, p2, p3) --[[ Clamp | Line: 335 ]]
	return math.min(p2, (math.max(p1, p3)))
end

local function CheckBounds(p1, p2, p3) --[[ CheckBounds | Line: 339 ]]
	local AbsolutePosition = p1.AbsolutePosition
	local AbsoluteSize = p1.AbsoluteSize

	return if AbsolutePosition.X < p2 and (p2 <= AbsolutePosition.X + AbsoluteSize.X and AbsolutePosition.Y < p3) then p3 <= AbsolutePosition.Y + AbsoluteSize.Y else false
end

local function GetOffset(p1, p2) --[[ GetOffset | Line: 345 ]]
	return (p1.AbsolutePosition + p1.AbsoluteSize / 2 - p2).Magnitude
end

local function DisableActiveHopper() --[[ DisableActiveHopper | Line: 350 | Upvalues: v36 (ref), t5 (copy) ]]
	v36:ToggleSelect()
	t5[v36]:UpdateEquipView()
	v36 = nil
end

local function UnequipAllTools() --[[ UnequipAllTools | Line: 356 | Upvalues: Humanoid (ref), v36 (ref), t5 (copy) ]]
	if not Humanoid then
		return
	end

	Humanoid:UnequipTools()

	if not v36 then
		return
	end

	v36:ToggleSelect()
	t5[v36]:UpdateEquipView()
	v36 = nil
end

local function EquipNewTool(p1) --[[ EquipNewTool | Line: 365 | Upvalues: Humanoid (ref), v36 (ref), t5 (copy) ]]
	if not Humanoid then
		Humanoid:EquipTool(p1)

		return
	end

	Humanoid:UnequipTools()

	if not v36 then
		Humanoid:EquipTool(p1)

		return
	end

	v36:ToggleSelect()
	t5[v36]:UpdateEquipView()
	v36 = nil
	Humanoid:EquipTool(p1)
end

local function IsEquipped(p1) --[[ IsEquipped | Line: 371 | Upvalues: v33 (ref) ]]
	return if p1 then p1.Parent == v33 else p1
end

local function v45(p1, p2) --[[ MakeSlot | Line: 376 | Upvalues: t4 (copy), v11 (ref), Hotbar (ref), v29 (ref), v42 (copy), Inventory (ref), UserInputService (copy), v35 (ref), v38 (ref), v30 (ref), ContextActionService (copy), v32 (ref), t5 (copy), v34 (ref), v33 (ref), v44 (ref), v12 (copy), v9 (copy), v3 (copy), UpdateScrollingFrameCanvasSize (copy), Humanoid (ref), v36 (ref), Backpack2 (ref), v8 (copy), v14 (copy), v13 (copy), v4 (copy), v17 (copy), v18 (copy), v19 (copy), v24 (copy), v25 (ref), v16 (copy), v15 (copy), v45 (copy), UIGridFrame (ref), v40 (ref), t6 (copy), Zero (copy), t7 (copy), v27 (copy), ScrollingFrame (ref) ]]
	local v1 = if p2 then p2 else #t4 + 1
	local t = {
		Tool = nil,
		Index = v1,
		Frame = nil
	}
	local v2 = nil
	local v37 = nil
	local Icon = nil
	local ToolName = nil
	local v43 = nil
	local v5 = nil
	local ToolTip = nil
	local Number = nil

	local function UpdateSlotFading() --[[ UpdateSlotFading | Line: 401 | Upvalues: v2 (ref), v11 (ref) ]]
		v2.SelectionImageObject = nil
		v2.BackgroundTransparency = if v2.Draggable then 0 else v11
	end

	function t.Readjust(p1, p2, p3) --[[ Readjust | Line: 407 | Upvalues: Hotbar (ref), v29 (ref), v2 (ref) ]]
		v2.Position = UDim2.new(0, Hotbar.Size.X.Offset / 2 - v29 / 2 + (v29 + 5) * (p2 - (p3 / 2 + 0.5)), 0, 5)
	end
	function t.Fill(p1, p2) --[[ Fill | Line: 417 | Upvalues: Icon (ref), ToolName (ref), ToolTip (ref), v43 (ref), v42 (ref), Inventory (ref), UserInputService (ref), v2 (ref), v35 (ref), v38 (ref), v30 (ref), ContextActionService (ref), v32 (ref), t5 (ref), v34 (ref), t4 (ref) ]]
		if not p2 then
			return p1:Clear()
		end

		p1.Tool = p2

		local function assignToolData() --[[ assignToolData | Line: 426 | Upvalues: p2 (copy), Icon (ref), ToolName (ref), ToolTip (ref) ]]
			local TextureId = p2.TextureId

			Icon.Image = TextureId

			if TextureId == "" then
				ToolName.Visible = true
			else
				ToolName.Visible = false
			end

			ToolName.Text = p2.Name

			if not (ToolTip and p2:IsA("Tool")) then
				return
			end

			ToolTip.Text = p2.ToolTip
			ToolTip.Size = UDim2.new(0, 0, 0, 16)
			ToolTip.Position = UDim2.new(0.5, 0, 0, -5)
		end

		assignToolData()

		if v43 then
			v43:Disconnect()
			v43 = nil
		end

		v43 = p2.Changed:Connect(function(p1) --[[ Line: 455 | Upvalues: assignToolData (copy) ]]
			if p1 ~= "TextureId" and (p1 ~= "Name" and p1 ~= "ToolTip") then
				return
			end

			assignToolData()
		end)

		local v1 = p1.Index <= v42

		if (not v1 or Inventory.Visible) and not UserInputService.VREnabled then
			v2.Draggable = true
		end

		p1:UpdateEquipView()

		if v1 then
			v35 = v35 + 1

			if v38 and (v35 >= 1 and not v30) then
				v30 = true
				ContextActionService:BindAction("BackpackHotbarEquip", v32, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
			end
		end

		t5[p2] = p1

		local v22

		for i = 1, v42 do
			local v3 = t4[i]

			if not v3.Tool then
				v22 = v3
				v34 = v3

				return
			end
		end

		v22 = nil
		v34 = v22
	end
	function t.Clear(p1) --[[ Clear | Line: 491 | Upvalues: v43 (ref), Icon (ref), ToolName (ref), ToolTip (ref), v2 (ref), v42 (ref), v35 (ref), v30 (ref), ContextActionService (ref), t5 (ref), v34 (ref), t4 (ref) ]]
		if not p1.Tool then
			return
		end

		if v43 then
			v43:Disconnect()
			v43 = nil
		end

		Icon.Image = ""
		ToolName.Text = ""

		if ToolTip then
			ToolTip.Text = ""
			ToolTip.Visible = false
		end

		v2.Draggable = false
		p1:UpdateEquipView(true)

		if p1.Index <= v42 then
			v35 = v35 - 1

			if v35 < 1 then
				v30 = false
				ContextActionService:UnbindAction("BackpackHotbarEquip")
			end
		end

		t5[p1.Tool] = nil
		p1.Tool = nil

		local v1

		for i = 1, v42 do
			local v22 = t4[i]

			if not v22.Tool then
				v1 = v22
				v34 = v22

				return
			end
		end

		v1 = nil
		v34 = v1
	end
	function t.UpdateEquipView(p1, p2) --[[ UpdateEquipView | Line: 526 | Upvalues: v33 (ref), v44 (ref), t (copy), v5 (ref), v12 (ref), v9 (ref), v3 (ref), Icon (ref), v2 (ref), v11 (ref) ]]
		if p2 then
			if v5 then
				v5.Parent = nil
			end
		else
			local Tool = p1.Tool

			if if Tool then Tool.Parent == v33 else Tool then
				v44 = t

				if not v5 then
					v5 = Instance.new("UIStroke")
					v5.Name = "Border"
					v5.Thickness = v12
					v5.Color = v9
					v5.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
				end

				if v3 == true then
					v5.Parent = Icon
				else
					v5.Parent = v2
				end
			elseif v5 then
				v5.Parent = nil
			end
		end

		v2.SelectionImageObject = nil
		v2.BackgroundTransparency = if v2.Draggable then 0 else v11
	end
	function t.IsEquipped(p1) --[[ IsEquipped | Line: 550 | Upvalues: v33 (ref) ]]
		local Tool = p1.Tool

		return if Tool then Tool.Parent == v33 else Tool
	end
	function t.Delete(p1) --[[ Delete | Line: 554 | Upvalues: v2 (ref), t4 (ref), UpdateScrollingFrameCanvasSize (ref) ]]
		v2:Destroy()
		table.remove(t4, p1.Index)

		for i = p1.Index, #t4 do
			t4[i]:SlideBack()
		end

		UpdateScrollingFrameCanvasSize()
	end
	function t.Swap(p1, p2) --[[ Swap | Line: 567 ]]
		local Tool = p1.Tool
		local Tool2 = p2.Tool

		p1:Clear()

		if Tool2 then
			p2:Clear()
			p1:Fill(Tool2)
		end

		if Tool then
			p2:Fill(Tool)
		else
			p2:Clear()
		end
	end
	function t.SlideBack(p1) --[[ SlideBack | Line: 581 | Upvalues: v2 (ref) ]]
		p1.Index = p1.Index - 1
		v2.Name = p1.Index
		v2.LayoutOrder = p1.Index
	end
	function t.TurnNumber(p1, p2) --[[ TurnNumber | Line: 587 | Upvalues: Number (ref) ]]
		if not Number then
			return
		end

		Number.Visible = p2
	end
	function t.SetClickability(p1, p2) --[[ SetClickability | Line: 593 | Upvalues: UserInputService (ref), v2 (ref), v11 (ref) ]]
		if not p1.Tool then
			return
		end

		if UserInputService.VREnabled then
			v2.Draggable = false
		else
			v2.Draggable = not p2
		end

		v2.SelectionImageObject = nil
		v2.BackgroundTransparency = if v2.Draggable then 0 else v11
	end
	function t.CheckTerms(p1, p2) --[[ CheckTerms | Line: 604 | Upvalues: ToolName (ref), ToolTip (ref) ]]
		local sum = 0

		local function checkEm(p1, p2) --[[ checkEm | Line: 606 | Upvalues: sum (ref) ]]
			local _, v1 = p1:lower():gsub(p2, "")

			sum = sum + v1
		end

		local Tool = p1.Tool

		if Tool then
			for k in pairs(p2) do
				local _, v1 = ToolName.Text:lower():gsub(k, "")

				sum = sum + v1

				if Tool:IsA("Tool") then
					local _2, v3 = (if ToolTip then ToolTip.Text or "" else ""):lower():gsub(k, "")

					sum = sum + v3
				end
			end
		end

		return sum
	end
	function t.Select(p1) --[[ Select | Line: 624 | Upvalues: t (copy), v33 (ref), Humanoid (ref), v36 (ref), t5 (ref), Backpack2 (ref) ]]
		local Tool = t.Tool

		if not Tool then
			return
		end

		if if Tool then if Tool.Parent == v33 then true else false else Tool then
			if not Humanoid then
				return
			end

			Humanoid:UnequipTools()

			if v36 then
				v36:ToggleSelect()
				t5[v36]:UpdateEquipView()
				v36 = nil
			end
		else
			if Tool.Parent ~= Backpack2 then
				return
			end

			if Humanoid then
				Humanoid:UnequipTools()

				if v36 then
					v36:ToggleSelect()
					t5[v36]:UpdateEquipView()
					v36 = nil
				end
			end

			Humanoid:EquipTool(Tool)
		end
	end
	v2 = Instance.new("TextButton")
	v2.Name = tostring(v1)
	v2.BackgroundColor3 = v8
	v2.BorderColor3 = v14
	v2.Text = ""
	v2.BorderSizePixel = 0
	v2.Size = UDim2.new(0, v29, 0, v29)
	v2.Active = true
	v2.Draggable = false
	v2.BackgroundTransparency = v11
	v2.MouseButton1Click:Connect(function() --[[ Line: 647 | Upvalues: t (copy) ]]
		changeSlot(t)
	end)

	local Corner = Instance.new("UICorner")

	Corner.Name = "Corner"
	Corner.CornerRadius = v13
	Corner.Parent = v2
	t.Frame = v2

	local SelectionObjectClipper = Instance.new("Frame")

	SelectionObjectClipper.Name = "SelectionObjectClipper"
	SelectionObjectClipper.BackgroundTransparency = 1
	SelectionObjectClipper.Visible = false
	SelectionObjectClipper.Parent = v2

	local Selector = Instance.new("ImageLabel")

	Selector.Name = "Selector"
	Selector.BackgroundTransparency = 1
	Selector.Size = UDim2.new(1, 0, 1, 0)
	Selector.Image = "rbxasset://textures/ui/Keyboard/key_selection_9slice.png"
	Selector.ScaleType = Enum.ScaleType.Slice
	Selector.SliceCenter = Rect.new(12, 12, 52, 52)
	Selector.Parent = SelectionObjectClipper
	Icon = Instance.new("ImageLabel")
	Icon.BackgroundTransparency = 1
	Icon.Name = "Icon"
	Icon.Size = UDim2.new(1, 0, 1, 0)
	Icon.Position = UDim2.new(0.5, 0, 0.5, 0)
	Icon.AnchorPoint = Vector2.new(0.5, 0.5)

	if v4 == true then
		Icon.Size = UDim2.new(1, -v12 * 2, 1, -v12 * 2)
	else
		Icon.Size = UDim2.new(1, 0, 1, 0)
	end

	Icon.Parent = v2

	local Corner2 = Instance.new("UICorner")

	Corner2.Name = "Corner"

	if v4 == true then
		Corner2.CornerRadius = v13 - UDim.new(0, v12)
	else
		Corner2.CornerRadius = v13
	end

	Corner2.Parent = Icon
	ToolName = Instance.new("TextLabel")
	ToolName.BackgroundTransparency = 1
	ToolName.Name = "ToolName"
	ToolName.Text = ""
	ToolName.TextColor3 = v17
	ToolName.TextStrokeTransparency = v18
	ToolName.TextStrokeColor3 = v19
	ToolName.FontFace = Font.new(v24.Family, Enum.FontWeight.Medium, Enum.FontStyle.Normal)
	ToolName.TextSize = v25
	ToolName.Size = UDim2.new(1, -v12 * 2, 1, -v12 * 2)
	ToolName.Position = UDim2.new(0.5, 0, 0.5, 0)
	ToolName.AnchorPoint = Vector2.new(0.5, 0.5)
	ToolName.TextWrapped = true
	ToolName.TextTruncate = Enum.TextTruncate.AtEnd
	ToolName.Parent = v2
	t.Frame.LayoutOrder = t.Index

	if v1 <= v42 then
		ToolTip = Instance.new("TextLabel")
		ToolTip.Name = "ToolTip"
		ToolTip.Text = ""
		ToolTip.Size = UDim2.new(1, 0, 1, 0)
		ToolTip.TextColor3 = v17
		ToolTip.TextStrokeTransparency = v18
		ToolTip.TextStrokeColor3 = v19
		ToolTip.FontFace = Font.new(v24.Family, Enum.FontWeight.Medium, Enum.FontStyle.Normal)
		ToolTip.TextSize = v25
		ToolTip.ZIndex = 2
		ToolTip.TextWrapped = false
		ToolTip.TextYAlignment = Enum.TextYAlignment.Center
		ToolTip.BackgroundColor3 = v16
		ToolTip.BackgroundTransparency = v11
		ToolTip.AnchorPoint = Vector2.new(0.5, 1)
		ToolTip.BorderSizePixel = 0
		ToolTip.Visible = false
		ToolTip.AutomaticSize = Enum.AutomaticSize.X
		ToolTip.Parent = v2

		local Corner3 = Instance.new("UICorner")

		Corner3.Name = "Corner"
		Corner3.CornerRadius = v15
		Corner3.Parent = ToolTip

		local UIPadding = Instance.new("UIPadding")

		UIPadding.PaddingLeft = UDim.new(0, 4)
		UIPadding.PaddingRight = UDim.new(0, 4)
		UIPadding.PaddingTop = UDim.new(0, 4)
		UIPadding.PaddingBottom = UDim.new(0, 4)
		UIPadding.Parent = ToolTip
		v2.MouseEnter:Connect(function() --[[ Line: 746 | Upvalues: ToolTip (ref) ]]
			if ToolTip.Text == "" then
				return
			end

			ToolTip.Visible = true
		end)
		v2.MouseLeave:Connect(function() --[[ Line: 751 | Upvalues: ToolTip (ref) ]]
			ToolTip.Visible = false
		end)
		function t.MoveToInventory(p1) --[[ MoveToInventory | Line: 755 | Upvalues: t (copy), v42 (ref), v45 (ref), UIGridFrame (ref), v33 (ref), Humanoid (ref), v36 (ref), t5 (ref), v40 (ref), Inventory (ref) ]]
			if not (t.Index <= v42) then
				return
			end

			local Tool = t.Tool

			p1:Clear()

			local v1 = v45(UIGridFrame)

			v1:Fill(Tool)

			if (if Tool then Tool.Parent == v33 else Tool) and Humanoid then
				Humanoid:UnequipTools()

				if v36 then
					v36:ToggleSelect()
					t5[v36]:UpdateEquipView()
					v36 = nil
				end
			end

			if not v40 then
				return
			end

			v1.Frame.Visible = false
			v1.Parent = Inventory
		end

		if v1 < 10 or v1 == v42 then
			local v6 = v1 < 10 and v1 or 0

			Number = Instance.new("TextLabel")
			Number.BackgroundTransparency = 1
			Number.Name = "Number"
			Number.TextColor3 = v17
			Number.TextStrokeTransparency = v18
			Number.TextStrokeColor3 = v19
			Number.TextSize = v25
			Number.Text = tostring(v6)
			Number.FontFace = Font.new(v24.Family, Enum.FontWeight.Heavy, Enum.FontStyle.Normal)
			Number.Size = UDim2.new(0.4, 0, 0.4, 0)
			Number.Visible = false
			Number.Parent = v2
			t6[Zero + v6] = t.Select
		end
	end

	local Position = v2.Position
	local v7 = 0
	local v82 = nil

	v2.DragBegin:Connect(function(p1) --[[ Line: 796 | Upvalues: t7 (ref), v2 (ref), Position (ref), v27 (ref), Icon (ref), ToolName (ref), Number (ref), v82 (ref), UIGridFrame (ref), Inventory (ref), v37 (ref) ]]
		t7[v2] = true
		Position = p1
		v2.BorderSizePixel = 2
		v27:lock()
		v2.ZIndex = 2
		Icon.ZIndex = 2
		ToolName.ZIndex = 2
		v2.Parent.ZIndex = 2

		if Number then
			Number.ZIndex = 2
		end

		v82 = v2.Parent

		if v82 ~= UIGridFrame then
			return
		end

		local v1 = UDim2.new(0, v2.AbsolutePosition.X - Inventory.AbsolutePosition.X, 0, v2.AbsolutePosition.Y - Inventory.AbsolutePosition.Y)

		v2.Parent = Inventory
		v2.Position = v1
		v37 = Instance.new("Frame")
		v37.Name = "FakeSlot"
		v37.LayoutOrder = v2.LayoutOrder
		v37.Size = v2.Size
		v37.BackgroundTransparency = 1
		v37.Parent = UIGridFrame
	end)
	v2.DragStopped:Connect(function(p1, p2) --[[ Line: 839 | Upvalues: v37 (ref), v2 (ref), Position (ref), v82 (ref), v27 (ref), Icon (ref), ToolName (ref), Number (ref), t7 (ref), t (copy), Inventory (ref), v42 (ref), v7 (ref), v34 (ref), Hotbar (ref), t4 (ref), v33 (ref), Humanoid (ref), v36 (ref), t5 (ref), v40 (ref) ]]
		if v37 then
			v37:Destroy()
		end

		local v1 = os.clock()

		v2.Position = Position
		v2.Parent = v82
		v2.BorderSizePixel = 0
		v27:unlock()
		v2.ZIndex = 1
		Icon.ZIndex = 1
		ToolName.ZIndex = 1
		v82.ZIndex = 1

		if Number then
			Number.ZIndex = 1
		end

		t7[v2] = nil

		if not t.Tool then
			return
		end

		local v22 = Inventory
		local AbsolutePosition = v22.AbsolutePosition
		local AbsoluteSize = v22.AbsoluteSize

		if if AbsolutePosition.X < p1 and (p1 <= AbsolutePosition.X + AbsoluteSize.X and AbsolutePosition.Y < p2) then if p2 <= AbsolutePosition.Y + AbsoluteSize.Y then true else false else false then
			if t.Index <= v42 then
				t:MoveToInventory()
			end

			if v42 < t.Index and v1 - v7 < 0.5 then
				if v34 then
					t:Clear()
					v34:Fill(t.Tool)
					t:Delete()
				end

				v1 = 0
			end
		else
			local v4 = Hotbar
			local AbsolutePosition2 = v4.AbsolutePosition
			local AbsoluteSize2 = v4.AbsoluteSize

			if if AbsolutePosition2.X < p1 and (p1 <= AbsolutePosition2.X + AbsoluteSize2.X and AbsolutePosition2.Y < p2) then if p2 <= AbsolutePosition2.Y + AbsoluteSize2.Y then true else false else false then
				local t2 = { (1 / 0), nil }

				for i = 1, v42 do
					local v6 = t4[i]
					local Frame = v6.Frame
					local Magnitude = (Frame.AbsolutePosition + Frame.AbsoluteSize / 2 - Vector2.new(p1, p2)).Magnitude

					if Magnitude < t2[1] then
						t2 = { Magnitude, v6 }
					end
				end

				local v8 = t2[2]

				if v8 ~= t then
					t:Swap(v8)

					if v42 < t.Index then
						local Tool = t.Tool

						if Tool then
							if (if Tool then Tool.Parent == v33 else Tool) and Humanoid then
								Humanoid:UnequipTools()

								if v36 then
									v36:ToggleSelect()
									t5[v36]:UpdateEquipView()
									v36 = nil
								end
							end

							if v40 then
								t.Frame.Visible = false
								t.Frame.Parent = Inventory
							end
						else
							t:Delete()
						end
					end
				end
			elseif t.Index <= v42 then
				t:MoveToInventory()
			end
		end

		v7 = v1
	end)
	v2.Parent = p1
	t4[v1] = t

	if not (v42 < v1) then
		return t
	end

	UpdateScrollingFrameCanvasSize()

	if not Inventory.Visible or v40 then
		return t
	end

	ScrollingFrame.CanvasPosition = Vector2.new(0, (math.max(0, ScrollingFrame.CanvasSize.Y.Offset - ScrollingFrame.AbsoluteSize.Y)))

	return t
end

local function OnChildAdded(p1) --[[ OnChildAdded | Line: 949 | Upvalues: v33 (ref), Humanoid (ref), v36 (ref), t5 (copy), v37 (ref), LocalPlayer (ref), v34 (ref), v45 (copy), UIGridFrame (ref), t4 (copy), Backpack2 (ref), AdjustHotbarFrames (copy), v42 (copy), Inventory (ref), t (copy) ]]
	if p1:IsA("Tool") or p1:IsA("HopperBin") then
		local isParent = p1.Parent == v33

		if v36 and p1.Parent == v33 then
			v36:ToggleSelect()
			t5[v36]:UpdateEquipView()
			v36 = nil
		end

		if not v37 and (p1.Parent == v33 and not t5[p1]) then
			local StarterGear = LocalPlayer:FindFirstChild("StarterGear")

			if StarterGear and StarterGear:FindFirstChild(p1.Name) then
				v37 = true

				for i = (v34 or v45(UIGridFrame)).Index, 1, -1 do
					local v2 = t4[i]
					local v3 = i - 1

					if v3 > 0 then
						t4[v3]:Swap(v2)

						continue
					end

					v2:Fill(p1)
				end

				for k, v in pairs(v33:GetChildren()) do
					if v:IsA("Tool") and v ~= p1 then
						v.Parent = Backpack2
					end
				end

				AdjustHotbarFrames()

				return
			end
		end

		local v4 = t5[p1]

		if v4 then
			v4:UpdateEquipView()
		else
			local v5 = v34 or v45(UIGridFrame)

			v5:Fill(p1)

			if v5.Index <= v42 and not Inventory.Visible then
				AdjustHotbarFrames()
			end

			if not (p1:IsA("HopperBin") and p1.Active) then
				t.BackpackItemAdded:Fire()

				return
			end

			if Humanoid then
				Humanoid:UnequipTools()

				if v36 then
					v36:ToggleSelect()
					t5[v36]:UpdateEquipView()
					v36 = nil
				end
			end

			v36 = p1
		end

		t.BackpackItemAdded:Fire()
	else
		if not p1:IsA("Humanoid") or p1.Parent ~= v33 then
			return
		end

		Humanoid = p1
	end
end

local function OnChildRemoved(p1) --[[ OnChildRemoved | Line: 1016 | Upvalues: v33 (ref), Backpack2 (ref), t5 (copy), v42 (copy), Inventory (ref), AdjustHotbarFrames (copy), v36 (ref), t (copy), t4 (copy) ]]
	if not (p1:IsA("Tool") or p1:IsA("HopperBin")) then
		return
	end

	local v1 = p1.Parent

	if v1 == v33 or v1 == Backpack2 then
		return
	end

	local v2 = t5[p1]

	if v2 then
		v2:Clear()

		if v42 < v2.Index then
			v2:Delete()
		elseif not Inventory.Visible then
			AdjustHotbarFrames()
		end
	end

	if p1 == v36 then
		v36 = nil
	end

	t.BackpackItemRemoved:Fire()

	local v3

	for i = v42 + 1, #t4 do
		local v4 = t4[i]

		if v4 and v4.Tool then
			v3 = false

			if not v3 then
				return
			end

			t.BackpackEmpty:Fire()

			return
		end
	end

	v3 = true

	if not v3 then
		return
	end

	t.BackpackEmpty:Fire()
end

local function OnCharacterAdded(p1) --[[ OnCharacterAdded | Line: 1050 | Upvalues: t4 (copy), v42 (copy), v36 (ref), t8 (ref), v33 (ref), OnChildRemoved (copy), OnChildAdded (copy), Backpack2 (ref), LocalPlayer (ref), AdjustHotbarFrames (copy) ]]
	for i = #t4, 1, -1 do
		local v1 = t4[i]

		if v1.Tool then
			v1:Clear()
		end

		if v42 < i then
			v1:Delete()
		end
	end

	v36 = nil

	for k, v in pairs(t8) do
		v:Disconnect()
	end

	t8 = {}
	v33 = p1
	table.insert(t8, p1.ChildRemoved:Connect(OnChildRemoved))
	table.insert(t8, p1.ChildAdded:Connect(OnChildAdded))

	for k, v in pairs(p1:GetChildren()) do
		OnChildAdded(v)
	end

	Backpack2 = LocalPlayer:WaitForChild("Backpack")
	table.insert(t8, Backpack2.ChildRemoved:Connect(OnChildRemoved))
	table.insert(t8, Backpack2.ChildAdded:Connect(OnChildAdded))

	for k, v in pairs(Backpack2:GetChildren()) do
		OnChildAdded(v)
	end

	AdjustHotbarFrames()
end

local function OnInputBegan(p1, p2) --[[ OnInputBegan | Line: 1089 | Upvalues: TextChatService (copy), v39 (ref), v38 (ref), Backspace (copy), t6 (copy), Inventory (ref), v27 (copy) ]]
	local ChatInputBarConfiguration = TextChatService:FindFirstChildOfClass("ChatInputBarConfiguration")

	if p1.UserInputType == Enum.UserInputType.Keyboard and (not v39 and (not ChatInputBarConfiguration.IsFocused and (v38 or p1.KeyCode.Value == Backspace))) then
		local v1 = t6[p1.KeyCode.Value]

		if v1 then
			v1(p2)
		end
	end

	local UserInputType = p1.UserInputType

	if p2 or UserInputType ~= Enum.UserInputType.MouseButton1 and UserInputType ~= Enum.UserInputType.Touch or not Inventory.Visible then
		return
	end

	v27:deselect()
end

local function OnUISChanged() --[[ OnUISChanged | Line: 1115 | Upvalues: UserInputService (copy), v42 (copy), t4 (copy), t2 (copy), t3 (copy) ]]
	if UserInputService:GetLastInputType() == Enum.UserInputType.Touch then
		for i = 1, v42 do
			t4[i]:TurnNumber(false)
		end
	elseif UserInputService:GetLastInputType() == Enum.UserInputType.Keyboard then
		for j = 1, v42 do
			t4[j]:TurnNumber(true)
		end
	else
		for k, v in pairs(t2) do
			if UserInputService:GetLastInputType() == v then
				for k2 = 1, v42 do
					t4[k2]:TurnNumber(true)
				end

				return
			end
		end

		for k, v in pairs(t3) do
			if UserInputService:GetLastInputType() == v then
				for n = 1, v42 do
					t4[n]:TurnNumber(false)
				end

				return
			end
		end
	end
end

local v46 = nil
local v47 = nil

local function f48() --[[ Line: 1156 ]] end

function unbindAllGamepadEquipActions() --[[ unbindAllGamepadEquipActions | Line: 1159 | Upvalues: ContextActionService (copy) ]]
	ContextActionService:UnbindAction("BackpackHasGamepadFocus")
	ContextActionService:UnbindAction("BackpackCloseInventory")
end
v32 = function(p1, p2, p3) --[[ Line: 1235 | Upvalues: v46 (ref), v47 (ref), Humanoid (ref), v36 (ref), t5 (copy), v42 (copy), t4 (copy), v44 (ref) ]]
	if p2 ~= Enum.UserInputState.Begin then
		return
	end

	if v46 then
		if (v46.KeyCode ~= Enum.KeyCode.ButtonR1 or p3.KeyCode ~= Enum.KeyCode.ButtonL1) and (v46.KeyCode ~= Enum.KeyCode.ButtonL1 or p3.KeyCode ~= Enum.KeyCode.ButtonR1) then
			v46 = p3
			v47 = os.clock()
			task.delay(0.06, function() --[[ Line: 1263 | Upvalues: v46 (ref), p3 (copy), v42 (ref), t4 (ref), Humanoid (ref), v36 (ref), t5 (ref), v44 (ref) ]]
				if v46 ~= p3 then
					return
				end

				local v1 = if p3.KeyCode == Enum.KeyCode.ButtonL1 then -1 else 1

				for i = 1, v42 do
					if t4[i]:IsEquipped() then
						local sum2 = v1 + i
						local v2 = false

						if v42 < sum2 then
							sum2 = 1
							v2 = true
						elseif sum2 < 1 then
							sum2 = v42
							v2 = true
						end

						local v3 = sum2

						while not t4[sum2].Tool do
							sum2 = sum2 + v1

							if sum2 == v3 then
								return
							end

							if v42 < sum2 then
								sum2 = 1
								v2 = true
							elseif sum2 < 1 then
								sum2 = v42
								v2 = true
							else
								continue
							end
						end

						if not v2 then
							t4[sum2]:Select()

							return
						end

						if not Humanoid then
							v44 = nil

							return
						end

						Humanoid:UnequipTools()

						if not v36 then
							v44 = nil

							return
						end

						v36:ToggleSelect()
						t5[v36]:UpdateEquipView()
						v36 = nil
						v44 = nil

						return
					end
				end

				if v44 and v44.Tool then
					v44:Select()

					return
				end

				for j = if v1 == -1 then v42 or 1 else 1, if v1 == -1 then 1 else v42, v1 do
					if t4[j].Tool then
						t4[j]:Select()

						return
					end
				end
			end)

			return
		end

		if os.clock() - v47 <= 0.06 then
			if not Humanoid then
				v46 = p3
				v47 = os.clock()

				return
			end

			Humanoid:UnequipTools()

			if not v36 then
				v46 = p3
				v47 = os.clock()

				return
			end

			v36:ToggleSelect()
			t5[v36]:UpdateEquipView()
			v36 = nil
			v46 = p3
			v47 = os.clock()

			return
		end
	end

	v46 = p3
	v47 = os.clock()
	task.delay(0.06, function() --[[ Line: 1263 | Upvalues: v46 (ref), p3 (copy), v42 (ref), t4 (ref), Humanoid (ref), v36 (ref), t5 (ref), v44 (ref) ]]
		if v46 ~= p3 then
			return
		end

		local v1 = if p3.KeyCode == Enum.KeyCode.ButtonL1 then -1 else 1

		for i = 1, v42 do
			if t4[i]:IsEquipped() then
				local sum2 = v1 + i
				local v2 = false

				if v42 < sum2 then
					sum2 = 1
					v2 = true
				elseif sum2 < 1 then
					sum2 = v42
					v2 = true
				end

				local v3 = sum2

				while not t4[sum2].Tool do
					sum2 = sum2 + v1

					if sum2 == v3 then
						return
					end

					if v42 < sum2 then
						sum2 = 1
						v2 = true
					elseif sum2 < 1 then
						sum2 = v42
						v2 = true
					else
						continue
					end
				end

				if not v2 then
					t4[sum2]:Select()

					return
				end

				if not Humanoid then
					v44 = nil

					return
				end

				Humanoid:UnequipTools()

				if not v36 then
					v44 = nil

					return
				end

				v36:ToggleSelect()
				t5[v36]:UpdateEquipView()
				v36 = nil
				v44 = nil

				return
			end
		end

		if v44 and v44.Tool then
			v44:Select()

			return
		end

		for j = if v1 == -1 then v42 or 1 else 1, if v1 == -1 then 1 else v42, v1 do
			if t4[j].Tool then
				t4[j]:Select()

				return
			end
		end
	end)
end
function getGamepadSwapSlot() --[[ getGamepadSwapSlot | Line: 1330 | Upvalues: t4 (copy) ]]
	for i = 1, #t4 do
		if t4[i].Frame.BorderSizePixel > 0 then
			return t4[i]
		end
	end
end
function changeSlot(p1) --[[ changeSlot | Line: 1340 | Upvalues: VRService (copy), Inventory (ref), GuiService (copy), VRInventorySelector (ref), v42 (copy) ]]
	if p1.Frame == GuiService.SelectedObject and (not VRService.VREnabled or Inventory.Visible) then
		local v2 = getGamepadSwapSlot()

		if not v2 then
			local Size = p1.Frame.Size
			local Position = p1.Frame.Position

			p1.Frame:TweenSizeAndPosition(Size + UDim2.new(0, 10, 0, 10), Position - UDim2.new(0, 5, 0, 5), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.1, true, function() --[[ Line: 1376 | Upvalues: p1 (copy), Size (copy), Position (copy) ]]
				p1.Frame:TweenSizeAndPosition(Size, Position, Enum.EasingDirection.In, Enum.EasingStyle.Quad, 0.1, true)
			end)
			p1.Frame.BorderSizePixel = 3
			VRInventorySelector.SelectionImageObject.Visible = true

			return
		end

		v2.Frame.BorderSizePixel = 0

		if v2 == p1 then
			return
		end

		p1:Swap(v2)
		VRInventorySelector.SelectionImageObject.Visible = false

		if v42 < p1.Index and not p1.Tool then
			if GuiService.SelectedObject == p1.Frame then
				GuiService.SelectedObject = v2.Frame
			end

			p1:Delete()
		end

		if not (v42 < v2.Index) or v2.Tool then
			return
		end

		if GuiService.SelectedObject ~= v2.Frame then
			v2:Delete()

			return
		end

		GuiService.SelectedObject = p1.Frame
		v2:Delete()

		return
	end

	p1:Select()
	VRInventorySelector.SelectionImageObject.Visible = false
end
function vrMoveSlotToInventory() --[[ vrMoveSlotToInventory | Line: 1396 | Upvalues: VRService (copy), VRInventorySelector (ref) ]]
	if not VRService.VREnabled then
		return
	end

	local v1 = getGamepadSwapSlot()

	if not (v1 and v1.Tool) then
		return
	end

	v1.Frame.BorderSizePixel = 0
	v1:MoveToInventory()
	VRInventorySelector.SelectionImageObject.Visible = false
end
function enableGamepadInventoryControl() --[[ enableGamepadInventoryControl | Line: 1409 | Upvalues: Inventory (ref), v27 (copy), ContextActionService (copy), f48 (copy), GuiService (copy), Hotbar (ref) ]]
	local function f1() --[[ Line: 1410 | Upvalues: Inventory (ref), v27 (ref) ]]
		if getGamepadSwapSlot() then
			local v1 = getGamepadSwapSlot()

			if v1 then
				v1.Frame.BorderSizePixel = 0
			end
		else
			if not Inventory.Visible then
				return
			end

			v27:deselect()
		end
	end

	ContextActionService:BindAction("BackpackHasGamepadFocus", f48, false, Enum.UserInputType.Gamepad1)
	ContextActionService:BindAction("BackpackCloseInventory", f1, false, Enum.KeyCode.ButtonB, Enum.KeyCode.ButtonStart)
	GuiService.SelectedObject = Hotbar:FindFirstChild("1")
end
function disableGamepadInventoryControl() --[[ disableGamepadInventoryControl | Line: 1443 | Upvalues: v42 (copy), t4 (copy), GuiService (copy), Backpack (ref) ]]
	unbindAllGamepadEquipActions()

	for i = 1, v42 do
		local v1 = t4[i]

		if v1 and v1.Frame then
			v1.Frame.BorderSizePixel = 0
		end
	end

	if not (GuiService.SelectedObject and GuiService.SelectedObject:IsDescendantOf(Backpack)) then
		return
	end

	GuiService.SelectedObject = nil
end

local function bindBackpackHotbarAction() --[[ bindBackpackHotbarAction | Line: 1458 | Upvalues: v38 (ref), v30 (ref), ContextActionService (copy), v32 (ref) ]]
	if not v38 or v30 then
		return
	end

	v30 = true
	ContextActionService:BindAction("BackpackHotbarEquip", v32, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
end

local function unbindBackpackHotbarAction() --[[ unbindBackpackHotbarAction | Line: 1471 | Upvalues: v30 (ref), ContextActionService (copy) ]]
	disableGamepadInventoryControl()
	v30 = false
	ContextActionService:UnbindAction("BackpackHotbarEquip")
end

function gamepadDisconnected() --[[ gamepadDisconnected | Line: 1477 | Upvalues: v41 (ref) ]]
	v41 = false
	disableGamepadInventoryControl()
end
function gamepadConnected() --[[ gamepadConnected | Line: 1482 | Upvalues: v41 (ref), GuiService (copy), Backpack (ref), v35 (ref), v38 (ref), v30 (ref), ContextActionService (copy), v32 (ref), Inventory (ref) ]]
	v41 = true
	GuiService:AddSelectionParent("BackpackSelection", Backpack)

	if v35 >= 1 and (v38 and not v30) then
		v30 = true
		ContextActionService:BindAction("BackpackHotbarEquip", v32, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
	end

	if not Inventory.Visible then
		return
	end

	enableGamepadInventoryControl()
end

local function OnIconChanged(p1) --[[ OnIconChanged | Line: 1495 | Upvalues: StarterGui (copy), v38 (ref), Backpack (ref), v35 (ref), v30 (ref), ContextActionService (copy), v32 (ref) ]]
	local v1 = if p1 then StarterGui:GetCore("TopbarEnabled") else p1

	v38 = v1
	Backpack.Visible = v1

	if v1 then
		if v35 >= 1 and (v1 and not v30) then
			v30 = true
			ContextActionService:BindAction("BackpackHotbarEquip", v32, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
		end
	else
		disableGamepadInventoryControl()
		v30 = false
		ContextActionService:UnbindAction("BackpackHotbarEquip")
	end
end

local function MakeVRRoundButton(p1, p2) --[[ MakeVRRoundButton | Line: 1519 ]]
	local ImageButton = Instance.new("ImageButton")

	ImageButton.BackgroundTransparency = 1
	ImageButton.Name = p1
	ImageButton.Size = UDim2.new(0, 40, 0, 40)
	ImageButton.Image = "rbxasset://textures/ui/Keyboard/close_button_background.png"

	local Icon = Instance.new("ImageLabel")

	Icon.Name = "Icon"
	Icon.BackgroundTransparency = 1
	Icon.Size = UDim2.new(0.5, 0, 0.5, 0)
	Icon.Position = UDim2.new(0.25, 0, 0.25, 0)
	Icon.Image = p2
	Icon.Parent = ImageButton

	local Selection = Instance.new("ImageLabel")

	Selection.BackgroundTransparency = 1
	Selection.Name = "Selection"
	Selection.Size = UDim2.new(0.9, 0, 0.9, 0)
	Selection.Position = UDim2.new(0.05, 0, 0.05, 0)
	Selection.Image = "rbxasset://textures/ui/Keyboard/close_button_selection.png"
	ImageButton.SelectionImageObject = Selection

	return ImageButton, Icon, Selection
end

Backpack = Instance.new("Frame")
Backpack.BackgroundTransparency = 1
Backpack.Name = "Backpack"
Backpack.Size = UDim2.new(1, 0, 1, 0)
Backpack.Visible = false
Backpack.Parent = BackpackGui
Hotbar = Instance.new("Frame")
Hotbar.BackgroundTransparency = 1
Hotbar.Name = "Hotbar"
Hotbar.Size = UDim2.new(1, 0, 1, 0)
Hotbar.Parent = Backpack

for i = 1, v42 do
	local v49 = v45(Hotbar, i)

	v49.Frame.Visible = false

	if not v34 then
		v34 = v49
	end
end

local LeftBumper = Instance.new("ImageLabel")

LeftBumper.BackgroundTransparency = 1
LeftBumper.Name = "LeftBumper"
LeftBumper.Size = UDim2.new(0, 40, 0, 40)
LeftBumper.Position = UDim2.new(0, -LeftBumper.Size.X.Offset, 0.5, -LeftBumper.Size.Y.Offset / 2)

local RightBumper = Instance.new("ImageLabel")

RightBumper.BackgroundTransparency = 1
RightBumper.Name = "RightBumper"
RightBumper.Size = UDim2.new(0, 40, 0, 40)
RightBumper.Position = UDim2.new(1, 0, 0.5, -RightBumper.Size.Y.Offset / 2)
Inventory = Instance.new("Frame")
Inventory.Name = "Inventory"
Inventory.Size = UDim2.new(1, 0, 1, 0)
Inventory.BackgroundTransparency = v6
Inventory.BackgroundColor3 = v8
Inventory.Active = true
Inventory.Visible = false
Inventory.Parent = Backpack

local Corner = Instance.new("UICorner")

Corner.Name = "Corner"
Corner.CornerRadius = v7
Corner.Parent = Inventory
VRInventorySelector = Instance.new("TextButton")
VRInventorySelector.Name = "VRInventorySelector"
VRInventorySelector.Position = UDim2.new(0, 0, 0, 0)
VRInventorySelector.Size = UDim2.new(1, 0, 1, 0)
VRInventorySelector.BackgroundTransparency = 1
VRInventorySelector.Text = ""
VRInventorySelector.Parent = Inventory

local Selector = Instance.new("ImageLabel")

Selector.BackgroundTransparency = 1
Selector.Name = "Selector"
Selector.Size = UDim2.new(1, 0, 1, 0)
Selector.Image = "rbxasset://textures/ui/Keyboard/key_selection_9slice.png"
Selector.ScaleType = Enum.ScaleType.Slice
Selector.SliceCenter = Rect.new(12, 12, 52, 52)
Selector.Visible = false
VRInventorySelector.SelectionImageObject = Selector
VRInventorySelector.MouseButton1Click:Connect(function() --[[ Line: 1616 ]]
	vrMoveSlotToInventory()
end)
ScrollingFrame = Instance.new("ScrollingFrame")
ScrollingFrame.BackgroundTransparency = 1
ScrollingFrame.Name = "ScrollingFrame"
ScrollingFrame.Size = UDim2.new(1, 0, 1, 0)
ScrollingFrame.Selectable = false
ScrollingFrame.ScrollingDirection = Enum.ScrollingDirection.Y
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.ScrollBarThickness = 8
ScrollingFrame.ScrollBarImageColor3 = Color3.new(255/255, 255/255, 255/255)
ScrollingFrame.VerticalScrollBarInset = Enum.ScrollBarInset.ScrollBar
ScrollingFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
ScrollingFrame.Parent = Inventory
UIGridFrame = Instance.new("Frame")
UIGridFrame.BackgroundTransparency = 1
UIGridFrame.Name = "UIGridFrame"
UIGridFrame.Selectable = false
UIGridFrame.Size = UDim2.new(1, -10, 1, 0)
UIGridFrame.Position = UDim2.new(0, 5, 0, 0)
UIGridFrame.Parent = ScrollingFrame

local UIGridLayout = Instance.new("UIGridLayout")

UIGridLayout.SortOrder = Enum.SortOrder.LayoutOrder
UIGridLayout.CellSize = UDim2.new(0, v29, 0, v29)
UIGridLayout.CellPadding = UDim2.new(0, 5, 0, 5)
UIGridLayout.Parent = UIGridFrame

local v50 = MakeVRRoundButton("ScrollUpButton", "rbxasset://textures/ui/Backpack/ScrollUpArrow.png")

v50.Size = UDim2.new(0, 34, 0, 34)
v50.Position = UDim2.new(0.5, -v50.Size.X.Offset / 2, 0, 43)
v50.Icon.Position = v50.Icon.Position - UDim2.new(0, 0, 0, 2)
v50.MouseButton1Click:Connect(function() --[[ Line: 1653 | Upvalues: ScrollingFrame (ref), v29 (ref) ]]
	ScrollingFrame.CanvasPosition = Vector2.new(ScrollingFrame.CanvasPosition.X, (math.min(ScrollingFrame.CanvasSize.Y.Offset - ScrollingFrame.AbsoluteWindowSize.Y, (math.max(0, ScrollingFrame.CanvasPosition.Y - (v29 + 5))))))
end)

local v51 = MakeVRRoundButton("ScrollDownButton", "rbxasset://textures/ui/Backpack/ScrollUpArrow.png")

v51.Rotation = 180
v51.Icon.Position = v51.Icon.Position - UDim2.new(0, 0, 0, 2)
v51.Size = UDim2.new(0, 34, 0, 34)
v51.Position = UDim2.new(0.5, -v51.Size.X.Offset / 2, 1, -v51.Size.Y.Offset - 3)
v51.MouseButton1Click:Connect(function() --[[ Line: 1670 | Upvalues: ScrollingFrame (ref), v29 (ref) ]]
	ScrollingFrame.CanvasPosition = Vector2.new(ScrollingFrame.CanvasPosition.X, (math.min(ScrollingFrame.CanvasSize.Y.Offset - ScrollingFrame.AbsoluteWindowSize.Y, (math.max(0, ScrollingFrame.CanvasPosition.Y + (v29 + 5))))))
end)
ScrollingFrame.Changed:Connect(function(p1) --[[ Line: 1681 | Upvalues: ScrollingFrame (ref), v50 (ref), v51 (ref) ]]
	if p1 ~= "AbsoluteWindowSize" and (p1 ~= "CanvasPosition" and p1 ~= "CanvasSize") then
		return
	end

	local v1 = if ScrollingFrame.CanvasPosition.Y < ScrollingFrame.CanvasSize.Y.Offset - ScrollingFrame.AbsoluteWindowSize.Y then true else false

	v50.Visible = ScrollingFrame.CanvasPosition.Y ~= 0
	v51.Visible = v1
end)
UpdateBackpackLayout()

local GamepadHintsFrame = Instance.new("Frame")

GamepadHintsFrame.Name = "GamepadHintsFrame"

local v52 = UDim2.new
local Offset = Hotbar.Size.X.Offset

GamepadHintsFrame.Size = v52(0, Offset, 0, if v28 then 95 else 60)
GamepadHintsFrame.BackgroundTransparency = v6
GamepadHintsFrame.BackgroundColor3 = v8
GamepadHintsFrame.Visible = false
GamepadHintsFrame.Parent = Backpack

local Layout = Instance.new("UIListLayout")

Layout.Name = "Layout"
Layout.Padding = UDim.new(0, 25)
Layout.FillDirection = Enum.FillDirection.Horizontal
Layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
Layout.SortOrder = Enum.SortOrder.LayoutOrder
Layout.Parent = GamepadHintsFrame

local Corner2 = Instance.new("UICorner")

Corner2.Name = "Corner"
Corner2.CornerRadius = v7
Corner2.Parent = GamepadHintsFrame

local function addGamepadHint(p1, p2) --[[ addGamepadHint | Line: 1717 | Upvalues: GamepadHintsFrame (copy), v28 (copy), v24 (copy) ]]
	local HintFrame = Instance.new("Frame")

	HintFrame.Name = "HintFrame"
	HintFrame.AutomaticSize = Enum.AutomaticSize.XY
	HintFrame.BackgroundTransparency = 1
	HintFrame.Parent = GamepadHintsFrame

	local Layout = Instance.new("UIListLayout")

	Layout.Name = "Layout"
	Layout.Padding = v28 and UDim.new(0, 20) or UDim.new(0, 12)
	Layout.FillDirection = Enum.FillDirection.Horizontal
	Layout.SortOrder = Enum.SortOrder.LayoutOrder
	Layout.VerticalAlignment = Enum.VerticalAlignment.Center
	Layout.Parent = HintFrame

	local HintImage = Instance.new("ImageLabel")

	HintImage.Name = "HintImage"
	HintImage.Size = v28 and UDim2.new(0, 60, 0, 60) or UDim2.new(0, 30, 0, 30)
	HintImage.BackgroundTransparency = 1
	HintImage.Image = p1
	HintImage.Parent = HintFrame

	local HintText = Instance.new("TextLabel")

	HintText.Name = "HintText"
	HintText.AutomaticSize = Enum.AutomaticSize.XY
	HintText.FontFace = Font.new(v24.Family, Enum.FontWeight.Medium, Enum.FontStyle.Normal)
	HintText.TextSize = if v28 then 32 else 19
	HintText.BackgroundTransparency = 1
	HintText.Text = p2
	HintText.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	HintText.TextXAlignment = Enum.TextXAlignment.Left
	HintText.TextYAlignment = Enum.TextYAlignment.Center
	HintText.TextWrapped = true
	HintText.Parent = HintFrame

	local UITextSizeConstraint = Instance.new("UITextSizeConstraint")

	UITextSizeConstraint.MaxTextSize = HintText.TextSize
	UITextSizeConstraint.Parent = HintText
end

addGamepadHint(UserInputService:GetImageForKeyCode(Enum.KeyCode.ButtonX), "Remove From Hotbar")
addGamepadHint(UserInputService:GetImageForKeyCode(Enum.KeyCode.ButtonA), "Select/Swap")
addGamepadHint(UserInputService:GetImageForKeyCode(Enum.KeyCode.ButtonB), "Close Backpack")

local function resizeGamepadHintsFrame() --[[ resizeGamepadHintsFrame | Line: 1761 | Upvalues: GamepadHintsFrame (copy), Hotbar (ref), v28 (copy), Inventory (ref) ]]
	GamepadHintsFrame.Size = UDim2.new(Hotbar.Size.X.Scale, Hotbar.Size.X.Offset, 0, if v28 then 95 else 60)
	GamepadHintsFrame.Position = UDim2.new(Hotbar.Position.X.Scale, Hotbar.Position.X.Offset, Inventory.Position.Y.Scale, Inventory.Position.Y.Offset - GamepadHintsFrame.Size.Y.Offset - 5)

	local t = {}
	local sum = 0

	for k, v in pairs((GamepadHintsFrame:GetChildren())) do
		if v:IsA("GuiObject") then
			table.insert(t, v)
		end
	end

	for i = 1, #t do
		if t[i]:IsA("GuiObject") then
			t[i].Size = UDim2.new(1, 0, 1, -5)
			t[i].Position = UDim2.new(0, 0, 0, 0)
			sum = sum + (t[i].HintText.Position.X.Offset + t[i].HintText.TextBounds.X)
		end
	end

	local v6 = (GamepadHintsFrame.AbsoluteSize.X - sum) / (#t - 1)

	for j = 1, #t do
		t[j].Position = j == 1 and UDim2.new(0, 0, 0, 0) or UDim2.new(0, t[j - 1].Position.X.Offset + t[j - 1].Size.X.Offset + v6, 0, 0)
		t[j].Size = UDim2.new(0, t[j].HintText.Position.X.Offset + t[j].HintText.TextBounds.X, 1, -5)
	end
end

local Search = Instance.new("Frame")

Search.Name = "Search"
Search.BackgroundColor3 = v20
Search.BackgroundTransparency = v21
Search.Size = UDim2.new(0, 190, 0, 30)
Search.Position = UDim2.new(1, -Search.Size.X.Offset - 5, 0, 5)
Search.Parent = Inventory

local Corner3 = Instance.new("UICorner")

Corner3.Name = "Corner"
Corner3.CornerRadius = v23
Corner3.Parent = Search

local Border = Instance.new("UIStroke")

Border.Name = "Border"
Border.Color = v22
Border.Thickness = 1
Border.Transparency = 0.8
Border.Parent = Search

local TextBox = Instance.new("TextBox")

TextBox.BackgroundTransparency = 1
TextBox.Name = "TextBox"
TextBox.Text = ""
TextBox.TextColor3 = v17
TextBox.TextStrokeTransparency = v18
TextBox.TextStrokeColor3 = v19
TextBox.FontFace = Font.new(v24.Family, Enum.FontWeight.Medium, Enum.FontStyle.Normal)
TextBox.PlaceholderText = "Search"
TextBox.TextColor3 = v17
TextBox.TextTransparency = v18
TextBox.TextStrokeColor3 = v19
TextBox.ClearTextOnFocus = false
TextBox.TextTruncate = Enum.TextTruncate.AtEnd
TextBox.TextSize = v25
TextBox.TextXAlignment = Enum.TextXAlignment.Left
TextBox.TextYAlignment = Enum.TextYAlignment.Center
TextBox.Size = UDim2.new(0, 154, 0, 14)
TextBox.AnchorPoint = Vector2.new(0, 0.5)
TextBox.Position = UDim2.new(0, 8, 0.5, 0)
TextBox.ZIndex = 2
TextBox.Parent = Search

local X = Instance.new("TextButton")

X.Name = "X"
X.Text = ""
X.Size = UDim2.new(0, 30, 0, 30)
X.Position = UDim2.new(1, -X.Size.X.Offset, 0.5, -X.Size.Y.Offset / 2)
X.ZIndex = 4
X.Visible = false
X.BackgroundTransparency = 1
X.Parent = Search

local X2 = Instance.new("ImageButton")

X2.Name = "X"
X2.Image = "rbxasset://textures/ui/InspectMenu/x.png"
X2.BackgroundTransparency = 1
X2.Size = UDim2.new(0, Search.Size.Y.Offset - 20, 0, Search.Size.Y.Offset - 20)
X2.AnchorPoint = Vector2.new(0.5, 0.5)
X2.Position = UDim2.new(0.5, 0, 0.5, 0)
X2.ZIndex = 1
X2.BorderSizePixel = 0
X2.Parent = X

local function search() --[[ search | Line: 1898 | Upvalues: TextBox (copy), v42 (copy), t4 (copy), Inventory (ref), v40 (ref), UIGridFrame (ref), ScrollingFrame (ref), UpdateScrollingFrameCanvasSize (copy), X (copy) ]]
	local t = {}

	for v1 in TextBox.Text:gmatch("%S+") do
		t[v1:lower()] = true
	end

	local list = {}

	for i = v42 + 1, #t4 do
		local v2 = t4[i]

		table.insert(list, { v2, (v2:CheckTerms(t)) })
		v2.Frame.Visible = false
		v2.Frame.Parent = Inventory
	end

	table.sort(list, function(p1, p2) --[[ Line: 1913 ]]
		return p1[2] > p2[2]
	end)
	v40 = true

	local count = 0

	for i, v in ipairs(list) do
		local v3 = v[1]

		if v[2] > 0 then
			v3.Frame.Visible = true
			v3.Frame.Parent = UIGridFrame
			v3.Frame.LayoutOrder = v42 + count
			count = count + 1
		end
	end

	ScrollingFrame.CanvasPosition = Vector2.new(0, 0)
	UpdateScrollingFrameCanvasSize()
	X.ZIndex = 3
end

local function clearResults() --[[ clearResults | Line: 1935 | Upvalues: X (copy), v40 (ref), v42 (copy), t4 (copy), UIGridFrame (ref), UpdateScrollingFrameCanvasSize (copy) ]]
	if not (X.ZIndex > 0) then
		UpdateScrollingFrameCanvasSize()

		return
	end

	v40 = false

	for i = v42 + 1, #t4 do
		local v1 = t4[i]

		v1.Frame.LayoutOrder = v1.Index
		v1.Frame.Parent = UIGridFrame
		v1.Frame.Visible = true
	end

	X.ZIndex = 0
	UpdateScrollingFrameCanvasSize()
end

local function reset() --[[ reset | Line: 1949 | Upvalues: clearResults (copy), TextBox (copy) ]]
	clearResults()
	TextBox.Text = ""
end

local function onChanged(p1) --[[ onChanged | Line: 1954 | Upvalues: TextBox (copy), v18 (copy), clearResults (copy), search (copy), X (copy) ]]
	if p1 ~= "Text" then
		return
	end

	local Text = TextBox.Text

	if Text == "" then
		TextBox.TextTransparency = v18
		clearResults()
	elseif Text ~= "" then
		TextBox.TextTransparency = 0
		search()
	end

	X.Visible = if Text == "" then false else Text ~= ""
end

local function focusLost(p1) --[[ focusLost | Line: 1968 | Upvalues: search (copy) ]]
	if not p1 then
		return
	end

	search()
end

X.MouseButton1Click:Connect(reset)
TextBox.Changed:Connect(onChanged)
TextBox.FocusLost:Connect(focusLost)
t.StateChanged.Event:Connect(function(p1) --[[ Line: 1979 | Upvalues: clearResults (copy), TextBox (copy) ]]
	if p1 then
		return
	end

	clearResults()
	TextBox.Text = ""
end)
t6[Enum.KeyCode.Escape.Value] = function(p1) --[[ Line: 1987 | Upvalues: clearResults (copy), TextBox (copy) ]]
	if not p1 then
		return
	end

	clearResults()
	TextBox.Text = ""
end

local function detectGamepad(p1) --[[ detectGamepad | Line: 1992 | Upvalues: UserInputService (copy), Search (copy) ]]
	if p1 == Enum.UserInputType.Gamepad1 and not UserInputService.VREnabled then
		Search.Visible = false
	else
		Search.Visible = true
	end
end

UserInputService.LastInputTypeChanged:Connect(detectGamepad)
GuiService.MenuOpened:Connect(function() --[[ Line: 2003 | Upvalues: BackpackGui (copy), v27 (copy) ]]
	BackpackGui.Enabled = false
	v27:setEnabled(false)
end)
GuiService.MenuClosed:Connect(function() --[[ Line: 2009 | Upvalues: BackpackGui (copy), v27 (copy) ]]
	BackpackGui.Enabled = true
	v27:setEnabled(true)
end)

local function f56(p1, p2, p3) --[[ Line: 2016 | Upvalues: GuiService (copy), v42 (copy), t4 (copy) ]]
	if p2 ~= Enum.UserInputState.Begin then
		return
	end

	if not GuiService.SelectedObject then
		return
	end

	for i = 1, v42 do
		if t4[i].Frame == GuiService.SelectedObject and t4[i].Tool then
			t4[i]:MoveToInventory()

			return
		end
	end
end

local function openClose() --[[ openClose | Line: 2032 | Upvalues: t7 (copy), Inventory (ref), AdjustHotbarFrames (copy), Hotbar (ref), v42 (copy), t4 (copy), v41 (ref), t3 (copy), UserInputService (copy), resizeGamepadHintsFrame (copy), GamepadHintsFrame (copy), ContextActionService (copy), f56 (copy), t (copy) ]]
	if not next(t7) then
		Inventory.Visible = not Inventory.Visible

		local Visible = Inventory.Visible

		AdjustHotbarFrames()
		Hotbar.Active = not Hotbar.Active

		for i = 1, v42 do
			t4[i]:SetClickability(not Visible)
		end
	end

	if Inventory.Visible then
		if v41 then
			if t3[UserInputService:GetLastInputType()] then
				resizeGamepadHintsFrame()
				GamepadHintsFrame.Visible = not UserInputService.VREnabled
			end

			enableGamepadInventoryControl()
		end
	else
		if v41 then
			GamepadHintsFrame.Visible = false
		end

		disableGamepadInventoryControl()
	end

	if Inventory.Visible then
		ContextActionService:BindAction("BackpackRemoveSlot", f56, false, Enum.KeyCode.ButtonX)
	else
		ContextActionService:UnbindAction("BackpackRemoveSlot")
	end

	t.IsOpen = Inventory.Visible
	t.StateChanged:Fire(Inventory.Visible)
end

StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
t.OpenClose = openClose

while not LocalPlayer do
	task.wait()
	LocalPlayer = Players.LocalPlayer
end

LocalPlayer.CharacterAdded:Connect(OnCharacterAdded)

if LocalPlayer.Character then
	OnCharacterAdded(LocalPlayer.Character)
end

UserInputService.InputBegan:Connect(OnInputBegan)
UserInputService.TextBoxFocused:Connect(function() --[[ Line: 2095 | Upvalues: v39 (ref) ]]
	v39 = true
end)
UserInputService.TextBoxFocusReleased:Connect(function() --[[ Line: 2098 | Upvalues: v39 (ref) ]]
	v39 = false
end)
t6[Backspace] = function() --[[ Line: 2103 | Upvalues: v36 (ref), Humanoid (ref), t5 (copy) ]]
	if not (v36 and Humanoid) then
		return
	end

	Humanoid:UnequipTools()

	if not v36 then
		return
	end

	v36:ToggleSelect()
	t5[v36]:UpdateEquipView()
	v36 = nil
end
UserInputService.LastInputTypeChanged:Connect(OnUISChanged)
OnUISChanged()

local v57

if not UserInputService:GetGamepadConnected(Enum.UserInputType.Gamepad1) then
	UserInputService.GamepadConnected:Connect(function(p13) --[[ Line: 2117 ]]
		if p13 ~= Enum.UserInputType.Gamepad1 then
			return
		end

		gamepadConnected()
	end)
	UserInputService.GamepadDisconnected:Connect(function(p13) --[[ Line: 2122 ]]
		if p13 ~= Enum.UserInputType.Gamepad1 then
			return
		end

		gamepadDisconnected()
	end)
	function t.SetBackpackEnabled(p13, p23) --[[ SetBackpackEnabled | Line: 2130 | Upvalues: v26 (ref) ]]
		v26 = p23
	end
	function t.IsOpened(p13) --[[ IsOpened | Line: 2135 | Upvalues: t (copy) ]]
		return t.IsOpen
	end
	function t.GetBackpackEnabled(p13) --[[ GetBackpackEnabled | Line: 2140 | Upvalues: v26 (ref) ]]
		return v26
	end
	function t.GetStateChangedEvent(p13) --[[ GetStateChangedEvent | Line: 2145 | Upvalues: t (copy) ]]
		return t.StateChanged
	end
	RunService.Heartbeat:Connect(function() --[[ Line: 2150 | Upvalues: v26 (ref), StarterGui (copy), v38 (ref), Backpack (ref), v35 (ref), v30 (ref), ContextActionService (copy), v32 (ref) ]]
		local v1 = v26
		local v2 = if v1 then StarterGui:GetCore("TopbarEnabled") else v1

		v38 = v2
		Backpack.Visible = v2

		if v2 then
			if v35 >= 1 and (v2 and not v30) then
				v30 = true
				ContextActionService:BindAction("BackpackHotbarEquip", v32, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
			end
		else
			disableGamepadInventoryControl()
			v30 = false
			ContextActionService:UnbindAction("BackpackHotbarEquip")
		end
	end)
	v57 = function() --[[ OnPreferredTransparencyChanged | Line: 2155 | Upvalues: GuiService (copy), v6 (ref), v5 (copy), Inventory (ref), v11 (ref), v10 (copy), t4 (copy), v21 (ref), Search (copy) ]]
		local PreferredTransparency = GuiService.PreferredTransparency

		v6 = v5 * PreferredTransparency
		Inventory.BackgroundTransparency = v6
		v11 = v10 * PreferredTransparency

		for i2, v in ipairs(t4) do
			v.Frame.BackgroundTransparency = v11
		end

		v21 = PreferredTransparency * 0.2
		Search.BackgroundTransparency = v21
	end
	GuiService:GetPropertyChangedSignal("PreferredTransparency"):Connect(v57)

	return t
end

gamepadConnected()
UserInputService.GamepadConnected:Connect(function(p13) --[[ Line: 2117 ]]
	if p13 ~= Enum.UserInputType.Gamepad1 then
		return
	end

	gamepadConnected()
end)
UserInputService.GamepadDisconnected:Connect(function(p13) --[[ Line: 2122 ]]
	if p13 ~= Enum.UserInputType.Gamepad1 then
		return
	end

	gamepadDisconnected()
end)
function t.SetBackpackEnabled(p13, p23) --[[ SetBackpackEnabled | Line: 2130 | Upvalues: v26 (ref) ]]
	v26 = p23
end
function t.IsOpened(p13) --[[ IsOpened | Line: 2135 | Upvalues: t (copy) ]]
	return t.IsOpen
end
function t.GetBackpackEnabled(p13) --[[ GetBackpackEnabled | Line: 2140 | Upvalues: v26 (ref) ]]
	return v26
end
function t.GetStateChangedEvent(p13) --[[ GetStateChangedEvent | Line: 2145 | Upvalues: t (copy) ]]
	return t.StateChanged
end
RunService.Heartbeat:Connect(function() --[[ Line: 2150 | Upvalues: v26 (ref), StarterGui (copy), v38 (ref), Backpack (ref), v35 (ref), v30 (ref), ContextActionService (copy), v32 (ref) ]]
	local v1 = v26
	local v2 = if v1 then StarterGui:GetCore("TopbarEnabled") else v1

	v38 = v2
	Backpack.Visible = v2

	if v2 then
		if v35 >= 1 and (v2 and not v30) then
			v30 = true
			ContextActionService:BindAction("BackpackHotbarEquip", v32, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
		end
	else
		disableGamepadInventoryControl()
		v30 = false
		ContextActionService:UnbindAction("BackpackHotbarEquip")
	end
end)
v57 = function() --[[ OnPreferredTransparencyChanged | Line: 2155 | Upvalues: GuiService (copy), v6 (ref), v5 (copy), Inventory (ref), v11 (ref), v10 (copy), t4 (copy), v21 (ref), Search (copy) ]]
	local PreferredTransparency = GuiService.PreferredTransparency

	v6 = v5 * PreferredTransparency
	Inventory.BackgroundTransparency = v6
	v11 = v10 * PreferredTransparency

	for i2, v in ipairs(t4) do
		v.Frame.BackgroundTransparency = v11
	end

	v21 = PreferredTransparency * 0.2
	Search.BackgroundTransparency = v21
end
GuiService:GetPropertyChangedSignal("PreferredTransparency"):Connect(v57)

return t