-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextChatService = game:GetService("TextChatService")
local MarketplaceService = game:GetService("MarketplaceService")
local LocalPlayer = Players.LocalPlayer
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")

LocalPlayer:WaitForChild("PlayerScripts")

local Gamepasses = LocalPlayer:WaitForChild("Gamepasses", 30)
local ArrastarGuis = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Utils"):WaitForChild("ArrastarGuis"))
local Emotes = PlayerGui:WaitForChild("Emotes", 30)
local Main = Emotes:WaitForChild("Main", 30)
local Fechar = Main:WaitForChild("Topbar", 30):WaitForChild("Fechar", 30)
local Adquirir = Main:WaitForChild("Adquirir", 30)
local Emotes2 = Main:WaitForChild("Emotes", 30)
local Emote = Emotes2:WaitForChild("Template", 30):WaitForChild("Emote", 30)
local Animations = script.Parent.Parent:WaitForChild("Animations", 30)
local Emotes3 = Animations:WaitForChild("Emotes", 30)
local Poses = Animations:WaitForChild("Poses", 30)
local v1 = nil
local v2 = nil
local v3 = nil
local v4 = nil
local t = {}

ArrastarGuis.new(Main):Enable()

local function NormalizeName(p1) --[[ NormalizeName | Line: 57 ]]
	return string.lower(string.gsub(p1, "%s+", ""))
end

local function StopCurrentAnimation() --[[ StopCurrentAnimation | Line: 61 | Upvalues: v4 (ref) ]]
	if not v4 then
		return
	end

	v4:Stop()
	v4:Destroy()
	v4 = nil
end

local function PlayAnimation(p1) --[[ PlayAnimation | Line: 69 | Upvalues: v3 (ref), v4 (ref) ]]
	if not v3 then
		return
	end

	local v1

	if not v4 then
		v1 = v3:LoadAnimation(p1)
		v1.Looped = true
		v1:Play()
		v4 = v1

		return
	end

	v4:Stop()
	v4:Destroy()
	v4 = nil
	v1 = v3:LoadAnimation(p1)
	v1.Looped = true
	v1:Play()
	v4 = v1
end

local function FindBestMatch(p1) --[[ FindBestMatch | Line: 81 | Upvalues: t (copy) ]]
	local v1 = (-1 / 0)
	local v2 = nil

	for k, v in pairs(t) do
		local sum = 0

		if string.sub(k, 1, #p1) == p1 then
			sum = sum + 100
		end

		if string.find(k, p1) then
			sum = sum + 50
		end

		local v3 = sum - math.abs(#k - #p1)

		if v1 < v3 then
			v1 = v3
			v2 = v
		end
	end

	return v2
end

local function PromptGamepass() --[[ PromptGamepass | Line: 107 | Upvalues: MarketplaceService (copy), LocalPlayer (copy) ]]
	local _, _2 = pcall(function() --[[ Line: 109 | Upvalues: MarketplaceService (ref), LocalPlayer (ref) ]]
		return MarketplaceService:PromptGamePassPurchase(LocalPlayer, 1928557905)
	end)
end

local function OwnsGamepass() --[[ OwnsGamepass | Line: 117 | Upvalues: Gamepasses (copy), MarketplaceService (copy), LocalPlayer (copy), Adquirir (copy) ]]
	if not Gamepasses then
		return
	end

	if Gamepasses:GetAttribute("EMOTES") or MarketplaceService:UserOwnsGamePassAsync(LocalPlayer.UserId, 1928557905) then
		Adquirir.Text = "Possu\195\173do"
		Adquirir.Interactable = false

		return true
	end
end

local function UpdateEmotes() --[[ UpdateEmotes | Line: 132 | Upvalues: Emotes2 (copy), Animations (copy), Emote (copy), Gamepasses (copy), MarketplaceService (copy), LocalPlayer (copy), Adquirir (copy), v3 (ref), v4 (ref) ]]
	for v1, v2 in Emotes2:GetChildren() do
		if v2:IsA("TextButton") then
			v2:Destroy()
		end
	end

	for v32, v42 in Animations:GetDescendants() do
		if v42:IsA("Animation") then
			local v5 = Emote:Clone()

			v5.Text = v42.Name
			v5.Parent = Emotes2
			v5.Visible = true
			v5.Activated:Connect(function() --[[ Line: 154 | Upvalues: Gamepasses (ref), MarketplaceService (ref), LocalPlayer (ref), Adquirir (ref), v42 (copy), v3 (ref), v4 (ref) ]]
				local v1

				if Gamepasses and (Gamepasses:GetAttribute("EMOTES") or MarketplaceService:UserOwnsGamePassAsync(LocalPlayer.UserId, 1928557905)) then
					Adquirir.Text = "Possu\195\173do"
					Adquirir.Interactable = false
					v1 = true
				else
					v1 = nil
				end

				if not v1 then
					local _, _2 = pcall(function() --[[ Line: 109 | Upvalues: MarketplaceService (ref), LocalPlayer (ref) ]]
						return MarketplaceService:PromptGamePassPurchase(LocalPlayer, 1928557905)
					end)

					return
				end

				local v2 = v42

				if not v3 then
					return
				end

				local v32

				if not v4 then
					v32 = v3:LoadAnimation(v2)
					v32.Looped = true
					v32:Play()
					v4 = v32

					return
				end

				v4:Stop()
				v4:Destroy()
				v4 = nil
				v32 = v3:LoadAnimation(v2)
				v32.Looped = true
				v32:Play()
				v4 = v32
			end)
		end
	end
end

local function LoadAnimations() --[[ LoadAnimations | Line: 176 | Upvalues: t (copy), Emotes3 (copy), Poses (copy) ]]
	table.clear(t)

	for v1, v2 in Emotes3:GetChildren() do
		if v2:IsA("Animation") then
			t[string.lower(string.gsub(v2.Name, "%s+", ""))] = v2
		end
	end

	for v5, v6 in Poses:GetChildren() do
		if v6:IsA("Animation") then
			t[string.lower(string.gsub(v6.Name, "%s+", ""))] = v6
		end
	end
end

local function SetupCharacter(p1) --[[ SetupCharacter | Line: 196 | Upvalues: v1 (ref), v2 (ref), v3 (ref), v4 (ref) ]]
	v1 = p1
	v2 = p1:WaitForChild("Humanoid", 100)
	v3 = v2:WaitForChild("Animator", 100)
	v2.Running:Connect(function(p1) --[[ Line: 201 | Upvalues: v4 (ref) ]]
		if not (p1 > 0.5 and v4) then
			return
		end

		v4:Stop()
		v4:Destroy()
		v4 = nil
	end)
end

local function SetupCommand() --[[ SetupCommand | Line: 212 | Upvalues: TextChatService (copy), LocalPlayer (copy), t (copy), FindBestMatch (copy), v3 (ref), v4 (ref) ]]
	local TextChatCommands = TextChatService:WaitForChild("TextChatCommands")
	local EmoteCommand = Instance.new("TextChatCommand")

	EmoteCommand.Name = "EmoteCommand"
	EmoteCommand.PrimaryAlias = "/e"
	EmoteCommand.Parent = TextChatCommands
	EmoteCommand.Triggered:Connect(function(p1, p2) --[[ Line: 220 | Upvalues: LocalPlayer (ref), t (ref), FindBestMatch (ref), v3 (ref), v4 (ref) ]]
		if p1.UserId ~= LocalPlayer.UserId then
			return
		end

		if not p2 then
			return
		end

		if not LocalPlayer:WaitForChild("Gamepasses"):GetAttribute("EMOTES") then
			return
		end

		local v1 = string.gsub(p2, "^/e%s*", "")

		if v1 == "" then
			return
		end

		local v2 = string.lower(string.gsub(v1, "%s+", ""))
		local v32 = t[v2] or FindBestMatch(v2)

		if not v32 then
			return
		end

		if not v3 then
			return
		end

		if v4 then
			v4:Stop()
			v4:Destroy()
			v4 = nil
		end

		local v42 = v3:LoadAnimation(v32)

		v42.Looped = true
		v42:Play()
		v4 = v42
	end)
end

ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("OpenEmotes").OnClientEvent:Connect(function() --[[ Line: 247 | Upvalues: Emotes (copy) ]]
	Emotes.Enabled = true
end)
Fechar.Activated:Connect(function() --[[ Line: 253 | Upvalues: Emotes (copy) ]]
	Emotes.Enabled = false
end)
Adquirir.Activated:Connect(function() --[[ Line: 259 | Upvalues: MarketplaceService (copy), LocalPlayer (copy) ]]
	local _, _2 = pcall(function() --[[ Line: 109 | Upvalues: MarketplaceService (ref), LocalPlayer (ref) ]]
		return MarketplaceService:PromptGamePassPurchase(LocalPlayer, 1928557905)
	end)
end)
LoadAnimations()
SetupCommand()

local v5

if Gamepasses and (Gamepasses:GetAttribute("EMOTES") or MarketplaceService:UserOwnsGamePassAsync(LocalPlayer.UserId, 1928557905)) then
	Adquirir.Text = "Possu\195\173do"
	Adquirir.Interactable = false
	v5 = true
else
	v5 = nil
end

if v5 then
	Adquirir.Text = "Possu\195\173do"
	Adquirir.Interactable = false
	UpdateEmotes()
end

if LocalPlayer.Character then
	SetupCharacter(LocalPlayer.Character)
end

LocalPlayer.CharacterAdded:Connect(SetupCharacter)

if Gamepasses and (Gamepasses:GetAttribute("EMOTES") or MarketplaceService:UserOwnsGamePassAsync(LocalPlayer.UserId, 1928557905)) then
	Adquirir.Text = "Possu\195\173do"
	Adquirir.Interactable = false
end

UpdateEmotes()