-- https://lua.expert/
local Players = game:GetService("Players")
local StarterGui = game:GetService("StarterGui")
local LocalPlayer = Players.LocalPlayer

local function safeSetCore(p1, p2) --[[ safeSetCore | Line: 6 | Upvalues: StarterGui (copy) ]]
	pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), p1 (copy), p2 (copy) ]]
		StarterGui:SetCore(p1, p2)
	end)
end

local function applyArrestState(p1) --[[ applyArrestState | Line: 12 | Upvalues: StarterGui (copy), LocalPlayer (copy) ]]
	local v1 = not p1
	local v2 = "ResetButtonCallback"

	pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v2 (copy), v1 (copy) ]]
		StarterGui:SetCore(v2, v1)
	end)

	local Backpack = Enum.CoreGuiType.Backpack
	local v3 = "SetCoreGuiEnabled"

	pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v3 (copy), Backpack (copy) ]]
		StarterGui:SetCore(v3, Backpack)
	end)

	if not p1 then
		return
	end

	local Character = LocalPlayer.Character

	if not Character then
		return
	end

	local v4 = Character:FindFirstChildWhichIsA("Humanoid")

	if not v4 then
		return
	end

	v4:UnequipTools()
end

local function monitorArrestedAttribute() --[[ monitorArrestedAttribute | Line: 27 | Upvalues: LocalPlayer (copy), StarterGui (copy) ]]
	local v1 = LocalPlayer:GetAttribute("Arrested")
	local v2 = not v1
	local v3 = "ResetButtonCallback"

	pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v3 (copy), v2 (copy) ]]
		StarterGui:SetCore(v3, v2)
	end)

	local Backpack = Enum.CoreGuiType.Backpack
	local v4 = "SetCoreGuiEnabled"

	pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v4 (copy), Backpack (copy) ]]
		StarterGui:SetCore(v4, Backpack)
	end)

	if not v1 then
		LocalPlayer:GetAttributeChangedSignal("Arrested"):Connect(function() --[[ Line: 30 | Upvalues: LocalPlayer (ref), StarterGui (ref) ]]
			local v1 = LocalPlayer:GetAttribute("Arrested")
			local v2 = not v1
			local v3 = "ResetButtonCallback"

			pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v3 (copy), v2 (copy) ]]
				StarterGui:SetCore(v3, v2)
			end)

			local Backpack = Enum.CoreGuiType.Backpack
			local v4 = "SetCoreGuiEnabled"

			pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v4 (copy), Backpack (copy) ]]
				StarterGui:SetCore(v4, Backpack)
			end)

			if not v1 then
				return
			end

			local Character = LocalPlayer.Character

			if not Character then
				return
			end

			local v5 = Character:FindFirstChildWhichIsA("Humanoid")

			if not v5 then
				return
			end

			v5:UnequipTools()
		end)

		return
	end

	local Character = LocalPlayer.Character

	if not Character then
		LocalPlayer:GetAttributeChangedSignal("Arrested"):Connect(function() --[[ Line: 30 | Upvalues: LocalPlayer (ref), StarterGui (ref) ]]
			local v1 = LocalPlayer:GetAttribute("Arrested")
			local v2 = not v1
			local v3 = "ResetButtonCallback"

			pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v3 (copy), v2 (copy) ]]
				StarterGui:SetCore(v3, v2)
			end)

			local Backpack = Enum.CoreGuiType.Backpack
			local v4 = "SetCoreGuiEnabled"

			pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v4 (copy), Backpack (copy) ]]
				StarterGui:SetCore(v4, Backpack)
			end)

			if not v1 then
				return
			end

			local Character = LocalPlayer.Character

			if not Character then
				return
			end

			local v5 = Character:FindFirstChildWhichIsA("Humanoid")

			if not v5 then
				return
			end

			v5:UnequipTools()
		end)

		return
	end

	local v5 = Character:FindFirstChildWhichIsA("Humanoid")

	if not v5 then
		LocalPlayer:GetAttributeChangedSignal("Arrested"):Connect(function() --[[ Line: 30 | Upvalues: LocalPlayer (ref), StarterGui (ref) ]]
			local v1 = LocalPlayer:GetAttribute("Arrested")
			local v2 = not v1
			local v3 = "ResetButtonCallback"

			pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v3 (copy), v2 (copy) ]]
				StarterGui:SetCore(v3, v2)
			end)

			local Backpack = Enum.CoreGuiType.Backpack
			local v4 = "SetCoreGuiEnabled"

			pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v4 (copy), Backpack (copy) ]]
				StarterGui:SetCore(v4, Backpack)
			end)

			if not v1 then
				return
			end

			local Character = LocalPlayer.Character

			if not Character then
				return
			end

			local v5 = Character:FindFirstChildWhichIsA("Humanoid")

			if not v5 then
				return
			end

			v5:UnequipTools()
		end)

		return
	end

	v5:UnequipTools()
	LocalPlayer:GetAttributeChangedSignal("Arrested"):Connect(function() --[[ Line: 30 | Upvalues: LocalPlayer (ref), StarterGui (ref) ]]
		local v1 = LocalPlayer:GetAttribute("Arrested")
		local v2 = not v1
		local v3 = "ResetButtonCallback"

		pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v3 (copy), v2 (copy) ]]
			StarterGui:SetCore(v3, v2)
		end)

		local Backpack = Enum.CoreGuiType.Backpack
		local v4 = "SetCoreGuiEnabled"

		pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v4 (copy), Backpack (copy) ]]
			StarterGui:SetCore(v4, Backpack)
		end)

		if not v1 then
			return
		end

		local Character = LocalPlayer.Character

		if not Character then
			return
		end

		local v5 = Character:FindFirstChildWhichIsA("Humanoid")

		if not v5 then
			return
		end

		v5:UnequipTools()
	end)
end

if LocalPlayer.Character then
	task.spawn(monitorArrestedAttribute)
end

LocalPlayer.CharacterAdded:Connect(function() --[[ Line: 39 | Upvalues: monitorArrestedAttribute (copy) ]]
	task.delay(0.1, monitorArrestedAttribute)
end)
LocalPlayer.CharacterRemoving:Connect(function() --[[ Line: 43 | Upvalues: LocalPlayer (copy), StarterGui (copy) ]]
	if not LocalPlayer:GetAttribute("Arrested") then
		return
	end

	local v1 = "ResetButtonCallback"
	local v2 = true

	pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v1 (copy), v2 (copy) ]]
		StarterGui:SetCore(v1, v2)
	end)

	local Backpack = Enum.CoreGuiType.Backpack
	local v3 = "SetCoreGuiEnabled"

	pcall(function() --[[ Line: 7 | Upvalues: StarterGui (ref), v3 (copy), Backpack (copy) ]]
		StarterGui:SetCore(v3, Backpack)
	end)
end)