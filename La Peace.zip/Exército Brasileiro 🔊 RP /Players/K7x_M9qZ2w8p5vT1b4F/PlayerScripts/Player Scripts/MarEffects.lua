-- https://lua.expert/
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Lighting = game:GetService("Lighting")
local SoundService = game:GetService("SoundService")
local LocalPlayer = Players.LocalPlayer
local v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
local Humanoid = v1:WaitForChild("Humanoid", 30)
local CurrentCamera = workspace.CurrentCamera
local Mar = workspace:WaitForChild("Map"):WaitForChild("Zonas"):WaitForChild("Mar")
local Underwater = SoundService:WaitForChild("GameSounds"):WaitForChild("Underwater")
local UnderwaterEffect = Instance.new("ColorCorrectionEffect")

UnderwaterEffect.Name = "UnderwaterEffect"
UnderwaterEffect.Enabled = false
UnderwaterEffect.Brightness = -0.05
UnderwaterEffect.Contrast = 0.1
UnderwaterEffect.Saturation = -0.1
UnderwaterEffect.Parent = Lighting

local function IsInsideWater(p1, p2, p3) --[[ IsInsideWater | Line: 29 ]]
	local v1 = p2.CFrame:PointToObjectSpace(p3)
	local v2 = p2.Size / 2

	return if math.abs(v1.X) <= v2.X then if math.abs(v1.Y) <= v2.Y then math.abs(v1.Z) <= v2.Z else false else false
end

RunService.RenderStepped:Connect(function() --[[ Line: 40 | Upvalues: LocalPlayer (copy), Humanoid (ref), Mar (copy), CurrentCamera (ref), UnderwaterEffect (copy), Underwater (copy) ]]
	local v1 = false
	local v2 = nil

	if LocalPlayer:GetAttribute("Nadando") then
		Humanoid:UnequipTools()
	end

	for v4, v5 in Mar:GetChildren() do
		local v3

		if v5:IsA("BasePart") then
			local v6 = v5.CFrame:PointToObjectSpace(CurrentCamera.CFrame.Position)
			local v7 = v5.Size / 2

			v3 = if math.abs(v6.X) <= v7.X then if math.abs(v6.Y) <= v7.Y then math.abs(v6.Z) <= v7.Z else false else false

			if v3 then
				v2 = v5.Color
				v1 = true

				break
			end
		end
	end

	UnderwaterEffect.Enabled = v1

	if v1 then
		UnderwaterEffect.TintColor = v2

		if not Underwater.IsPlaying then
			Underwater.TimePosition = math.random() * Underwater.TimeLength
			Underwater:Play()
		end
	else
		if not Underwater.IsPlaying then
			return
		end

		Underwater:Stop()
	end
end)
LocalPlayer.CharacterAdded:Connect(function(p1) --[[ Line: 91 | Upvalues: CurrentCamera (ref), v1 (ref), Humanoid (ref) ]]
	local CurrentCamera2 = workspace.CurrentCamera
	local Humanoid2 = p1:WaitForChild("Humanoid", 30)

	CurrentCamera = CurrentCamera2
	v1 = p1
	Humanoid = Humanoid2
end)