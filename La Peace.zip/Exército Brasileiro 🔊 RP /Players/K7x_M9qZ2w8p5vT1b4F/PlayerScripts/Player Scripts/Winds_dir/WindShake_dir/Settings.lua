-- https://lua.expert/
return {
	new = function(p1, p2) --[[ new | Line: 9 ]]
		local v1 = table.create(3)
		local v2 = p1:GetAttribute("WindPower")
		local v3 = p1:GetAttribute("WindSpeed")
		local v4 = p1:GetAttribute("WindDirection")

		v1.WindPower = typeof(v2) == "number" and v2 or p2.WindPower
		v1.WindSpeed = typeof(v3) == "number" and v3 or p2.WindSpeed
		v1.WindDirection = typeof(v4) == "Vector3" and v4 or p2.WindDirection

		local v8 = p1:GetAttributeChangedSignal("WindPower"):Connect(function() --[[ Line: 24 | Upvalues: v2 (ref), p1 (copy), v1 (copy), p2 (copy) ]]
			v2 = p1:GetAttribute("WindPower")
			v1.WindPower = typeof(v2) == "number" and v2 or p2.WindPower
		end)
		local v9 = p1:GetAttributeChangedSignal("WindSpeed"):Connect(function() --[[ Line: 29 | Upvalues: v3 (ref), p1 (copy), v1 (copy), p2 (copy) ]]
			v3 = p1:GetAttribute("WindSpeed")
			v1.WindSpeed = typeof(v3) == "number" and v3 or p2.WindSpeed
		end)
		local v10 = p1:GetAttributeChangedSignal("WindDirection"):Connect(function() --[[ Line: 34 | Upvalues: v4 (ref), p1 (copy), v1 (copy), p2 (copy) ]]
			v4 = p1:GetAttribute("WindDirection")
			v1.WindDirection = typeof(v4) == "Vector3" and v4 or p2.WindDirection
		end)

		function v1.Destroy(p1) --[[ Destroy | Line: 41 | Upvalues: v8 (copy), v9 (copy), v10 (copy), v1 (copy) ]]
			v8:Disconnect()
			v9:Disconnect()
			v10:Disconnect()
			table.clear(v1)
		end

		return v1
	end
}