-- https://lua.expert/
local RunService = game:GetService("RunService")
local Terrain = workspace:FindFirstChildOfClass("Terrain")
local t = {}
local t2 = {
	UpdateQueue = table.create(10)
}

function t2.Init(p1, p2) --[[ Init | Line: 11 | Upvalues: t2 (copy), RunService (copy) ]]
	t2.Lifetime = p2.Lifetime or 3
	t2.Direction = p2.Direction or Vector3.new(1, 0, 0)
	t2.Speed = p2.Speed or 6

	if t2.UpdateConnection then
		t2.UpdateConnection:Disconnect()
		t2.UpdateConnection = nil
	end

	for i, v in ipairs(t2.UpdateQueue) do
		v.Attachment0:Destroy()
		v.Attachment1:Destroy()
		v.Trail:Destroy()
	end

	table.clear(t2.UpdateQueue)
	t2.LastSpawned = os.clock()

	local v1 = 1 / (p2.SpawnRate or 25)

	t2.UpdateConnection = RunService.Heartbeat:Connect(function() --[[ Line: 34 | Upvalues: t2 (ref), v1 (copy) ]]
		local v12 = os.clock()

		if v1 < v12 - t2.LastSpawned then
			t2:Create()
			t2.LastSpawned = v12
		end

		debug.profilebegin("Wind Lines")

		for i, v in ipairs(t2.UpdateQueue) do
			local v2 = v12 - v.StartClock

			if v.Lifetime <= v2 then
				v.Attachment0:Destroy()
				v.Attachment1:Destroy()
				v.Trail:Destroy()

				local v3 = #t2.UpdateQueue

				t2.UpdateQueue[i] = t2.UpdateQueue[v3]
				t2.UpdateQueue[v3] = nil

				continue
			end

			v.Trail.MaxLength = 20 - 20 * (v2 / v.Lifetime)

			local v4 = (v12 + v.Seed) * (v.Speed * 0.2)
			local Position = v.Position
			local Position2 = (CFrame.new(Position, Position + v.Direction) * CFrame.new(0, 0, v.Speed * -v2)).Position

			v.Attachment0.WorldPosition = Position2 + Vector3.new(math.sin(v4) * 0.5, math.sin(v4) * 0.8, math.sin(v4) * 0.5)
			v.Attachment1.WorldPosition = v.Attachment0.WorldPosition + Vector3.new(0, 0.1, 0)
		end

		debug.profileend()
	end)
end
function t2.Cleanup(p1) --[[ Cleanup | Line: 79 | Upvalues: t2 (copy) ]]
	if t2.UpdateConnection then
		t2.UpdateConnection:Disconnect()
		t2.UpdateConnection = nil
	end

	for i, v in ipairs(t2.UpdateQueue) do
		v.Attachment0:Destroy()
		v.Attachment1:Destroy()
		v.Trail:Destroy()
	end

	table.clear(t2.UpdateQueue)
end
function t2.Create(p1, p2) --[[ Create | Line: 95 | Upvalues: t (copy), t2 (copy), Terrain (copy) ]]
	debug.profilebegin("Add Wind Line")

	local v1 = if p2 then p2 else t
	local v2 = v1.Lifetime or t2.Lifetime
	local Position = v1.Position

	if not Position then
		local v3 = workspace.CurrentCamera.CFrame
		local Angles = CFrame.Angles
		local v5 = math.rad((math.random(-30, 70)))
		local v6 = math.random(-80, 80)

		Position = v3 * Angles(v5, math.rad(v6), 0) * CFrame.new(0, 0, math.random(200, 600) * -0.1).Position
	end

	local v7 = v1.Direction or t2.Direction
	local v8 = v1.Speed or t2.Speed

	if not (v8 <= 0) then
		local Attachment = Instance.new("Attachment")
		local Attachment2 = Instance.new("Attachment")
		local Trail = Instance.new("Trail")

		Trail.Attachment0 = Attachment
		Trail.Attachment1 = Attachment2
		Trail.WidthScale = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.3),
			NumberSequenceKeypoint.new(0.2, 1),
			NumberSequenceKeypoint.new(0.8, 1),
			NumberSequenceKeypoint.new(1, 0.3)
		})
		Trail.Transparency = NumberSequence.new(0.9, 0.8)
		Trail.FaceCamera = true
		Trail.Parent = Attachment
		Attachment.WorldPosition = Position
		Attachment2.WorldPosition = Position + Vector3.new(0, 0.1, 0)
		t2.UpdateQueue[#t2.UpdateQueue + 1] = {
			Attachment0 = Attachment,
			Attachment1 = Attachment2,
			Trail = Trail,
			Lifetime = v2 + math.random(-10, 10) * 0.1,
			Position = Position,
			Direction = v7,
			Speed = v8 + math.random(-10, 10) * 0.1,
			StartClock = os.clock(),
			Seed = math.random(1, 1000) * 0.1
		}
		Attachment.Parent = Terrain
		Attachment2.Parent = Terrain
		debug.profileend()
	end
end

return t2