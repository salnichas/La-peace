-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local RunService = game:GetService("RunService")
local Settings = require(script.Settings)
local Octree = require(script.Octree)
local v1 = Settings.new(script, {
	WindDirection = Vector3.new(0.5, 0, 0.5),
	WindSpeed = 20,
	WindPower = 0.5
})
local v2 = Instance.new("BindableEvent")
local v3 = Instance.new("BindableEvent")
local v4 = Instance.new("BindableEvent")
local v5 = Instance.new("BindableEvent")
local v6 = Instance.new("BindableEvent")

return {
	Handled = 0,
	Active = 0,
	ObjectMetadata = {},
	Octree = Octree.new(),
	LastUpdate = os.clock(),
	ObjectShakeAdded = v2.Event,
	ObjectShakeRemoved = v3.Event,
	ObjectShakeUpdated = v4.Event,
	Paused = v5.Event,
	Resumed = v6.Event,
	Connect = function(p1, p2, p3) --[[ Connect | Line: 59 ]]
		local v1 = p1[p2]

		assert(if typeof(v1) == "function" then true else false, "Unknown function: " .. p2)

		return p3:Connect(function(...) --[[ Line: 63 | Upvalues: v1 (copy), p1 (copy) ]]
			return v1(p1, ...)
		end)
	end,
	AddObjectShake = function(p1, p2, p3) --[[ AddObjectShake | Line: 68 | Upvalues: Settings (copy), v1 (copy), v2 (copy) ]]
		if typeof(p2) ~= "Instance" then
			return
		end

		if not p2:IsA("BasePart") then
			return
		end

		local ObjectMetadata = p1.ObjectMetadata

		if not ObjectMetadata[p2] then
			p1.Handled = p1.Handled + 1
			ObjectMetadata[p2] = {
				Node = p1.Octree:CreateNode(p2.Position, p2),
				Settings = Settings.new(p2, v1),
				Seed = math.random(1000) * 0.1,
				Origin = p2.CFrame
			}
			p1:UpdateObjectSettings(p2, p3)
			v2:Fire(p2)
		end
	end,
	RemoveObjectShake = function(p1, p2) --[[ RemoveObjectShake | Line: 98 | Upvalues: v3 (copy) ]]
		if typeof(p2) ~= "Instance" then
			return
		end

		local ObjectMetadata = p1.ObjectMetadata
		local v1 = ObjectMetadata[p2]

		if v1 then
			p1.Handled = p1.Handled - 1
			ObjectMetadata[p2] = nil
			v1.Settings:Destroy()
			v1.Node:Destroy()

			if p2:IsA("BasePart") then
				p2.CFrame = v1.Origin
			end
		end

		v3:Fire(p2)
	end,
	Update = function(p1) --[[ Update | Line: 120 ]]
		local v1 = os.clock()
		local v2 = v1 - p1.LastUpdate

		if v2 < 0.022222222222222223 then
			return
		end

		p1.LastUpdate = v1
		debug.profilebegin("WindShake")

		local CurrentCamera = workspace.CurrentCamera
		local v3 = if CurrentCamera then CurrentCamera.CFrame else CurrentCamera

		debug.profilebegin("Octree Search")

		local v4 = p1.Octree:RadiusSearch(v3.Position + v3.LookVector * 115, 120)

		debug.profileend()

		local v5 = #v4

		p1.Active = v5

		if v5 < 1 then
			return
		end

		local v6 = math.min(1, v2 * 8)
		local v7 = table.create(v5)
		local ObjectMetadata = p1.ObjectMetadata

		debug.profilebegin("Calc")

		for i, v in ipairs(v4) do
			local v8 = ObjectMetadata[v]
			local Origin = v8.Origin
			local v10 = v8.CFrame or Origin

			if v1 - (v8.LastCompute or 0) > 0.03333333333333333 then
				local Settings = v8.Settings
				local Seed = v8.Seed
				local v11 = Settings.WindPower * 0.1
				local v12 = v1 * (Settings.WindSpeed * 0.08)
				local v13 = math.noise(v12, 0, Seed) * v11
				local v14 = math.noise(v12, 0, -Seed) * v11
				local v15 = math.noise(v12, 0, Seed + Seed) * v11
				local PivotOffset = v.PivotOffset

				v8.Target = (Origin * PivotOffset * CFrame.Angles(v13, v14, v15) + Settings.WindDirection * ((0.5 + math.noise(v12, Seed, Seed)) * v11)) * PivotOffset:Inverse()
				v8.LastCompute = v1
			end

			local v16 = v10:Lerp(v8.Target, v6)

			v8.CFrame = v16
			v7[i] = v16
		end

		debug.profileend()
		workspace:BulkMoveTo(v4, v7, Enum.BulkMoveMode.FireCFrameChanged)
		debug.profileend()
	end,
	Pause = function(p1) --[[ Pause | Line: 187 | Upvalues: v5 (copy) ]]
		if p1.UpdateConnection then
			p1.UpdateConnection:Disconnect()
			p1.UpdateConnection = nil
		end

		p1.Active = 0
		p1.Running = false
		v5:Fire()
	end,
	Resume = function(p1) --[[ Resume | Line: 199 | Upvalues: RunService (copy), v6 (copy) ]]
		if not p1.Running then
			p1.Running = true
			p1.UpdateConnection = p1:Connect("Update", RunService.Heartbeat)
			v6:Fire()
		end
	end,
	Init = function(p1) --[[ Init | Line: 212 | Upvalues: v1 (copy), CollectionService (copy) ]]
		if p1.Initialized then
			return
		end

		p1.Initialized = true

		local v12 = script:GetAttribute("WindPower")
		local v2 = script:GetAttribute("WindSpeed")
		local v3 = script:GetAttribute("WindDirection")

		if typeof(v12) ~= "number" then
			script:SetAttribute("WindPower", v1.WindPower)
		end

		if typeof(v2) ~= "number" then
			script:SetAttribute("WindSpeed", v1.WindSpeed)
		end

		if typeof(v3) ~= "Vector3" then
			script:SetAttribute("WindDirection", v1.WindDirection)
		end

		p1:Cleanup()
		p1.AddedConnection = p1:Connect("AddObjectShake", (CollectionService:GetInstanceAddedSignal("WindShake")))
		p1.RemovedConnection = p1:Connect("RemoveObjectShake", (CollectionService:GetInstanceRemovedSignal("WindShake")))

		for k, v in pairs(CollectionService:GetTagged("WindShake")) do
			p1:AddObjectShake(v)
		end

		p1:Resume()
	end,
	Cleanup = function(p1) --[[ Cleanup | Line: 254 ]]
		if not p1.Initialized then
			return
		end

		p1:Pause()

		if p1.AddedConnection then
			p1.AddedConnection:Disconnect()
			p1.AddedConnection = nil
		end

		if p1.RemovedConnection then
			p1.RemovedConnection:Disconnect()
			p1.RemovedConnection = nil
		end

		table.clear(p1.ObjectMetadata)
		p1.Octree:ClearNodes()
		p1.Handled = 0
		p1.Active = 0
		p1.Initialized = false
	end,
	UpdateObjectSettings = function(p1, p2, p3) --[[ UpdateObjectSettings | Line: 279 | Upvalues: v4 (copy) ]]
		if typeof(p2) ~= "Instance" then
			return
		end

		if typeof(p3) ~= "table" then
			return
		end

		if not p1.ObjectMetadata[p2] and p2 ~= script then
			return
		end

		for k, v in pairs(p3) do
			p2:SetAttribute(k, v)
		end

		v4:Fire(p2)
	end,
	UpdateAllObjectSettings = function(p1, p2) --[[ UpdateAllObjectSettings | Line: 299 | Upvalues: v4 (copy) ]]
		if typeof(p2) ~= "table" then
			return
		end

		for k, v in pairs(p1.ObjectMetadata) do
			for k2, v2 in pairs(p2) do
				k:SetAttribute(k2, v2)
			end

			v4:Fire(k)
		end
	end,
	SetDefaultSettings = function(p1, p2) --[[ SetDefaultSettings | Line: 312 ]]
		p1:UpdateObjectSettings(script, p2)
	end
}