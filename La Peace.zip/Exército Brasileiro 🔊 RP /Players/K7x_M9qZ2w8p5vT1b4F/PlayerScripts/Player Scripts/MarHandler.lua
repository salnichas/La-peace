-- https://lua.expert/
local SwimController = require(script.SwimController)

repeat
	task.wait()
until game:IsLoaded()

for v1, v2 in workspace:WaitForChild("Map"):WaitForChild("Zonas"):WaitForChild("Mar"):GetChildren() do
	if v2:IsA("BasePart") then
		SwimController:AddZone(v2)
	end
end

SwimController:Start()