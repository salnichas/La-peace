-- https://lua.expert/
local Players = game:GetService("Players")
local MarketplaceService = game:GetService("MarketplaceService")
local v1 = Players.LocalPlayer or Players.PlayerAdded:Wait()
local Gamepasses = v1:WaitForChild("Gamepasses", 30)

local function safeWait(p1, p2) --[[ safeWait | Line: 16 ]]
	local ok, result = pcall(function() --[[ Line: 17 | Upvalues: p1 (copy), p2 (copy) ]]
		return p1:WaitForChild(p2, 10)
	end)

	if ok and result then
		return result
	end

	warn("[DOORS] Missing:", p2)

	return nil
end

local function isValid(p1) --[[ isValid | Line: 29 ]]
	return if p1 then p1.Parent ~= nil else p1
end

local v2 = nil
local t = {}
local t2 = {
	Teams = {
		["[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito"] = { "PortaCIE" },
		["[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos"] = { "PortaBAC" },
		["[BFE] Batalh\195\163o de For\195\167as Especiais"] = { "PortaBFE" },
		["[BPE] Batalh\195\163o da Policia do Ex\195\169rcito"] = { "PortaBPE" },
		["[BIP] Brigada de Infantaria Paraquedista"] = { "PortaBIP" },
		["[CAAT] Batalh\195\163o de Infantaria de Caatinga"] = { "PortaCAAT" },
		["[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva"] = { "PortaCIGS" },
		["[REC MEC] Regimento de Cavalaria Mecanizado"] = { "PortaRecMec" },
		["[CYBER] Comando de Defesa Cibern\195\169tica"] = { "PortaCYBER" }
	},
	DivisionalAccess = {
		["[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito"] = true,
		["[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos"] = true,
		["[BFE] Batalh\195\163o de For\195\167as Especiais"] = true,
		["[BPE] Batalh\195\163o da Policia do Ex\195\169rcito"] = true,
		["[BIP] Brigada de Infantaria Paraquedista"] = true,
		["[CAAT] Batalh\195\163o de Infantaria de Caatinga"] = true,
		["[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva"] = true,
		["[REC MEC] Regimento de Cavalaria Mecanizado"] = true,
		["[CYBER] Comando de Defesa Cibern\195\169tica"] = true
	},
	Special = {
		EB = "PortaEB",
		VIP = "PortaVIP",
		Divisional = { "PortaDivisional01", "PortaDivisional02", "PortaDivisional03", "PortaDivisional04" }
	}
}

local function setDoorState(p1, p2, p3, p4) --[[ setDoorState | Line: 83 ]]
	if not (if p1 then if p1.Parent == nil then false else true else p1) then
		return
	end

	local function apply(p12) --[[ apply | Line: 86 | Upvalues: p2 (copy), p4 (copy), p1 (copy), p3 (copy) ]]
		p12.CanCollide = p2

		for v1, v2 in p12:GetDescendants() do
			if v2:IsA("BasePart") then
				v2.CanCollide = p2
			end
		end

		if p4 or p1.Name == "PortaVIP" then
			return
		end

		p12.Transparency = p3
	end

	if p1:IsA("BasePart") then
		apply(p1)

		return
	end

	for i, v in ipairs(p1:GetDescendants()) do
		if v:IsA("BasePart") then
			apply(v)
		end
	end
end

local function openDoor(p1, p2) --[[ openDoor | Line: 117 | Upvalues: setDoorState (copy) ]]
	setDoorState(p1, false, 0.5, p2)
end

local function closeDoor(p1, p2) --[[ closeDoor | Line: 121 | Upvalues: setDoorState (copy) ]]
	setDoorState(p1, true, 0, p2)
end

local function forceTransparency(p1, p2) --[[ forceTransparency | Line: 125 ]]
	if not (if p1 then if p1.Parent == nil then false else true else p1) then
		return
	end

	if p1:IsA("BasePart") then
		p1.Transparency = p2

		return
	end

	for i, v in ipairs(p1:GetDescendants()) do
		if v:IsA("BasePart") then
			v.Transparency = p2
		end
	end
end

local function loadDoors() --[[ loadDoors | Line: 143 | Upvalues: v2 (ref), t (copy), t2 (copy), forceTransparency (copy) ]]
	local v1 = workspace
	local v22 = "Map"
	local ok, result = pcall(function() --[[ Line: 17 | Upvalues: v1 (copy), v22 (copy) ]]
		return v1:WaitForChild(v22, 10)
	end)
	local v3

	if ok and result then
		v3 = result
	else
		warn("[DOORS] Missing:", "Map")
		v3 = nil
	end

	if not v3 then
		return
	end

	local v4 = "Doors"
	local ok2, result2 = pcall(function() --[[ Line: 17 | Upvalues: v3 (copy), v4 (copy) ]]
		return v3:WaitForChild(v4, 10)
	end)
	local v5

	if ok2 and result2 then
		v5 = result2
	else
		warn("[DOORS] Missing:", "Doors")
		v5 = nil
	end

	v2 = v5

	if not v5 then
		return
	end

	for i, v in ipairs(v5:GetChildren()) do
		t[v.Name] = v
	end

	local v6 = t[t2.Special.VIP]

	if not v6 then
		return
	end

	forceTransparency(v6, 1)
end

local function closeAllTeamDoors() --[[ closeAllTeamDoors | Line: 164 | Upvalues: t (copy), setDoorState (copy) ]]
	for k, v in pairs(t) do
		setDoorState(v, true, 0, nil)
	end
end

local function updateTeamDoors() --[[ updateTeamDoors | Line: 170 | Upvalues: v1 (copy), t (copy), setDoorState (copy), t2 (copy) ]]
	local Team = v1.Team

	if not Team then
		return
	end

	for k, v in pairs(t) do
		setDoorState(v, true, 0, nil)
	end

	task.defer(function() --[[ Line: 176 | Upvalues: t2 (ref), Team (copy), t (ref), setDoorState (ref) ]]
		local v1 = t2.Teams[Team.Name]

		if v1 then
			for i2, v in ipairs(v1) do
				setDoorState(t[v], false, 0.5, nil)
			end
		end

		for i2, v in ipairs(t2.Special.Divisional) do
			if t2.DivisionalAccess[Team.Name] then
				setDoorState(t[v], false, 0.5, nil)

				continue
			end

			setDoorState(t[v], true, 0, nil)
		end
	end)
end

local function updateEB() --[[ updateEB | Line: 202 | Upvalues: t (copy), t2 (copy), v1 (copy), setDoorState (copy) ]]
	local v12 = t[t2.Special.EB]

	if not v12 then
		return
	end

	local Team = v1.Team
	local v2 = v1:GetAttribute("IsMilitary")
	local v3 = v1:GetAttribute("Patente")

	if v2 or typeof(v3) == "number" and v3 >= 1 then
		setDoorState(v12, false, 0.5, nil)
	else
		setDoorState(v12, true, 0, nil)
	end
end

local function updateVIP() --[[ updateVIP | Line: 222 | Upvalues: t (copy), t2 (copy), v1 (copy), setDoorState (copy), forceTransparency (copy) ]]
	local v12 = t[t2.Special.VIP]

	if not v12 then
		return
	end

	if v1:WaitForChild("Gamepasses", 60):GetAttribute("PASSELIVRE") then
		setDoorState(v12, false, 0.5, true)
	else
		setDoorState(v12, true, 0, true)
	end

	task.wait(0.25, function() --[[ Line: 235 | Upvalues: v12 (copy) ]]
		repeat
			v12.Transparency = 1
			task.wait()
		until v12.Transparency == 1
	end)
	task.defer(function() --[[ Line: 242 | Upvalues: forceTransparency (ref), v12 (copy) ]]
		forceTransparency(v12, 1)
	end)
end

local function isLocalCharacter(p1) --[[ isLocalCharacter | Line: 251 | Upvalues: v1 (copy) ]]
	local Character = v1.Character

	return if Character then p1:IsDescendantOf(Character) else Character
end

local function connectTouched(p1, p2) --[[ connectTouched | Line: 256 | Upvalues: v1 (copy) ]]
	if not (if p1 then if p1.Parent == nil then false else true else p1) then
		return
	end

	local function bindPart(p1) --[[ bindPart | Line: 259 | Upvalues: v1 (ref), p2 (copy) ]]
		if not p1:IsA("BasePart") then
			return
		end

		p1.Touched:Connect(function(p1) --[[ Line: 261 | Upvalues: v1 (ref), p2 (ref) ]]
			local Character = v1.Character

			if not (Character and p1:IsDescendantOf(Character)) then
				return
			end

			p2()
		end)
	end

	if p1:IsA("BasePart") then
		if p1:IsA("BasePart") then
			p1.Touched:Connect(function(p1) --[[ Line: 261 | Upvalues: v1 (ref), p2 (copy) ]]
				local Character = v1.Character

				if not (Character and p1:IsDescendantOf(Character)) then
					return
				end

				p2()
			end)
		end
	else
		for i, v in ipairs(p1:GetDescendants()) do
			if v:IsA("BasePart") then
				v.Touched:Connect(function(p1) --[[ Line: 261 | Upvalues: v1 (ref), p2 (copy) ]]
					local Character = v1.Character

					if not (Character and p1:IsDescendantOf(Character)) then
						return
					end

					p2()
				end)
			end
		end
	end
end

local function connectDoorTouches() --[[ connectDoorTouches | Line: 278 | Upvalues: t (copy), t2 (copy), connectTouched (copy), updateEB (copy), updateVIP (copy) ]]
	local v1 = t[t2.Special.EB]

	if v1 then
		connectTouched(v1, updateEB)
	end

	local v2 = t[t2.Special.VIP]

	if not v2 then
		return
	end

	connectTouched(v2, updateVIP)
end

local function connectEvents() --[[ connectEvents | Line: 294 | Upvalues: v1 (copy), updateTeamDoors (copy), updateEB (copy), updateVIP (copy), Gamepasses (copy) ]]
	v1:GetPropertyChangedSignal("Team"):Connect(updateTeamDoors)
	v1:GetAttributeChangedSignal("Patente"):Connect(updateEB)
	v1:GetAttributeChangedSignal("IsMilitary"):Connect(updateEB)
	v1:GetAttributeChangedSignal("ViceClub"):Connect(updateVIP)
	Gamepasses.AttributeChanged:Connect(function(p1) --[[ Line: 303 | Upvalues: updateVIP (ref) ]]
		if p1 ~= "PASSELIVRE" then
			return
		end

		updateVIP()
	end)
end

local ProximityPrompt = workspace:WaitForChild("Map", 30):WaitForChild("Doors", 30):WaitForChild("PortaVIP", 30):WaitForChild("ProximityPrompt")

if Gamepasses then
	while not Gamepasses:GetAttribute("Loaded") do
		Gamepasses:GetAttributeChangedSignal("Loaded"):Wait()
	end

	if not Gamepasses:GetAttribute("PASSELIVRE") then
		ProximityPrompt.Enabled = true
	end
end

ProximityPrompt.Triggered:Connect(function() --[[ Line: 338 | Upvalues: MarketplaceService (copy), v1 (copy) ]]
	MarketplaceService:PromptGamePassPurchase(v1, 1927219873)
end)
task.defer(function() --[[ Line: 344 | Upvalues: loadDoors (copy), connectEvents (copy), t (copy), t2 (copy), connectTouched (copy), updateEB (copy), updateVIP (copy), v1 (copy), setDoorState (copy) ]]
	loadDoors()
	connectEvents()

	local v12 = t[t2.Special.EB]

	if v12 then
		connectTouched(v12, updateEB)
	end

	local v2 = t[t2.Special.VIP]

	if v2 then
		connectTouched(v2, updateVIP)
	end

	repeat
		task.wait()
	until v1.Team ~= nil

	task.wait(1)

	local Team = v1.Team

	if not Team then
		updateEB()
		updateVIP()

		return
	end

	for k, v in pairs(t) do
		setDoorState(v, true, 0, nil)
	end

	task.defer(function() --[[ Line: 176 | Upvalues: t2 (ref), Team (copy), t (ref), setDoorState (ref) ]]
		local v1 = t2.Teams[Team.Name]

		if v1 then
			for i2, v in ipairs(v1) do
				setDoorState(t[v], false, 0.5, nil)
			end
		end

		for i2, v in ipairs(t2.Special.Divisional) do
			if t2.DivisionalAccess[Team.Name] then
				setDoorState(t[v], false, 0.5, nil)

				continue
			end

			setDoorState(t[v], true, 0, nil)
		end
	end)
	updateEB()
	updateVIP()
end)