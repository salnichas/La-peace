-- https://lua.expert/
local ok, result = pcall(function() --[[ Line: 17 ]]
	return UserSettings():IsUserFeatureEnabled("UserVRVehicleCameraOrbital")
end)
local v1 = ok and result
local VRService = game:GetService("VRService")
local LocalPlayer = game:GetService("Players").LocalPlayer
local Lighting = game:GetService("Lighting")
local RunService = game:GetService("RunService")
local UserGameSettings = UserSettings():GetService("UserGameSettings")
local CameraInput = require(script.Parent:WaitForChild("CameraInput"))
local ZoomController = require(script.Parent:WaitForChild("ZoomController"))
local CommonUtils = script.Parent.Parent:WaitForChild("CommonUtils")
local v2 = require(CommonUtils:WaitForChild("FlagUtil")).getUserFlag("UserVRRemoveLuaEdgeBlur")
local BaseCamera = require(script.Parent:WaitForChild("BaseCamera"))
local v3 = setmetatable({}, BaseCamera)

v3.__index = v3
function v3.new() --[[ new | Line: 42 | Upvalues: BaseCamera (copy), v3 (copy) ]]
	local v32 = setmetatable(BaseCamera.new(), v3)

	v32.gamepadZoomLevels = { 0, 7 }
	v32.headScale = 1
	v32:SetCameraToSubjectDistance(7)
	v32.VRFadeResetTimer = 0
	v32.VREdgeBlurTimer = 0
	v32.gamepadResetConnection = nil
	v32.needsReset = true
	v32.recentered = false
	v32:Reset()

	return v32
end
function v3.Reset(p1) --[[ Reset | Line: 68 ]]
	p1.stepRotateTimeout = 0
end
function v3.GetModuleName(p1) --[[ GetModuleName | Line: 72 ]]
	return "VRBaseCamera"
end
function v3.GamepadZoomPress(p1) --[[ GamepadZoomPress | Line: 76 | Upvalues: BaseCamera (copy) ]]
	BaseCamera.GamepadZoomPress(p1)
	p1:GamepadReset()
	p1:ResetZoom()
end
function v3.GamepadReset(p1) --[[ GamepadReset | Line: 84 ]]
	p1.stepRotateTimeout = 0
	p1.needsReset = true
end
function v3.ResetZoom(p1) --[[ ResetZoom | Line: 89 | Upvalues: ZoomController (copy) ]]
	ZoomController.SetZoomParameters(p1.currentSubjectDistance, 0)
	ZoomController.ReleaseSpring()
end
function v3.OnEnabledChanged(p1) --[[ OnEnabledChanged | Line: 94 | Upvalues: BaseCamera (copy), CameraInput (copy), VRService (copy), v1 (ref), v2 (copy), LocalPlayer (copy), Lighting (copy) ]]
	BaseCamera.OnEnabledChanged(p1)

	if p1.enabled then
		p1.gamepadResetConnection = CameraInput.gamepadReset:Connect(function() --[[ Line: 98 | Upvalues: p1 (copy) ]]
			p1:GamepadReset()
		end)
		p1.thirdPersonOptionChanged = VRService:GetPropertyChangedSignal("ThirdPersonFollowCamEnabled"):Connect(function() --[[ Line: 103 | Upvalues: v1 (ref), p1 (copy) ]]
			if not v1 and p1:IsInFirstPerson() then
				return
			end

			p1:Reset()
		end)
		p1.vrRecentered = VRService.UserCFrameChanged:Connect(function(p12, p2) --[[ Line: 114 | Upvalues: p1 (copy) ]]
			if p12 ~= Enum.UserCFrame.Floor then
				return
			end

			p1.recentered = true
		end)

		return
	end

	if p1.inFirstPerson then
		p1:GamepadZoomPress()
	end

	if p1.thirdPersonOptionChanged then
		p1.thirdPersonOptionChanged:Disconnect()
		p1.thirdPersonOptionChanged = nil
	end

	if p1.vrRecentered then
		p1.vrRecentered:Disconnect()
		p1.vrRecentered = nil
	end

	if p1.cameraHeadScaleChangedConn then
		p1.cameraHeadScaleChangedConn:Disconnect()
		p1.cameraHeadScaleChangedConn = nil
	end

	if p1.gamepadResetConnection then
		p1.gamepadResetConnection:Disconnect()
		p1.gamepadResetConnection = nil
	end

	if not v2 then
		p1.VREdgeBlurTimer = 0
		p1:UpdateEdgeBlur(LocalPlayer, 1)
	end

	local VRFade = Lighting:FindFirstChild("VRFade")

	if not VRFade then
		return
	end

	VRFade.Brightness = 0
end
function v3.OnCurrentCameraChanged(p1) --[[ OnCurrentCameraChanged | Line: 158 | Upvalues: BaseCamera (copy) ]]
	BaseCamera.OnCurrentCameraChanged(p1)

	if p1.cameraHeadScaleChangedConn then
		p1.cameraHeadScaleChangedConn:Disconnect()
		p1.cameraHeadScaleChangedConn = nil
	end

	local CurrentCamera = workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	p1.cameraHeadScaleChangedConn = CurrentCamera:GetPropertyChangedSignal("HeadScale"):Connect(function() --[[ Line: 170 | Upvalues: p1 (copy) ]]
		p1:OnHeadScaleChanged()
	end)
	p1:OnHeadScaleChanged()
end
function v3.OnHeadScaleChanged(p1) --[[ OnHeadScaleChanged | Line: 175 ]]
	local HeadScale = workspace.CurrentCamera.HeadScale

	for v1, v2 in p1.gamepadZoomLevels do
		p1.gamepadZoomLevels[v1] = v2 * HeadScale / p1.headScale
	end

	p1:SetCameraToSubjectDistance(p1:GetCameraToSubjectDistance() * HeadScale / p1.headScale)
	p1.headScale = HeadScale
end
function v3.GetVRFocus(p1, p2, p3) --[[ GetVRFocus | Line: 191 ]]
	local v1 = p1.lastCameraFocus or p2

	p1.cameraTranslationConstraints = Vector3.new(p1.cameraTranslationConstraints.x, math.min(1, p1.cameraTranslationConstraints.y + p3), p1.cameraTranslationConstraints.z)

	local v5 = Vector3.new(0, p1:GetCameraHeight(), 0)

	return CFrame.new(Vector3.new(p2.x, v1.y, p2.z):Lerp(p2 + v5, p1.cameraTranslationConstraints.y))
end
function v3.StartFadeFromBlack(p1) --[[ StartFadeFromBlack | Line: 207 | Upvalues: UserGameSettings (copy), Lighting (copy) ]]
	if UserGameSettings.VignetteEnabled == false then
		return
	end

	local VRFade = Lighting:FindFirstChild("VRFade")

	if not VRFade then
		local VRFade2 = Instance.new("ColorCorrectionEffect")

		VRFade2.Name = "VRFade"
		VRFade2.Parent = Lighting
		VRFade = VRFade2
	end

	VRFade.Brightness = -1
	p1.VRFadeResetTimer = 0.1
end
function v3.UpdateFadeFromBlack(p1, p2) --[[ UpdateFadeFromBlack | Line: 222 | Upvalues: Lighting (copy) ]]
	local VRFade = Lighting:FindFirstChild("VRFade")

	if p1.VRFadeResetTimer > 0 then
		p1.VRFadeResetTimer = math.max(p1.VRFadeResetTimer - p2, 0)

		local VRFade2 = Lighting:FindFirstChild("VRFade")

		if VRFade2 and VRFade2.Brightness < 0 then
			VRFade2.Brightness = math.min(VRFade2.Brightness + p2 * 10, 0)
		end
	else
		if not VRFade then
			return
		end

		VRFade.Brightness = 0
	end
end
function v3.StartVREdgeBlur(p1, p2, p3) --[[ StartVREdgeBlur | Line: 238 | Upvalues: UserGameSettings (copy), RunService (copy), VRService (copy) ]]
	if not p3 and UserGameSettings.VignetteEnabled == false then
		return
	end

	local VRBlurPart = workspace.CurrentCamera:FindFirstChild("VRBlurPart")

	if not VRBlurPart then
		VRBlurPart = Instance.new("Part")
		VRBlurPart.Name = "VRBlurPart"
		VRBlurPart.Parent = workspace.CurrentCamera
		VRBlurPart.CanTouch = false
		VRBlurPart.CanCollide = false
		VRBlurPart.CanQuery = false
		VRBlurPart.Anchored = true
		VRBlurPart.Size = Vector3.new(0.44, 0.47, 1)
		VRBlurPart.Transparency = 1
		VRBlurPart.CastShadow = false
		RunService.RenderStepped:Connect(function(p1) --[[ Line: 258 | Upvalues: VRService (ref), VRBlurPart (ref) ]]
			local v1 = VRService:GetUserCFrame(Enum.UserCFrame.Head)
			local v2 = workspace.CurrentCamera.CFrame * (CFrame.new(v1.p * workspace.CurrentCamera.HeadScale) * (v1 - v1.p))

			VRBlurPart.CFrame = v2 * CFrame.Angles(0, math.pi, 0) + v2.LookVector * (1.05 * workspace.CurrentCamera.HeadScale)
			VRBlurPart.Size = Vector3.new(0.44, 0.47, 1) * workspace.CurrentCamera.HeadScale
		end)
	end

	local VRBlurScreen = p2.PlayerGui:FindFirstChild("VRBlurScreen")
	local v1 = if VRBlurScreen then VRBlurScreen:FindFirstChild("VRBlur") else nil

	if not v1 then
		if not VRBlurScreen then
			VRBlurScreen = Instance.new("SurfaceGui") or Instance.new("ScreenGui")
		end

		VRBlurScreen.Name = "VRBlurScreen"
		VRBlurScreen.Parent = p2.PlayerGui
		VRBlurScreen.Adornee = VRBlurPart

		local VRBlur = Instance.new("ImageLabel")

		VRBlur.Name = "VRBlur"
		VRBlur.Parent = VRBlurScreen
		VRBlur.Image = "rbxasset://textures/ui/VR/edgeBlur.png"
		VRBlur.AnchorPoint = Vector2.new(0.5, 0.5)
		VRBlur.Position = UDim2.new(0.5, 0, 0.5, 0)

		local v3 = workspace.CurrentCamera.ViewportSize.X * 2.3 / 512

		VRBlur.Size = UDim2.fromScale(v3, workspace.CurrentCamera.ViewportSize.Y * 2.3 / 512)
		VRBlur.BackgroundTransparency = 1
		VRBlur.Active = true
		VRBlur.ScaleType = Enum.ScaleType.Stretch
		v1 = VRBlur
	end

	v1.Visible = true
	v1.ImageTransparency = 0
	p1.VREdgeBlurTimer = 0.14
end
function v3.UpdateEdgeBlur(p1, p2, p3) --[[ UpdateEdgeBlur | Line: 307 ]]
	local VRBlurScreen = p2.PlayerGui:FindFirstChild("VRBlurScreen")
	local v1 = if VRBlurScreen then VRBlurScreen:FindFirstChild("VRBlur") else nil

	if not v1 then
		return
	end

	if p1.VREdgeBlurTimer > 0 then
		p1.VREdgeBlurTimer = p1.VREdgeBlurTimer - p3

		local VRBlurScreen2 = p2.PlayerGui:FindFirstChild("VRBlurScreen")

		if not VRBlurScreen2 then
			return
		end

		local VRBlur = VRBlurScreen2:FindFirstChild("VRBlur")

		if VRBlur then
			VRBlur.ImageTransparency = 1 - math.clamp(p1.VREdgeBlurTimer, 0.01, 0.14) * 7.142857142857142
		end
	else
		v1.Visible = false
	end
end
function v3.GetCameraHeight(p1) --[[ GetCameraHeight | Line: 332 ]]
	if p1.inFirstPerson then
		return 0
	end

	return 0.25881904510252074 * p1.currentSubjectDistance
end
function v3.GetSubjectCFrame(p1) --[[ GetSubjectCFrame | Line: 339 | Upvalues: BaseCamera (copy) ]]
	local v1 = BaseCamera.GetSubjectCFrame(p1)
	local CurrentCamera = workspace.CurrentCamera
	local v2 = if CurrentCamera then CurrentCamera.CameraSubject else CurrentCamera

	if not v2 then
		return v1
	end

	if v2:IsA("Humanoid") then
		local isDead = v2:GetState() == Enum.HumanoidStateType.Dead

		if isDead and v2 == p1.lastSubject then
			v1 = p1.lastSubjectCFrame
		end
	end

	if v1 then
		p1.lastSubjectCFrame = v1
	end

	return v1
end
function v3.GetSubjectPosition(p1) --[[ GetSubjectPosition | Line: 365 | Upvalues: BaseCamera (copy) ]]
	local v1 = BaseCamera.GetSubjectPosition(p1)
	local CurrentCamera = game.Workspace.CurrentCamera
	local v2 = if CurrentCamera then CurrentCamera.CameraSubject else CurrentCamera

	if not v2 then
		return nil
	end

	if v2:IsA("Humanoid") then
		if (if v2:GetState() == Enum.HumanoidStateType.Dead then true else false) and v2 == p1.lastSubject then
			v1 = p1.lastSubjectPosition
		end
	elseif v2:IsA("VehicleSeat") then
		v1 = v2.CFrame.p + v2.CFrame:vectorToWorldSpace(Vector3.new(0, 4, 0))
	end

	p1.lastSubjectPosition = v1

	return v1
end
function v3.getRotation(p1, p2) --[[ getRotation | Line: 394 | Upvalues: CameraInput (copy), UserGameSettings (copy) ]]
	local v1 = CameraInput.getRotation(p2)

	if UserGameSettings.VRSmoothRotationEnabled then
		return v1.X
	end

	if math.abs(v1.X) > 0.03 then
		if p1.stepRotateTimeout > 0 then
			p1.stepRotateTimeout = p1.stepRotateTimeout - p2
		end

		if p1.stepRotateTimeout <= 0 then
			local v3 = if v1.X < 0 then -1 else 1

			p1:StartFadeFromBlack()
			p1.stepRotateTimeout = 0.25

			return v3 * 0.5235987755982988
		end
	elseif math.abs(v1.X) < 0.02 then
		p1.stepRotateTimeout = 0
	end

	return 0
end
function v3.HandleSubjectDistance(p1, p2) --[[ HandleSubjectDistance | Line: 429 | Upvalues: v1 (ref) ]]
	if not (v1 and (p2 and (p2.IsInFirstPerson and p2:IsInFirstPerson()))) then
		return
	end

	p1:SetCameraToSubjectDistance(0)
end

return v3