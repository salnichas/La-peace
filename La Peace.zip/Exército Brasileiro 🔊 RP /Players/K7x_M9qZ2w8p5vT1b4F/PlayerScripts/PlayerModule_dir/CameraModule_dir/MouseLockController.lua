-- https://lua.expert/
local CommonUtils = script.Parent.Parent:WaitForChild("CommonUtils")
local FlagUtil = require(CommonUtils:WaitForChild("FlagUtil"))
local Medium = Enum.ContextActionPriority.Medium.Value
local Players = game:GetService("Players")
local ContextActionService = game:GetService("ContextActionService")
local UserInputService = game:GetService("UserInputService")
local GameSettings = UserSettings().GameSettings
local CameraUtils = require(script.Parent:WaitForChild("CameraUtils"))
local v1 = FlagUtil.getUserFlag("UserFixStuckShiftLock")
local t = {}

t.__index = t
function t.new() --[[ new | Line: 33 | Upvalues: t (copy), GameSettings (copy), Players (copy), UserInputService (copy) ]]
	local v2 = setmetatable({}, t)

	v2.isMouseLocked = false
	v2.savedMouseCursor = nil
	v2.boundKeys = { Enum.KeyCode.LeftShift, Enum.KeyCode.RightShift }
	v2.mouseLockToggledEvent = Instance.new("BindableEvent")

	local BoundKeys = script:FindFirstChild("BoundKeys")

	if not (BoundKeys and BoundKeys:IsA("StringValue")) then
		if BoundKeys then
			BoundKeys:Destroy()
		end

		local BoundKeys2 = Instance.new("StringValue")

		assert(BoundKeys2, "")
		BoundKeys2.Name = "BoundKeys"
		BoundKeys2.Value = "LeftShift,RightShift"
		BoundKeys2.Parent = script
		BoundKeys = BoundKeys2
	end

	if BoundKeys then
		BoundKeys.Changed:Connect(function(p1) --[[ Line: 58 | Upvalues: v2 (copy) ]]
			v2:OnBoundKeysObjectChanged(p1)
		end)
		v2:OnBoundKeysObjectChanged(BoundKeys.Value)
	end

	GameSettings.Changed:Connect(function(p1) --[[ Line: 65 | Upvalues: v2 (copy) ]]
		if p1 ~= "ControlMode" and p1 ~= "ComputerMovementMode" then
			return
		end

		v2:UpdateMouseLockAvailability()
	end)
	Players.LocalPlayer:GetPropertyChangedSignal("DevEnableMouseLock"):Connect(function() --[[ Line: 72 | Upvalues: v2 (copy) ]]
		v2:UpdateMouseLockAvailability()
	end)
	Players.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function() --[[ Line: 77 | Upvalues: v2 (copy) ]]
		v2:UpdateMouseLockAvailability()
	end)
	UserInputService:GetPropertyChangedSignal("PreferredInput"):Connect(function() --[[ Line: 81 | Upvalues: v2 (copy) ]]
		v2:UpdateMouseLockAvailability()
	end)
	v2:UpdateMouseLockAvailability()

	return v2
end
function t.GetIsMouseLocked(p1) --[[ GetIsMouseLocked | Line: 90 ]]
	return p1.isMouseLocked
end
function t.GetBindableToggleEvent(p1) --[[ GetBindableToggleEvent | Line: 94 ]]
	return p1.mouseLockToggledEvent.Event
end
function t.GetMouseLockOffset(p1) --[[ GetMouseLockOffset | Line: 98 ]]
	return Vector3.new(1.75, 0, 0)
end
function t.UpdateMouseLockAvailability(p1) --[[ UpdateMouseLockAvailability | Line: 102 | Upvalues: Players (copy), GameSettings (copy), UserInputService (copy) ]]
	local DevEnableMouseLock = Players.LocalPlayer.DevEnableMouseLock
	local v1 = if Players.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.Scriptable then true else false
	local v2 = if GameSettings.ControlMode == Enum.ControlMode.MouseLockSwitch then true else false
	local v3 = if GameSettings.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove then true else false
	local v4 = if UserInputService.PreferredInput == Enum.PreferredInput.KeyboardAndMouse then true else false
	local v5 = if v4 then if DevEnableMouseLock then if v2 then not v3 and not v1 else v2 else DevEnableMouseLock else v4

	if v5 == p1.enabled then
		return
	end

	p1:EnableMouseLock(v5)
end
function t.OnBoundKeysObjectChanged(p1, p2) --[[ OnBoundKeysObjectChanged | Line: 115 ]]
	p1.boundKeys = {}

	for v1 in string.gmatch(p2, "[^%s,]+") do
		for k, v in pairs(Enum.KeyCode:GetEnumItems()) do
			if v1 == v.Name then
				p1.boundKeys[#p1.boundKeys + 1] = v

				break
			end
		end
	end

	p1:UnbindContextActions()
	p1:BindContextActions()
end
function t.OnMouseLockToggled(p1) --[[ OnMouseLockToggled | Line: 130 | Upvalues: CameraUtils (copy) ]]
	p1.isMouseLocked = not p1.isMouseLocked

	if p1.isMouseLocked then
		local CursorImage = script:FindFirstChild("CursorImage")

		if CursorImage and (CursorImage:IsA("StringValue") and CursorImage.Value) then
			CameraUtils.setMouseIconOverride(CursorImage.Value)
		else
			if CursorImage then
				CursorImage:Destroy()
			end

			local CursorImage2 = Instance.new("StringValue")

			assert(CursorImage2, "")
			CursorImage2.Name = "CursorImage"
			CursorImage2.Value = "rbxasset://textures/MouseLockedCursor.png"
			CursorImage2.Parent = script
			CameraUtils.setMouseIconOverride("rbxasset://textures/MouseLockedCursor.png")
		end
	else
		CameraUtils.restoreMouseIcon()
	end

	p1.mouseLockToggledEvent:Fire()
end
function t.DoMouseLockSwitch(p1, p2, p3, p4) --[[ DoMouseLockSwitch | Line: 155 ]]
	if p3 == Enum.UserInputState.Begin then
		p1:OnMouseLockToggled()

		return Enum.ContextActionResult.Sink
	end

	return Enum.ContextActionResult.Pass
end
function t.BindContextActions(p1) --[[ BindContextActions | Line: 163 | Upvalues: ContextActionService (copy), Medium (copy) ]]
	ContextActionService:BindActionAtPriority("MouseLockSwitchAction", function(p12, p2, p3) --[[ Line: 164 | Upvalues: p1 (copy) ]]
		return p1:DoMouseLockSwitch(p12, p2, p3)
	end, false, Medium, unpack(p1.boundKeys))
end
function t.UnbindContextActions(p1) --[[ UnbindContextActions | Line: 169 | Upvalues: ContextActionService (copy) ]]
	ContextActionService:UnbindAction("MouseLockSwitchAction")
end
function t.IsMouseLocked(p1) --[[ IsMouseLocked | Line: 173 ]]
	return p1.enabled and p1.isMouseLocked
end
function t.EnableMouseLock(p1, p2) --[[ EnableMouseLock | Line: 177 | Upvalues: CameraUtils (copy), v1 (copy) ]]
	if p2 == p1.enabled then
		return
	end

	p1.enabled = p2

	if p1.enabled then
		p1:BindContextActions()

		return
	end

	CameraUtils.restoreMouseIcon()
	p1:UnbindContextActions()

	if v1 then
		if p1.isMouseLocked then
			p1.isMouseLocked = false
			p1.mouseLockToggledEvent:Fire()
		end
	else
		if p1.isMouseLocked then
			p1.mouseLockToggledEvent:Fire()
		end

		p1.isMouseLocked = false
	end
end

return t