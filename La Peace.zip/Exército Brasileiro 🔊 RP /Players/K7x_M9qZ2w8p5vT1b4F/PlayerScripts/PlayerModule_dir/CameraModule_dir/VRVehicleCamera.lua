-- https://lua.expert/
local ok, result = pcall(function() --[[ Line: 8 ]]
	return UserSettings():IsUserFeatureEnabled("UserVRVehicleCameraOrbital")
end)
local v1 = ok and result
local t = { 0, 30 }
local VRBaseCamera = require(script.Parent:WaitForChild("VRBaseCamera"))
local CameraUtils = require(script.Parent:WaitForChild("CameraUtils"))
local CameraInput = require(script.Parent:WaitForChild("CameraInput"))
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local VRService = game:GetService("VRService")
local Lighting = game:GetService("Lighting")
local LocalPlayer = Players.LocalPlayer
local mapClamp = CameraUtils.mapClamp
local VehicleCameraConfig = require(script.Parent:WaitForChild("VehicleCamera"):FindFirstChild("VehicleCameraConfig"))
local v2 = RaycastParams.new()

v2.FilterType = Enum.RaycastFilterType.Exclude
v2.IgnoreWater = true

local function yawVelocity(p1, p2) --[[ yawVelocity | Line: 44 ]]
	return math.abs((p2.YVector:Dot(p1)))
end

local function computeCameraCFrame(p1, p2, p3) --[[ computeCameraCFrame | Line: 48 ]]
	local v1 = math.atan2(p2.X, p2.Z)

	return CFrame.new(p1.Position + p2 * p3) * CFrame.Angles(0, v1, 0)
end

local function vrOccludeDisplace(p1, p2, p3, p4) --[[ vrOccludeDisplace | Line: 53 | Upvalues: LocalPlayer (copy), v2 (copy) ]]
	local v1 = math.atan2(p2.X, p2.Z)
	local v22 = CFrame.new(p1.Position + p2 * p3) * CFrame.Angles(0, v1, 0)
	local CurrentCamera = workspace.CurrentCamera

	if not CurrentCamera then
		return v22
	end

	local Position = p1.Position
	local v3 = (v22.Position - Position) * Vector3.new(1, 0, 1)
	local Magnitude = v3.Magnitude

	if Magnitude < 0.5 then
		return v22
	end

	local t = { CurrentCamera }

	if p4 then
		table.insert(t, p4)
	end

	local v4 = LocalPlayer and LocalPlayer.Character

	if v4 then
		table.insert(t, v4)
	end

	v2.FilterDescendantsInstances = t

	local Unit = v3.Unit
	local v5 = workspace:Raycast(Position, v3, v2)

	if v5 and v5.Normal:Dot(Unit) < 0 then
		local v6 = (v5.Position - Position).Magnitude - 0.5

		if v6 < Magnitude then
			return CFrame.new(p1.Position + Unit * math.max(v6, 0.5)) * v22.Rotation
		end
	end

	return v22
end

local v3 = OverlapParams.new()

v3.FilterType = Enum.RaycastFilterType.Exclude

local function findObstructions(p1, p2, p3, p4) --[[ findObstructions | Line: 89 | Upvalues: VRService (copy), LocalPlayer (copy), v2 (copy), v3 (copy) ]]
	local CurrentCamera = workspace.CurrentCamera

	if not CurrentCamera then
		return 0, {}
	end

	local Position = p2.Position
	local v1 = VRService:GetUserCFrame(Enum.UserCFrame.Head)
	local v22 = p1 * (CFrame.new(v1.Position * CurrentCamera.HeadScale) * v1.Rotation)
	local v32 = v22.Position - Position
	local Magnitude = v32.Magnitude

	if Magnitude < 0.5 then
		return 0, {}
	end

	local t = { CurrentCamera }

	if p4 then
		table.insert(t, p4)
	end

	local v4 = LocalPlayer and LocalPlayer.Character

	if v4 then
		table.insert(t, v4)
	end

	v2.FilterDescendantsInstances = t

	local v5 = workspace:Raycast(Position, v32, v2)

	if not v5 then
		return 0, {}
	end

	local Magnitude2 = (v5.Position - Position).Magnitude

	if Magnitude2 < Magnitude then
		local v8 = math.max(math.clamp((1 - -v32.Unit:Dot(v22.LookVector)) / 0.1339745962155613, 0, 1), 1 - Magnitude2 / p3, 0.15)
		local Position2 = v5.Position
		local Position3 = v22.Position
		local v9 = Vector3.new(2, 2, (Position3 - Position2).Magnitude)
		local v10 = CFrame.lookAt((Position2 + Position3) / 2, Position3)

		v3.FilterDescendantsInstances = t

		return v8, workspace:GetPartBoundsInBox(v10, v9, v3)
	end

	return 0, {}
end

local v4 = 1 / 60
local v5 = setmetatable({}, VRBaseCamera)

v5.__index = v5
function v5.new() --[[ new | Line: 141 | Upvalues: v1 (ref), VRBaseCamera (copy), v5 (copy), RunService (copy), v4 (ref) ]]
	if not v1 then
		return require(script.Parent:WaitForChild("VRVehicleCameraDeprecated")).new()
	end

	local v3 = setmetatable(VRBaseCamera.new(), v5)

	v3.skipOcclusion = true
	v3:Reset()

	if v3.thirdPersonOptionChanged then
		v3.thirdPersonOptionChanged:Disconnect()
		v3.thirdPersonOptionChanged = nil
	end

	RunService.Stepped:Connect(function(p1, p2) --[[ Line: 156 | Upvalues: v4 (ref) ]]
		v4 = p2
	end)

	return v3
end
function v5.Reset(p1) --[[ Reset | Line: 163 | Upvalues: CameraUtils (copy), t (copy) ]]
	local CurrentCamera = workspace.CurrentCamera
	local v1 = if CurrentCamera then CurrentCamera.CameraSubject else CurrentCamera

	assert(CurrentCamera, "VRVehicleCamera initialization error")
	assert(v1)
	assert(v1:IsA("VehicleSeat"))
	p1.lastOrbitalDir = nil
	p1.wasInFirstPerson = nil

	local v2 = v1:GetConnectedParts(true)

	table.insert(v2, v1)

	local v3, v4 = CameraUtils.getLooseBoundingSphere(v2)

	p1.vehicleModel = v1:FindFirstAncestorOfClass("Model") or v1.Parent
	p1.assemblyRadius = math.max(v4, 5)
	p1.assemblyOffset = v1.CFrame:Inverse() * v3
	p1.gamepadZoomLevels = {}

	for v6, v7 in t do
		table.insert(p1.gamepadZoomLevels, v7 * p1.headScale * p1.assemblyRadius / 10)
	end

	p1.lastCameraFocus = nil

	if not p1:IsInFirstPerson() then
		p1:SetCameraToSubjectDistance(p1.gamepadZoomLevels[#p1.gamepadZoomLevels])
	end

	p1.needsReset = false
end
function v5._getThirdPersonLocalOffset(p1) --[[ _getThirdPersonLocalOffset | Line: 197 | Upvalues: VehicleCameraConfig (copy) ]]
	return p1.assemblyOffset + Vector3.new(0, p1.assemblyRadius * VehicleCameraConfig.verticalCenterOffset, 0)
end
function v5._getFirstPersonLocalOffset(p1, p2) --[[ _getFirstPersonLocalOffset | Line: 201 | Upvalues: LocalPlayer (copy) ]]
	local Character = LocalPlayer.Character

	if not (Character and Character.Parent) then
		return p1:_getThirdPersonLocalOffset()
	end

	local Head = Character:FindFirstChild("Head")

	if Head and Head:IsA("BasePart") then
		return p2:Inverse() * Head.Position
	end

	return p1:_getThirdPersonLocalOffset()
end
function v5._vrOccludeVignette(p1, p2, p3, p4) --[[ _vrOccludeVignette | Line: 215 | Upvalues: findObstructions (copy), Lighting (copy), LocalPlayer (copy) ]]
	local v1 = math.atan2(p3.X, p3.Z)
	local v2 = CFrame.new(p2.Position + p3 * p4) * CFrame.Angles(0, v1, 0)
	local v3, v4 = findObstructions(v2, p2, p4, p1.vehicleModel)
	local VRFade = Lighting:FindFirstChild("VRFade")

	if not VRFade then
		local VRFade2 = Instance.new("ColorCorrectionEffect")

		VRFade2.Name = "VRFade"
		VRFade2.Parent = Lighting
		VRFade = VRFade2
	end

	VRFade.Brightness = -v3

	if p1.lastOccludedParts then
		for v5, v6 in p1.lastOccludedParts do
			v6.LocalTransparencyModifier = 0
		end
	end

	if #v4 > 0 then
		for v7, v8 in v4 do
			v8.LocalTransparencyModifier = 1
		end

		p1:StartVREdgeBlur(LocalPlayer, true)
	end

	p1.lastOccludedParts = v4

	return v2
end
function v5.Update(p1) --[[ Update | Line: 242 | Upvalues: v4 (ref), LocalPlayer (copy) ]]
	local v1 = v4

	v4 = 0
	p1:UpdateFadeFromBlack(v1)
	p1:UpdateEdgeBlur(LocalPlayer, v1)

	local v2, v3 = p1:_updateStepRotation(v1)

	return v2, v3
end
function v5._updateStepRotation(p1, p2) --[[ _updateStepRotation | Line: 254 | Upvalues: mapClamp (copy), CameraInput (copy), VehicleCameraConfig (copy), vrOccludeDisplace (copy) ]]
	local v1 = p1:GetSubjectCFrame()
	local v2 = p1:GetCameraToSubjectDistance()
	local v3 = mapClamp(v2, 0.5, p1.assemblyRadius, 1, 0)
	local v4 = v1 * p1:_getThirdPersonLocalOffset():Lerp(p1:_getFirstPersonLocalOffset(v1), v3)
	local v7 = CFrame.new(v4 + Vector3.new(0, p1:GetCameraHeight(), 0))

	if p1.needsReset or p1.recentered then
		p1.lastOrbitalDir = nil
		p1.needsReset = false
		p1.recentered = false
	end

	local lastOrbitalDir = p1.lastOrbitalDir

	if not lastOrbitalDir then
		lastOrbitalDir = (v1.LookVector * Vector3.new(-1, 0, -1)).Unit
		p1:StartFadeFromBlack()
	end

	local v8 = if (p1:GetSubjectVelocity() * Vector3.new(1, 0, 1)).Magnitude > 2 then true else false

	if v8 then
		CameraInput.getRotation(p2)
	else
		local v9 = p1:getRotation(p2)

		if math.abs(v9) > 0 then
			lastOrbitalDir = (CFrame.Angles(0, -v9, 0) * CFrame.new(lastOrbitalDir)).Position.Unit
			p1.lastRotateTime = os.clock()
		end
	end

	local v10

	if p1:IsInFirstPerson() then
		if not p1.wasInFirstPerson or v8 then
			lastOrbitalDir = (v1.LookVector * Vector3.new(-1, 0, -1)).Unit
			p1.wasInFirstPerson = true
		end

		local v13 = math.atan2(-v1.LookVector.X, -v1.LookVector.Z)

		if p1.lastVehicleYaw then
			local v14 = (v13 - p1.lastVehicleYaw + math.pi) % 6.283185307179586 - math.pi

			if math.abs(v14) > 0.001 then
				lastOrbitalDir = (CFrame.Angles(0, v14, 0) * CFrame.new(lastOrbitalDir)).Position.Unit
			end
		end

		p1.lastVehicleYaw = v13

		local v15 = math.atan2(lastOrbitalDir.X, lastOrbitalDir.Z)

		v10 = CFrame.new(v7.Position + lastOrbitalDir * v2) * CFrame.Angles(0, v15, 0)
	else
		p1.wasInFirstPerson = false
		p1.lastVehicleYaw = nil

		if v8 and not (p1.lastRotateTime and (if os.clock() - p1.lastRotateTime < VehicleCameraConfig.autocorrectDelay then true else false)) then
			local Unit = (v1.LookVector * Vector3.new(-1, 0, -1)).Unit
			local v19 = math.acos((math.clamp(lastOrbitalDir:Dot(Unit), -1, 1)))

			lastOrbitalDir = lastOrbitalDir:Lerp(Unit, (math.min(0.01 + v19 / math.pi * 0.05 + math.abs((v1.YVector:Dot((p1:GetSubjectRotVelocity())))) * 0.02, 0.15)))
		end

		v10 = vrOccludeDisplace(v7, lastOrbitalDir, v2, p1.vehicleModel)
	end

	p1.lastOrbitalDir = lastOrbitalDir

	return v10, v10 * CFrame.new(0, 0, -v2)
end

return v5