-- https://lua.expert/
local t = {
	JUMP_STUDS = 4,
	SETTLED_STUDS = 1,
	DEBOUNCE_SECONDS = 0.25
}

function t.shouldRecenter(p1, p2, p3, p4) --[[ shouldRecenter | Line: 29 | Upvalues: t (copy) ]]
	if p2 <= t.JUMP_STUDS then
		return false
	end

	if p1 == nil or not (t.SETTLED_STUDS <= p1) then
		return (p3 == nil or not (p4 - p3 < t.DEBOUNCE_SECONDS)) and true or false
	end

	return false
end

return t