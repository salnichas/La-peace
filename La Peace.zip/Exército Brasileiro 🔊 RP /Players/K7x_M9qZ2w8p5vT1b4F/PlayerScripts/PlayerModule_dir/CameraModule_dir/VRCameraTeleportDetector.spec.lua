-- https://lua.expert/
local CorePackages = game:GetService("CorePackages")
local JestGlobals = require(CorePackages.Packages.Dev.JestGlobals)
local expect = JestGlobals.expect
local it = JestGlobals.it
local VRCameraTeleportDetector = require(script.Parent.VRCameraTeleportDetector)
local shouldRecenter = VRCameraTeleportDetector.shouldRecenter
local JUMP_STUDS = VRCameraTeleportDetector.JUMP_STUDS
local SETTLED_STUDS = VRCameraTeleportDetector.SETTLED_STUDS
local DEBOUNCE_SECONDS = VRCameraTeleportDetector.DEBOUNCE_SECONDS

JestGlobals.describe("VRCameraTeleportDetector.shouldRecenter", function() --[[ Line: 14 | Upvalues: it (copy), expect (copy), shouldRecenter (copy), JUMP_STUDS (copy), SETTLED_STUDS (copy), DEBOUNCE_SECONDS (copy) ]]
	it("fires on a discrete jump from rest (no prior step, never recentered)", function() --[[ Line: 15 | Upvalues: expect (ref), shouldRecenter (ref), JUMP_STUDS (ref) ]]
		expect(shouldRecenter(nil, JUMP_STUDS + 10, nil, 100)).toBe(true)
	end)
	it("fires on a discrete jump preceded by a near-still frame", function() --[[ Line: 19 | Upvalues: expect (ref), shouldRecenter (ref), SETTLED_STUDS (ref), JUMP_STUDS (ref) ]]
		expect(shouldRecenter(SETTLED_STUDS - 0.5, JUMP_STUDS + 10, nil, 100)).toBe(true)
	end)
	it("does not fire for sub-threshold motion", function() --[[ Line: 23 | Upvalues: expect (ref), shouldRecenter (ref), JUMP_STUDS (ref) ]]
		expect(shouldRecenter(0, JUMP_STUDS - 0.1, nil, 100)).toBe(false)
		expect(shouldRecenter(0, 0, nil, 100)).toBe(false)
	end)
	it("does not fire when the previous frame was already moving (continuous motion)", function() --[[ Line: 28 | Upvalues: expect (ref), shouldRecenter (ref), SETTLED_STUDS (ref), JUMP_STUDS (ref) ]]
		expect(shouldRecenter(SETTLED_STUDS + 0.1, JUMP_STUDS + 10, nil, 100)).toBe(false)
	end)
	it("does not fire within the debounce interval", function() --[[ Line: 33 | Upvalues: expect (ref), shouldRecenter (ref), JUMP_STUDS (ref), DEBOUNCE_SECONDS (ref) ]]
		expect(shouldRecenter(nil, JUMP_STUDS + 10, 100, 100 + DEBOUNCE_SECONDS - 0.01)).toBe(false)
	end)
	it("fires again once the debounce interval has elapsed", function() --[[ Line: 38 | Upvalues: expect (ref), shouldRecenter (ref), JUMP_STUDS (ref), DEBOUNCE_SECONDS (ref) ]]
		expect(shouldRecenter(nil, JUMP_STUDS + 10, 100, 100 + DEBOUNCE_SECONDS + 0.01)).toBe(true)
	end)
	it("does not retrigger every frame under continuous per-frame CFrame writes (oscillation guard)", function() --[[ Line: 43 | Upvalues: JUMP_STUDS (ref), shouldRecenter (ref), expect (ref) ]]
		local v1 = JUMP_STUDS + 10
		local v2 = nil
		local v3 = nil
		local v4 = 0
		local v5 = 0

		for i = 1, 120 do
			if shouldRecenter(v2, v1, v3, v4) then
				v3, v5 = v4, v5 + 1
			end

			v2, v4 = v1, v4 + 1 / 60
		end

		expect(v5).toBe(1)
	end)
end)