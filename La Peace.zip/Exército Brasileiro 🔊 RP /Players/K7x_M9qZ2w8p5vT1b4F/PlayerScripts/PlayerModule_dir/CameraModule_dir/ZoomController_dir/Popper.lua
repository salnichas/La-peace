-- https://lua.expert/
local Players = game:GetService("Players")
local CommonUtils = script.Parent.Parent.Parent:WaitForChild("CommonUtils")
local FlagUtil = require(CommonUtils:WaitForChild("FlagUtil"))
local CameraWrapper = require(CommonUtils:WaitForChild("CameraWrapper"))
local ConnectionUtil = require(CommonUtils:WaitForChild("ConnectionUtil"))
local v1 = FlagUtil.getUserFlag("UserRaycastUpdateAPI2")
local v2 = FlagUtil.getUserFlag("UserCurrentCameraUpdate2")
local v3 = FlagUtil.getUserFlag("UserPlayerConnectionMemoryLeak")
local v4 = if v2 then CameraWrapper.new() else nil
local v5 = if v2 then nil else game.Workspace.CurrentCamera

if v2 then
	v4:Enable()
end

local min = math.min
local tan = math.tan
local rad = math.rad
local v6 = Ray.new
local v7 = RaycastParams.new()

v7.IgnoreWater = true
v7.FilterType = Enum.RaycastFilterType.Exclude
v7.RespectCanCollide = true

local v8 = RaycastParams.new()

v8.IgnoreWater = true
v8.FilterType = Enum.RaycastFilterType.Include

local v9 = if v3 then ConnectionUtil.new() else nil

local function getTotalTransparency(p1) --[[ getTotalTransparency | Line: 43 ]]
	return 1 - (1 - p1.Transparency) * (1 - p1.LocalTransparencyModifier)
end

local function eraseFromEnd(p1, p2) --[[ eraseFromEnd | Line: 47 ]]
	for i = #p1, p2 + 1, -1 do
		p1[i] = nil
	end
end

local v10 = nil
local v11 = nil
local v12, v13, v14

if v2 then
	local function updateProjection() --[[ updateProjection | Line: 57 | Upvalues: v4 (copy), rad (copy), v11 (ref), tan (copy), v10 (ref) ]]
		local v1 = v4:getCamera()
		local v2 = rad(v1.FieldOfView)
		local ViewportSize = v1.ViewportSize

		v11 = tan(v2 / 2) * 2
		v10 = ViewportSize.X / ViewportSize.Y * v11
	end

	v4:Connect("FieldOfView", updateProjection)
	v4:Connect("ViewportSize", updateProjection)

	local v15 = v4:getCamera()
	local v16 = rad(v15.FieldOfView)
	local ViewportSize = v15.ViewportSize

	v12 = tan(v16 / 2) * 2
	v13 = ViewportSize.X / ViewportSize.Y * v12
	v14 = v4:getCamera().NearPlaneZ
	v4:Connect("NearPlaneZ", function() --[[ Line: 73 | Upvalues: v14 (ref), v4 (copy) ]]
		v14 = v4:getCamera().NearPlaneZ
	end)
else
	local function updateProjection() --[[ updateProjection | Line: 79 | Upvalues: v5 (ref), rad (copy), v11 (ref), tan (copy), v10 (ref) ]]
		local v1 = rad(v5.FieldOfView)
		local ViewportSize = v5.ViewportSize

		v11 = tan(v1 / 2) * 2
		v10 = ViewportSize.X / ViewportSize.Y * v11
	end

	v5:GetPropertyChangedSignal("FieldOfView"):Connect(updateProjection)
	v5:GetPropertyChangedSignal("ViewportSize"):Connect(updateProjection)

	local v18 = rad(v5.FieldOfView)
	local ViewportSize = v5.ViewportSize

	v12 = tan(v18 / 2) * 2
	v13 = ViewportSize.X / ViewportSize.Y * v12
	v14 = v5.NearPlaneZ
	v5:GetPropertyChangedSignal("NearPlaneZ"):Connect(function() --[[ Line: 93 | Upvalues: v14 (ref), v5 (ref) ]]
		v14 = v5.NearPlaneZ
	end)
end

local t = {}
local tbl = {}

local function refreshIgnoreList() --[[ refreshIgnoreList | Line: 102 | Upvalues: t (ref), tbl (copy) ]]
	local count = 1

	t = {}

	for k, v in pairs(tbl) do
		t[count] = v
		count = count + 1
	end
end

local function playerAdded(p1) --[[ playerAdded | Line: 111 | Upvalues: tbl (copy), t (ref), v3 (copy), v9 (copy) ]]
	local function characterAdded(p12) --[[ characterAdded | Line: 112 | Upvalues: tbl (ref), p1 (copy), t (ref) ]]
		tbl[p1] = p12

		local count = 1

		t = {}

		for k, v in pairs(tbl) do
			t[count] = v
			count = count + 1
		end
	end

	local function characterRemoving() --[[ characterRemoving | Line: 116 | Upvalues: tbl (ref), p1 (copy), t (ref) ]]
		tbl[p1] = nil

		local count = 1

		t = {}

		for k, v in pairs(tbl) do
			t[count] = v
			count = count + 1
		end
	end

	if v3 then
		v9:trackConnection(("%*CharacterAdded"):format(p1.UserId), p1.CharacterAdded:Connect(characterAdded))
		v9:trackConnection(("%*CharacterRemoving"):format(p1.UserId), p1.CharacterRemoving:Connect(characterRemoving))
	else
		p1.CharacterAdded:Connect(characterAdded)
		p1.CharacterRemoving:Connect(characterRemoving)
	end

	if not p1.Character then
		return
	end

	tbl[p1] = p1.Character

	local count = 1

	t = {}

	for k, v in pairs(tbl) do
		t[count] = v
		count = count + 1
	end
end

local function playerRemoving(p1) --[[ playerRemoving | Line: 134 | Upvalues: tbl (copy), t (ref), v3 (copy), v9 (copy) ]]
	tbl[p1] = nil

	local count = 1

	t = {}

	for k, v in pairs(tbl) do
		t[count] = v
		count = count + 1
	end

	if not v3 then
		return
	end

	v9:disconnect((("%*CharacterAdded"):format(p1.UserId)))
	v9:disconnect((("%*CharacterRemoving"):format(p1.UserId)))
end

Players.PlayerAdded:Connect(playerAdded)
Players.PlayerRemoving:Connect(playerRemoving)

for i, v in ipairs(Players:GetPlayers()) do
	playerAdded(v)
end

local count = 1

t = {}

for k, v in pairs(tbl) do
	t[count] = v
	count = count + 1
end

local v20 = nil
local v21 = nil

if v2 then
	v4:Connect("CameraSubject", function() --[[ Line: 174 | Upvalues: v4 (copy), v21 (ref) ]]
		local CameraSubject = v4:getCamera().CameraSubject

		if CameraSubject and CameraSubject:IsA("Humanoid") then
			v21 = CameraSubject.RootPart

			return
		end

		v21 = if CameraSubject and CameraSubject:IsA("BasePart") then CameraSubject else nil
	end)
else
	v5:GetPropertyChangedSignal("CameraSubject"):Connect(function() --[[ Line: 185 | Upvalues: v5 (ref), v21 (ref) ]]
		local CameraSubject = v5.CameraSubject

		if CameraSubject:IsA("Humanoid") then
			v21 = CameraSubject.RootPart

			return
		end

		v21 = if CameraSubject:IsA("BasePart") then CameraSubject else nil
	end)
end

local function canOcclude(p1) --[[ canOcclude | Line: 197 | Upvalues: v1 (copy), v20 (ref) ]]
	return if 1 - (1 - p1.Transparency) * (1 - p1.LocalTransparencyModifier) < 0.25 then if v1 then if v20 == (p1:GetRootPart() or p1) then false else not p1:IsA("TrussPart") else p1.CanCollide and (if v20 == (p1:GetRootPart() or p1) then false else not p1:IsA("TrussPart")) else false
end

local t2 = {
	Vector2.new(0.4, 0),
	Vector2.new(-0.4, 0),
	Vector2.new(0, -0.4),
	Vector2.new(0, 0.4),
	Vector2.new(0, 0.2)
}

local function getCollisionPoint(p1, p2) --[[ getCollisionPoint | Line: 225 | Upvalues: v1 (copy), v7 (copy), t (ref), v6 (copy) ]]
	if v1 then
		v7.FilterDescendantsInstances = t

		local v12 = workspace:Raycast(p1, p2, v7)

		if v12 then
			return v12.Position, true
		end
	else
		local v2 = #t

		repeat
			local v3, v4 = workspace:FindPartOnRayWithIgnoreList(v6(p1, p2), t, false, true)

			if v3 then
				if v3.CanCollide then
					local v5 = t

					for i = #v5, v2 + 1, -1 do
						v5[i] = nil
					end

					return v4, true
				end

				t[#t + 1] = v3
			end
		until not v3

		local v62 = t

		for j = #v62, v2 + 1, -1 do
			v62[j] = nil
		end
	end

	return p1 + p2, false
end

local function queryPoint(p1, p2, p3, p4) --[[ queryPoint | Line: 258 | Upvalues: t (ref), v14 (ref), v1 (copy), v7 (copy), v20 (ref), v8 (copy), v6 (copy) ]]
	debug.profilebegin("queryPoint")

	local v12 = #t
	local v2 = p3 + v14
	local v3 = p1 + p2 * v2
	local v4 = (1 / 0)
	local v5 = (1 / 0)
	local count = 0

	if v1 then
		v7.FilterDescendantsInstances = t

		local v62 = p1

		while true do
			local v72
			local v82 = workspace:Raycast(v62, v3 - v62, v7)

			if not v82 then
				break
			end

			count = count + 1

			local v9 = v82.Instance
			local Position = v82.Position
			local Magnitude = (Position - p1).Magnitude

			if count >= 64 then
				v5 = Magnitude
			else
				v72 = if 1 - (1 - v9.Transparency) * (1 - v9.LocalTransparencyModifier) < 0.25 then if v1 then if v20 == (v9:GetRootPart() or v9) then false else not v9:IsA("TrussPart") else v9.CanCollide and (if v20 == (v9:GetRootPart() or v9) then false else not v9:IsA("TrussPart")) else false

				if v72 then
					v8.FilterDescendantsInstances = { v9 }

					if workspace:Raycast(v3, Position - v3, v8) then
						if if p4 then workspace:Raycast(p4, v3 - p4, v8) or workspace:Raycast(v3, p4 - v3, v8) else false then
							v5 = Magnitude
						elseif v2 < v4 then
							v4 = Magnitude
						end
					else
						v5 = Magnitude
					end
				end
			end

			v7:AddToFilter(v9)

			if v5 < (1 / 0) or not v9 then
				break
			end

			v62 = Position - p2 * 0.001
		end
	else
		local v11 = p1

		repeat
			local v122, v13
			local v142, v15 = workspace:FindPartOnRayWithIgnoreList(v6(v11, v3 - v11), t, false, true)

			count = count + 1

			if v142 then
				local v16 = if count >= 64 then true else false

				v122 = if 1 - (1 - v142.Transparency) * (1 - v142.LocalTransparencyModifier) < 0.25 then if v1 then if v20 == (v142:GetRootPart() or v142) then false else not v142:IsA("TrussPart") else v142.CanCollide and (if v20 == (v142:GetRootPart() or v142) then false else not v142:IsA("TrussPart")) else false

				if v122 or v16 then
					local t2 = { v142 }
					local v17 = workspace:FindPartOnRayWithWhitelist(v6(v3, v15 - v3), t2, true)
					local Magnitude = (v15 - p1).Magnitude

					if v17 and not v16 then
						v13 = if p4 then workspace:FindPartOnRayWithWhitelist(v6(p4, v3 - p4), t2, true) or workspace:FindPartOnRayWithWhitelist(v6(v3, p4 - v3), t2, true) else false

						if v13 then
							v5 = Magnitude
						elseif v2 < v4 then
							v4 = Magnitude
						end
					else
						v5 = Magnitude
					end
				end

				t[#t + 1] = v142
				v11 = v15 - p2 * 0.001
			end
		until v5 < (1 / 0) or not v142

		local v19 = t

		for i = #v19, v12 + 1, -1 do
			v19[i] = nil
		end
	end

	debug.profileend()

	return v4 - v14, v5 - v14
end

local function queryViewport(p1, p2) --[[ queryViewport | Line: 361 | Upvalues: v5 (ref), v2 (copy), v4 (copy), v13 (ref), v12 (ref), v14 (ref), queryPoint (copy) ]]
	debug.profilebegin("queryViewport")

	local p = p1.p
	local rightVector = p1.rightVector
	local upVector = p1.upVector
	local v1 = -p1.lookVector

	v5 = if v2 then v4:getCamera() else v5

	local ViewportSize = v5.ViewportSize
	local v3 = (1 / 0)
	local v42 = (1 / 0)

	for i = 0, 1 do
		local v52 = rightVector * ((i - 0.5) * v13)

		for j = 0, 1 do
			local v6, v7 = queryPoint(p + v14 * (v52 + upVector * ((j - 0.5) * v12)), v1, p2, v5:ViewportPointToRay(ViewportSize.x * i, ViewportSize.y * j).Origin)

			if v7 < v3 then
				v3 = v7
			end

			if v6 < v42 then
				v42 = v6
			end
		end
	end

	debug.profileend()

	return v42, v3
end

local function testPromotion(p1, p2, p3) --[[ testPromotion | Line: 404 | Upvalues: getCollisionPoint (copy), min (copy), queryPoint (copy), t2 (copy) ]]
	debug.profilebegin("testPromotion")

	local p = p1.p
	local rightVector = p1.rightVector
	local upVector = p1.upVector
	local v1 = -p1.lookVector

	debug.profilebegin("extrapolate")

	local Magnitude = (getCollisionPoint(p, p3.posVelocity * 1.25) - p).Magnitude

	for i = 0, min(1.25, p3.rotVelocity.magnitude + Magnitude / p3.posVelocity.magnitude), 0.0625 do
		local v2 = p3.extrapolate(i)

		if p2 <= queryPoint(v2.p, -v2.lookVector, p2) then
			return false
		end
	end

	debug.profileend()
	debug.profilebegin("testOffsets")

	for i, v in ipairs(t2) do
		local v3 = getCollisionPoint(p, rightVector * v.x + upVector * v.y)

		if queryPoint(v3, (p + v1 * p2 - v3).Unit, p2) == (1 / 0) then
			return false
		end
	end

	debug.profileend()
	debug.profileend()

	return true
end

return function(p1, p2, p3) --[[ Popper | Line: 453 | Upvalues: v20 (ref), v21 (ref), queryViewport (copy), testPromotion (copy) ]]
	debug.profilebegin("popper")
	v20 = v21 and v21:GetRootPart() or v21

	local v2, v3 = queryViewport(p1, p2)
	local v4 = if v3 < p2 then v3 else p2

	if v2 < v4 and testPromotion(p1, p2, p3) then
		v4 = v2
	end

	v20 = nil
	debug.profileend()

	return v4
end