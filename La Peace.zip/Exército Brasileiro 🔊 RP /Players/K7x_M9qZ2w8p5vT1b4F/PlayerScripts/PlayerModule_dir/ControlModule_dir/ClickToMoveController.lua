-- https://lua.expert/
local ok, result = pcall(function() --[[ Line: 10 ]]
	return UserSettings():IsUserFeatureEnabled("UserExcludeNonCollidableForPathfinding")
end)
local v1 = ok and result
local ok2, result2 = pcall(function() --[[ Line: 14 ]]
	return UserSettings():IsUserFeatureEnabled("UserClickToMoveSupportAgentCanClimb2")
end)
local v2 = ok2 and result2
local UserInputService = game:GetService("UserInputService")
local PathfindingService = game:GetService("PathfindingService")
local Players = game:GetService("Players")

game:GetService("Debris")

local StarterGui = game:GetService("StarterGui")
local Workspace = game:GetService("Workspace")
local CollectionService = game:GetService("CollectionService")
local GuiService = game:GetService("GuiService")
local CommonUtils = script.Parent.Parent:WaitForChild("CommonUtils")
local v3 = require(CommonUtils:WaitForChild("FlagUtil")).getUserFlag("UserRaycastUpdateAPI2")
local v4 = true
local v5 = true
local v6 = false
local v7 = 1
local v8 = 8
local t = {
	[Enum.KeyCode.W] = true,
	[Enum.KeyCode.A] = true,
	[Enum.KeyCode.S] = true,
	[Enum.KeyCode.D] = true,
	[Enum.KeyCode.Up] = true,
	[Enum.KeyCode.Down] = true
}
local LocalPlayer = Players.LocalPlayer
local ClickToMoveDisplay = require(script.Parent:WaitForChild("ClickToMoveDisplay"))
local v9 = RaycastParams.new()

v9.FilterType = Enum.RaycastFilterType.Exclude

local t2 = {}

if not v3 then
	local function v10(p1) --[[ FindCharacterAncestor | Line: 65 | Upvalues: v10 (copy) ]]
		if not p1 then
			return
		end

		local Humanoid = p1:FindFirstChildOfClass("Humanoid")

		if Humanoid then
			return p1, Humanoid
		end

		return v10(p1.Parent)
	end

	t2.FindCharacterAncestor = v10

	local function v11(p1, p2, p3) --[[ Raycast | Line: 77 | Upvalues: Workspace (copy), v10 (copy), v11 (copy) ]]
		local v1 = if p3 then p3 else {}
		local v2, v3, v4, v5 = Workspace:FindPartOnRayWithIgnoreList(p1, v1)

		if not v2 then
			return nil, nil
		end

		if p2 and v2.CanCollide == false then
			local v6

			if v2 then
				local Humanoid = v2:FindFirstChildOfClass("Humanoid")

				if Humanoid then
					v6 = Humanoid
				else
					local _, v7 = v10(v2.Parent)

					v6 = v7
				end
			else
				v6 = nil
			end

			if v6 == nil then
				table.insert(v1, v2)

				return v11(p1, p2, v1)
			end
		end

		return v2, v3, v4, v5
	end

	t2.Raycast = v11
end

local t3 = {}

local function findPlayerHumanoid(p1) --[[ findPlayerHumanoid | Line: 99 | Upvalues: t3 (copy) ]]
	local v1 = if p1 then p1.Character else p1

	if not v1 then
		return
	end

	local v2 = t3[p1]

	if v2 and v2.Parent == v1 then
		return v2
	end

	t3[p1] = nil

	local Humanoid = v1:FindFirstChildOfClass("Humanoid")

	if Humanoid then
		t3[p1] = Humanoid
	end

	return Humanoid
end

local v12 = nil
local v13 = nil
local v14 = nil
local v15 = nil

local function GetCharacter() --[[ GetCharacter | Line: 123 | Upvalues: LocalPlayer (copy) ]]
	return LocalPlayer and LocalPlayer.Character
end

local function UpdateIgnoreTag(p1) --[[ UpdateIgnoreTag | Line: 127 | Upvalues: v13 (ref), v14 (ref), v15 (ref), v12 (ref), LocalPlayer (copy), CollectionService (copy) ]]
	if p1 == v13 then
		return
	end

	if v14 then
		v14:Disconnect()
		v14 = nil
	end

	if v15 then
		v15:Disconnect()
		v15 = nil
	end

	v13 = p1

	local t = {}

	t[1] = LocalPlayer and LocalPlayer.Character
	v12 = t

	if p1 == nil then
		return
	end

	for i, v in ipairs((CollectionService:GetTagged(p1))) do
		table.insert(v12, v)
	end

	v14 = CollectionService:GetInstanceAddedSignal(p1):Connect(function(p1) --[[ Line: 147 | Upvalues: v12 (ref) ]]
		table.insert(v12, p1)
	end)
	v15 = CollectionService:GetInstanceRemovedSignal(p1):Connect(function(p1) --[[ Line: 151 | Upvalues: v12 (ref) ]]
		for i = 1, #v12 do
			if v12[i] == p1 then
				v12[i] = v12[#v12]
				table.remove(v12)

				return
			end
		end
	end)
end

local function getIgnoreList() --[[ getIgnoreList | Line: 163 | Upvalues: v12 (ref), LocalPlayer (copy) ]]
	if v12 then
		return v12
	end

	v12 = {}
	assert(v12, "")
	table.insert(v12, LocalPlayer and LocalPlayer.Character)

	return v12
end

local function minV(p1, p2) --[[ minV | Line: 173 ]]
	return Vector3.new(math.min(p1.X, p2.X), math.min(p1.Y, p2.Y), (math.min(p1.Z, p2.Z)))
end

local function maxV(p1, p2) --[[ maxV | Line: 176 ]]
	return Vector3.new(math.max(p1.X, p2.X), math.max(p1.Y, p2.Y), (math.max(p1.Z, p2.Z)))
end

local function getCollidableExtentsSize(p1) --[[ getCollidableExtentsSize | Line: 179 ]]
	if p1 == nil or p1.PrimaryPart == nil then
		return
	end

	assert(p1, "")
	assert(p1.PrimaryPart, "")

	local v1 = p1.PrimaryPart.CFrame:Inverse()
	local v2 = Vector3.new(inf, inf, inf)
	local v3 = Vector3.new(-inf, -inf, -inf)

	for k, v in pairs(p1:GetDescendants()) do
		if v:IsA("BasePart") and v.CanCollide then
			local v4 = v1 * v.CFrame
			local v8 = Vector3.new(v.Size.X / 2, v.Size.Y / 2, v.Size.Z / 2)
			local list = {}
			local v9 = Vector3.new(v8.X, v8.Y, v8.Z)
			local v11 = Vector3.new(v8.X, v8.Y, -v8.Z)
			local v13 = Vector3.new(v8.X, -v8.Y, v8.Z)
			local v16 = Vector3.new(v8.X, -v8.Y, -v8.Z)
			local v18 = Vector3.new(-v8.X, v8.Y, v8.Z)
			local v21 = Vector3.new(-v8.X, v8.Y, -v8.Z)
			local v24 = Vector3.new(-v8.X, -v8.Y, v8.Z)

			list[1] = v9
			list[2] = v11
			list[3] = v13
			list[4] = v16
			list[5] = v18
			list[6] = v21
			list[7] = v24
			list[8] = Vector3.new(-v8.X, -v8.Y, -v8.Z)

			for i, v28 in ipairs(list) do
				local v282 = v4 * v28

				v2, v3 = Vector3.new(math.min(v2.X, v282.X), math.min(v2.Y, v282.Y), (math.min(v2.Z, v282.Z))), Vector3.new(math.max(v3.X, v282.X), math.max(v3.Y, v282.Y), (math.max(v3.Z, v282.Z)))
			end
		end
	end

	local v37 = v3 - v2

	if v37.X < 0 or (v37.Y < 0 or v37.Z < 0) then
		return nil
	end

	return v37
end

local function Pather(p1, p2, p3) --[[ Pather | Line: 214 | Upvalues: v6 (ref), LocalPlayer (copy), t3 (copy), v7 (ref), v1 (copy), getCollidableExtentsSize (copy), v2 (copy), PathfindingService (copy), v4 (ref), ClickToMoveDisplay (copy), v8 (ref), v3 (copy), v9 (copy), v12 (ref), Workspace (copy) ]]
	local t = {}
	local v13, v22

	if p3 == nil then
		v13 = v6
		v22 = true
	else
		v22 = p3
		v13 = p3
	end

	t.Cancelled = false
	t.Started = false
	t.Finished = Instance.new("BindableEvent")
	t.PathFailed = Instance.new("BindableEvent")
	t.PathComputing = false
	t.PathComputed = false
	t.OriginalTargetPoint = p1
	t.TargetPoint = p1
	t.TargetSurfaceNormal = p2
	t.DiedConn = nil
	t.SeatedConn = nil
	t.BlockedConn = nil
	t.TeleportedConn = nil
	t.CurrentPoint = 0
	t.HumanoidOffsetFromPath = Vector3.new(0, 0, 0)
	t.CurrentWaypointPosition = nil
	t.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
	t.CurrentWaypointPlaneDistance = 0
	t.CurrentWaypointNeedsJump = false
	t.CurrentHumanoidPosition = Vector3.new(0, 0, 0)
	t.CurrentHumanoidVelocity = 0
	t.NextActionMoveDirection = Vector3.new(0, 0, 0)
	t.NextActionJump = false
	t.Timeout = 0

	local v32 = LocalPlayer
	local v42 = if v32 then v32.Character else v32
	local v5

	if v42 then
		local v62 = t3[v32]

		if v62 and v62.Parent == v42 then
			v5 = v62
		else
			t3[v32] = nil

			local Humanoid = v42:FindFirstChildOfClass("Humanoid")

			if Humanoid then
				t3[v32] = Humanoid
			end

			v5 = Humanoid
		end
	else
		v5 = nil
	end

	t.Humanoid = v5
	t.OriginPoint = nil
	t.AgentCanFollowPath = false
	t.DirectPath = false
	t.DirectPathRiseFirst = false
	t.stopTraverseFunc = nil
	t.setPointFunc = nil
	t.pointList = nil

	local v72 = t.Humanoid and t.Humanoid.RootPart

	if v72 then
		t.OriginPoint = v72.CFrame.Position

		local v82 = 2
		local v92 = 5
		local v10 = true
		local SeatPart = t.Humanoid.SeatPart

		if SeatPart and SeatPart:IsA("VehicleSeat") then
			local v11 = SeatPart:FindFirstAncestorOfClass("Model")

			if v11 then
				local PrimaryPart = v11.PrimaryPart

				v11.PrimaryPart = SeatPart

				if v22 then
					local v122 = v11:GetExtentsSize()

					v82 = v7 * 0.5 * math.sqrt(v122.X * v122.X + v122.Z * v122.Z)
					v92 = v7 * v122.Y
					t.AgentCanFollowPath = true
					t.DirectPath = v22
					v10 = false
				end

				v11.PrimaryPart = PrimaryPart
			end
		else
			local v15 = nil

			if v1 then
				local v16 = LocalPlayer and LocalPlayer.Character

				if v16 ~= nil then
					v15 = getCollidableExtentsSize(v16)
				end
			end

			if v15 == nil then
				v15 = (LocalPlayer and LocalPlayer.Character):GetExtentsSize()
			end

			assert(v15, "")
			v82 = v7 * 0.5 * math.sqrt(v15.X * v15.X + v15.Z * v15.Z)
			v92 = v7 * v15.Y
			v10 = if t.Humanoid.JumpPower > 0 then true else false
			t.AgentCanFollowPath = true
			t.DirectPath = v13
			t.DirectPathRiseFirst = t.Humanoid.Sit
		end

		if v2 then
			t.pathResult = PathfindingService:CreatePath({
				AgentCanClimb = true,
				AgentRadius = v82,
				AgentHeight = v92,
				AgentCanJump = v10
			})
		else
			t.pathResult = PathfindingService:CreatePath({
				AgentRadius = v82,
				AgentHeight = v92,
				AgentCanJump = v10
			})
		end
	end

	function t.Cleanup(p1) --[[ Cleanup | Line: 332 | Upvalues: t (copy) ]]
		if t.stopTraverseFunc then
			t.stopTraverseFunc()
			t.stopTraverseFunc = nil
		end

		if t.BlockedConn then
			t.BlockedConn:Disconnect()
			t.BlockedConn = nil
		end

		if t.DiedConn then
			t.DiedConn:Disconnect()
			t.DiedConn = nil
		end

		if t.SeatedConn then
			t.SeatedConn:Disconnect()
			t.SeatedConn = nil
		end

		if t.TeleportedConn then
			t.TeleportedConn:Disconnect()
			t.TeleportedConn = nil
		end

		t.Started = false
	end
	function t.Cancel(p1) --[[ Cancel | Line: 361 | Upvalues: t (copy) ]]
		t.Cancelled = true
		t:Cleanup()
	end
	function t.IsActive(p1) --[[ IsActive | Line: 366 | Upvalues: t (copy) ]]
		return t.AgentCanFollowPath and (t.Started and not t.Cancelled)
	end
	function t.OnPathInterrupted(p1) --[[ OnPathInterrupted | Line: 370 | Upvalues: t (copy) ]]
		t.Cancelled = true
		t:OnPointReached(false)
	end
	function t.ComputePath(p1) --[[ ComputePath | Line: 376 | Upvalues: t (copy) ]]
		if not t.OriginPoint then
			return
		end

		if t.PathComputed or t.PathComputing then
			return
		end

		t.PathComputing = true

		if t.AgentCanFollowPath then
			if t.DirectPath then
				local t2 = {}
				local v2 = PathWaypoint.new(t.OriginPoint, Enum.PathWaypointAction.Walk)
				local v3 = PathWaypoint.new
				local v4 = t.DirectPathRiseFirst and Enum.PathWaypointAction.Jump or Enum.PathWaypointAction.Walk

				t2[1] = v2
				t2[2] = v3(t.TargetPoint, v4)
				t.pointList = t2
				t.PathComputed = true
			else
				t.pathResult:ComputeAsync(t.OriginPoint, t.TargetPoint)
				t.pointList = t.pathResult:GetWaypoints()
				t.BlockedConn = t.pathResult.Blocked:Connect(function(p1) --[[ Line: 390 | Upvalues: t (ref) ]]
					t:OnPathBlocked(p1)
				end)

				local v5 = t

				v5.PathComputed = t.pathResult.Status == Enum.PathStatus.Success
			end
		end

		t.PathComputing = false
	end
	function t.IsValidPath(p1) --[[ IsValidPath | Line: 398 | Upvalues: t (copy) ]]
		t:ComputePath()

		return t.PathComputed and t.AgentCanFollowPath
	end
	t.Recomputing = false
	function t.OnPathBlocked(p1, p2) --[[ OnPathBlocked | Line: 404 | Upvalues: t (copy), v4 (ref), ClickToMoveDisplay (ref) ]]
		if not (t.CurrentPoint <= p2) or t.Recomputing then
			return
		end

		t.Recomputing = true

		if t.stopTraverseFunc then
			t.stopTraverseFunc()
			t.stopTraverseFunc = nil
		end

		t.OriginPoint = t.Humanoid.RootPart.CFrame.p
		t.pathResult:ComputeAsync(t.OriginPoint, t.TargetPoint)
		t.pointList = t.pathResult:GetWaypoints()

		if #t.pointList > 0 then
			t.HumanoidOffsetFromPath = t.pointList[1].Position - t.OriginPoint
		end

		t.PathComputed = t.pathResult.Status == Enum.PathStatus.Success

		if v4 then
			local v5, v6 = ClickToMoveDisplay.CreatePathDisplay(t.pointList)

			t.stopTraverseFunc = v5
			t.setPointFunc = v6
		end

		if t.PathComputed then
			t.CurrentPoint = 1
			t:OnPointReached(true)
		else
			t.PathFailed:Fire()
			t:Cleanup()
		end

		t.Recomputing = false
	end
	function t.OnRenderStepped(p1, p2) --[[ OnRenderStepped | Line: 440 | Upvalues: t (copy), v8 (ref) ]]
		if not t.Started or t.Cancelled then
			return
		end

		t.Timeout = t.Timeout + p2

		if v8 < t.Timeout then
			t:OnPointReached(false)

			return
		end

		t.CurrentHumanoidPosition = t.Humanoid.RootPart.Position + t.HumanoidOffsetFromPath
		t.CurrentHumanoidVelocity = t.Humanoid.RootPart.Velocity

		while t.Started and t:IsCurrentWaypointReached() do
			t:OnPointReached(true)
		end

		if not t.Started then
			return
		end

		t.NextActionMoveDirection = t.CurrentWaypointPosition - t.CurrentHumanoidPosition

		if t.NextActionMoveDirection.Magnitude > 1e-6 then
			t.NextActionMoveDirection = t.NextActionMoveDirection.Unit
		else
			t.NextActionMoveDirection = Vector3.new(0, 0, 0)
		end

		if t.CurrentWaypointNeedsJump then
			t.NextActionJump = true
			t.CurrentWaypointNeedsJump = false

			return
		end

		t.NextActionJump = false
	end
	function t.IsCurrentWaypointReached(p1) --[[ IsCurrentWaypointReached | Line: 478 | Upvalues: t (copy) ]]
		local v1

		if t.CurrentWaypointPlaneNormal == Vector3.new(0, 0, 0) then
			v1 = true
		else
			local v2 = t.CurrentWaypointPlaneNormal:Dot(t.CurrentHumanoidPosition) - t.CurrentWaypointPlaneDistance

			v1 = v2 < math.max(1, 0.0625 * -t.CurrentWaypointPlaneNormal:Dot(t.CurrentHumanoidVelocity))
		end

		if not v1 then
			return v1
		end

		t.CurrentWaypointPosition = nil
		t.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
		t.CurrentWaypointPlaneDistance = 0

		return v1
	end
	function t.OnPointReached(p1, p2) --[[ OnPointReached | Line: 504 | Upvalues: t (copy) ]]
		if not p2 or t.Cancelled then
			t.PathFailed:Fire()
			t:Cleanup()

			return
		end

		if t.setPointFunc then
			t.setPointFunc(t.CurrentPoint)
		end

		local v1 = t.CurrentPoint + 1

		if #t.pointList < v1 then
			if not t.stopTraverseFunc then
				t.Finished:Fire()
				t:Cleanup()

				return
			end

			t.stopTraverseFunc()
			t.Finished:Fire()
			t:Cleanup()
		else
			local v2 = t.pointList[t.CurrentPoint]
			local v3 = t.pointList[v1]
			local v4 = t.Humanoid:GetState()

			if if v4 == Enum.HumanoidStateType.FallingDown or v4 == Enum.HumanoidStateType.Freefall then true else v4 == Enum.HumanoidStateType.Jumping then
				local isJump = v3.Action == Enum.PathWaypointAction.Jump

				if not isJump and t.CurrentPoint > 1 then
					local v7 = v2.Position - t.pointList[t.CurrentPoint - 1].Position
					local v8 = v3.Position - v2.Position

					isJump = if Vector2.new(v7.x, v7.z).Unit:Dot(Vector2.new(v8.x, v8.z).Unit) < 0.996 then true else false
				end

				if isJump then
					t.Humanoid.FreeFalling:Wait()
					wait(0.1)
				end
			end

			t:MoveToNextWayPoint(v2, v3, v1)
		end
	end
	function t.MoveToNextWayPoint(p1, p2, p3, p4) --[[ MoveToNextWayPoint | Line: 567 | Upvalues: t (copy), v2 (ref) ]]
		t.CurrentWaypointPlaneNormal = p2.Position - p3.Position

		if not v2 or p3.Label ~= "Climb" then
			t.CurrentWaypointPlaneNormal = Vector3.new(t.CurrentWaypointPlaneNormal.X, 0, t.CurrentWaypointPlaneNormal.Z)
		end

		if t.CurrentWaypointPlaneNormal.Magnitude > 1e-6 then
			t.CurrentWaypointPlaneNormal = t.CurrentWaypointPlaneNormal.Unit
			t.CurrentWaypointPlaneDistance = t.CurrentWaypointPlaneNormal:Dot(p3.Position)
		else
			t.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			t.CurrentWaypointPlaneDistance = 0
		end

		t.CurrentWaypointNeedsJump = if p3.Action == Enum.PathWaypointAction.Jump then true else false
		t.CurrentWaypointPosition = p3.Position
		t.CurrentPoint = p4
		t.Timeout = 0
	end
	function t.Start(p1, p2) --[[ Start | Line: 599 | Upvalues: t (copy), ClickToMoveDisplay (ref), v4 (ref) ]]
		if not t.AgentCanFollowPath then
			t.PathFailed:Fire()

			return
		end

		if t.Started then
			return
		end

		t.Started = true
		ClickToMoveDisplay.CancelFailureAnimation()

		if v4 and (p2 == nil or p2) then
			local v3, v42 = ClickToMoveDisplay.CreatePathDisplay(t.pointList, t.OriginalTargetPoint)

			t.stopTraverseFunc = v3
			t.setPointFunc = v42
		end

		if #t.pointList > 0 then
			local v5 = t
			local v6 = t.pointList[1].Position.Y - t.OriginPoint.Y

			v5.HumanoidOffsetFromPath = Vector3.new(0, v6, 0)
			t.CurrentHumanoidPosition = t.Humanoid.RootPart.Position + t.HumanoidOffsetFromPath
			t.CurrentHumanoidVelocity = t.Humanoid.RootPart.Velocity
			t.SeatedConn = t.Humanoid.Seated:Connect(function(p1, p2) --[[ Line: 626 | Upvalues: t (ref) ]]
				t:OnPathInterrupted()
			end)
			t.DiedConn = t.Humanoid.Died:Connect(function() --[[ Line: 627 | Upvalues: t (ref) ]]
				t:OnPathInterrupted()
			end)
			t.TeleportedConn = t.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function() --[[ Line: 628 | Upvalues: t (ref) ]]
				t:OnPathInterrupted()
			end)
			t.CurrentPoint = 1
			t:OnPointReached(true)

			return
		end

		t.PathFailed:Fire()

		if not t.stopTraverseFunc then
			return
		end

		t.stopTraverseFunc()
	end

	local v222 = t.TargetPoint + t.TargetSurfaceNormal * 1.5

	if v3 then
		if not v12 then
			v12 = {}
			assert(v12, "")
			table.insert(v12, LocalPlayer and LocalPlayer.Character)
		end

		v9.FilterDescendantsInstances = v12

		local v28 = Workspace:Raycast(v222, Vector3.new(-0, -50, -0), v9)

		if v28 then
			t.TargetPoint = v28.Position
		end
	else
		local v29 = Ray.new(v222, Vector3.new(0, -50, 0))

		if not v12 then
			v12 = {}
			assert(v12, "")
			table.insert(v12, LocalPlayer and LocalPlayer.Character)
		end

		local v36, v37 = Workspace:FindPartOnRayWithIgnoreList(v29, v12)

		if v36 then
			t.TargetPoint = v37
		end
	end

	t:ComputePath()

	return t
end

local function CheckAlive() --[[ CheckAlive | Line: 664 | Upvalues: LocalPlayer (copy), t3 (copy) ]]
	local v1 = LocalPlayer
	local v2 = if v1 then v1.Character else v1
	local v3

	if v2 then
		local v4 = t3[v1]

		if v4 and v4.Parent == v2 then
			v3 = v4
		else
			t3[v1] = nil

			local Humanoid = v2:FindFirstChildOfClass("Humanoid")

			if Humanoid then
				t3[v1] = Humanoid
			end

			v3 = Humanoid
		end
	else
		v3 = nil
	end

	return if v3 == nil then false else v3.Health > 0
end

local function GetEquippedTool(p1) --[[ GetEquippedTool | Line: 669 ]]
	if p1 == nil then
		return
	end

	for k, v in pairs(p1:GetChildren()) do
		if v:IsA("Tool") then
			return v
		end
	end
end

local v16 = nil
local v17 = nil
local v18 = nil

local function CleanupPath() --[[ CleanupPath | Line: 684 | Upvalues: v16 (ref), v17 (ref), v18 (ref) ]]
	if v16 then
		v16:Cancel()
		v16 = nil
	end

	if v17 then
		v17:Disconnect()
		v17 = nil
	end

	if not v18 then
		return
	end

	v18:Disconnect()
	v18 = nil
end

local function HandleMoveTo(p1, p2, p3, p4, p5) --[[ HandleMoveTo | Line: 702 | Upvalues: v16 (ref), v17 (ref), v18 (ref), GetEquippedTool (copy), v5 (ref), ClickToMoveDisplay (copy) ]]
	if v16 then
		if v16 then
			v16:Cancel()
			v16 = nil
		end

		if v17 then
			v17:Disconnect()
			v17 = nil
		end

		if v18 then
			v18:Disconnect()
			v18 = nil
		end
	end

	v16 = p1
	p1:Start(p5)
	v17 = p1.Finished.Event:Connect(function() --[[ Line: 709 | Upvalues: v16 (ref), v17 (ref), v18 (ref), p3 (copy), GetEquippedTool (ref), p4 (copy) ]]
		if v16 then
			v16:Cancel()
			v16 = nil
		end

		if v17 then
			v17:Disconnect()
			v17 = nil
		end

		if v18 then
			v18:Disconnect()
			v18 = nil
		end

		if not p3 then
			return
		end

		local v1 = GetEquippedTool(p4)

		if not v1 then
			return
		end

		v1:Activate()
	end)
	v18 = p1.PathFailed.Event:Connect(function() --[[ Line: 718 | Upvalues: v16 (ref), v17 (ref), v18 (ref), p5 (copy), v5 (ref), ClickToMoveDisplay (ref), p2 (copy) ]]
		if v16 then
			v16:Cancel()
			v16 = nil
		end

		if v17 then
			v17:Disconnect()
			v17 = nil
		end

		if v18 then
			v18:Disconnect()
			v18 = nil
		end

		if p5 ~= nil and not p5 then
			return
		end

		local v1 = v5

		if v1 then
			v1 = not (v16 and v16:IsActive())
		end

		if v1 then
			ClickToMoveDisplay.PlayFailureAnimation()
		end

		ClickToMoveDisplay.DisplayFailureWaypoint(p2)
	end)
end

local function ShowPathFailedFeedback(p1) --[[ ShowPathFailedFeedback | Line: 730 | Upvalues: v16 (ref), v5 (ref), ClickToMoveDisplay (copy) ]]
	if v16 and v16:IsActive() then
		v16:Cancel()
	end

	if not v5 then
		ClickToMoveDisplay.DisplayFailureWaypoint(p1)

		return
	end

	ClickToMoveDisplay.PlayFailureAnimation()
	ClickToMoveDisplay.DisplayFailureWaypoint(p1)
end

function OnTap(p1, p2, p3) --[[ OnTap | Line: 740 | Upvalues: Workspace (copy), LocalPlayer (copy), t3 (copy), v3 (copy), v12 (ref), v9 (copy), StarterGui (copy), Players (copy), v16 (ref), v17 (ref), v18 (ref), Pather (copy), HandleMoveTo (copy), v5 (ref), ClickToMoveDisplay (copy), t2 (copy), GetEquippedTool (copy) ]]
	local CurrentCamera = Workspace.CurrentCamera
	local Character = LocalPlayer.Character
	local v1 = LocalPlayer
	local v2 = if v1 then v1.Character else v1
	local v32

	if v2 then
		local v4 = t3[v1]

		if v4 and v4.Parent == v2 then
			v32 = v4
		else
			t3[v1] = nil

			local Humanoid = v2:FindFirstChildOfClass("Humanoid")

			if Humanoid then
				t3[v1] = Humanoid
			end

			v32 = Humanoid
		end
	else
		v32 = nil
	end

	if not (if v32 == nil then false else v32.Health > 0) then
		return
	end

	if #p1 == 1 or p2 then
		if not CurrentCamera then
			return
		end

		local v6 = CurrentCamera:ScreenPointToRay(p1[1].X, p1[1].Y)

		if v3 then
			local v7 = nil
			local v8 = nil

			if not v12 then
				v12 = {}
				assert(v12, "")
				table.insert(v12, LocalPlayer and LocalPlayer.Character)
			end

			local v122 = v12 or {}
			local v13

			repeat
				local v14, v15
				local v162 = true

				v9.FilterDescendantsInstances = v122

				local v172 = Workspace:Raycast(v6.Origin, v6.Direction * 1000, v9)

				if v172 then
					local v182 = v172.Instance

					if v182.CanCollide then
						v13 = v172

						continue
					end

					v13 = v172

					while true do
						v14 = v182:FindFirstChildOfClass("Humanoid")
						v15 = v182.Parent

						if v14 or not v15 then
							break
						end

						v182 = v15
					end

					if v14 or not v15 then
						v7 = v14
						v8 = v182

						continue
					end

					table.insert(v122, v15)
					v162 = false
					v7 = v14
					v8 = nil

					continue
				end

				v13 = v172
			until v162

			if p3 and (v7 and (StarterGui:GetCore("AvatarContextMenuEnabled") and Players:GetPlayerFromCharacter(v7.Parent))) then
				if v16 then
					v16:Cancel()
					v16 = nil
				end

				if v17 then
					v17:Disconnect()
					v17 = nil
				end

				if not v18 then
					return
				end

				v18:Disconnect()
				v18 = nil
			else
				if not (v13 and Character) then
					return
				end

				local Position = v13.Position

				if p2 then
					Position = p2
					v8 = nil
				end

				if v16 then
					v16:Cancel()
					v16 = nil
				end

				if v17 then
					v17:Disconnect()
					v17 = nil
				end

				if v18 then
					v18:Disconnect()
					v18 = nil
				end

				local v19 = Pather(Position, v13.Normal)

				if v19:IsValidPath() then
					HandleMoveTo(v19, Position, v8, Character)

					return
				end

				v19:Cleanup()

				if v16 and v16:IsActive() then
					v16:Cancel()
				end

				if v5 then
					ClickToMoveDisplay.PlayFailureAnimation()
				end

				ClickToMoveDisplay.DisplayFailureWaypoint(Position)
			end
		else
			local v20 = Ray.new(v6.Origin, v6.Direction * 1000)

			if not v12 then
				v12 = {}
				assert(v12, "")
				table.insert(v12, LocalPlayer and LocalPlayer.Character)
			end

			local v27, v28, v29 = t2.Raycast(v20, true, v12)
			local v30, v31 = t2.FindCharacterAncestor(v27)

			if p3 and (v31 and (StarterGui:GetCore("AvatarContextMenuEnabled") and Players:GetPlayerFromCharacter(v31.Parent))) then
				if v16 then
					v16:Cancel()
					v16 = nil
				end

				if v17 then
					v17:Disconnect()
					v17 = nil
				end

				if not v18 then
					return
				end

				v18:Disconnect()
				v18 = nil
			else
				if p2 then
					v28 = p2
					v30 = nil
				end

				if not (v28 and Character) then
					return
				end

				if v16 then
					v16:Cancel()
					v16 = nil
				end

				if v17 then
					v17:Disconnect()
					v17 = nil
				end

				if v18 then
					v18:Disconnect()
					v18 = nil
				end

				local v322 = Pather(v28, v29)

				if v322:IsValidPath() then
					HandleMoveTo(v322, v28, v30, Character)

					return
				end

				v322:Cleanup()

				if v16 and v16:IsActive() then
					v16:Cancel()
				end

				if v5 then
					ClickToMoveDisplay.PlayFailureAnimation()
				end

				ClickToMoveDisplay.DisplayFailureWaypoint(v28)
			end
		end

		return
	end

	if not (#p1 >= 2 and CurrentCamera) then
		return
	end

	local v33 = GetEquippedTool(Character)

	if not v33 then
		return
	end

	v33:Activate()
end

local function DisconnectEvent(p1) --[[ DisconnectEvent | Line: 850 ]]
	if not p1 then
		return
	end

	p1:Disconnect()
end

local Keyboard = require(script.Parent:WaitForChild("Keyboard"))
local v19 = setmetatable({}, Keyboard)

v19.__index = v19
function v19.new(p1) --[[ new | Line: 861 | Upvalues: Keyboard (copy), v19 (copy) ]]
	local v3 = setmetatable(Keyboard.new(p1), v19)

	v3.fingerTouches = {}
	v3.numUnsunkTouches = 0
	v3.mouse2DownTime = tick()
	v3.mouse2DownPos = Vector2.new()
	v3.mouse2UpTime = tick()
	v3.keyboardMoveVector = Vector3.new(0, 0, 0)
	v3.tapConn = nil
	v3.inputBeganConn = nil
	v3.inputChangedConn = nil
	v3.inputEndedConn = nil
	v3.humanoidDiedConn = nil
	v3.characterChildAddedConn = nil
	v3.onCharacterAddedConn = nil
	v3.characterChildRemovedConn = nil
	v3.renderSteppedConn = nil
	v3.menuOpenedConnection = nil
	v3.preferredInputChangedConnection = nil
	v3.running = false
	v3.wasdEnabled = false

	return v3
end
function v19.DisconnectEvents(p1) --[[ DisconnectEvents | Line: 892 ]]
	local tapConn = p1.tapConn

	if tapConn then
		tapConn:Disconnect()
	end

	local inputBeganConn = p1.inputBeganConn

	if inputBeganConn then
		inputBeganConn:Disconnect()
	end

	local inputChangedConn = p1.inputChangedConn

	if inputChangedConn then
		inputChangedConn:Disconnect()
	end

	local inputEndedConn = p1.inputEndedConn

	if inputEndedConn then
		inputEndedConn:Disconnect()
	end

	local humanoidDiedConn = p1.humanoidDiedConn

	if humanoidDiedConn then
		humanoidDiedConn:Disconnect()
	end

	local characterChildAddedConn = p1.characterChildAddedConn

	if characterChildAddedConn then
		characterChildAddedConn:Disconnect()
	end

	local onCharacterAddedConn = p1.onCharacterAddedConn

	if onCharacterAddedConn then
		onCharacterAddedConn:Disconnect()
	end

	local renderSteppedConn = p1.renderSteppedConn

	if renderSteppedConn then
		renderSteppedConn:Disconnect()
	end

	local characterChildRemovedConn = p1.characterChildRemovedConn

	if characterChildRemovedConn then
		characterChildRemovedConn:Disconnect()
	end

	local menuOpenedConnection = p1.menuOpenedConnection

	if menuOpenedConnection then
		menuOpenedConnection:Disconnect()
	end

	local preferredInputChangedConnection = p1.preferredInputChangedConnection

	if not preferredInputChangedConnection then
		return
	end

	preferredInputChangedConnection:Disconnect()
end
function v19.OnTouchBegan(p1, p2, p3) --[[ OnTouchBegan | Line: 906 ]]
	if p1.fingerTouches[p2] == nil and not p3 then
		p1.numUnsunkTouches = p1.numUnsunkTouches + 1
	end

	p1.fingerTouches[p2] = p3
end
function v19.OnTouchChanged(p1, p2, p3) --[[ OnTouchChanged | Line: 913 ]]
	if p1.fingerTouches[p2] ~= nil then
		return
	end

	p1.fingerTouches[p2] = p3

	if p3 then
		return
	end

	p1.numUnsunkTouches = p1.numUnsunkTouches + 1
end
function v19.OnTouchEnded(p1, p2, p3) --[[ OnTouchEnded | Line: 922 ]]
	if p1.fingerTouches[p2] ~= nil and p1.fingerTouches[p2] == false then
		p1.numUnsunkTouches = p1.numUnsunkTouches - 1
	end

	p1.fingerTouches[p2] = nil
end
function v19.OnPreferredInputChanged(p1) --[[ OnPreferredInputChanged | Line: 929 | Upvalues: LocalPlayer (copy), UserInputService (copy) ]]
	local Character = LocalPlayer.Character

	if not Character then
		return
	end

	local isTouch = UserInputService.PreferredInput == Enum.PreferredInput.Touch

	for k, v in pairs(Character:GetChildren()) do
		if v:IsA("Tool") then
			v.ManualActivationOnly = isTouch
		end
	end
end
function v19.OnCharacterAdded(p1, p2) --[[ OnCharacterAdded | Line: 941 | Upvalues: UserInputService (copy), t (copy), v16 (ref), v17 (ref), v18 (ref), ClickToMoveDisplay (copy), GuiService (copy) ]]
	p1:DisconnectEvents()
	p1.inputBeganConn = UserInputService.InputBegan:Connect(function(p12, p2) --[[ Line: 944 | Upvalues: p1 (copy), t (ref), v16 (ref), v17 (ref), v18 (ref), ClickToMoveDisplay (ref) ]]
		if p12.UserInputType == Enum.UserInputType.Touch then
			p1:OnTouchBegan(p12, p2)
		end

		if p1.wasdEnabled and (p2 == false and (p12.UserInputType == Enum.UserInputType.Keyboard and t[p12.KeyCode])) then
			if v16 then
				v16:Cancel()
				v16 = nil
			end

			if v17 then
				v17:Disconnect()
				v17 = nil
			end

			if v18 then
				v18:Disconnect()
				v18 = nil
			end

			ClickToMoveDisplay.CancelFailureAnimation()
		end

		if p12.UserInputType ~= Enum.UserInputType.MouseButton2 then
			return
		end

		p1.mouse2DownTime = tick()
		p1.mouse2DownPos = p12.Position
	end)
	p1.inputChangedConn = UserInputService.InputChanged:Connect(function(p12, p2) --[[ Line: 961 | Upvalues: p1 (copy) ]]
		if p12.UserInputType ~= Enum.UserInputType.Touch then
			return
		end

		p1:OnTouchChanged(p12, p2)
	end)
	p1.inputEndedConn = UserInputService.InputEnded:Connect(function(p12, p2) --[[ Line: 967 | Upvalues: p1 (copy), v16 (ref) ]]
		if p12.UserInputType == Enum.UserInputType.Touch then
			p1:OnTouchEnded(p12, p2)
		end

		if p12.UserInputType ~= Enum.UserInputType.MouseButton2 then
			return
		end

		p1.mouse2UpTime = tick()

		local Position = p12.Position

		if not (p1.mouse2UpTime - p1.mouse2DownTime < 0.25 and ((Position - p1.mouse2DownPos).magnitude < 5 and (v16 or p1.keyboardMoveVector.Magnitude <= 0))) then
			return
		end

		OnTap({ Position })
	end)
	p1.tapConn = UserInputService.TouchTap:Connect(function(p1, p2) --[[ Line: 984 ]]
		if p2 then
			return
		end

		OnTap(p1, nil, true)
	end)
	p1.menuOpenedConnection = GuiService.MenuOpened:Connect(function() --[[ Line: 990 | Upvalues: v16 (ref), v17 (ref), v18 (ref) ]]
		if v16 then
			v16:Cancel()
			v16 = nil
		end

		if v17 then
			v17:Disconnect()
			v17 = nil
		end

		if not v18 then
			return
		end

		v18:Disconnect()
		v18 = nil
	end)

	local function OnCharacterChildAdded(p12) --[[ OnCharacterChildAdded | Line: 994 | Upvalues: UserInputService (ref), p1 (copy) ]]
		if UserInputService.PreferredInput == Enum.PreferredInput.Touch and p12:IsA("Tool") then
			p12.ManualActivationOnly = true
		end

		if not p12:IsA("Humanoid") then
			return
		end

		local humanoidDiedConn = p1.humanoidDiedConn

		if humanoidDiedConn then
			humanoidDiedConn:Disconnect()
		end

		p1.humanoidDiedConn = p12.Died:Connect(function() --[[ Line: 1002 ]] end)
	end

	p1.characterChildAddedConn = p2.ChildAdded:Connect(function(p1) --[[ Line: 1010 | Upvalues: OnCharacterChildAdded (copy) ]]
		OnCharacterChildAdded(p1)
	end)
	p1.characterChildRemovedConn = p2.ChildRemoved:Connect(function(p1) --[[ Line: 1013 | Upvalues: UserInputService (ref) ]]
		if UserInputService.PreferredInput ~= Enum.PreferredInput.Touch or not p1:IsA("Tool") then
			return
		end

		p1.ManualActivationOnly = false
	end)

	for k, v in pairs(p2:GetChildren()) do
		OnCharacterChildAdded(v)
	end

	p1.preferredInputChangedConnection = UserInputService:GetPropertyChangedSignal("PreferredInput"):Connect(function() --[[ Line: 1024 | Upvalues: p1 (copy) ]]
		p1:OnPreferredInputChanged()
	end)
end
function v19.Start(p1) --[[ Start | Line: 1029 ]]
	p1:Enable(true)
end
function v19.Stop(p1) --[[ Stop | Line: 1033 ]]
	p1:Enable(false)
end
function v19.CleanupPath(p1) --[[ CleanupPath | Line: 1037 | Upvalues: v16 (ref), v17 (ref), v18 (ref) ]]
	if v16 then
		v16:Cancel()
		v16 = nil
	end

	if v17 then
		v17:Disconnect()
		v17 = nil
	end

	if not v18 then
		return
	end

	v18:Disconnect()
	v18 = nil
end
function v19.Enable(p1, p2, p3, p4) --[[ Enable | Line: 1041 | Upvalues: LocalPlayer (copy), v16 (ref), v17 (ref), v18 (ref), UserInputService (copy), Keyboard (copy) ]]
	if p2 then
		if not p1.running then
			if LocalPlayer.Character then
				p1:OnCharacterAdded(LocalPlayer.Character)
			end

			p1.onCharacterAddedConn = LocalPlayer.CharacterAdded:Connect(function(p12) --[[ Line: 1047 | Upvalues: p1 (copy) ]]
				p1:OnCharacterAdded(p12)
			end)
			p1.running = true
		end

		p1.touchJumpController = p4

		if p1.touchJumpController then
			p1.touchJumpController:Enable(p1.jumpEnabled)
		end
	else
		if p1.running then
			p1:DisconnectEvents()

			if v16 then
				v16:Cancel()
				v16 = nil
			end

			if v17 then
				v17:Disconnect()
				v17 = nil
			end

			if v18 then
				v18:Disconnect()
				v18 = nil
			end

			if UserInputService.PreferredInput == Enum.PreferredInput.Touch then
				local Character = LocalPlayer.Character

				if Character then
					for k, v in pairs(Character:GetChildren()) do
						if v:IsA("Tool") then
							v.ManualActivationOnly = false
						end
					end
				end
			end

			p1.running = false
		end

		if p1.touchJumpController and not p1.jumpEnabled then
			p1.touchJumpController:Enable(true)
		end

		p1.touchJumpController = nil
	end

	Keyboard.Enable(p1, p2)
	p1.wasdEnabled = if p2 and p3 then p3 else false
	p1.enabled = p2
end
function v19.OnRenderStepped(p1, p2) --[[ OnRenderStepped | Line: 1086 | Upvalues: v16 (ref) ]]
	p1.isJumping = false

	if v16 then
		v16:OnRenderStepped(p2)

		if v16 then
			p1.moveVector = v16.NextActionMoveDirection
			p1.moveVectorIsCameraRelative = false

			if v16.NextActionJump then
				p1.isJumping = true
			end
		else
			p1.moveVector = p1.keyboardMoveVector
			p1.moveVectorIsCameraRelative = true
		end
	else
		p1.moveVector = p1.keyboardMoveVector
		p1.moveVectorIsCameraRelative = true
	end

	if not p1.jumpRequested then
		return
	end

	p1.isJumping = true
end
function v19.UpdateMovement(p1, p2) --[[ UpdateMovement | Line: 1121 ]]
	if p2 == Enum.UserInputState.Cancel then
		p1.keyboardMoveVector = Vector3.new(0, 0, 0)

		return
	end

	if not p1.wasdEnabled then
		return
	end

	p1.keyboardMoveVector = Vector3.new(p1.leftValue + p1.rightValue, 0, p1.forwardValue + p1.backwardValue)
end
function v19.UpdateJump(p1) --[[ UpdateJump | Line: 1130 ]] end
function v19.SetShowPath(p1, p2) --[[ SetShowPath | Line: 1135 | Upvalues: v4 (ref) ]]
	v4 = p2
end
function v19.GetShowPath(p1) --[[ GetShowPath | Line: 1139 | Upvalues: v4 (ref) ]]
	return v4
end
function v19.SetWaypointTexture(p1, p2) --[[ SetWaypointTexture | Line: 1143 | Upvalues: ClickToMoveDisplay (copy) ]]
	ClickToMoveDisplay.SetWaypointTexture(p2)
end
function v19.GetWaypointTexture(p1) --[[ GetWaypointTexture | Line: 1147 | Upvalues: ClickToMoveDisplay (copy) ]]
	return ClickToMoveDisplay.GetWaypointTexture()
end
function v19.SetWaypointRadius(p1, p2) --[[ SetWaypointRadius | Line: 1151 | Upvalues: ClickToMoveDisplay (copy) ]]
	ClickToMoveDisplay.SetWaypointRadius(p2)
end
function v19.GetWaypointRadius(p1) --[[ GetWaypointRadius | Line: 1155 | Upvalues: ClickToMoveDisplay (copy) ]]
	return ClickToMoveDisplay.GetWaypointRadius()
end
function v19.SetEndWaypointTexture(p1, p2) --[[ SetEndWaypointTexture | Line: 1159 | Upvalues: ClickToMoveDisplay (copy) ]]
	ClickToMoveDisplay.SetEndWaypointTexture(p2)
end
function v19.GetEndWaypointTexture(p1) --[[ GetEndWaypointTexture | Line: 1163 | Upvalues: ClickToMoveDisplay (copy) ]]
	return ClickToMoveDisplay.GetEndWaypointTexture()
end
function v19.SetWaypointsAlwaysOnTop(p1, p2) --[[ SetWaypointsAlwaysOnTop | Line: 1167 | Upvalues: ClickToMoveDisplay (copy) ]]
	ClickToMoveDisplay.SetWaypointsAlwaysOnTop(p2)
end
function v19.GetWaypointsAlwaysOnTop(p1) --[[ GetWaypointsAlwaysOnTop | Line: 1171 | Upvalues: ClickToMoveDisplay (copy) ]]
	return ClickToMoveDisplay.GetWaypointsAlwaysOnTop()
end
function v19.SetFailureAnimationEnabled(p1, p2) --[[ SetFailureAnimationEnabled | Line: 1175 | Upvalues: v5 (ref) ]]
	v5 = p2
end
function v19.GetFailureAnimationEnabled(p1) --[[ GetFailureAnimationEnabled | Line: 1179 | Upvalues: v5 (ref) ]]
	return v5
end
function v19.SetIgnoredPartsTag(p1, p2) --[[ SetIgnoredPartsTag | Line: 1183 | Upvalues: UpdateIgnoreTag (copy) ]]
	UpdateIgnoreTag(p2)
end
function v19.GetIgnoredPartsTag(p1) --[[ GetIgnoredPartsTag | Line: 1187 | Upvalues: v13 (ref) ]]
	return v13
end
function v19.SetUseDirectPath(p1, p2) --[[ SetUseDirectPath | Line: 1191 | Upvalues: v6 (ref) ]]
	v6 = p2
end
function v19.GetUseDirectPath(p1) --[[ GetUseDirectPath | Line: 1195 | Upvalues: v6 (ref) ]]
	return v6
end
function v19.SetAgentSizeIncreaseFactor(p1, p2) --[[ SetAgentSizeIncreaseFactor | Line: 1199 | Upvalues: v7 (ref) ]]
	v7 = p2 / 100 + 1
end
function v19.GetAgentSizeIncreaseFactor(p1) --[[ GetAgentSizeIncreaseFactor | Line: 1203 | Upvalues: v7 (ref) ]]
	return (v7 - 1) * 100
end
function v19.SetUnreachableWaypointTimeout(p1, p2) --[[ SetUnreachableWaypointTimeout | Line: 1207 | Upvalues: v8 (ref) ]]
	v8 = p2
end
function v19.GetUnreachableWaypointTimeout(p1) --[[ GetUnreachableWaypointTimeout | Line: 1211 | Upvalues: v8 (ref) ]]
	return v8
end
function v19.SetUserJumpEnabled(p1, p2) --[[ SetUserJumpEnabled | Line: 1215 ]]
	p1.jumpEnabled = p2

	if not p1.touchJumpController then
		return
	end

	p1.touchJumpController:Enable(p2)
end
function v19.GetUserJumpEnabled(p1) --[[ GetUserJumpEnabled | Line: 1222 ]]
	return p1.jumpEnabled
end
function v19.MoveTo(p1, p2, p3, p4) --[[ MoveTo | Line: 1226 | Upvalues: LocalPlayer (copy), Pather (copy), HandleMoveTo (copy) ]]
	local Character = LocalPlayer.Character

	if Character == nil then
		return false
	end

	local v1 = Pather(p2, Vector3.new(0, 1, 0), p4)

	if v1 and v1:IsValidPath() then
		HandleMoveTo(v1, p2, nil, Character, p3)

		return true
	end

	return false
end

return v19