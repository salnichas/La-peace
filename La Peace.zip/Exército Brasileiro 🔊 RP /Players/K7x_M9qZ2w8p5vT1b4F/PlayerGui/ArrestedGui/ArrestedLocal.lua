-- https://lua.expert/
local v1 = script.Parent
local Close = v1:WaitForChild("Main"):WaitForChild("Close")

local function closeGUI() --[[ closeGUI | Line: 5 | Upvalues: v1 (copy) ]]
	if not v1.Enabled then
		return
	end

	v1.Enabled = false
end

Close.Activated:Connect(closeGUI)