-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local BackpackItems = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("BackpackItems")
local BackpackItems2 = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("BackpackItems")
local LocalPlayer = Players.LocalPlayer
local v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
local Backpack = LocalPlayer:WaitForChild("Backpack")
local Close = script.Parent:FindFirstChild("Close")
local ScrollingFrame = script.Parent:WaitForChild("ScrollingFrame")
local t = {}

local function UpdateEquipped(p1) --[[ UpdateEquipped | Line: 26 | Upvalues: t (copy), Backpack (copy), v1 (ref) ]]
	local v12 = t[p1]

	if not v12 then
		return
	end

	local IsEquipped = v12:FindFirstChild("IsEquipped")

	if not IsEquipped then
		return
	end

	if Backpack:FindFirstChild(p1) or v1:FindFirstChild(p1) then
		IsEquipped.Visible = true
	else
		IsEquipped.Visible = false
	end
end

local function CreateItems() --[[ CreateItems | Line: 41 | Upvalues: LocalPlayer (copy), BackpackItems (copy), ScrollingFrame (copy), t (copy), Backpack (copy), v1 (ref), BackpackItems2 (copy) ]]
	local CooldownStorage = Instance.new("Folder")

	CooldownStorage.Name = "CooldownStorage"
	CooldownStorage.Parent = LocalPlayer

	for v12, v2 in BackpackItems:GetChildren() do
		if v2:IsA("Tool") then
			local v3 = v2.Name
			local v4 = v2:GetAttribute("ItemImage")
			local v5 = script:WaitForChild("Template"):Clone()

			v5.Name = v3
			v5.ContentImage.Image = v4
			v5.Parent = ScrollingFrame
			t[v3] = v5

			local v6 = t[v3]

			if v6 then
				local IsEquipped = v6:FindFirstChild("IsEquipped")

				if IsEquipped and (Backpack:FindFirstChild(v3) or v1:FindFirstChild(v3)) then
					IsEquipped.Visible = true
				elseif IsEquipped then
					IsEquipped.Visible = false
				end
			end

			v5.ContentImage.MouseButton1Down:Connect(function() --[[ Line: 64 | Upvalues: CooldownStorage (copy), v3 (copy), Backpack (ref), v1 (ref), BackpackItems2 (ref) ]]
				if CooldownStorage:FindFirstChild(v3) then
					return
				end

				if Backpack:FindFirstChild(v3) or v1:FindFirstChild(v3) then
					BackpackItems2:FireServer("UnequipTool", v3)
				else
					BackpackItems2:FireServer("EquipTool", v3)
				end
			end)
		end
	end
end

local function SetupListeners(p1) --[[ SetupListeners | Line: 179 | Upvalues: t (copy), Backpack (copy), v1 (ref) ]]
	p1.ChildAdded:Connect(function(p1) --[[ Line: 180 | Upvalues: t (ref), Backpack (ref), v1 (ref) ]]
		if not p1:IsA("Tool") then
			return
		end

		local v12 = p1.Name
		local v2 = t[v12]

		if not v2 then
			return
		end

		local IsEquipped = v2:FindFirstChild("IsEquipped")

		if not IsEquipped then
			return
		end

		if Backpack:FindFirstChild(v12) or v1:FindFirstChild(v12) then
			IsEquipped.Visible = true

			return
		end

		IsEquipped.Visible = false
	end)
	p1.ChildRemoved:Connect(function(p1) --[[ Line: 186 | Upvalues: t (ref), Backpack (ref), v1 (ref) ]]
		if not p1:IsA("Tool") then
			return
		end

		local v12 = p1.Name
		local v2 = t[v12]

		if not v2 then
			return
		end

		local IsEquipped = v2:FindFirstChild("IsEquipped")

		if not IsEquipped then
			return
		end

		if Backpack:FindFirstChild(v12) or v1:FindFirstChild(v12) then
			IsEquipped.Visible = true

			return
		end

		IsEquipped.Visible = false
	end)
end

SetupListeners(Backpack)
SetupListeners(v1)
LocalPlayer.CharacterAdded:Connect(function(p1) --[[ Line: 198 | Upvalues: v1 (ref), SetupListeners (copy) ]]
	v1 = p1
	SetupListeners(p1)
end)
Close.MouseButton1Down:Connect(function() --[[ Line: 204 ]]
	script.Parent.Parent.Enabled = false
end)
task.delay(0.25, CreateItems)