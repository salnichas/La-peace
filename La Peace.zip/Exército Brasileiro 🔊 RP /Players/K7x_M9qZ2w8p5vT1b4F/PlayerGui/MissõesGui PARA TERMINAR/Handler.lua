-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

game:GetService("RunService")

local LocalPlayer = Players.LocalPlayer
local v1 = LocalPlayer:WaitForChild("Miss\195\181esData", 60)
local TempoJogado = v1:WaitForChild("TempoJogado", 60)
local GramasCortadas = v1:WaitForChild("GramasCortadas", 60)
local LixosRecolhidos = v1:WaitForChild("LixosRecolhidos", 60)
local v2 = v1:WaitForChild("Miss\195\163oAtual", 60)
local FinishedRankMission = v1:WaitForChild("FinishedRankMission", 60)
local FinishedEventMission = v1:WaitForChild("FinishedEventMission", 60)
local LastMissionTime = v1:WaitForChild("LastMissionTime", 60)
local Handler = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("Events"):WaitForChild("Miss\195\163o"):WaitForChild("Handler")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local NotificationClient = require(Modules:WaitForChild("NotificationClient"))
local v3 = script.Parent
local Main = v3:WaitForChild("Main")
local Background = Main:WaitForChild("Background")
local Container = Background:WaitForChild("Container")
local Models = Container:WaitForChild("Models")

Container:WaitForChild("Info")
Container:WaitForChild("Title")

local Completed = Models:WaitForChild("Completed")
local Title = Completed:WaitForChild("Title")
local Description = Completed:WaitForChild("Description")
local Cooldown = Models:WaitForChild("Cooldown")

Cooldown:WaitForChild("Title")
Cooldown:WaitForChild("Timer")
Cooldown:WaitForChild("Description")

local Error = Models:WaitForChild("Error")

Error:WaitForChild("Title")
Error:WaitForChild("Description")
Models:WaitForChild("Loading"):WaitForChild("Icon")

local Options = Models:WaitForChild("Options")

Options:WaitForChild("Eventos"):WaitForChild("Blocked")
Options:WaitForChild("Graduados"):WaitForChild("Blocked")
Options:WaitForChild("Pracas"):WaitForChild("Blocked")

local QuestTemplate = Models:WaitForChild("QuestTemplate")
local Data = QuestTemplate:WaitForChild("Data")
local Bar = Data:WaitForChild("Bar")

Bar:WaitForChild("Progress")
Bar:WaitForChild("Percentage")
Data:WaitForChild("Items"):WaitForChild("Template")
Data:WaitForChild("Line")
Data:WaitForChild("Name")

local Rewards = QuestTemplate:WaitForChild("Rewards")

Rewards:WaitForChild("Container"):WaitForChild("Template")
Rewards:WaitForChild("Title"):WaitForChild("Text")

local Close = Background:WaitForChild("Close")

while not LocalPlayer:GetAttribute("RanksAndRolesLoaded") do
	LocalPlayer:GetAttributeChangedSignal("RanksAndRolesLoaded"):Wait()
end

local PlayerInfos = LocalPlayer:WaitForChild("PlayerInfos", 60)
local v4

if PlayerInfos then
	if not PlayerInfos:GetAttribute("EB_Rank") then
		return
	end

	if typeof(PlayerInfos:GetAttribute("EB_Rank")) ~= "number" then
		return
	end

	v4 = PlayerInfos:GetAttribute("EB_Rank")
else
	v4 = 0
end

if v4 <= 0 then
	return
end

local t = {
	["Pra\195\167as"] = {
		Grama = 30,
		Lixo = 15,
		TempoJogado = 30,
		Recompensa = "+1 Up de Patente"
	},
	Graduados = {
		Grama = 60,
		Lixo = 30,
		TempoJogado = 60,
		Recompensa = "+1 Up de Patente"
	},
	Evento = {
		Grama = 100,
		Lixo = 75,
		TempoJogado = 85,
		Recompensa = "+1 Up de Patente e uma Deagle dourada permanente"
	}
}
local v5 = "N/A"
local v6 = false
local v7 = true

local function EmptyGui() --[[ EmptyGui | Line: 159 | Upvalues: Title (copy), Description (copy), Main (copy) ]]
	Title.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	Description.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	Title.Text = "Aguardando T\195\173tulo..."
	Description.Text = "Aguardando Informa\195\167\195\181es..."

	for v1, v2 in Main:GetChildren() do
		if v2:IsA("GuiObject") then
			v2.Visible = false
		end
	end
end

local function ErrorScreen(p1) --[[ ErrorScreen | Line: 179 | Upvalues: EmptyGui (copy), Title (copy), Description (copy), Completed (copy) ]]
	EmptyGui()
	Title.Text = "Um erro inesperado ocorreu! :("
	Description.Text = p1 .. " Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
	Completed.Visible = true
end

local function UpdateProgress() --[[ UpdateProgress | Line: 190 | Upvalues: v6 (ref), v5 (ref), t (copy), EmptyGui (copy), Title (copy), Description (copy), Completed (copy), LixosRecolhidos (copy), GramasCortadas (copy), TempoJogado (copy), TweenService (copy), Handler (copy) ]]
	if v6 then
		return
	end

	if v5 == "N/A" then
		return
	end

	local v1 = t[v5]

	if not v1 then
		warn("[MISS\195\131O] Vari\195\161vel \'MissaoEncontrada\' n\195\163o encontrada! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "Erro ao encontrar sua miss\195\163o! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true

		return
	end

	local v2 = LixosRecolhidos.Value
	local v3 = GramasCortadas.Value
	local v4 = TempoJogado.Value

	if typeof(v2) ~= "number" or (typeof(v3) ~= "number" or typeof(v4) ~= "number") then
		warn("[MISS\195\131O] Um dos valores do jogador est\195\161 com formato inv\195\161lido! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "Algum valor est\195\161 com formato inv\195\161lido! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true

		return
	end

	local TempoJogado2 = v1.TempoJogado
	local Grama = v1.Grama
	local Lixo = v1.Lixo

	if TempoJogado2 and (Grama and Lixo) then
		local v52 = math.floor(v4 / 60)
		local v62 = math.clamp(v52 / TempoJogado2, 0, 1)
		local v7 = math.clamp(v3 / Grama, 0, 1)
		local v8 = math.clamp(v2 / Lixo, 0, 1)

		if TempoLabel and TempoLabel.Text then
			TempoLabel.Text = ("Tempo Jogado: %* / %* minutos"):format(v52, TempoJogado2)
		end

		if GramasLabel and GramasLabel.Text then
			GramasLabel.Text = ("Gramas Cortadas: %* / %*"):format(tostring(v3), Grama)
		end

		if LixosLabel and LixosLabel.Text then
			LixosLabel.Text = ("Lixo Coletado: %* / %*"):format(tostring(v2), Lixo)
		end

		local v9 = (v8 + v7 + v62) / 3

		if ProgressText and ProgressText.Text then
			ProgressText.Text = string.format("%d%%", (math.floor(v9 * 100)))
		end

		TweenService:Create(ProgressBar, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Size = UDim2.new(v9, 0, 1, 0)
		}):Play()

		if not (v9 >= 1) then
			return
		end

		v6 = true

		if ProgressText and ProgressText.Text then
			ProgressText.Text = "100%"
		end

		Handler:FireServer("Finalizar")
		EmptyGui()
		AnyWarnTitle.Text = "Processando Miss\195\163o..."
		AnyWarnInfo.Text = "O Servidor est\195\161 processando sua miss\195\163o, aguarde alguns minutos!"
		AnyWarnTitle.Visible = true
		AnyWarnInfo.Visible = true
	else
		warn("[MISS\195\131O] Algum valor da sua miss\195\163o n\195\163o foi encontrado! Se alguma das seguintes vari\195\161veis estiver como \'nil\', por favor reporte o bug aos desenvolvedores do jogo. TempoNecessario:", TempoJogado2, "| GramasNecessarias:", Grama, "| LixosNecessarios:", Lixo)
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "Algum valor da sua miss\195\163o n\195\163o foi encontrado! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true
	end
end

local function SetupGui() --[[ SetupGui | Line: 301 | Upvalues: v6 (ref), EmptyGui (copy), v2 (copy), v5 (ref), t (copy), Title (copy), Description (copy), Completed (copy), v4 (ref), Handler (copy), UpdateProgress (copy), NotificationClient (copy), FinishedRankMission (copy) ]]
	v6 = false
	EmptyGui()

	if v2.Value == "N/A" then
		M_GeralButton.Interactable = true
		M_GeralButton.Visible = true
		GeralLock.Visible = false
		M_GraduadosButton.Interactable = false
		M_GraduadosButton.Visible = true
		GraduadosLock.Visible = true
		M_PracasButton.Interactable = false
		M_PracasButton.Visible = true
		PracasLock.Visible = true

		if v4 >= 1 and (v4 <= 3 and not FinishedRankMission.Value) then
			M_PracasButton.Interactable = true
			PracasLock.Visible = false

			return
		end

		if not (v4 >= 4) or (not (v4 <= 7) or FinishedRankMission.Value) then
			return
		end

		M_GraduadosButton.Interactable = true
		GraduadosLock.Visible = false
	else
		v5 = v2.Value

		local v1 = t[v5]

		if not v1 then
			warn("[MISS\195\131O] Vari\195\161vel \'MissaoEncontrada\' n\195\163o encontrada! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Title.Text = "Um erro inesperado ocorreu! :("
			Description.Text = "Erro ao encontrar sua miss\195\163o! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			Completed.Visible = true

			return
		end

		local Recompensa = v1.Recompensa

		if not Recompensa then
			warn("[MISS\195\131O] Vari\195\161vel \'Recompensa\' n\195\163o encontrada! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Title.Text = "Um erro inesperado ocorreu! :("
			Description.Text = "Erro ao encontrar recompensa da miss\195\163o! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			Completed.Visible = true

			return
		end

		CurrentMissionLabel.Text = "Miss\195\163o: " .. v5
		RecompensaLabel.Text = "Recompensa: " .. Recompensa

		if v5 ~= "Evento" or not (v4 >= 18) then
			CurrentMissionLabel.Visible = true
			ProgressMain.Visible = true
			Bar1.Visible = true
			Bar2.Visible = true
			LoadingIcon.Visible = false
			LoadingDataWarn.Visible = false
			Handler:FireServer("Continuar")
			UpdateProgress()
			NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 tem uma miss\195\163o ativa! Termine a miss\195\163o para receber sua recompensa.")

			return
		end

		RecompensaLabel.Text = "Recompensa: Deagle dourada"
		CurrentMissionLabel.Visible = true
		ProgressMain.Visible = true
		Bar1.Visible = true
		Bar2.Visible = true
		LoadingIcon.Visible = false
		LoadingDataWarn.Visible = false
		Handler:FireServer("Continuar")
		UpdateProgress()
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 tem uma miss\195\163o ativa! Termine a miss\195\163o para receber sua recompensa.")
	end
end

local function PlayLoadingAnimation(p1) --[[ PlayLoadingAnimation | Line: 419 | Upvalues: TweenService (copy) ]]
	LoadingIcon.Visible = true
	LoadingDataWarn.Visible = true
	LoadingIcon.Rotation = 0

	local v1 = TweenService:Create(LoadingIcon, TweenInfo.new(1, Enum.EasingStyle.Linear), {
		Rotation = 360
	})

	v1:Play()
	v1.Completed:Wait()

	if not p1 then
		return
	end

	LoadingIcon.Visible = false
	LoadingDataWarn.Visible = false
end

local function CheckCooldown() --[[ CheckCooldown | Line: 446 | Upvalues: v1 (copy), EmptyGui (copy), Title (copy), Description (copy), Completed (copy), LastMissionTime (copy) ]]
	if not v1 then
		warn("[MISS\195\131O] Vari\195\161vel \'MissoesData\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "A vari\195\161vel \'MissoesData\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true

		return
	end

	if not LastMissionTime then
		warn("[MISS\195\131O] \'LastMissionTime\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "A vari\195\161vel \'LastMissionTime\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true

		return
	end

	if LastMissionTime.Value > 0 then
		return true, LastMissionTime.Value
	end
end

local function RequestMission(p1) --[[ RequestMission | Line: 476 | Upvalues: EmptyGui (copy), t (copy), v5 (ref), Title (copy), Description (copy), Completed (copy), v4 (ref) ]]
	EmptyGui()

	local v1 = t[v5]

	if not v1 then
		warn("[MISS\195\131O] Vari\195\161vel \'MissaoEncontrada\' n\195\163o encontrada! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "Erro ao encontrar sua miss\195\163o! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true

		return
	end

	local TempoJogado = v1.TempoJogado
	local Grama = v1.Grama
	local Lixo = v1.Lixo
	local Recompensa = v1.Recompensa

	if TempoJogado and (Grama and (Lixo and Recompensa)) then
		if TempoLabel and TempoLabel.Text then
			TempoLabel.Text = ("Tempo Jogado: 0/%* minutos"):format(TempoJogado)
		end

		if GramasLabel and GramasLabel.Text then
			GramasLabel.Text = ("Gramas Cortadas: 0/%*"):format(Grama)
		end

		if LixosLabel and LixosLabel.Text then
			LixosLabel.Text = ("Lixo Coletado: 0/%*"):format(Lixo)
		end

		Bar1.Visible = true
		Bar2.Visible = true
		CurrentMissionLabel.Text = "Miss\195\163o: " .. v5
		RecompensaLabel.Text = "Recompensa: " .. Recompensa

		if v5 == "Evento" and v4 >= 18 then
			RecompensaLabel.Text = "Recompensa: Deagle dourada"
		end

		CurrentMissionLabel.Visible = true

		if p1 == "MostrarConteudo" then
			Aceitar.Visible = true

			return
		end

		if p1 ~= "Confirmar" then
			return
		end

		Aceitar.Visible = false
		ProgressMain.Visible = true
	else
		warn("[MISS\195\131O] Algum valor da sua miss\195\163o n\195\163o foi encontrado! Se alguma das seguintes vari\195\161veis estiver como \'nil\', por favor reporte o bug aos desenvolvedores do jogo. TempoNecessario:", TempoJogado, "| GramasNecessarias:", Grama, "| LixosNecessarios:", Lixo)
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "Algum valor da sua miss\195\163o n\195\163o foi encontrado! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true
	end
end

Close.Activated:Connect(function() --[[ Line: 555 | Upvalues: v3 (copy) ]]
	v3.Enabled = false
end)
M_GeralButton.Activated:Connect(function() --[[ Line: 561 | Upvalues: v7 (ref), v5 (ref), RequestMission (copy) ]]
	if v7 then
		v7 = false
		task.delay(1, function() --[[ Line: 566 | Upvalues: v7 (ref) ]]
			v7 = true
		end)
		v5 = "Evento"
		RequestMission("MostrarConteudo")
	end
end)
M_GraduadosButton.Activated:Connect(function() --[[ Line: 614 | Upvalues: v4 (ref), v7 (ref), v1 (copy), EmptyGui (copy), Title (copy), Description (copy), Completed (copy), LastMissionTime (copy), NotificationClient (copy), v5 (ref), RequestMission (copy) ]]
	if v4 <= 3 then
		return
	end

	if not v7 then
		return
	end

	v7 = false
	task.delay(1, function() --[[ Line: 621 | Upvalues: v7 (ref) ]]
		v7 = true
	end)

	local v12, v2

	if v1 then
		if LastMissionTime then
			if LastMissionTime.Value > 0 then
				v12 = LastMissionTime.Value
				v2 = true
			else
				v2 = nil
				v12 = nil
			end
		else
			warn("[MISS\195\131O] \'LastMissionTime\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Title.Text = "Um erro inesperado ocorreu! :("
			Description.Text = "A vari\195\161vel \'LastMissionTime\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			Completed.Visible = true
			v2 = nil
			v12 = nil
		end
	else
		warn("[MISS\195\131O] Vari\195\161vel \'MissoesData\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "A vari\195\161vel \'MissoesData\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true
		v2 = nil
		v12 = nil
	end

	if not (v2 and v12) then
		v5 = "Graduados"
		RequestMission("MostrarConteudo")

		return
	end

	local v3 = 86400 - (os.time() - v12)

	if v3 > 0 then
		local v6 = string.format("%02d:%02d:%02d", math.floor(v3 / 3600) % 24, math.floor(v3 / 60) % 60, v3 % 60)

		EmptyGui()
		CooldownTitle.Visible = true
		CooldownWarn.Visible = true
		CooldownRemainingLabel.Visible = true
		CooldownRemainingLabel.Text = "Tempo Restante: " .. v6
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 precisa aguardar para fazer outra miss\195\163o.")
	else
		v5 = "Graduados"
		RequestMission("MostrarConteudo")
	end
end)
M_PracasButton.Activated:Connect(function() --[[ Line: 669 | Upvalues: v4 (ref), v7 (ref), v1 (copy), EmptyGui (copy), Title (copy), Description (copy), Completed (copy), LastMissionTime (copy), NotificationClient (copy), v5 (ref), RequestMission (copy) ]]
	if v4 >= 4 then
		return
	end

	if not v7 then
		return
	end

	v7 = false
	task.delay(1, function() --[[ Line: 676 | Upvalues: v7 (ref) ]]
		v7 = true
	end)

	local v12, v2

	if v1 then
		if LastMissionTime then
			if LastMissionTime.Value > 0 then
				v12 = LastMissionTime.Value
				v2 = true
			else
				v2 = nil
				v12 = nil
			end
		else
			warn("[MISS\195\131O] \'LastMissionTime\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Title.Text = "Um erro inesperado ocorreu! :("
			Description.Text = "A vari\195\161vel \'LastMissionTime\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			Completed.Visible = true
			v2 = nil
			v12 = nil
		end
	else
		warn("[MISS\195\131O] Vari\195\161vel \'MissoesData\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Title.Text = "Um erro inesperado ocorreu! :("
		Description.Text = "A vari\195\161vel \'MissoesData\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		Completed.Visible = true
		v2 = nil
		v12 = nil
	end

	if not (v2 and v12) then
		v5 = "Pra\195\167as"
		RequestMission("MostrarConteudo")

		return
	end

	local v3 = 86400 - (os.time() - v12)

	if v3 > 0 then
		local v6 = string.format("%02d:%02d:%02d", math.floor(v3 / 3600) % 24, math.floor(v3 / 60) % 60, v3 % 60)

		EmptyGui()
		CooldownTitle.Visible = true
		CooldownWarn.Visible = true
		CooldownRemainingLabel.Visible = true
		CooldownRemainingLabel.Text = "Tempo Restante: " .. v6
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 precisa aguardar para fazer outra miss\195\163o.")
	else
		v5 = "Pra\195\167as"
		RequestMission("MostrarConteudo")
	end
end)
Aceitar.Activated:Connect(function() --[[ Line: 724 | Upvalues: v7 (ref), EmptyGui (copy), PlayLoadingAnimation (copy), RequestMission (copy), Handler (copy), v5 (ref), NotificationClient (copy) ]]
	if v7 then
		v7 = false
		task.delay(1, function() --[[ Line: 729 | Upvalues: v7 (ref) ]]
			v7 = true
		end)
		EmptyGui()
		PlayLoadingAnimation(true)
		RequestMission("Confirmar")
		Handler:FireServer("Come\195\167ar", v5)
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 iniciou a miss\195\163o \'" .. v5 .. "\', complete e receba sua recompensa! Boa sorte!")
	end
end)

if TempoJogado and (GramasCortadas and (LixosRecolhidos and (v2 and (FinishedRankMission and FinishedEventMission)))) then
	PlayLoadingAnimation(true)
	SetupGui()
	TempoJogado:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 760 | Upvalues: UpdateProgress (copy) ]]
		UpdateProgress()
	end)
	GramasCortadas:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 766 | Upvalues: UpdateProgress (copy) ]]
		UpdateProgress()
	end)
	LixosRecolhidos:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 772 | Upvalues: UpdateProgress (copy) ]]
		UpdateProgress()
	end)
	Handler.OnClientEvent:Connect(function(p1, p2) --[[ Line: 778 | Upvalues: NotificationClient (copy), EmptyGui (copy), v5 (ref), v4 (ref), SetupGui (copy), Title (copy), Description (copy), Completed (copy) ]]
		if p1 == "Finalizou" then
			NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 finalizou a miss\195\163o! Voc\195\170 receber\195\161 sua recompensa dentro de 24 horas. Se n\195\163o receber, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			AnyWarnTitle.Text = "Sua miss\195\163o foi processada corretamente!"

			if v5 == "Evento" then
				if v4 >= 18 then
					AnyWarnInfo.Text = "Seu item foi entregue! Para equipar o item, Reentre no jogo e procure o item na mochila localizada \195\160 esquerda da sua tela. Caso seu item n\195\163o tenha sido entregue ap\195\179s o rejoin, aguarde alguns minutos e tente novamente. Se mesmo assim seu item n\195\163o tiver sido entregue, por favor reporte o bug aos desenvolvedores do jogo."
				else
					AnyWarnInfo.Text = "Sua patente e seu item foram entregues! Para equipar o item, Reentre no jogo e procure o item na mochila localizada \195\160 esquerda da sua tela. Caso sua patente e seu item n\195\163o tenham sido entregue ap\195\179s o rejoin, aguarde alguns minutos e tente novamente. Se mesmo assim sua patente e seu item n\195\163o tiverem sido entregues, por favor reporte o bug aos desenvolvedores do jogo."
				end
			else
				AnyWarnInfo.Text = "Sua patente foi entregue! Reentre no jogo para as mudan\195\167as serem aplicadas. Caso sua patente n\195\163o tenha sido entregue ap\195\179s o rejoin, aguarde alguns minutos e tente novamente. Se mesmo assim sua patente n\195\163o tiver sido entregue, por favor reporte o bug aos desenvolvedores do jogo."
			end

			AnyWarnTitle.TextColor3 = Color3.new(0/255, 255/255, 0/255)
			AnyWarnInfo.TextColor3 = Color3.new(0/255, 255/255, 0/255)
			AnyWarnTitle.Visible = true
			AnyWarnInfo.Visible = true
			task.delay(10, function() --[[ Line: 812 | Upvalues: SetupGui (ref) ]]
				SetupGui()
			end)
		else
			if p1 ~= "Error" then
				return
			end

			EmptyGui()
			Title.Text = "Um erro inesperado ocorreu! :("
			Description.Text = p2 .. " Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			Completed.Visible = true
		end
	end)

	local v8 = LastMissionTime.Value

	if v8 > 0 then
		while true do
			if FinishedEventMission.Value then
				EmptyGui()
				AnyWarnTitle.Text = "Voc\195\170 completou todas suas miss\195\181es!"
				AnyWarnInfo.Text = "Aguarde novas miss\195\181es serem adicionadas ao jogo para voltar a fazer mais miss\195\181es."
				AnyWarnTitle.Visible = true
				AnyWarnInfo.Visible = true

				return
			end

			local v9 = 86400 - (os.time() - v8)

			if v9 <= 0 then
				break
			end

			local v12 = "Tempo Restante: " .. string.format("%02d:%02d:%02d", math.floor(v9 / 3600), math.floor(v9 / 60) % 60, v9 % 60)

			if CooldownRemainingLabel.Text ~= v12 then
				CooldownRemainingLabel.Text = v12
			end

			task.wait(1)
		end

		SetupGui()
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Seu Cooldown acabou! Voc\195\170 j\195\161 pode fazer outra miss\195\163o!")
	else
		SetupGui()
	end
else
	warn("[MISS\195\131O] Alguma vari\195\161vel importante falhou em carregar. Se alguma das seguintes vari\195\161veis estiver como \'nil\', por favor reporte o bug aos desenvolvedores do jogo. TempoJogado:", TempoJogado, "| GramasCortadas:", GramasCortadas, "| LixosRecolhidos:", LixosRecolhidos, "| MissaoAtual:", v2, "| FinishedRankMission:", FinishedRankMission, "| FinishedEventMission:", FinishedEventMission)
	EmptyGui()
	Title.Text = "Um erro inesperado ocorreu! :("
	Description.Text = "Uma das vari\195\161veis importantes para o funcionamento do sistema n\195\163o conseguiu carregar corretamente! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
	Completed.Visible = true
end