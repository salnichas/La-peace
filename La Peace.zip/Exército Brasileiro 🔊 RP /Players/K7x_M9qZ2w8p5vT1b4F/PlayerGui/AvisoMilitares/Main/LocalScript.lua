-- https://lua.expert/
local v1 = script.Parent
local v2 = v1:FindFirstAncestorOfClass("ScreenGui")
local Template = v1:WaitForChild("Template")
local Anterior = Template:WaitForChild("Anterior")
local Proximo = Template:WaitForChild("Proximo")
local Title = v1:WaitForChild("Title")
local TutorialEvent = game:GetService("ReplicatedStorage").Remotes.Events.Tutorial:WaitForChild("TutorialEvent")
local ProgressLabel = Instance.new("TextLabel")

ProgressLabel.Name = "ProgressLabel"
ProgressLabel.Size = UDim2.new(0, 120, 0, 30)
ProgressLabel.Position = UDim2.new(0.5, -60, 1, -40)
ProgressLabel.BackgroundTransparency = 1
ProgressLabel.TextScaled = true
ProgressLabel.TextColor3 = Color3.new(255/255, 255/255, 255/255)
ProgressLabel.Font = Enum.Font.GothamBold
ProgressLabel.Parent = Template

local t = {}
local v3 = 1
local v4 = nil

local function ocultarSlides() --[[ ocultarSlides | Line: 25 | Upvalues: t (ref) ]]
	for i, v in ipairs(t) do
		v.Visible = false
	end
end

local function mostrarSlideAtual() --[[ mostrarSlideAtual | Line: 31 | Upvalues: t (ref), v3 (ref), ProgressLabel (copy), Proximo (copy) ]]
	for i, v in ipairs(t) do
		v.Visible = false
	end

	if #t == 0 then
		return
	end

	t[v3].Visible = true
	ProgressLabel.Text = string.format("%d / %d", v3, #t)
	Proximo.Text = if v3 == #t then "Concluir" else "Pr\195\179ximo"
end

local function carregarSlidesDoFrame(p1) --[[ carregarSlidesDoFrame | Line: 40 | Upvalues: t (ref), v3 (ref), ProgressLabel (copy), Proximo (copy) ]]
	t = {}

	for i, v in ipairs(p1:GetChildren()) do
		if v:IsA("ImageLabel") then
			table.insert(t, v)
			v.Visible = false
		end
	end

	table.sort(t, function(p1, p2) --[[ Line: 48 ]]
		return p1.Name < p2.Name
	end)
	v3 = 1

	for i, v in ipairs(t) do
		v.Visible = false
	end

	if #t == 0 then
		return
	end

	t[v3].Visible = true
	ProgressLabel.Text = string.format("%d / %d", v3, #t)
	Proximo.Text = if v3 == #t then "Concluir" else "Pr\195\179ximo"
end

local function detectarFrameAtivo() --[[ detectarFrameAtivo | Line: 55 | Upvalues: Template (copy) ]]
	for i, v in ipairs(Template:GetChildren()) do
		if (v:IsA("Frame") or v:IsA("Folder")) and v.Visible then
			return v
		end
	end

	return nil
end

local function atualizarFrameAtivo() --[[ atualizarFrameAtivo | Line: 64 | Upvalues: v4 (ref), detectarFrameAtivo (copy), Title (copy), carregarSlidesDoFrame (copy), t (ref), ProgressLabel (copy) ]]
	v4 = detectarFrameAtivo()

	if v4 then
		Title.Text = "TUTORIAL " .. string.upper(v4.Name)
		carregarSlidesDoFrame(v4)
	else
		t = {}
		ProgressLabel.Text = ""
	end
end

local function resetarTutorial() --[[ resetarTutorial | Line: 75 | Upvalues: t (ref), v3 (ref), v4 (ref), detectarFrameAtivo (copy), Template (copy), ProgressLabel (copy), Proximo (copy), atualizarFrameAtivo (copy) ]]
	t = {}
	v3 = 1
	v4 = detectarFrameAtivo()

	for i, v in ipairs(Template:GetChildren()) do
		if v:IsA("Folder") or v:IsA("Frame") then
			for i2, v2 in ipairs(v:GetChildren()) do
				if v2:IsA("ImageLabel") then
					v2.Visible = false
				end
			end
		end
	end

	ProgressLabel.Text = ""
	Proximo.Text = "Pr\195\179ximo"
	atualizarFrameAtivo()
end

local function verificarPatente() --[[ verificarPatente | Line: 93 | Upvalues: v2 (copy), TutorialEvent (copy), Template (copy), resetarTutorial (copy) ]]
	local LocalPlayer = game.Players.LocalPlayer

	if not LocalPlayer then
		return
	end

	local v1 = LocalPlayer:GetAttribute("Patente")

	if not v1 then
		v2.Enabled = false

		return
	end

	local v22

	if v1 >= 1 and v1 <= 3 then
		v22 = "Pracas"
	elseif v1 >= 4 and v1 <= 8 then
		v22 = "Graduados"
	else
		if not (v1 >= 9) then
			v2.Enabled = false

			return
		end

		v22 = "Oficiais"
	end

	if TutorialEvent:InvokeServer("Checar") == v22 then
		v2.Enabled = false

		return
	end

	for i, v in ipairs(Template:GetChildren()) do
		if v:IsA("Frame") or v:IsA("Folder") then
			v.Visible = false
		end
	end

	if v22 == "Pracas" then
		Template.Pracas.Visible = true
	elseif v22 == "Graduados" then
		Template.Graduados.Visible = true
	elseif v22 == "Oficiais" then
		Template.Oficiais.Visible = true
	end

	v2.Enabled = true
	resetarTutorial()
end

Proximo.MouseButton1Click:Connect(function() --[[ Line: 140 | Upvalues: t (ref), v3 (ref), TutorialEvent (copy), v2 (copy), ProgressLabel (copy), Proximo (copy) ]]
	if #t == 0 then
		return
	end

	local LocalPlayer = game.Players.LocalPlayer

	if v3 == #t then
		local v1 = LocalPlayer:GetAttribute("Patente")
		local v22 = nil

		if v1 >= 1 and v1 <= 3 then
			v22 = "Pracas"
		elseif v1 >= 4 and v1 <= 8 then
			v22 = "Graduados"
		elseif v1 >= 9 then
			v22 = "Oficiais"
		end

		TutorialEvent:InvokeServer("Concluir", v22)
		v2.Enabled = false
	else
		v3 = v3 + 1

		for i, v in ipairs(t) do
			v.Visible = false
		end

		if #t == 0 then
			return
		end

		t[v3].Visible = true
		ProgressLabel.Text = string.format("%d / %d", v3, #t)
		Proximo.Text = if v3 == #t then "Concluir" else "Pr\195\179ximo"
	end
end)
Anterior.MouseButton1Click:Connect(function() --[[ Line: 163 | Upvalues: t (ref), v3 (ref), ProgressLabel (copy), Proximo (copy) ]]
	if #t == 0 then
		return
	end

	v3 = v3 - 1

	if v3 < 1 then
		v3 = #t
	end

	for i, v in ipairs(t) do
		v.Visible = false
	end

	if #t == 0 then
		return
	end

	t[v3].Visible = true
	ProgressLabel.Text = string.format("%d / %d", v3, #t)
	Proximo.Text = if v3 == #t then "Concluir" else "Pr\195\179ximo"
end)
task.defer(function() --[[ Line: 170 | Upvalues: verificarPatente (copy) ]]
	local LocalPlayer = game.Players.LocalPlayer

	if not LocalPlayer then
		return
	end

	while not LocalPlayer:GetAttribute("LoadingCompleted") do
		task.wait(0.5)
	end

	verificarPatente()
	LocalPlayer:GetAttributeChangedSignal("Patente"):Connect(verificarPatente)
end)