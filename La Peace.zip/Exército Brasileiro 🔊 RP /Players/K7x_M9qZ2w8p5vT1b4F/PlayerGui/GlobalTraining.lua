-- https://lua.expert/
local GlobalTraining = game.Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("GlobalTraining")

GlobalTraining:GetAttributeChangedSignal("SenderId"):Connect(function() --[[ Line: 5 | Upvalues: GlobalTraining (copy) ]]
	local v1 = GlobalTraining:GetAttribute("SenderId")
	local v2 = GlobalTraining:GetAttribute("SenderName")
	local servidor = GlobalTraining:GetAttribute("IDServer")

	print("Evento Global recebido!")
	print("Servidor:", servidor)
	print("Enviado por:", v2 .. " (ID: " .. tostring(v1) .. ")")
end)