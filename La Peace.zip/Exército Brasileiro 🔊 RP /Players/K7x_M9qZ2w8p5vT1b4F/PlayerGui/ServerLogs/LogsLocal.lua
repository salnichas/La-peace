-- https://lua.expert/
local v1 = 0
local LogsEvent = game.ReplicatedStorage.Remotes.Events.LogsAtividades.LogsEvent
local ScrollingFrame = script.Parent.Main.Logs.ScrollingFrame
local Log = script.Parent.Templates.Log

LogsEvent.OnClientEvent:Connect(function(p1, p2) --[[ Line: 6 | Upvalues: v1 (ref), Log (copy), ScrollingFrame (copy) ]]
	if not p1 then
		return
	end

	v1 = v1 + 1

	local v12 = Log:Clone()

	v12.Parent = ScrollingFrame
	v12.Visible = true

	local v2 = os.date("[%H:%M:%S]")
	local t = { "%s \226\154\148\239\184\143 %s foi solado por %s!", "%s \240\159\146\128 %s amassou %s!", "%s \240\159\148\165 %s foi humilhado por %s!", "%s \226\154\176\239\184\143 %s n\195\163o teve chance contra %s!" }
	local t2 = { "%s \240\159\164\175 %s se suicidou", "%s \240\159\152\181 %s se matou", "%s \240\159\146\128 %s foi morto pela vida" }

	if p2 and p2 ~= p1 then
		v12.Text = string.format(t[math.random(1, #t)], v2, p1, p2)
	else
		v12.Text = string.format(t2[math.random(1, #t2)], v2, p1)
	end

	v12.LayoutOrder = -v1
end)