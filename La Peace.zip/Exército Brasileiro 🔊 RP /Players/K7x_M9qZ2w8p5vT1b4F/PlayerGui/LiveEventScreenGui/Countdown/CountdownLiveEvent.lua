-- https://lua.expert/
local TweenService = game:GetService("TweenService")
local v1 = game.ReplicatedStorage:WaitForChild("LiveEventClient"):WaitForChild("StartTime").Value
local v2 = script.Parent
local Numbers = v2:WaitForChild("Numbers")
local Days = Numbers:WaitForChild("Days")
local Hours = Numbers:WaitForChild("Hours")
local Minutes = Numbers:WaitForChild("Minutes")
local Seconds = Numbers:WaitForChild("Seconds")
local v3 = Days:FindFirstChildWhichIsA("TextLabel")
local v4 = Hours:FindFirstChildWhichIsA("TextLabel")
local v5 = Minutes:FindFirstChildWhichIsA("TextLabel")
local v6 = Seconds:FindFirstChildWhichIsA("TextLabel")
local v7 = Seconds:FindFirstChildWhichIsA("UIScale")
local TickSound = script:WaitForChild("TickSound")

local function format(p1) --[[ format | Line: 44 ]]
	return string.format("%02d", p1)
end

local function pulse(p1) --[[ pulse | Line: 48 | Upvalues: TweenService (copy) ]]
	if p1 then
		p1.Scale = 1

		local v1 = TweenService:Create(p1, TweenInfo.new(0.12), {
			Scale = 1.25
		})
		local v2 = TweenService:Create(p1, TweenInfo.new(0.12), {
			Scale = 1
		})

		v1:Play()
		v1.Completed:Connect(function() --[[ Line: 57 | Upvalues: v2 (copy) ]]
			v2:Play()
		end)
	end
end

local function flashRed(p1) --[[ flashRed | Line: 62 | Upvalues: TweenService (copy) ]]
	if p1 then
		local v1 = TweenService:Create(p1, TweenInfo.new(0.1), {
			TextColor3 = Color3.fromRGB(255, 60, 60)
		})
		local v2 = TweenService:Create(p1, TweenInfo.new(0.1), {
			TextColor3 = Color3.fromRGB(255, 255, 255)
		})

		v1:Play()
		v1.Completed:Connect(function() --[[ Line: 74 | Upvalues: v2 (copy) ]]
			v2:Play()
		end)
	end
end

local function waveEffect() --[[ waveEffect | Line: 79 | Upvalues: Days (copy), Hours (copy), Minutes (copy), Seconds (copy), pulse (copy) ]]
	for i, v in ipairs({ Days, Hours, Minutes, Seconds }) do
		task.delay(i * 0.05, function() --[[ Line: 83 | Upvalues: v (copy), pulse (ref) ]]
			local v1 = v:FindFirstChildWhichIsA("UIScale")

			if not v1 then
				return
			end

			pulse(v1)
		end)
	end
end

local function fadeOutUI(p1) --[[ fadeOutUI | Line: 93 | Upvalues: TweenService (copy) ]]
	for i, v in ipairs(p1:GetDescendants()) do
		if v:IsA("TextLabel") then
			TweenService:Create(v, TweenInfo.new(0.5), {
				TextTransparency = 1
			}):Play()

			continue
		end

		if v:IsA("ImageLabel") or v:IsA("ImageButton") then
			TweenService:Create(v, TweenInfo.new(0.5), {
				ImageTransparency = 1
			}):Play()

			continue
		end

		if v:IsA("Frame") then
			TweenService:Create(v, TweenInfo.new(0.5), {
				BackgroundTransparency = 1
			}):Play()

			continue
		end

		if v:IsA("UIStroke") then
			TweenService:Create(v, TweenInfo.new(0.5), {
				Transparency = 1
			}):Play()
		end
	end
end

local v8 = nil
local v9 = nil
local v10 = nil

task.spawn(function() --[[ Line: 124 | Upvalues: v1 (copy), fadeOutUI (copy), v2 (copy), v8 (ref), waveEffect (copy), v9 (ref), v10 (ref), Days (copy), Hours (copy), Minutes (copy), Seconds (copy), v6 (copy), pulse (copy), v7 (copy), flashRed (copy), TickSound (copy), v3 (copy), v4 (copy), v5 (copy) ]]
	while true do
		local v12 = v1 - (DateTime.now().UnixTimestamp + -10800)

		if v12 <= 0 then
			break
		end

		local v22 = math.floor(v12 / 86400)
		local v32 = math.floor(v12 % 86400 / 3600)
		local v42 = math.floor(v12 % 3600 / 60)
		local v52 = v12 % 60

		if v8 and v22 ~= v8 or (v9 and v32 ~= v9 or v10 and v42 ~= v10) then
			waveEffect()
		end

		v8 = v22
		v9 = v32
		v10 = v42

		if v12 <= 10 then
			Days.Visible = false
			Hours.Visible = false
			Minutes.Visible = false
			Seconds.Visible = true
			v6.Text = string.format("%02d", v52)
			pulse(v7)
			flashRed(v6)

			if TickSound then
				TickSound:Play()
			end
		else
			Days.Visible = true
			Hours.Visible = true
			Minutes.Visible = true
			Seconds.Visible = true
			v3.Text = string.format("%02d", v22)
			v4.Text = string.format("%02d", v32)
			v5.Text = string.format("%02d", v42)
			v6.Text = string.format("%02d", v52)
		end

		task.wait(1)
	end

	fadeOutUI(v2)
end)