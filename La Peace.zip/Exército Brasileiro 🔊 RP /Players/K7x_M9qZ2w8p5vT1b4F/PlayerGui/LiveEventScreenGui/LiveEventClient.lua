-- https://lua.expert/
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local StarterGui = game:GetService("StarterGui")
local LocalPlayer = Players.LocalPlayer
local CurrentCamera = workspace.CurrentCamera
local Cameras = workspace:WaitForChild("LiveEventWorkspace"):WaitForChild("Cameras")
local LiveEventClient = ReplicatedStorage:WaitForChild("LiveEventClient")
local LiveEvent = LiveEventClient:WaitForChild("LiveEvent")

LiveEventClient:WaitForChild("StartTime")

local v1 = script.Parent
local EventFrame = v1:WaitForChild("EventFrame")
local IntroFrame = EventFrame:WaitForChild("IntroFrame")

IntroFrame.Visible = false

local UtilsModule = require(LiveEventClient:WaitForChild("UtilsModule"))

local function DisableAllScreensGui() --[[ DisableAllScreensGui | Line: 39 | Upvalues: LocalPlayer (copy), v1 (copy) ]]
	local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")

	for i, v in ipairs(PlayerGui:GetChildren()) do
		if v:IsA("ScreenGui") and v ~= v1 then
			v.Enabled = false
		end
	end
end

local function FormatTime(p1) --[[ FormatTime | Line: 50 ]]
	return string.format("%d:%02d", math.floor(p1 / 60), p1 % 60)
end

local function DisableReset(p1, p2) --[[ DisableReset | Line: 57 | Upvalues: StarterGui (copy) ]]
	local v1 = p1 or 10
	local v2 = p2 or 0.2

	task.spawn(function() --[[ Line: 61 | Upvalues: v1 (ref), StarterGui (ref), v2 (ref) ]]
		for i = 1, v1 do
			if pcall(function() --[[ Line: 63 | Upvalues: StarterGui (ref) ]]
				StarterGui:SetCore("ResetButtonCallback", false)
			end) then
				break
			end

			task.wait(v2)
		end
	end)
end

local function TweenTransparency(p1, p2, p3) --[[ TweenTransparency | Line: 76 | Upvalues: TweenService (copy) ]]
	local v1 = TweenService:Create(p1, TweenInfo.new(p3), {
		TextTransparency = p2
	})

	v1:Play()

	return v1
end

local function TypeWriter(p1, p2, p3) --[[ TypeWriter | Line: 84 ]]
	p1.Text = ""

	for i = 1, #p2 do
		p1.Text = string.sub(p2, 1, i)
		task.wait(p3)
	end
end

local v2 = require(LiveEventClient:WaitForChild("CameraShaker")).new(Enum.RenderPriority.Camera.Value, function(p1) --[[ Line: 93 | Upvalues: CurrentCamera (copy) ]]
	CurrentCamera.CFrame = CurrentCamera.CFrame * p1
end)

v2:Start()

local function FadeIn(p1) --[[ FadeIn | Line: 99 | Upvalues: v1 (copy), TweenService (copy) ]]
	local BlackFrame = v1:WaitForChild("BlackFrame")

	BlackFrame.BackgroundTransparency = 1
	BlackFrame.Visible = true
	TweenService:Create(BlackFrame, TweenInfo.new(p1), {
		BackgroundTransparency = 0
	}):Play()
end

local function FadeOut(p1) --[[ FadeOut | Line: 108 | Upvalues: v1 (copy), TweenService (copy) ]]
	TweenService:Create(v1:WaitForChild("BlackFrame"), TweenInfo.new(p1), {
		BackgroundTransparency = 1
	}):Play()
end

local function IntroEnd() --[[ IntroEnd | Line: 119 | Upvalues: IntroFrame (copy), TweenService (copy), CurrentCamera (copy) ]]
	local Title = IntroFrame:WaitForChild("Title")
	local Description = IntroFrame:WaitForChild("Description")
	local UIScale = IntroFrame:WaitForChild("UIScale")

	TweenService:Create(CurrentCamera, TweenInfo.new(2), {
		FieldOfView = 70
	}):Play()

	local v1 = TweenService:Create(UIScale, TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		Scale = 0.5
	})
	local v2 = TweenService:Create(Title, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
		TextTransparency = 1
	})

	TweenService:Create(Description, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
		TextTransparency = 1
	}):Play()
	task.wait(0.5)
	v2:Play()
	v1:Play()
	task.wait(2)
	IntroFrame.Visible = false
end

local function IntroStart() --[[ IntroStart | Line: 158 | Upvalues: IntroFrame (copy), TweenService (copy), CurrentCamera (copy), IntroEnd (copy) ]]
	local Title = IntroFrame:WaitForChild("Title")
	local Description = IntroFrame:WaitForChild("Description")
	local UIScale = IntroFrame:WaitForChild("UIScale")

	IntroFrame.Visible = true
	UIScale.Scale = 0.5
	Title.TextTransparency = 1
	Description.TextTransparency = 1
	TweenService:Create(CurrentCamera, TweenInfo.new(5), {
		FieldOfView = 60
	}):Play()

	local v1 = TweenService:Create(UIScale, TweenInfo.new(3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Scale = 1
	})
	local v2 = TweenService:Create(Title, TweenInfo.new(1.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		TextTransparency = 0
	})
	local v3 = TweenService:Create(Description, TweenInfo.new(1.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		TextTransparency = 0
	})

	v1:Play()
	task.wait(1.5)
	v2:Play()
	task.wait(2)
	v3:Play()
	task.wait(3)
	IntroEnd(IntroFrame)
end

local function Subtitle(p1, p2) --[[ Subtitle | Line: 206 | Upvalues: EventFrame (copy), TweenService (copy) ]]
	local Subtitle = EventFrame:WaitForChild("Subtitle")
	local v1 = Subtitle:FindFirstChildWhichIsA("UIScale")

	Subtitle.Visible = true
	Subtitle.Text = ""
	Subtitle.TextTransparency = 1
	v1.Scale = 0.5

	local v2 = TweenService:Create(v1, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Scale = 1
	})
	local v3 = TweenService:Create(Subtitle, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		TextTransparency = 0
	})

	v2:Play()
	v3:Play()

	local v4 = p2 / 2
	local v5 = #p1

	if v5 > 0 then
		local v6 = v4 / v5

		for i = 1, v5 do
			Subtitle.Text = string.sub(p1, 1, i)
			task.wait(v6)
		end
	end

	task.wait(p2 - v4)
	TweenService:Create(Subtitle, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
		TextTransparency = 1
	}):Play()
	task.wait(0.3)
	Subtitle.Visible = false
	Subtitle.Text = ""
end

local function MeteorCutscene1() --[[ MeteorCutscene1 | Line: 262 | Upvalues: Cameras (copy), FadeIn (copy), FadeOut (copy), CurrentCamera (copy), TweenService (copy), v2 (copy) ]]
	local MeteorCam = Cameras:WaitForChild("MeteorCam")

	FadeIn(0.35)
	task.wait(0.35)
	FadeOut(0.35)
	CurrentCamera.CameraType = Enum.CameraType.Scriptable
	CurrentCamera.CFrame = MeteorCam.CFrame
	CurrentCamera.FieldOfView = 100
	TweenService:Create(CurrentCamera, TweenInfo.new(3), {
		FieldOfView = 55
	}):Play()
	v2:StartShake(0.15, 5, 0.5, 0.5)
	task.wait(6)
	FadeIn(0.5)
	task.wait(0.5)
	FadeOut(0.5)
	TweenService:Create(CurrentCamera, TweenInfo.new(3), {
		FieldOfView = 70
	}):Play()
	CurrentCamera.CameraType = Enum.CameraType.Custom
end

local function EmitInstance(p1) --[[ EmitInstance | Line: 291 | Upvalues: UtilsModule (copy) ]]
	if not p1 then
		return
	end

	UtilsModule.EmitAll(p1)
end

local function FirstMeteorExplosion() --[[ FirstMeteorExplosion | Line: 302 | Upvalues: v2 (copy) ]]
	v2:ShakeOnce(10, 5, 0.1, 5)
end

local function ShakeCamera(p1, p2, p3, p4, p5) --[[ ShakeCamera | Line: 311 | Upvalues: v2 (copy) ]]
	v2:ShakeOnce(p1, p2, p3, p4, p5)
end

local function MegaExplosion() --[[ MegaExplosion | Line: 319 | Upvalues: v2 (copy), TweenService (copy), CurrentCamera (copy) ]]
	v2:ShakeOnce(10, 10, 0.1, 10)
	TweenService:Create(CurrentCamera, TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		FieldOfView = 100
	}):Play()
	task.wait(0.5)
	TweenService:Create(CurrentCamera, TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		FieldOfView = 70
	}):Play()
end

local function CustomCountdown(p1, p2) --[[ CustomCountdown | Line: 331 | Upvalues: EventFrame (copy), TweenService (copy), TypeWriter (copy), LiveEventClient (copy) ]]
	local Countdown = EventFrame:WaitForChild("Countdown")
	local Title = Countdown:WaitForChild("Title")
	local Timer = Countdown:WaitForChild("Timer")

	Countdown.Visible = true
	Title.TextTransparency = 1
	Timer.TextTransparency = 1
	TweenService:Create(Title, TweenInfo.new(0.5), {
		TextTransparency = 0
	}):Play()
	TweenService:Create(Timer, TweenInfo.new(0.5), {
		TextTransparency = 0
	}):Play()
	TypeWriter(Title, p1, 0.03)

	for i = p2, 0, -1 do
		Timer.Text = string.format("%d:%02d", math.floor(i / 60), i % 60)
		LiveEventClient:WaitForChild("ClockTick"):Play()
		task.wait(1)
	end

	local v2 = TweenService:Create(Title, TweenInfo.new(0.5), {
		TextTransparency = 1
	})

	v2:Play()

	local v3 = TweenService:Create(Timer, TweenInfo.new(0.5), {
		TextTransparency = 1
	})

	v3:Play()
	v2.Completed:Wait()
	v3.Completed:Wait()
	Countdown.Visible = false
end

local function ShowCredits() --[[ ShowCredits | Line: 364 | Upvalues: EventFrame (copy), StarterGui (copy), DisableAllScreensGui (copy), TweenService (copy), CurrentCamera (copy) ]]
	local CreditsFrame = EventFrame:WaitForChild("CreditsFrame")
	local Shadow = CreditsFrame:WaitForChild("Shadow")
	local Credits = CreditsFrame:WaitForChild("Credits")

	StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.All, false)
	CreditsFrame.Visible = true
	Shadow.Visible = true
	DisableAllScreensGui()
	TweenService:Create(CurrentCamera, TweenInfo.new(8), {
		FieldOfView = 25
	}):Play()
	Shadow.ImageTransparency = 1
	TweenService:Create(Shadow, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		ImageTransparency = 0
	}):Play()
	Credits.Position = UDim2.new(0.5, 0, -0.3, 0)
	Credits.AnchorPoint = Vector2.new(0.5, 0.5)
	TweenService:Create(Credits, TweenInfo.new(10, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		Position = UDim2.new(0.5, 0, 0.5, 0)
	}):Play()
end

local v3 = nil

local function TweenCameraToMeteor() --[[ TweenCameraToMeteor | Line: 399 | Upvalues: Cameras (copy), StarterGui (copy), CurrentCamera (copy), DisableAllScreensGui (copy), FadeIn (copy), FadeOut (copy), TweenService (copy), v3 (ref), RunService (copy) ]]
	local OldMeteor = workspace:WaitForChild("LiveEventWorkspace"):WaitForChild("Meteor"):WaitForChild("OldMeteor")
	local EndCam = Cameras:WaitForChild("EndCam")

	StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.All, false)
	CurrentCamera.CameraType = Enum.CameraType.Scriptable
	CurrentCamera.CFrame = EndCam.CFrame

	local v1 = nil or 10
	local v2 = nil or 0.2

	task.spawn(function() --[[ Line: 61 | Upvalues: v1 (ref), StarterGui (ref), v2 (ref) ]]
		for i = 1, v1 do
			if pcall(function() --[[ Line: 63 | Upvalues: StarterGui (ref) ]]
				StarterGui:SetCore("ResetButtonCallback", false)
			end) then
				break
			end

			task.wait(v2)
		end
	end)
	DisableAllScreensGui()
	FadeIn(0.5)
	task.wait(0.6)
	FadeOut(0.25)
	TweenService:Create(CurrentCamera, TweenInfo.new(3), {
		FieldOfView = 60
	}):Play()

	if not v3 then
		v3 = RunService.RenderStepped:Connect(function() --[[ Line: 423 | Upvalues: CurrentCamera (ref), OldMeteor (copy) ]]
			local Position2 = OldMeteor:GetPivot().Position

			CurrentCamera.CFrame = CFrame.new(CurrentCamera.CFrame.Position, Position2)
		end)

		return
	end

	v3:Disconnect()
	v3 = RunService.RenderStepped:Connect(function() --[[ Line: 423 | Upvalues: CurrentCamera (ref), OldMeteor (copy) ]]
		local Position2 = OldMeteor:GetPivot().Position

		CurrentCamera.CFrame = CFrame.new(CurrentCamera.CFrame.Position, Position2)
	end)
end

local function StopCameraLook() --[[ StopCameraLook | Line: 431 | Upvalues: v3 (ref) ]]
	if not v3 then
		return
	end

	v3:Disconnect()
	v3 = nil
end

local function EndCam() --[[ EndCam | Line: 438 | Upvalues: Cameras (copy), v3 (ref), v2 (copy), StarterGui (copy), CurrentCamera (copy), TweenService (copy) ]]
	local EndCam = Cameras:WaitForChild("EndCam")
	local v1, v22

	if not v3 then
		v2:StopSustained(0.1)
		v1 = nil or 10
		v22 = nil or 0.2
		task.spawn(function() --[[ Line: 61 | Upvalues: v1 (ref), StarterGui (ref), v22 (ref) ]]
			for i = 1, v1 do
				if pcall(function() --[[ Line: 63 | Upvalues: StarterGui (ref) ]]
					StarterGui:SetCore("ResetButtonCallback", false)
				end) then
					break
				end

				task.wait(v22)
			end
		end)
		CurrentCamera.CameraType = Enum.CameraType.Scriptable
		TweenService:Create(CurrentCamera, TweenInfo.new(1), {
			CFrame = EndCam.CFrame
		}):Play()
		TweenService:Create(CurrentCamera, TweenInfo.new(3), {
			FieldOfView = 55
		}):Play()

		return
	end

	v3:Disconnect()
	v3 = nil
	v2:StopSustained(0.1)
	v1 = nil or 10
	v22 = nil or 0.2
	task.spawn(function() --[[ Line: 61 | Upvalues: v1 (ref), StarterGui (ref), v22 (ref) ]]
		for i = 1, v1 do
			if pcall(function() --[[ Line: 63 | Upvalues: StarterGui (ref) ]]
				StarterGui:SetCore("ResetButtonCallback", false)
			end) then
				break
			end

			task.wait(v22)
		end
	end)
	CurrentCamera.CameraType = Enum.CameraType.Scriptable
	TweenService:Create(CurrentCamera, TweenInfo.new(1), {
		CFrame = EndCam.CFrame
	}):Play()
	TweenService:Create(CurrentCamera, TweenInfo.new(3), {
		FieldOfView = 55
	}):Play()
end

LiveEvent.OnClientEvent:Connect(function(p1, ...) --[[ Line: 457 | Upvalues: IntroStart (copy), Subtitle (copy), MeteorCutscene1 (copy), UtilsModule (copy), v2 (copy), MegaExplosion (copy), CustomCountdown (copy), EndCam (copy), TweenCameraToMeteor (copy), ShowCredits (copy), FadeIn (copy) ]]
	if p1 == "Intro" then
		IntroStart()

		return
	end

	if p1 == "Subtitle" then
		Subtitle(...)

		return
	end

	if p1 == "MeteorCutscene1" then
		MeteorCutscene1()

		return
	end

	if p1 == "EmitInstance" then
		local v1 = ...

		if v1 then
			UtilsModule.EmitAll(v1)
		end
	else
		if p1 == "FirstMeteorExplosion" then
			v2:ShakeOnce(10, 5, 0.1, 5)

			return
		end

		if p1 == "ShakeCamera" then
			local v22, v3, v4, v5, v6 = ...

			v2:ShakeOnce(v22, v3, v4, v5, v6)

			return
		end

		if p1 == "MegaExplosion" then
			MegaExplosion()

			return
		end

		if p1 == "CustomCountdown" then
			CustomCountdown(...)

			return
		end

		if p1 == "EndCam" then
			EndCam(...)

			return
		end

		if p1 == "TweenCameraToMeteor" then
			TweenCameraToMeteor(...)

			return
		end

		if p1 == "ShowCredits" then
			EndCam()
			ShowCredits()

			return
		end

		if p1 ~= "TheEnd" then
			return
		end

		FadeIn(5)
	end
end)
UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 498 | Upvalues: LocalPlayer (copy), LiveEvent (copy) ]]
	if p2 then
		return
	end

	if LocalPlayer.Name ~= "uDavidII" or p1.KeyCode ~= Enum.KeyCode.Z then
		return
	end

	LiveEvent:FireServer("ForceStart")
end)