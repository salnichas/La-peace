-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

game:GetService("RunService")

local LocalPlayer = Players.LocalPlayer
local v1 = LocalPlayer:WaitForChild("Miss\195\181esData", 60)
local TempoJogado = v1:WaitForChild("TempoJogado", 60)
local GramasCortadas = v1:WaitForChild("GramasCortadas", 60)
local LixosRecolhidos = v1:WaitForChild("LixosRecolhidos", 60)
local v2 = v1:WaitForChild("Miss\195\163oAtual", 60)
local FinishedRankMission = v1:WaitForChild("FinishedRankMission", 60)
local FinishedEventMission = v1:WaitForChild("FinishedEventMission", 60)
local LastMissionTime = v1:WaitForChild("LastMissionTime", 60)
local Handler = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("Events"):WaitForChild("Miss\195\163o"):WaitForChild("Handler")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local NotificationClient = require(Modules:WaitForChild("NotificationClient"))
local v3 = script.Parent
local Main = v3:WaitForChild("Main")
local Title = Main:WaitForChild("Title")
local Infos = Main:WaitForChild("Infos")
local Fechar = Main:WaitForChild("Fechar")

Main:WaitForChild("Voltar")

local LoadingIcon = Main:WaitForChild("LoadingIcon")
local LoadingDataWarn = Main:WaitForChild("LoadingDataWarn")
local CooldownWarn = Main:WaitForChild("CooldownWarn")
local CooldownRemaining = Main:WaitForChild("CooldownRemaining")
local AnyWarnTitle = Main:WaitForChild("AnyWarnTitle")
local AnyWarnInfo = Main:WaitForChild("AnyWarnInfo")

Main:WaitForChild("MissionsTitle")

local CooldownTitle = Main:WaitForChild("CooldownTitle")
local Geral = Main:WaitForChild("Geral")
local Graduados = Main:WaitForChild("Graduados")
local v4 = Main:WaitForChild("Pra\195\167as")
local Locked = Geral:WaitForChild("Locked")
local Locked2 = Graduados:WaitForChild("Locked")
local Locked3 = v4:WaitForChild("Locked")
local CurrentMission = Main:WaitForChild("CurrentMission")
local Tempo = CurrentMission:WaitForChild("Tempo")
local Gramas = CurrentMission:WaitForChild("Gramas")
local Lixos = CurrentMission:WaitForChild("Lixos")
local Recompensa = CurrentMission:WaitForChild("Recompensa")
local ProgressMain = Main:WaitForChild("ProgressMain")
local ProgressBar = ProgressMain:WaitForChild("ProgressBar")
local ProgressText = ProgressMain:WaitForChild("ProgressText")
local Aceitar = Main:WaitForChild("Aceitar")
local Bar1 = Main:WaitForChild("Bar1")
local Bar2 = Main:WaitForChild("Bar2")

while not LocalPlayer:GetAttribute("RanksAndRolesLoaded") do
	LocalPlayer:GetAttributeChangedSignal("RanksAndRolesLoaded"):Wait()
end

local PlayerInfos = LocalPlayer:WaitForChild("PlayerInfos", 60)
local v5

if PlayerInfos then
	if not PlayerInfos:GetAttribute("EB_Rank") then
		return
	end

	if typeof(PlayerInfos:GetAttribute("EB_Rank")) ~= "number" then
		return
	end

	v5 = PlayerInfos:GetAttribute("EB_Rank")
else
	v5 = 0
end

if v5 <= 0 then
	return
end

local t = {
	["Pra\195\167as"] = {
		Grama = 30,
		Lixo = 15,
		TempoJogado = 30,
		Recompensa = "+1 Up de Patente"
	},
	Graduados = {
		Grama = 60,
		Lixo = 30,
		TempoJogado = 60,
		Recompensa = "+1 Up de Patente"
	},
	Evento = {
		Grama = 100,
		Lixo = 75,
		TempoJogado = 85,
		Recompensa = "+1 Up de Patente e uma Deagle dourada permanente"
	}
}
local v6 = "N/A"
local v7 = false
local v8 = true

local function EmptyGui() --[[ EmptyGui | Line: 141 | Upvalues: AnyWarnTitle (copy), AnyWarnInfo (copy), Main (copy), Title (copy), Fechar (copy), Infos (copy) ]]
	AnyWarnTitle.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	AnyWarnInfo.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	AnyWarnTitle.Text = "Aguardando T\195\173tulo..."
	AnyWarnInfo.Text = "Aguardando Informa\195\167\195\181es..."

	for v1, v2 in Main:GetChildren() do
		if v2:IsA("GuiObject") then
			v2.Visible = false
		end
	end

	Title.Visible = true
	Fechar.Visible = true
	Infos.Visible = true
end

local function ErrorScreen(p1) --[[ ErrorScreen | Line: 165 | Upvalues: EmptyGui (copy), Infos (copy), Main (copy), AnyWarnTitle (copy), AnyWarnInfo (copy) ]]
	EmptyGui()
	Infos.Visible = false
	Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
	AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
	AnyWarnInfo.Text = p1 .. " Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
	AnyWarnTitle.Visible = true
	AnyWarnInfo.Visible = true
end

local function UpdateProgress() --[[ UpdateProgress | Line: 181 | Upvalues: v7 (ref), v6 (ref), t (copy), EmptyGui (copy), Infos (copy), Main (copy), AnyWarnTitle (copy), AnyWarnInfo (copy), LixosRecolhidos (copy), GramasCortadas (copy), TempoJogado (copy), Tempo (copy), Gramas (copy), Lixos (copy), ProgressText (copy), TweenService (copy), ProgressBar (copy), Handler (copy) ]]
	if v7 then
		return
	end

	if v6 == "N/A" then
		return
	end

	local v1 = t[v6]

	if not v1 then
		warn("[MISS\195\131O] Vari\195\161vel \'MissaoEncontrada\' n\195\163o encontrada! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Infos.Visible = false
		Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
		AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
		AnyWarnInfo.Text = "Erro ao encontrar sua miss\195\163o! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
	else
		local v2 = LixosRecolhidos.Value
		local v3 = GramasCortadas.Value
		local v4 = TempoJogado.Value

		if typeof(v2) ~= "number" or (typeof(v3) ~= "number" or typeof(v4) ~= "number") then
			warn("[MISS\195\131O] Um dos valores do jogador est\195\161 com formato inv\195\161lido! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Infos.Visible = false
			Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
			AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
			AnyWarnInfo.Text = "Algum valor est\195\161 com formato inv\195\161lido! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		else
			local TempoJogado2 = v1.TempoJogado
			local Grama = v1.Grama
			local Lixo = v1.Lixo

			if TempoJogado2 and (Grama and Lixo) then
				local v5 = math.floor(v4 / 60)
				local v62 = math.clamp(v5 / TempoJogado2, 0, 1)
				local v72 = math.clamp(v3 / Grama, 0, 1)
				local v8 = math.clamp(v2 / Lixo, 0, 1)

				if Tempo and Tempo.Text then
					Tempo.Text = ("Tempo Jogado: %* / %* minutos"):format(v5, TempoJogado2)
				end

				if Gramas and Gramas.Text then
					Gramas.Text = ("Gramas Cortadas: %* / %*"):format(tostring(v3), Grama)
				end

				if Lixos and Lixos.Text then
					Lixos.Text = ("Lixo Coletado: %* / %*"):format(tostring(v2), Lixo)
				end

				local v9 = (v8 + v72 + v62) / 3

				if ProgressText and ProgressText.Text then
					ProgressText.Text = string.format("%d%%", (math.floor(v9 * 100)))
				end

				TweenService:Create(ProgressBar, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					Size = UDim2.new(v9, 0, 1, 0)
				}):Play()

				if not (v9 >= 1) then
					return
				end

				v7 = true

				if ProgressText and ProgressText.Text then
					ProgressText.Text = "100%"
				end

				Handler:FireServer("Finalizar")
				EmptyGui()
				AnyWarnTitle.Text = "Processando Miss\195\163o..."
				AnyWarnInfo.Text = "O Servidor est\195\161 processando sua miss\195\163o, aguarde alguns minutos!"
			else
				warn("[MISS\195\131O] Algum valor da sua miss\195\163o n\195\163o foi encontrado! Se alguma das seguintes vari\195\161veis estiver como \'nil\', por favor reporte o bug aos desenvolvedores do jogo. TempoNecessario:", TempoJogado2, "| GramasNecessarias:", Grama, "| LixosNecessarios:", Lixo)
				EmptyGui()
				Infos.Visible = false
				Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
				AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
				AnyWarnInfo.Text = "Algum valor da sua miss\195\163o n\195\163o foi encontrado! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			end
		end
	end

	AnyWarnTitle.Visible = true
	AnyWarnInfo.Visible = true
end

local function SetupGui() --[[ SetupGui | Line: 292 | Upvalues: v7 (ref), EmptyGui (copy), v2 (copy), v6 (ref), t (copy), Infos (copy), Main (copy), AnyWarnTitle (copy), AnyWarnInfo (copy), CurrentMission (copy), Recompensa (copy), v5 (ref), ProgressMain (copy), Bar1 (copy), Bar2 (copy), LoadingIcon (copy), LoadingDataWarn (copy), Handler (copy), UpdateProgress (copy), NotificationClient (copy), Geral (copy), Locked (copy), Graduados (copy), Locked2 (copy), v4 (copy), Locked3 (copy), FinishedRankMission (copy) ]]
	v7 = false
	EmptyGui()

	if v2.Value == "N/A" then
		Geral.Interactable = true
		Geral.Visible = true
		Locked.Visible = false
		Graduados.Interactable = false
		Graduados.Visible = true
		Locked2.Visible = true
		v4.Interactable = false
		v4.Visible = true
		Locked3.Visible = true

		if v5 >= 1 and (v5 <= 3 and not FinishedRankMission.Value) then
			v4.Interactable = true
			Locked3.Visible = false

			return
		end

		if not (v5 >= 4) or (not (v5 <= 7) or FinishedRankMission.Value) then
			return
		end

		Graduados.Interactable = true
		Locked2.Visible = false
	else
		v6 = v2.Value

		local v1 = t[v6]

		if not v1 then
			warn("[MISS\195\131O] Vari\195\161vel \'MissaoEncontrada\' n\195\163o encontrada! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Infos.Visible = false
			Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
			AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
			AnyWarnInfo.Text = "Erro ao encontrar sua miss\195\163o! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			AnyWarnTitle.Visible = true
			AnyWarnInfo.Visible = true

			return
		end

		local Recompensa2 = v1.Recompensa

		if not Recompensa2 then
			warn("[MISS\195\131O] Vari\195\161vel \'Recompensa\' n\195\163o encontrada! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Infos.Visible = false
			Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
			AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
			AnyWarnInfo.Text = "Erro ao encontrar recompensa da miss\195\163o! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			AnyWarnTitle.Visible = true
			AnyWarnInfo.Visible = true

			return
		end

		CurrentMission.Text = "Miss\195\163o: " .. v6
		Recompensa.Text = "Recompensa: " .. Recompensa2

		if v6 ~= "Evento" or not (v5 >= 18) then
			CurrentMission.Visible = true
			ProgressMain.Visible = true
			Bar1.Visible = true
			Bar2.Visible = true
			LoadingIcon.Visible = false
			LoadingDataWarn.Visible = false
			Handler:FireServer("Continuar")
			UpdateProgress()
			NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 tem uma miss\195\163o ativa! Termine a miss\195\163o para receber sua recompensa.")

			return
		end

		Recompensa.Text = "Recompensa: Deagle dourada"
		CurrentMission.Visible = true
		ProgressMain.Visible = true
		Bar1.Visible = true
		Bar2.Visible = true
		LoadingIcon.Visible = false
		LoadingDataWarn.Visible = false
		Handler:FireServer("Continuar")
		UpdateProgress()
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 tem uma miss\195\163o ativa! Termine a miss\195\163o para receber sua recompensa.")
	end
end

local function PlayLoadingAnimation(p1) --[[ PlayLoadingAnimation | Line: 410 | Upvalues: LoadingIcon (copy), LoadingDataWarn (copy), TweenService (copy) ]]
	LoadingIcon.Visible = true
	LoadingDataWarn.Visible = true
	LoadingIcon.Rotation = 0

	local v1 = TweenService:Create(LoadingIcon, TweenInfo.new(1, Enum.EasingStyle.Linear), {
		Rotation = 360
	})

	v1:Play()
	v1.Completed:Wait()

	if not p1 then
		return
	end

	LoadingIcon.Visible = false
	LoadingDataWarn.Visible = false
end

local function CheckCooldown() --[[ CheckCooldown | Line: 437 | Upvalues: v1 (copy), EmptyGui (copy), Infos (copy), Main (copy), AnyWarnTitle (copy), AnyWarnInfo (copy), LastMissionTime (copy) ]]
	if not v1 then
		warn("[MISS\195\131O] Vari\195\161vel \'MissoesData\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Infos.Visible = false
		Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
		AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
		AnyWarnInfo.Text = "A vari\195\161vel \'MissoesData\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		AnyWarnTitle.Visible = true
		AnyWarnInfo.Visible = true

		return
	end

	if not LastMissionTime then
		warn("[MISS\195\131O] \'LastMissionTime\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Infos.Visible = false
		Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
		AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
		AnyWarnInfo.Text = "A vari\195\161vel \'LastMissionTime\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		AnyWarnTitle.Visible = true
		AnyWarnInfo.Visible = true

		return
	end

	if LastMissionTime.Value > 0 then
		return true, LastMissionTime.Value
	end
end

local function RequestMission(p1) --[[ RequestMission | Line: 467 | Upvalues: EmptyGui (copy), t (copy), v6 (ref), Infos (copy), Main (copy), AnyWarnTitle (copy), AnyWarnInfo (copy), Tempo (copy), Gramas (copy), Lixos (copy), Bar1 (copy), Bar2 (copy), CurrentMission (copy), Recompensa (copy), v5 (ref), Aceitar (copy), ProgressMain (copy) ]]
	EmptyGui()

	local v1 = t[v6]

	if not v1 then
		warn("[MISS\195\131O] Vari\195\161vel \'MissaoEncontrada\' n\195\163o encontrada! Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Infos.Visible = false
		Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
		AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
		AnyWarnInfo.Text = "Erro ao encontrar sua miss\195\163o! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		AnyWarnTitle.Visible = true
		AnyWarnInfo.Visible = true

		return
	end

	local TempoJogado = v1.TempoJogado
	local Grama = v1.Grama
	local Lixo = v1.Lixo
	local Recompensa2 = v1.Recompensa

	if TempoJogado and (Grama and (Lixo and Recompensa2)) then
		if Tempo and Tempo.Text then
			Tempo.Text = ("Tempo Jogado: 0/%* minutos"):format(TempoJogado)
		end

		if Gramas and Gramas.Text then
			Gramas.Text = ("Gramas Cortadas: 0/%*"):format(Grama)
		end

		if Lixos and Lixos.Text then
			Lixos.Text = ("Lixo Coletado: 0/%*"):format(Lixo)
		end

		Bar1.Visible = true
		Bar2.Visible = true
		CurrentMission.Text = "Miss\195\163o: " .. v6
		Recompensa.Text = "Recompensa: " .. Recompensa2

		if v6 == "Evento" and v5 >= 18 then
			Recompensa.Text = "Recompensa: Deagle dourada"
		end

		CurrentMission.Visible = true

		if p1 == "MostrarConteudo" then
			Aceitar.Visible = true

			return
		end

		if p1 ~= "Confirmar" then
			return
		end

		Aceitar.Visible = false
		ProgressMain.Visible = true
	else
		warn("[MISS\195\131O] Algum valor da sua miss\195\163o n\195\163o foi encontrado! Se alguma das seguintes vari\195\161veis estiver como \'nil\', por favor reporte o bug aos desenvolvedores do jogo. TempoNecessario:", TempoJogado, "| GramasNecessarias:", Grama, "| LixosNecessarios:", Lixo)
		EmptyGui()
		Infos.Visible = false
		Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
		AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
		AnyWarnInfo.Text = "Algum valor da sua miss\195\163o n\195\163o foi encontrado! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		AnyWarnTitle.Visible = true
		AnyWarnInfo.Visible = true
	end
end

Fechar.Activated:Connect(function() --[[ Line: 546 | Upvalues: v3 (copy) ]]
	v3.Enabled = false
end)
Geral.Activated:Connect(function() --[[ Line: 552 | Upvalues: v8 (ref), v6 (ref), RequestMission (copy) ]]
	if v8 then
		v8 = false
		task.delay(1, function() --[[ Line: 557 | Upvalues: v8 (ref) ]]
			v8 = true
		end)
		v6 = "Evento"
		RequestMission("MostrarConteudo")
	end
end)
Graduados.Activated:Connect(function() --[[ Line: 605 | Upvalues: v5 (ref), v8 (ref), v1 (copy), EmptyGui (copy), Infos (copy), Main (copy), AnyWarnTitle (copy), AnyWarnInfo (copy), LastMissionTime (copy), CooldownTitle (copy), CooldownWarn (copy), CooldownRemaining (copy), NotificationClient (copy), v6 (ref), RequestMission (copy) ]]
	if v5 <= 3 then
		return
	end

	if not v8 then
		return
	end

	v8 = false
	task.delay(1, function() --[[ Line: 612 | Upvalues: v8 (ref) ]]
		v8 = true
	end)

	local v12, v2

	if v1 then
		if LastMissionTime then
			if LastMissionTime.Value > 0 then
				v12 = LastMissionTime.Value
				v2 = true
			else
				v2 = nil
				v12 = nil
			end
		else
			warn("[MISS\195\131O] \'LastMissionTime\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Infos.Visible = false
			Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
			AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
			AnyWarnInfo.Text = "A vari\195\161vel \'LastMissionTime\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			AnyWarnTitle.Visible = true
			AnyWarnInfo.Visible = true
			v2 = nil
			v12 = nil
		end
	else
		warn("[MISS\195\131O] Vari\195\161vel \'MissoesData\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Infos.Visible = false
		Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
		AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
		AnyWarnInfo.Text = "A vari\195\161vel \'MissoesData\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		AnyWarnTitle.Visible = true
		AnyWarnInfo.Visible = true
		v2 = nil
		v12 = nil
	end

	if not (v2 and v12) then
		v6 = "Graduados"
		RequestMission("MostrarConteudo")

		return
	end

	local v3 = 86400 - (os.time() - v12)

	if v3 > 0 then
		local v62 = string.format("%02d:%02d:%02d", math.floor(v3 / 3600) % 24, math.floor(v3 / 60) % 60, v3 % 60)

		EmptyGui()
		CooldownTitle.Visible = true
		CooldownWarn.Visible = true
		CooldownRemaining.Visible = true
		CooldownRemaining.Text = "Tempo Restante: " .. v62
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 precisa aguardar para fazer outra miss\195\163o.")
	else
		v6 = "Graduados"
		RequestMission("MostrarConteudo")
	end
end)
v4.Activated:Connect(function() --[[ Line: 660 | Upvalues: v5 (ref), v8 (ref), v1 (copy), EmptyGui (copy), Infos (copy), Main (copy), AnyWarnTitle (copy), AnyWarnInfo (copy), LastMissionTime (copy), CooldownTitle (copy), CooldownWarn (copy), CooldownRemaining (copy), NotificationClient (copy), v6 (ref), RequestMission (copy) ]]
	if v5 >= 4 then
		return
	end

	if not v8 then
		return
	end

	v8 = false
	task.delay(1, function() --[[ Line: 667 | Upvalues: v8 (ref) ]]
		v8 = true
	end)

	local v12, v2

	if v1 then
		if LastMissionTime then
			if LastMissionTime.Value > 0 then
				v12 = LastMissionTime.Value
				v2 = true
			else
				v2 = nil
				v12 = nil
			end
		else
			warn("[MISS\195\131O] \'LastMissionTime\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			Infos.Visible = false
			Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
			AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
			AnyWarnInfo.Text = "A vari\195\161vel \'LastMissionTime\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			AnyWarnTitle.Visible = true
			AnyWarnInfo.Visible = true
			v2 = nil
			v12 = nil
		end
	else
		warn("[MISS\195\131O] Vari\195\161vel \'MissoesData\' n\195\163o encontrado; Se voc\195\170 consegue ver esse erro, por favor reporte o bug aos desenvolvedores do jogo.")
		EmptyGui()
		Infos.Visible = false
		Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
		AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
		AnyWarnInfo.Text = "A vari\195\161vel \'MissoesData\' n\195\163o foi encontrada! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
		AnyWarnTitle.Visible = true
		AnyWarnInfo.Visible = true
		v2 = nil
		v12 = nil
	end

	if not (v2 and v12) then
		v6 = "Pra\195\167as"
		RequestMission("MostrarConteudo")

		return
	end

	local v3 = 86400 - (os.time() - v12)

	if v3 > 0 then
		local v62 = string.format("%02d:%02d:%02d", math.floor(v3 / 3600) % 24, math.floor(v3 / 60) % 60, v3 % 60)

		EmptyGui()
		CooldownTitle.Visible = true
		CooldownWarn.Visible = true
		CooldownRemaining.Visible = true
		CooldownRemaining.Text = "Tempo Restante: " .. v62
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 precisa aguardar para fazer outra miss\195\163o.")
	else
		v6 = "Pra\195\167as"
		RequestMission("MostrarConteudo")
	end
end)
Aceitar.Activated:Connect(function() --[[ Line: 715 | Upvalues: v8 (ref), EmptyGui (copy), PlayLoadingAnimation (copy), RequestMission (copy), Handler (copy), v6 (ref), NotificationClient (copy) ]]
	if v8 then
		v8 = false
		task.delay(1, function() --[[ Line: 720 | Upvalues: v8 (ref) ]]
			v8 = true
		end)
		EmptyGui()
		PlayLoadingAnimation(true)
		RequestMission("Confirmar")
		Handler:FireServer("Come\195\167ar", v6)
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 iniciou a miss\195\163o \'" .. v6 .. "\', complete e receba sua recompensa! Boa sorte!")
	end
end)

if TempoJogado and (GramasCortadas and (LixosRecolhidos and (v2 and (FinishedRankMission and FinishedEventMission)))) then
	PlayLoadingAnimation(true)
	SetupGui()
	TempoJogado:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 751 | Upvalues: UpdateProgress (copy) ]]
		UpdateProgress()
	end)
	GramasCortadas:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 757 | Upvalues: UpdateProgress (copy) ]]
		UpdateProgress()
	end)
	LixosRecolhidos:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 763 | Upvalues: UpdateProgress (copy) ]]
		UpdateProgress()
	end)
	Handler.OnClientEvent:Connect(function(p1, p2) --[[ Line: 769 | Upvalues: NotificationClient (copy), EmptyGui (copy), AnyWarnTitle (copy), v6 (ref), v5 (ref), AnyWarnInfo (copy), SetupGui (copy), Infos (copy), Main (copy) ]]
		if p1 == "Finalizou" then
			NotificationClient:Notification("Normal", "[MISS\195\131O]", "Voc\195\170 finalizou a miss\195\163o! Voc\195\170 receber\195\161 sua recompensa dentro de 24 horas. Se n\195\163o receber, por favor reporte o bug aos desenvolvedores do jogo.")
			EmptyGui()
			AnyWarnTitle.Text = "Sua miss\195\163o foi processada corretamente!"

			if v6 == "Evento" then
				if v5 >= 18 then
					AnyWarnInfo.Text = "Seu item foi entregue! Para equipar o item, Reentre no jogo e procure o item na mochila localizada \195\160 esquerda da sua tela. Caso seu item n\195\163o tenha sido entregue ap\195\179s o rejoin, aguarde alguns minutos e tente novamente. Se mesmo assim seu item n\195\163o tiver sido entregue, por favor reporte o bug aos desenvolvedores do jogo."
				else
					AnyWarnInfo.Text = "Sua patente e seu item foram entregues! Para equipar o item, Reentre no jogo e procure o item na mochila localizada \195\160 esquerda da sua tela. Caso sua patente e seu item n\195\163o tenham sido entregue ap\195\179s o rejoin, aguarde alguns minutos e tente novamente. Se mesmo assim sua patente e seu item n\195\163o tiverem sido entregues, por favor reporte o bug aos desenvolvedores do jogo."
				end
			else
				AnyWarnInfo.Text = "Sua patente foi entregue! Reentre no jogo para as mudan\195\167as serem aplicadas. Caso sua patente n\195\163o tenha sido entregue ap\195\179s o rejoin, aguarde alguns minutos e tente novamente. Se mesmo assim sua patente n\195\163o tiver sido entregue, por favor reporte o bug aos desenvolvedores do jogo."
			end

			AnyWarnTitle.TextColor3 = Color3.new(0/255, 255/255, 0/255)
			AnyWarnInfo.TextColor3 = Color3.new(0/255, 255/255, 0/255)
			AnyWarnTitle.Visible = true
			AnyWarnInfo.Visible = true
			task.delay(10, function() --[[ Line: 803 | Upvalues: SetupGui (ref) ]]
				SetupGui()
			end)
		else
			if p1 ~= "Error" then
				return
			end

			EmptyGui()
			Infos.Visible = false
			Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
			AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
			AnyWarnInfo.Text = p2 .. " Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
			AnyWarnTitle.Visible = true
			AnyWarnInfo.Visible = true
		end
	end)

	local v9 = LastMissionTime.Value

	if v9 > 0 then
		while true do
			if FinishedEventMission.Value then
				EmptyGui()
				AnyWarnTitle.Text = "Voc\195\170 completou todas suas miss\195\181es!"
				AnyWarnInfo.Text = "Aguarde novas miss\195\181es serem adicionadas ao jogo para voltar a fazer mais miss\195\181es."
				AnyWarnTitle.Visible = true
				AnyWarnInfo.Visible = true

				return
			end

			local v10 = 86400 - (os.time() - v9)

			if v10 <= 0 then
				break
			end

			local v13 = "Tempo Restante: " .. string.format("%02d:%02d:%02d", math.floor(v10 / 3600), math.floor(v10 / 60) % 60, v10 % 60)

			if CooldownRemaining.Text ~= v13 then
				CooldownRemaining.Text = v13
			end

			task.wait(1)
		end

		SetupGui()
		NotificationClient:Notification("Normal", "[MISS\195\131O]", "Seu Cooldown acabou! Voc\195\170 j\195\161 pode fazer outra miss\195\163o!")
	else
		SetupGui()
	end
else
	warn("[MISS\195\131O] Alguma vari\195\161vel importante falhou em carregar. Se alguma das seguintes vari\195\161veis estiver como \'nil\', por favor reporte o bug aos desenvolvedores do jogo. TempoJogado:", TempoJogado, "| GramasCortadas:", GramasCortadas, "| LixosRecolhidos:", LixosRecolhidos, "| MissaoAtual:", v2, "| FinishedRankMission:", FinishedRankMission, "| FinishedEventMission:", FinishedEventMission)
	EmptyGui()
	Infos.Visible = false
	Main.BackgroundColor3 = Color3.new(0, 0.576471, 0.862745)
	AnyWarnTitle.Text = "Um erro inesperado ocorreu! :("
	AnyWarnInfo.Text = "Uma das vari\195\161veis importantes para o funcionamento do sistema n\195\163o conseguiu carregar corretamente! Se poss\195\173vel, abra o console de desenvolvedor e veja se h\195\161 algum erro relacionado ao sistema de miss\195\181es. Em seguida, tire um print dessa tela e envie no canal de \'Bugs\' no nosso servidor de comunica\195\167\195\181es."
	AnyWarnTitle.Visible = true
	AnyWarnInfo.Visible = true
end