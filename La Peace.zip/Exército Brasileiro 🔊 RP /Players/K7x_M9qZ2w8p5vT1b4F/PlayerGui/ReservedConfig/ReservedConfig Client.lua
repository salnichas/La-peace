-- https://lua.expert/
local Knit = require(game:GetService("ReplicatedStorage").Modules.Packages.Knit)

Knit.OnStart():expect()

local ReservedService = Knit.GetService("ReservedService")
local Trainnings = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("Trainnings")
local LocalPlayer = game.Players.LocalPlayer
local v1 = script.Parent
local Main = v1:WaitForChild("Main")
local Sim = Main:WaitForChild("Sim")
local Nao = Main:WaitForChild("Nao")
local Graduados = Main:WaitForChild("Graduados")
local Pracas = Main:WaitForChild("Pracas")
local Outros = Main:WaitForChild("Outros")
local Aviso01 = Main:WaitForChild("Aviso01")

Graduados.Visible = false
Pracas.Visible = false
Outros.Visible = false

if game.Workspace:GetAttribute("Owner") == LocalPlayer.UserId then
	v1.Enabled = true
end

local function resetGUI() --[[ resetGUI | Line: 28 | Upvalues: v1 (copy) ]]
	v1.Enabled = false
end

Sim.MouseButton1Up:Connect(function() --[[ Line: 32 | Upvalues: ReservedService (copy), Sim (copy), Nao (copy), Graduados (copy), Pracas (copy), Outros (copy), Aviso01 (copy) ]]
	ReservedService:ActiveTrainingMode()
	Sim.Visible = false
	Nao.Visible = false
	Graduados.Visible = true
	Pracas.Visible = true
	Outros.Visible = true
	Aviso01.Text = "Qual a categoria do treino?"
end)
Nao.MouseButton1Up:Connect(function() --[[ Line: 44 | Upvalues: v1 (copy) ]]
	v1.Enabled = false
	v1:Destroy()
end)

local function onCategoryClicked(p1) --[[ onCategoryClicked | Line: 49 | Upvalues: ReservedService (copy), Trainnings (copy), v1 (copy) ]]
	if not (p1 and p1.ButtonName) then
		return
	end

	local v12 = ReservedService:GetMyReservedServer()

	if v12 then
		print("Anunciando treino:", p1.ButtonName, "ID:", v12)
		Trainnings:FireServer({
			action = "create",
			id = v12,
			tipo = p1.ButtonName
		})
		v1.Enabled = false
	else
		warn("Sem servidor reservado")
	end
end

Graduados.MouseButton1Up:Connect(function() --[[ Line: 69 | Upvalues: onCategoryClicked (copy) ]]
	onCategoryClicked({
		ButtonName = "Graduados"
	})
end)
Pracas.MouseButton1Up:Connect(function() --[[ Line: 73 | Upvalues: onCategoryClicked (copy) ]]
	onCategoryClicked({
		ButtonName = "Pracas"
	})
end)
Outros.MouseButton1Up:Connect(function() --[[ Line: 77 | Upvalues: onCategoryClicked (copy) ]]
	onCategoryClicked({
		ButtonName = "Outros"
	})
end)