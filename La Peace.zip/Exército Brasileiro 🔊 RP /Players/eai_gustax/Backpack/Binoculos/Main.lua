-- https://lua.expert/
local LocalPlayer = game:GetService("Players").LocalPlayer
local v1 = LocalPlayer:GetMouse()
local CurrentCamera = workspace.CurrentCamera
local v2 = false

v1.Button1Down:Connect(function() --[[ Line: 5 | Upvalues: v2 (ref), CurrentCamera (copy) ]]
	while wait() and not (v2 or CurrentCamera.FieldOfView < script.Parent.Configuration.MinZoom.Value) do
		CurrentCamera.FieldOfView = CurrentCamera.FieldOfView - 1
	end
end)
v1.Button1Up:Connect(function() --[[ Line: 13 | Upvalues: v2 (ref) ]]
	v2 = true
	wait()
	v2 = false
end)
v1.Button2Up:Connect(function() --[[ Line: 18 | Upvalues: v2 (ref) ]]
	v2 = true
	wait()
	v2 = false
end)
v1.Button2Down:Connect(function() --[[ Line: 23 | Upvalues: v2 (ref), CurrentCamera (copy) ]]
	while wait() and not (v2 or CurrentCamera.FieldOfView > script.Parent.Configuration.MaxZoom.Value) do
		CurrentCamera.FieldOfView = CurrentCamera.FieldOfView + 1
	end
end)
script.Parent.Equipped:Connect(function() --[[ Line: 31 | Upvalues: LocalPlayer (copy) ]]
	LocalPlayer.CameraMode = Enum.CameraMode.LockFirstPerson
end)
script.Parent.Unequipped:Connect(function() --[[ Line: 34 | Upvalues: CurrentCamera (copy), LocalPlayer (copy) ]]
	CurrentCamera.FieldOfView = 70
	LocalPlayer.CameraMode = Enum.CameraMode.Classic
end)

while true do
	game:GetService("RunService").Stepped:Wait()
	script.Parent.Handle.LocalTransparencyModifier = LocalPlayer.Character.Head.LocalTransparencyModifier
end