-- https://lua.expert/
script.Parent.Equipped:Connect(function() --[[ Line: 1 ]]
	script.Parent.Main.Disabled = false
end)
script.Parent.Unequipped:Connect(function() --[[ Line: 4 ]]
	script.Parent.Main.Disabled = true
end)