-- https://lua.expert/
local Players = game:GetService("Players")
local v1 = script.Parent
local Animation = v1:WaitForChild("Animation")
local LocalPlayer = Players.LocalPlayer
local v2 = nil
local v3 = nil
local v4 = nil

local function getAnimator() --[[ getAnimator | Line: 11 | Upvalues: LocalPlayer (copy), v2 (ref) ]]
	v2 = (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):FindFirstChildOfClass("Humanoid")

	if not v2 then
		return nil
	end

	local Animator = v2:FindFirstChildOfClass("Animator")

	if not Animator then
		local Animator2 = Instance.new("Animator")

		Animator2.Name = "Animator"
		Animator2.Parent = v2
		Animator = Animator2
	end

	return Animator
end

v1.Equipped:Connect(function() --[[ Line: 26 | Upvalues: v3 (ref), getAnimator (copy), Animation (copy), v4 (ref) ]]
	v3 = getAnimator()

	if not (v3 and Animation) then
		return
	end

	v4 = v3:LoadAnimation(Animation)
	v4.Priority = Enum.AnimationPriority.Action
	v4:Play()
end)
v1.Unequipped:Connect(function() --[[ Line: 35 | Upvalues: v4 (ref) ]]
	if not (v4 and v4.IsPlaying) then
		return
	end

	v4:Stop()
	v4:Destroy()
	v4 = nil
end)