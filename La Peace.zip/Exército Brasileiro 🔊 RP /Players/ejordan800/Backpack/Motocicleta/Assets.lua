-- https://lua.expert/
local PhysicsService = game:GetService("PhysicsService")

local function CreateCollisionGroup(p1) --[[ CreateCollisionGroup | Line: 4 | Upvalues: PhysicsService (copy) ]]
	if PhysicsService:IsCollisionGroupRegistered(p1) then
		return
	end

	PhysicsService:RegisterCollisionGroup(p1)
end

if not PhysicsService:IsCollisionGroupRegistered("Motorcycle") then
	PhysicsService:RegisterCollisionGroup("Motorcycle")
end

if not PhysicsService:IsCollisionGroupRegistered("Players") then
	PhysicsService:RegisterCollisionGroup("Players")
end

PhysicsService:CollisionGroupSetCollidable("Players", "Motorcycle", false)
BaseUrl = "http://www.roblox.com/asset/?id="

local function Create_PrivImpl(p1) --[[ Create_PrivImpl | Line: 20 ]]
	if type(p1) == "string" then
		return function(p13) --[[ Line: 28 | Upvalues: p1 (copy) ]]
			local v2 = Instance.new(p1)
			local v3 = nil
			local v4 = nil

			for k2, v in pairs(if p13 then p13 else {}) do
				if type(k2) == "string" then
					if k2 == "Parent" then
						v4 = v

						continue
					end

					v2[k2] = v

					continue
				end

				if type(k2) == "number" then
					if type(v) ~= "userdata" then
						error("Bad entry in Create body: Numeric keys must be paired with children, got a: " .. type(v), 2)
					end

					v.Parent = v2

					continue
				end

				if type(k2) == "table" and k2.__eventname then
					if type(v) ~= "function" then
						error("Bad entry in Create body: Key `[Create.E\'" .. k2.__eventname .. "\']` must have a function value\n\t\t\t\t\t\t\tgot: " .. tostring(v), 2)
					end

					v2[k2.__eventname]:connect(v)

					continue
				end

				if k2 == t.Create then
					if type(v) == "function" then
						if v3 then
							error("Bad entry in Create body: Only one constructor function is allowed", 2)
						end
					else
						error("Bad entry in Create body: Key `[Create]` should be paired with a constructor function, \n\t\t\t\t\t\t\tgot: " .. tostring(v), 2)
					end

					v3 = v

					continue
				end

				error("Bad entry (" .. tostring(k2) .. " => " .. tostring(v) .. ") in Create body", 2)
			end

			if v3 then
				v3(v2)
			end

			if v4 then
				v2.Parent = v4
			end

			return v2
		end
	end

	error("Argument of Create must be a string", 2)
end

Create = setmetatable({}, {
	__call = function(p1, ...) --[[ __call | Line: 100 ]]
		local v1 = ...

		if type(v1) == "string" then
			return function(p13) --[[ Line: 28 | Upvalues: v1 (copy) ]]
				local v2 = Instance.new(v1)
				local v3 = nil
				local v4 = nil

				for k2, v in pairs(if p13 then p13 else {}) do
					if type(k2) == "string" then
						if k2 == "Parent" then
							v4 = v

							continue
						end

						v2[k2] = v

						continue
					end

					if type(k2) == "number" then
						if type(v) ~= "userdata" then
							error("Bad entry in Create body: Numeric keys must be paired with children, got a: " .. type(v), 2)
						end

						v.Parent = v2

						continue
					end

					if type(k2) == "table" and k2.__eventname then
						if type(v) ~= "function" then
							error("Bad entry in Create body: Key `[Create.E\'" .. k2.__eventname .. "\']` must have a function value\n\t\t\t\t\t\t\tgot: " .. tostring(v), 2)
						end

						v2[k2.__eventname]:connect(v)

						continue
					end

					if k2 == t.Create then
						if type(v) == "function" then
							if v3 then
								error("Bad entry in Create body: Only one constructor function is allowed", 2)
							end
						else
							error("Bad entry in Create body: Key `[Create]` should be paired with a constructor function, \n\t\t\t\t\t\t\tgot: " .. tostring(v), 2)
						end

						v3 = v

						continue
					end

					error("Bad entry (" .. tostring(k2) .. " => " .. tostring(v) .. ") in Create body", 2)
				end

				if v3 then
					v3(v2)
				end

				if v4 then
					v2.Parent = v4
				end

				return v2
			end
		end

		error("Argument of Create must be a string", 2)
	end
})
function Create.E(p1) --[[ Line: 104 ]]
	return {
		__eventname = p1
	}
end
BasePart = Create("Part")({
	Size = Vector3.new(0.2, 0.2, 0.2),
	Anchored = false,
	CanCollide = true,
	Locked = true,
	Material = Enum.Material.Plastic,
	Shape = Enum.PartType.Block,
	TopSurface = Enum.SurfaceType.Smooth,
	BottomSurface = Enum.SurfaceType.Smooth,
	FormFactor = Enum.FormFactor.Custom
})
MeshData = {
	TextureId = 553732913,
	Meshes = {
		Body = 215130094,
		Wheel = 215130160
	}
}
function CreateVehicle() --[[ CreateVehicle | Line: 129 | Upvalues: PhysicsService (copy) ]]
	local t = {}
	local Body = BasePart:Clone()

	Body.Name = "Body"
	Body.Size = Vector3.new(1, 3.9, 6)
	Body.CanCollide = false
	Create("SpecialMesh")({
		Scale = Vector3.new(1.5, 1.5, 1.5),
		VertexColor = Vector3.new(1, 1, 1),
		Offset = Vector3.new(0, 0, 0),
		MeshType = Enum.MeshType.FileMesh,
		MeshId = MeshData.Meshes.Body,
		TextureId = MeshData.TextureId,
		Parent = Body
	})

	local v1 = BasePart:Clone()

	v1.Size = Vector3.new(0.5, 1, 1)
	v1.CanCollide = false
	Create("SpecialMesh")({
		MeshId = "",
		Scale = Vector3.new(1.5, 1.5, 1.5),
		VertexColor = Vector3.new(1, 1, 1),
		Offset = Vector3.new(0, 0, 0),
		MeshType = Enum.MeshType.FileMesh,
		TextureId = MeshData.TextureId,
		Parent = v1
	})

	local FrontWheel = v1:Clone()

	FrontWheel.Name = "FrontWheel"
	FrontWheel.Mesh.MeshId = MeshData.Meshes.Wheel
	FrontWheel.Mesh.Scale = Vector3.new(1.25, 1.25, 1.25)

	local BackWheel = v1:Clone()

	BackWheel.Name = "BackWheel"
	BackWheel.Mesh.MeshId = MeshData.Meshes.Wheel

	local LightPart = BasePart:Clone()

	LightPart.Name = "LightPart"
	LightPart.Transparency = 1
	Create("SpotLight")({
		Name = "Light",
		Angle = 90,
		Brightness = 50,
		Shadows = false,
		Enabled = false,
		Face = Enum.NormalId.Front,
		Color = Color3.new(255/255, 252/255, 153/255),
		Parent = LightPart
	})

	local SmokePart = BasePart:Clone()

	SmokePart.Name = "SmokePart"
	SmokePart.Transparency = 1
	Create("Smoke")({
		Name = "ExhaustSmoke",
		Size = 0.1,
		RiseVelocity = 0.01,
		Enabled = true,
		Color = Color3.new(127/255, 127/255, 127/255),
		Parent = SmokePart
	})

	local v2 = FrontWheel:Clone()

	v2.Parent = Body

	local v3 = Create("Motor6D")({
		Name = "FrontMotor",
		Part0 = Body,
		Part1 = v2,
		C0 = CFrame.new(0, -0.85, -2.7) * CFrame.Angles(0, 1.5707963267948966, 0),
		C1 = CFrame.new() * CFrame.Angles(0, -1.5707963267948966, 0),
		Parent = Body
	})
	local v4 = BackWheel:Clone()

	v4.Parent = Body

	local v5 = Create("Motor6D")({
		Name = "BackMotor",
		Part0 = Body,
		Part1 = v4,
		C0 = CFrame.new(0, -0.7, 3) * CFrame.Angles(0, 1.5707963267948966, 0),
		C1 = CFrame.new() * CFrame.Angles(0, -1.5707963267948966, 0),
		Parent = Body
	})
	local v6 = LightPart:Clone()

	v6.Parent = Body
	table.insert(t, v6.Light)

	local t2 = {}
	local t3 = {}

	for k, v in pairs(v6:GetChildren()) do
		if v:IsA("Sparkles") then
			table.insert(t2, v)
		end
	end

	local v7 = Create("Weld")({
		Part0 = Body,
		Part1 = v6,
		C0 = CFrame.new(-0.14, -0.75, -0.94) * CFrame.Angles(0, 0, 0),
		Parent = v6
	})
	local ExhaustPipe = SmokePart:Clone()

	ExhaustPipe.Name = "ExhaustPipe"
	ExhaustPipe.Parent = Body
	table.insert(t3, ExhaustPipe.ExhaustSmoke)

	local v8 = Create("Weld")({
		C0 = CFrame.new(0, 0.75, 3) * CFrame.Angles(0, 0, 0),
		Part0 = Body,
		Part1 = ExhaustPipe,
		Parent = ExhaustPipe
	})
	local DisplayBody = Body:Clone()

	DisplayBody.Name = "DisplayBody"

	for k, v in pairs(DisplayBody:GetChildren()) do
		if v:IsA("BasePart") or v:IsA("JointInstance") then
			v:Destroy()
		end
	end

	Body.Transparency = 1
	DisplayBody.CanCollide = true

	local DisplayMotor = Instance.new("Motor6D")

	DisplayMotor.Name = "DisplayMotor"
	DisplayMotor.Part0 = Body
	DisplayMotor.Part1 = DisplayBody
	DisplayMotor.C0 = CFrame.new(0, 0, 0) * CFrame.Angles(0, -1.5707963267948966, 0)
	DisplayMotor.C1 = CFrame.new(0, 0, 0) * CFrame.Angles(0, -1.5707963267948966, 0)
	DisplayMotor.MaxVelocity = 0.01
	DisplayMotor.Parent = Body
	DisplayBody.Parent = Body
	v3.Part0 = DisplayBody
	v5.Part0 = DisplayBody
	v7.Part0 = DisplayBody
	v8.Part0 = DisplayBody

	for i, v in ipairs(Body:GetChildren()) do
		if v:IsA("BasePart") then
			PhysicsService:SetPartCollisionGroup(v, "Motorcycle")
		end
	end

	return {
		Vehicle = Body,
		Tables = {
			ExhaustSmoke = t3,
			Lights = t,
			Sparkles = t2
		}
	}
end

for k, v in pairs(MeshData) do
	if type(v) == "table" then
		for k2, v2 in pairs(v) do
			if type(v2) == "string" or type(v2) == "number" then
				MeshData[k][k2] = BaseUrl .. tostring(v2)
			end
		end

		continue
	end

	if type(v) == "string" or type(v) == "number" then
		MeshData[k] = BaseUrl .. tostring(v)
	end
end

return {
	BaseUrl = BaseUrl,
	MeshData = MeshData,
	CreateVehicle = CreateVehicle
}