-- https://lua.expert/
game:GetService("UserInputService")

local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local CurrentCamera = workspace.CurrentCamera
local v1 = script.Parent

v1:WaitForChild("Handle")

local ServerControl = v1:WaitForChild("ServerControl", 30)
local ClientControl = v1:WaitForChild("ClientControl", 30)
local t = {}
local t2 = {}
local v2 = false
local v3 = nil
local v4 = nil
local v5 = nil
local v6 = nil
local v7 = nil
local v8 = nil

function SetAnimation(p1, p2) --[[ SetAnimation | Line: 19 | Upvalues: v2 (ref), v4 (ref), t (ref) ]]
	if p1 == "PlayAnimation" and (p2 and (v2 and v4)) then
		for k, v in pairs(t) do
			if v.Animation == p2.Animation then
				v.AnimationTrack:Stop()
				table.remove(t, k)
			end
		end

		local v1 = v4:LoadAnimation(p2.Animation)

		table.insert(t, {
			Animation = p2.Animation,
			AnimationTrack = v1
		})
		v1:Play(p2.FadeTime, p2.Weight, p2.Speed)
	else
		if p1 ~= "StopAnimation" or not p2 then
			return
		end

		for k, v in pairs(t) do
			if v.Animation == p2.Animation then
				v.AnimationTrack:Stop()
				table.remove(t, k)
			end
		end
	end
end
function DisableJump(p1) --[[ DisableJump | Line: 40 | Upvalues: v7 (ref), v4 (ref) ]]
	if v7 then
		v7:Disconnect()
	end

	if not p1 then
		return
	end

	v7 = v4.Changed:Connect(function(p1) --[[ Line: 45 | Upvalues: v4 (ref) ]]
		if p1 ~= "Jump" then
			return
		end

		v4.Jump = false
	end)
end
function CheckIfAlive() --[[ CheckIfAlive | Line: 53 | Upvalues: v5 (ref), v4 (ref), v3 (ref) ]]
	return v5 and (v5.Parent and (v4 and (v4.Parent and (v4.Health > 0 and (v3 and v3.Parent))))) and true or false
end
function Equipped(p1) --[[ Equipped | Line: 57 | Upvalues: v5 (ref), v1 (copy), v3 (ref), Players (copy), v4 (ref), v2 (ref), v6 (ref), ContextActionService (copy) ]]
	v5 = v1.Parent
	v3 = Players:GetPlayerFromCharacter(v5)

	if v3 and v3:GetAttribute("Nadando") then
		return
	end

	v4 = v5:FindFirstChild("Humanoid")

	if not v4 then
		return
	end

	v2 = true

	if CheckIfAlive() then
		v6 = v3:GetMouse()
		p1.Button1Down:Connect(function() --[[ Line: 71 ]]
			InvokeServer("MouseClick", {
				Down = true
			})
		end)
		p1.Button1Up:Connect(function() --[[ Line: 75 ]]
			InvokeServer("MouseClick", {
				Down = false
			})
		end)

		local function Handler(p1, p2, p3) --[[ Handler | Line: 79 ]]
			if p2 == Enum.UserInputState.Begin then
				InvokeServer("KeyPress", {
					Down = true,
					Key = p1
				})

				return
			end

			if p2 ~= Enum.UserInputState.End then
				return
			end

			InvokeServer("KeyPress", {
				Down = false,
				Key = p1
			})
		end

		ContextActionService:BindAction("w", Handler, true, Enum.KeyCode.W)
		ContextActionService:SetTitle("w", "Andar")
		ContextActionService:SetPosition("w", UDim2.new(-1.7, 0, 0, 0))
		ContextActionService:BindAction("s", Handler, true, Enum.KeyCode.S)
		ContextActionService:SetTitle("s", "Freiar")
		ContextActionService:SetPosition("s", UDim2.new(-1.7, 0, 0.3, 0))
		ContextActionService:BindAction("a", Handler, true, Enum.KeyCode.A)
		ContextActionService:SetTitle("a", "Esquerda")
		ContextActionService:SetPosition("a", UDim2.new(-2, 0, 0.3, 0))
		ContextActionService:BindAction("d", Handler, true, Enum.KeyCode.D)
		ContextActionService:SetTitle("d", "Direita")
		ContextActionService:SetPosition("d", UDim2.new(-1.4, 0, 0.3, 0))
		ContextActionService:BindAction("ThumbstickMovement", function(p1, p2, p3) --[[ Line: 104 ]]
			if p3.UserInputType ~= Enum.UserInputType.Gamepad1 or p3.KeyCode ~= Enum.KeyCode.Thumbstick1 then
				return
			end

			local Position = p3.Position

			if Position.Y > 0.2 then
				InvokeServer("KeyPress", {
					Key = "w",
					Down = true
				})
				InvokeServer("KeyPress", {
					Key = "s",
					Down = false
				})
			elseif Position.Y < -0.2 then
				InvokeServer("KeyPress", {
					Key = "s",
					Down = true
				})
				InvokeServer("KeyPress", {
					Key = "w",
					Down = false
				})
			else
				InvokeServer("KeyPress", {
					Key = "w",
					Down = false
				})
				InvokeServer("KeyPress", {
					Key = "s",
					Down = false
				})
			end

			if Position.X < -0.2 then
				InvokeServer("KeyPress", {
					Key = "a",
					Down = true
				})
			else
				if Position.X > 0.2 then
					InvokeServer("KeyPress", {
						Key = "d",
						Down = true
					})
					InvokeServer("KeyPress", {
						Key = "a",
						Down = false
					})

					return
				end

				InvokeServer("KeyPress", {
					Key = "a",
					Down = false
				})
			end

			InvokeServer("KeyPress", {
				Key = "d",
				Down = false
			})
		end, false, Enum.KeyCode.Thumbstick1)
		p1.KeyDown:Connect(function(p1) --[[ Line: 132 ]]
			InvokeServer("KeyPress", {
				Down = true,
				Key = p1
			})
		end)
		p1.KeyUp:Connect(function(p1) --[[ Line: 136 ]]
			InvokeServer("KeyPress", {
				Down = false,
				Key = p1
			})
		end)
		task.delay(0.1, function() --[[ Line: 140 | Upvalues: v4 (ref) ]]
			if not (v4 and v4.Parent) then
				return
			end

			v4:ChangeState(Enum.HumanoidStateType.None)
		end)
	end
end
function Unequipped() --[[ Unequipped | Line: 147 | Upvalues: v2 (ref), t2 (ref), t (ref), v7 (ref), v8 (ref), ContextActionService (copy), v4 (ref) ]]
	v2 = false
	t2 = {}

	for k, v in pairs(t) do
		if v and v.AnimationTrack then
			v.AnimationTrack:Stop()
		end
	end

	for v1, v22 in { v7, v8 } do
		if v22 then
			v22:Disconnect()
		end
	end

	ContextActionService:UnbindAction("w")
	ContextActionService:UnbindAction("a")
	ContextActionService:UnbindAction("s")
	ContextActionService:UnbindAction("d")
	ContextActionService:UnbindAction("ThumbstickMovement")

	if not v4 then
		t = {}

		return
	end

	v4:ChangeState(Enum.HumanoidStateType.Freefall)
	t = {}
end
function InvokeServer(p1, p2) --[[ InvokeServer | Line: 173 | Upvalues: ServerControl (copy) ]]
	pcall(function() --[[ Line: 174 | Upvalues: ServerControl (ref), p1 (copy), p2 (copy) ]]
		ServerControl:InvokeServer(p1, p2)
	end)
end
function OnClientInvoke(p1, p2) --[[ OnClientInvoke | Line: 179 | Upvalues: v2 (ref), v4 (ref), v6 (ref), t2 (ref), v8 (ref), RunService (copy) ]]
	if p1 == "PlayAnimation" and (p2 and (v2 and v4)) then
		SetAnimation("PlayAnimation", p2)

		return
	end

	if p1 == "StopAnimation" and p2 then
		SetAnimation("StopAnimation", p2)

		return
	end

	if p1 == "PlaySound" and p2 then
		p2:Play()

		return
	end

	if p1 == "StopSound" and p2 then
		p2:Stop()

		return
	end

	if p1 == "MousePosition" then
		return {
			Position = v6.Hit.p,
			Target = v6.Target
		}
	end

	if p1 == "DisableJump" then
		DisableJump(p2)

		return
	end

	if p1 ~= "SetLocalTransparencyModifier" or not (p2 and v2) then
		return
	end

	pcall(function() --[[ Line: 193 | Upvalues: t2 (ref), p2 (copy), v8 (ref), RunService (ref) ]]
		local v1 = false

		for k, v in pairs(t2) do
			if v == p2 then
				v1 = true
			end
		end

		if v1 then
			return
		end

		local v2 = t2

		table.insert(v2, p2)

		if v8 then
			v8:Disconnect()
		end

		v8 = RunService.RenderStepped:Connect(function() --[[ Line: 203 | Upvalues: t2 (ref) ]]
			for k, v in pairs(t2) do
				if v.Object and v.Object.Parent then
					local LocalTransparencyModifier = v.Object.LocalTransparencyModifier

					if not v.AutoUpdate and (LocalTransparencyModifier == 1 or LocalTransparencyModifier == 0) or v.AutoUpdate then
						v.Object.LocalTransparencyModifier = v.Transparency
					end

					continue
				end

				table.remove(t2, k)
			end
		end)
	end)
end
ClientControl.OnClientInvoke = OnClientInvoke
v1.Equipped:Connect(Equipped)
v1.Unequipped:Connect(Unequipped)