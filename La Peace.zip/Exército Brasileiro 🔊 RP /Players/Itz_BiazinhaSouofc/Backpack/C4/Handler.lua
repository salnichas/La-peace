-- https://lua.expert/
local LocalPlayer = game:GetService("Players").LocalPlayer
local Animator = (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("Humanoid", 30):WaitForChild("Animator", 30)
local v2 = script.Parent
local t = {
	Idle = Animator:LoadAnimation(v2:WaitForChild("Anims", 30):WaitForChild("Idle", 30))
}

v2.Equipped:Connect(function() --[[ Line: 21 | Upvalues: t (copy) ]]
	if not t.Idle then
		return
	end

	t.Idle:Play()
end)
v2.Unequipped:Connect(function() --[[ Line: 31 | Upvalues: t (copy) ]]
	if not t.Idle then
		return
	end

	t.Idle:Stop()
end)
v2.Destroying:Connect(function() --[[ Line: 41 | Upvalues: t (copy) ]]
	if not t.Idle then
		return
	end

	t.Idle:Stop()
end)