-- https://lua.expert/
return {
	new = function() --[[ Line: 3 ]]
		local t = {
			WaitTime = 0.2,
			CurrentState = nil
		}

		function t.SwitchState(p1) --[[ Line: 8 | Upvalues: t (copy) ]]
			if t.CurrentState then
				t.CurrentState.Stop()
			end

			t.CurrentState = p1

			if not p1 then
				return
			end

			p1.Start()
		end
		function t.NewState() --[[ Line: 18 | Upvalues: t (copy) ]]
			local t2 = {
				Name = "",
				Conditions = {},
				isRunning = false,
				Action = function() --[[ Line: 23 ]] end
			}

			function t2.Run() --[[ Line: 24 | Upvalues: t2 (copy), t (ref) ]]
				t2.isRunning = true

				while t2.isRunning do
					for k, v in pairs(t2.Conditions) do
						if v.Evaluate() then
							t.SwitchState(v.TransitionState)

							return
						end
					end

					t2.Action()
					wait(t.WaitTime)
				end
			end
			function t2.Init() --[[ Line: 43 ]] end
			function t2.Start() --[[ Line: 46 | Upvalues: t2 (copy) ]]
				t2.Init()
				coroutine.resume((coroutine.create(t2.Run)))
			end
			function t2.Stop() --[[ Line: 52 | Upvalues: t2 (copy) ]]
				t2.isRunning = false
			end

			return t2
		end
		function t.NewCondition() --[[ Line: 59 ]]
			return {
				Name = "",
				Evaluate = function() --[[ Line: 62 ]]
					print("replace me")

					return false
				end,
				TransitionState = {}
			}
		end

		return t
	end
}