-- https://lua.expert/
local t = {}
local PathfindingService = game:GetService("PathfindingService")

PathfindingService.EmptyCutoff = 0.3
function t.new() --[[ new | Line: 8 | Upvalues: PathfindingService (copy) ]]
	local t = {}
	local v1 = Vector3.new(inf, inf, inf)
	local v2 = nil
	local v3 = 1

	function t.MoveToTarget(p1, p2, p3) --[[ MoveToTarget | Line: 16 | Upvalues: v1 (ref), v2 (ref), PathfindingService (ref), v3 (ref) ]]
		if (v1 - p3).magnitude > 10 then
			local Position = p2.HumanoidRootPart.Position
			local v12 = p2.Humanoid:GetState()

			if v12 == Enum.HumanoidStateType.Jumping or v12 == Enum.HumanoidStateType.Freefall then
				local v32, v4 = game.Workspace:FindPartOnRay(Ray.new(p2.HumanoidRootPart.Position, Vector3.new(0, -100, 0)), p2)

				if v32 then
					Position = v4
				end
			end

			local _, v6 = game.Workspace:FindPartOnRay(Ray.new(p3 + Vector3.new(0, -3, 0), Vector3.new(0, -100, 0)), p2)

			v2 = PathfindingService:ComputeSmoothPathAsync(Position, if v6 and (v6 - p3).magnitude > 4 then p3 * Vector3.new(1, 0, 1) + Vector3.new(0, 3, 0) else p3, 500)

			local isSuccess = v2.Status == Enum.PathStatus.Success

			v3 = 1
			v1 = p3
		end

		if not v2 then
			return
		end

		local v8 = v2:GetPointCoordinates()

		if v3 < #v8 then
			if (p2.HumanoidRootPart.Position - v8[v3]).magnitude < 4 then
				v3 = v3 + 1
			end

			p2.Humanoid:MoveTo(v8[v3])

			if v8[v3].Y - p2.HumanoidRootPart.Position.Y > 1.5 then
				p2.Humanoid.Jump = true
			end
		else
			p2.Humanoid:MoveTo(p3)
		end
	end

	return t
end

return t