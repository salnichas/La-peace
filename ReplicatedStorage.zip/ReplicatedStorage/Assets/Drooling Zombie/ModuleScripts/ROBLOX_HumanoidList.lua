-- https://lua.expert/
local t = {}
local t2 = {}

function t.GetCurrent(p1) --[[ GetCurrent | Line: 4 | Upvalues: t2 (ref) ]]
	return t2
end

local function v1(p1, p2) --[[ findHumanoids | Line: 8 | Upvalues: v1 (copy) ]]
	if not p1 then
		return
	end

	if p1:IsA("Humanoid") then
		table.insert(p2, p1)
	end

	for k, v in pairs(p1:GetChildren()) do
		v1(v, p2)
	end
end

local v2 = coroutine.create(function() --[[ Line: 20 | Upvalues: t2 (ref), v1 (copy) ]]
	while true do
		t2 = {}
		v1(game.Workspace, t2)
		wait(3)
	end
end)

coroutine.resume(v2)

return t