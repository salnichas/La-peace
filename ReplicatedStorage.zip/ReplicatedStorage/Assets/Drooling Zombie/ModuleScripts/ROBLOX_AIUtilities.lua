-- https://lua.expert/
local t = {
	WideRayCast = function(p1, p2, p3, p4, p5) --[[ WideRayCast | Line: 3 ]]
		local t = {}
		local v2, _ = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(p2, p3 - p2), p5)

		if v2 then
			table.insert(t, v2)
		end

		local v3 = p4 * (p3 - p2):Cross(Vector3.FromNormalId(Enum.NormalId.Top)).unit
		local v5, _2 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(p2 + v3, p3 - p2 + v3), p5)

		if v5 then
			table.insert(t, v5)
		end

		local v7, _3 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(p2 - v3, p3 - p2 - v3), p5)

		if v7 then
			table.insert(t, v7)
		end

		return t
	end
}

function t.FindNearestPathPoint(p1, p2, p3, p4, p5, p6) --[[ FindNearestPathPoint | Line: 22 | Upvalues: t (copy) ]]
	if not (p2:CheckOcclusionAsync(p3) > 0) then
		return
	end

	t:WideRayCast(p4)
end
function t.GetRepulsionVector(p1, p2, p3) --[[ GetRepulsionVector | Line: 31 ]]
	local sum = Vector3.new(0, 0, 0)

	for k, v in pairs(p3) do
		local v1 = p2 - v

		sum = sum + v1.unit * 1000 / math.pow(v1.magnitude + 1, 2)
	end

	return sum * 15
end
function t.GetIdleState(p1, p2) --[[ GetIdleState | Line: 43 ]]
	local Idle = p2.NewState()

	Idle.Name = "Idle"
	function Idle.Action() --[[ Line: 46 ]] end
	function Idle.Init() --[[ Line: 47 ]] end

	return Idle
end
function t.GetClosestVisibleTarget(p1, p2, p3, p4, p5) --[[ GetClosestVisibleTarget | Line: 51 ]]
	local v1 = (1 / 0)
	local v2 = nil

	for k, v in pairs(p3) do
		local v3 = v.HumanoidRootPart.Position - p2.HumanoidRootPart.Position
		local v4 = v3 * Vector3.new(1, 0, 1)

		if math.deg((math.acos(v4:Dot(p2.HumanoidRootPart.CFrame.lookVector) / v4.magnitude))) < p5 then
			local v8, _ = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(p2.HumanoidRootPart.Position, v3), p4)

			if v8 and (v8.Parent == v and v3.magnitude < v1) then
				v1 = v3.magnitude
				v2 = v
			end
		end
	end

	return v2
end

local function isSpaceEmpty(p1) --[[ isSpaceEmpty | Line: 72 ]]
	return game.Workspace:IsRegion3Empty((Region3.new(p1 - Vector3.new(2, 2, 2), p1 + Vector3.new(2, 2, 2))))
end

function t.FindCloseEmptySpace(p1, p2) --[[ FindCloseEmptySpace | Line: 77 ]]
	math.randomseed(os.time())

	local count = 0

	while true do
		local v1 = math.random(5, 10)

		if math.random() > 0.5 then
			v1 = v1 * -1
		end

		local v2 = math.random(5, 10)

		if math.random() > 0.5 then
			v2 = v2 * -1
		end

		local v5 = Vector3.new(p2.HumanoidRootPart.Position.X + v1, p2.HumanoidRootPart.Position.Y, p2.HumanoidRootPart.Position.Z + v2)

		if game.Workspace:IsRegion3Empty((Region3.new(v5 - Vector3.new(2, 2, 2), v5 + Vector3.new(2, 2, 2)))) then
			return v5
		end

		local v7 = v5 + Vector3.new(0, 4, 0)

		if game.Workspace:IsRegion3Empty((Region3.new(v7 - Vector3.new(2, 2, 2), v7 + Vector3.new(2, 2, 2)))) then
			return v7
		end

		count = count + 1

		if count > 10 then
			return nil
		end
	end
end

return t