-- https://lua.expert/
local t = {}
local t2 = {}

function t.AddItem(p1, p2, p3) --[[ AddItem | Line: 5 | Upvalues: t2 (copy) ]]
	local t = {
		object = p2,
		destroyTime = p3 + os.time()
	}

	for k, v in pairs(t2) do
		if t2[k].destroyTime > t.destroyTime then
			table.insert(t2, k, t)

			return true
		end
	end

	table.insert(t2, t)

	return true
end
coroutine.resume((coroutine.create(function() --[[ Line: 18 | Upvalues: t2 (copy) ]]
	while true do
		local v1 = os.time()

		for k, v in pairs(t2) do
			if v.destroyTime <= v1 then
				table.remove(t2, 1)

				if v.object then
					v.object:Destroy()
				end

				continue
			end

			if not (v.destroyTime - 1 <= v1) then
				break
			end

			if v.object and v.object:IsA("Part") then
				v.object.Transparency = v.object.Transparency + 0.03333333333333333
			end
		end

		wait()
	end
end)))

return t