-- https://lua.expert/
local ROBLOX_HumanoidList = require(game.ServerStorage.ROBLOX_HumanoidList)
local ROBLOX_AIUtilities = require(game.ServerStorage.ROBLOX_AIUtilities)
local t = {}

function updateDisplay(p1, p2) --[[ updateDisplay | Line: 7 ]]
	coroutine.resume((coroutine.create(function() --[[ Line: 8 | Upvalues: p2 (copy), p1 (copy) ]]
		while true do
			repeat
				wait()
			until p2

			p1.Text = p2.Name
		end
	end)))
end
function t.new(p1) --[[ Line: 19 | Upvalues: ROBLOX_AIUtilities (copy), ROBLOX_HumanoidList (copy) ]]
	local t = {}
	local Configurations = p1.Configurations
	local t2 = {}

	local function loadConfig(p1, p2) --[[ loadConfig | Line: 28 | Upvalues: Configurations (copy), t2 (copy) ]]
		if Configurations:FindFirstChild(p1) then
			t2[p1] = Configurations:FindFirstChild(p1).Value
		else
			t2[p1] = p2
		end
	end

	if Configurations:FindFirstChild("AttackRange") then
		t2.AttackRange = Configurations:FindFirstChild("AttackRange").Value
	else
		t2.AttackRange = 3
	end

	if Configurations:FindFirstChild("FieldOfView") then
		t2.FieldOfView = Configurations:FindFirstChild("FieldOfView").Value
	else
		t2.FieldOfView = 180
	end

	if Configurations:FindFirstChild("AggroRange") then
		t2.AggroRange = Configurations:FindFirstChild("AggroRange").Value
	else
		t2.AggroRange = 200
	end

	if Configurations:FindFirstChild("ChanceOfBoredom") then
		t2.ChanceOfBoredom = Configurations:FindFirstChild("ChanceOfBoredom").Value
	else
		t2.ChanceOfBoredom = 0.5
	end

	if Configurations:FindFirstChild("BoredomDuration") then
		t2.BoredomDuration = Configurations:FindFirstChild("BoredomDuration").Value
	else
		t2.BoredomDuration = 10
	end

	if Configurations:FindFirstChild("Damage") then
		t2.Damage = Configurations:FindFirstChild("Damage").Value
	else
		t2.Damage = 10
	end

	if Configurations:FindFirstChild("DamageCooldown") then
		t2.DamageCooldown = Configurations:FindFirstChild("DamageCooldown").Value
	else
		t2.DamageCooldown = 1
	end

	local v1 = require(game.ServerStorage.ROBLOX_StateMachine).new()
	local v2 = require(game.ServerStorage.ROBLOX_PathfindingLibrary).new()
	local v3 = nil
	local v4 = nil
	local v5 = os.time()
	local Idle = v1.NewState()

	Idle.Name = "Idle"
	function Idle.Action() --[[ Line: 57 ]] end
	function Idle.Init() --[[ Line: 59 | Upvalues: v5 (ref) ]]
		v5 = os.time()
	end

	local Search = v1.NewState()

	Search.Name = "Search"

	local v6 = os.time()
	local v7 = nil

	function Search.Action() --[[ Line: 70 | Upvalues: p1 (copy), v6 (ref), ROBLOX_AIUtilities (ref), v7 (ref), v2 (copy) ]]
		if not p1 then
			return
		end

		local v1 = os.time()

		if v1 - v6 > 2 then
			v6 = v1

			local v22 = math.random(5, 10)

			if math.random() > 0.5 then
				v22 = v22 * -1
			end

			local v3 = math.random(5, 10)

			if math.random() > 0.5 then
				v3 = v3 * -1
			end

			local v4 = ROBLOX_AIUtilities:FindCloseEmptySpace(p1)

			v7 = Vector3.new(p1.HumanoidRootPart.Position.X + v22, p1.HumanoidRootPart.Position.Y, p1.HumanoidRootPart.Position.Z + v3)
			v7 = v4
		end

		if not v7 then
			return
		end

		v2:MoveToTarget(p1, v7)
	end
	function Search.Init() --[[ Line: 97 | Upvalues: v5 (ref) ]]
		v5 = os.time()
	end

	local Pursue = v1.NewState()

	Pursue.Name = "Pursue"
	function Pursue.Action() --[[ Line: 104 | Upvalues: v3 (ref), p1 (copy), t2 (copy), v2 (copy) ]]
		if not v3 then
			return
		end

		if (p1.HumanoidRootPart.Position - v3.HumanoidRootPart.Position).magnitude > t2.AttackRange + 5 then
			v2:MoveToTarget(p1, v3.HumanoidRootPart.Position)

			return
		end

		p1.Humanoid:MoveTo(v3.HumanoidRootPart.Position)
	end
	function Pursue.Init() --[[ Line: 121 ]] end

	local Attack = v1.NewState()

	Attack.Name = "Attack"

	local v8 = os.time()
	local v9 = p1.Humanoid:LoadAnimation(p1.Animations.Attack)

	function Attack.Action() --[[ Line: 129 | Upvalues: p1 (copy), v3 (ref), v8 (ref), v9 (copy) ]]
		p1.Humanoid:MoveTo(v3.HumanoidRootPart.Position)

		local v1 = os.time()

		if not (v1 - v8 > 3) then
			return
		end

		v8 = v1
		v9:Play()
	end

	local Hunt = v1.NewState()

	Hunt.Name = "Hunt"
	function Hunt.Action() --[[ Line: 142 | Upvalues: v4 (ref), v2 (copy), p1 (copy) ]]
		if not v4 then
			return
		end

		v2:MoveToTarget(p1, v4)
	end
	function Hunt.Init() --[[ Line: 147 | Upvalues: v5 (ref), t2 (copy) ]]
		v5 = os.time() + t2.BoredomDuration / 2
	end

	local CanSeeTarget = v1.NewCondition()

	CanSeeTarget.Name = "CanSeeTarget"
	function CanSeeTarget.Evaluate() --[[ Line: 158 | Upvalues: p1 (copy), ROBLOX_HumanoidList (ref), t2 (copy), ROBLOX_AIUtilities (ref), v3 (ref) ]]
		if not p1 then
			return false
		end

		local t = {}
		local t3 = {}

		for k, v in pairs((ROBLOX_HumanoidList:GetCurrent())) do
			if v and (v.Parent and (v.Parent:FindFirstChild("HumanoidRootPart") and (v.Health > 0 and v.WalkSpeed > 0))) then
				local HumanoidRootPart = v.Parent:FindFirstChild("HumanoidRootPart")

				if HumanoidRootPart and (p1.HumanoidRootPart.Position - HumanoidRootPart.Position).magnitude <= t2.AggroRange then
					if v.Parent.Name == "Drooling Zombie" then
						table.insert(t3, v.Parent)

						continue
					end

					table.insert(t, v.Parent)
				end
			end
		end

		local v4 = ROBLOX_AIUtilities:GetClosestVisibleTarget(p1, t, t3, t2.FieldOfView)

		if v4 then
			v3 = v4

			return true
		end

		return false
	end
	CanSeeTarget.TransitionState = Pursue

	local TargetDead = v1.NewCondition()

	TargetDead.Name = "TargetDead"
	function TargetDead.Evaluate() --[[ Line: 212 | Upvalues: v3 (ref) ]]
		if not (v3 and v3.Humanoid) then
			return true
		end

		return v3.Humanoid.Health <= 0
	end
	TargetDead.TransitionState = Idle

	local Health = p1.Humanoid.Health
	local GotDamaged = v1.NewCondition()

	GotDamaged.Name = "GotDamaged"
	function GotDamaged.Evaluate() --[[ Line: 224 | Upvalues: p1 (copy), Health (copy) ]]
		return p1 and Health > p1.Humanoid.Health and true or false
	end
	GotDamaged.TransitionState = Search

	local GotBored = v1.NewCondition()

	GotBored.Name = "GotBored"
	function GotBored.Evaluate() --[[ Line: 237 | Upvalues: v5 (ref), t2 (copy), GotBored (copy), Search (copy), Idle (copy) ]]
		local v1 = os.time()

		if not (v1 - v5 > t2.BoredomDuration and math.random() < t2.ChanceOfBoredom) then
			return false
		end

		v5 = v1

		if GotBored.TransitionState == Search then
			GotBored.TransitionState = Idle
		else
			GotBored.TransitionState = Search
		end

		return true
	end
	GotBored.TransitionState = Idle

	local LostTarget = v1.NewCondition()

	LostTarget.Name = "LostTarget"
	function LostTarget.Evaluate() --[[ Line: 258 ]]
		return false
	end
	LostTarget.TransitionState = Hunt

	local WithinRange = v1.NewCondition()

	WithinRange.Name = "WithinRange"
	function WithinRange.Evaluate() --[[ Line: 278 | Upvalues: v3 (ref), p1 (copy), t2 (copy) ]]
		return v3 and (p1.HumanoidRootPart.Position - v3.HumanoidRootPart.Position).magnitude < t2.AttackRange and true or false
	end
	WithinRange.TransitionState = Attack

	local OutsideRange = v1.NewCondition()

	OutsideRange.Name = "OutsideRange"
	function OutsideRange.Evaluate() --[[ Line: 292 | Upvalues: v3 (ref), p1 (copy), t2 (copy) ]]
		return v3 and (p1.HumanoidRootPart.Position - v3.HumanoidRootPart.Position).magnitude > t2.AttackRange and true or false
	end
	OutsideRange.TransitionState = Pursue
	table.insert(Idle.Conditions, CanSeeTarget)
	table.insert(Idle.Conditions, GotDamaged)
	table.insert(Idle.Conditions, GotBored)
	table.insert(Search.Conditions, GotBored)
	table.insert(Search.Conditions, CanSeeTarget)
	table.insert(Pursue.Conditions, LostTarget)
	table.insert(Pursue.Conditions, WithinRange)
	table.insert(Pursue.Conditions, TargetDead)
	table.insert(Attack.Conditions, OutsideRange)
	table.insert(Attack.Conditions, TargetDead)
	table.insert(Hunt.Conditions, GotBored)
	table.insert(Hunt.Conditions, CanSeeTarget)

	local v10 = true
	local v11 = os.time()

	local function handleHit(p1) --[[ handleHit | Line: 324 | Upvalues: v10 (ref), t2 (copy), v11 (ref) ]]
		if v10 then
			if not p1 or (not p1.Parent or (p1.Parent.Name == "Drooling Zombie" or not p1.Parent:FindFirstChild("Humanoid"))) then
				return
			end

			local v1 = p1.Parent

			if v1.Humanoid.WalkSpeed > 0 then
				v1.Humanoid.Health = v1.Humanoid.Health - t2.Damage
				v10 = false
			end
		else
			local v2 = os.time()

			if not (v2 - v11 > t2.DamageCooldown) then
				return
			end

			v11 = v2
			v10 = true
		end
	end

	p1:FindFirstChild("Left Arm").Touched:connect(handleHit)
	p1:FindFirstChild("Right Arm").Touched:connect(handleHit)

	local v12 = coroutine.create(function() --[[ Line: 348 | Upvalues: ROBLOX_HumanoidList (ref), p1 (copy), ROBLOX_AIUtilities (ref), v1 (copy) ]]
		while true do
			repeat
				wait()

				local t = {}

				for k, v in pairs((ROBLOX_HumanoidList:GetCurrent())) do
					if v and (v ~= p1.Humanoid and (v.Parent and v.Parent:FindFirstChild("HumanoidRootPart"))) then
						local HumanoidRootPart = v.Parent:FindFirstChild("HumanoidRootPart")

						if (p1.HumanoidRootPart.Position - HumanoidRootPart.Position).magnitude <= 2.5 then
							table.insert(t, HumanoidRootPart.Position)
						end
					end
				end

				local v2 = ROBLOX_AIUtilities:GetRepulsionVector(p1.HumanoidRootPart.Position, t)
				local _ = v2.magnitude > 0

				p1.HumanoidRootPart.RepulsionForce.force = v2

				if not (v1.CurrentState and p1.Configurations.Debug.Value) then
					continue
				end

				p1.BillboardGui.TextLabel.Visible = true
				p1.BillboardGui.TextLabel.Text = v1.CurrentState.Name
			until not p1.Configurations.Debug.Value

			p1.BillboardGui.TextLabel.Visible = false
		end
	end)

	coroutine.resume(v12)
	v1.SwitchState(Idle)
	function t.Stop() --[[ Line: 383 | Upvalues: v1 (copy) ]]
		v1.SwitchState(nil)
	end

	return t
end

return t