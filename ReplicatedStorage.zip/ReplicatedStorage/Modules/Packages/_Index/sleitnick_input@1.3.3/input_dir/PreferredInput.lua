-- https://lua.expert/
local Signal = require(script.Parent.Parent.Signal)
local EnumList = require(script.Parent.Parent.EnumList)
local UserInputService = game:GetService("UserInputService")
local Touch = Enum.UserInputType.Touch
local Keyboard = Enum.UserInputType.Keyboard
local t = {
	Changed = Signal.new(),
	InputType = EnumList.new("InputType", { "MouseKeyboard", "Touch", "Gamepad" })
}

t.Current = t.InputType.MouseKeyboard
function t.Observe(p1) --[[ Observe | Line: 111 | Upvalues: t (copy) ]]
	task.spawn(p1, t.Current)

	return t.Changed:Connect(p1)
end

local function SetPreferred(p1) --[[ SetPreferred | Line: 117 | Upvalues: t (copy) ]]
	if p1 == t.Current then
		return
	end

	t.Current = p1
	t.Changed:Fire(p1)
end

local function DeterminePreferred(p1) --[[ DeterminePreferred | Line: 125 | Upvalues: Touch (copy), t (copy), Keyboard (copy) ]]
	if p1 == Touch then
		local Touch2 = t.InputType.Touch

		if Touch2 ~= t.Current then
			t.Current = Touch2
			t.Changed:Fire(Touch2)
		end
	elseif p1 == Keyboard or p1.Name:sub(1, 5) == "Mouse" then
		local MouseKeyboard = t.InputType.MouseKeyboard

		if MouseKeyboard ~= t.Current then
			t.Current = MouseKeyboard
			t.Changed:Fire(MouseKeyboard)
		end
	else
		if p1.Name:sub(1, 7) ~= "Gamepad" then
			return
		end

		local Gamepad = t.InputType.Gamepad

		if Gamepad == t.Current then
			return
		end

		t.Current = Gamepad
		t.Changed:Fire(Gamepad)
	end
end

DeterminePreferred(UserInputService:GetLastInputType())
UserInputService.LastInputTypeChanged:Connect(DeterminePreferred)

return t