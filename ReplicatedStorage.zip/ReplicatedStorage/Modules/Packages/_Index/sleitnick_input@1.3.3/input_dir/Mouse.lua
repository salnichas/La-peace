-- https://lua.expert/
local Trove = require(script.Parent.Parent.Trove)
local Signal = require(script.Parent.Parent.Signal)
local UserInputService = game:GetService("UserInputService")
local t = {}

t.__index = t
function t.new() --[[ new | Line: 65 | Upvalues: t (copy), Trove (copy), Signal (copy), UserInputService (copy) ]]
	local v2 = setmetatable({}, t)

	v2._trove = Trove.new()
	v2.LeftDown = v2._trove:Construct(Signal)
	v2.LeftUp = v2._trove:Construct(Signal)
	v2.RightDown = v2._trove:Construct(Signal)
	v2.RightUp = v2._trove:Construct(Signal)
	v2.Scrolled = v2._trove:Construct(Signal)
	v2._trove:Connect(UserInputService.InputBegan, function(p1, p2) --[[ Line: 77 | Upvalues: v2 (copy) ]]
		if p2 then
			return
		end

		if p1.UserInputType == Enum.UserInputType.MouseButton1 then
			v2.LeftDown:Fire()

			return
		end

		if p1.UserInputType ~= Enum.UserInputType.MouseButton2 then
			return
		end

		v2.RightDown:Fire()
	end)
	v2._trove:Connect(UserInputService.InputEnded, function(p1, p2) --[[ Line: 86 | Upvalues: v2 (copy) ]]
		if p2 then
			return
		end

		if p1.UserInputType == Enum.UserInputType.MouseButton1 then
			v2.LeftUp:Fire()

			return
		end

		if p1.UserInputType ~= Enum.UserInputType.MouseButton2 then
			return
		end

		v2.RightUp:Fire()
	end)
	v2._trove:Connect(UserInputService.InputChanged, function(p1, p2) --[[ Line: 95 | Upvalues: v2 (copy) ]]
		if p2 then
			return
		end

		if p1.UserInputType ~= Enum.UserInputType.MouseWheel then
			return
		end

		v2.Scrolled:Fire(p1.Position.Z)
	end)

	return v2
end
function t.IsLeftDown(p1) --[[ IsLeftDown | Line: 110 | Upvalues: UserInputService (copy) ]]
	return UserInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1)
end
function t.IsRightDown(p1) --[[ IsRightDown | Line: 118 | Upvalues: UserInputService (copy) ]]
	return UserInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton2)
end
function t.GetPosition(p1) --[[ GetPosition | Line: 126 | Upvalues: UserInputService (copy) ]]
	return UserInputService:GetMouseLocation()
end
function t.GetDelta(p1) --[[ GetDelta | Line: 141 | Upvalues: UserInputService (copy) ]]
	return UserInputService:GetMouseDelta()
end
function t.GetRay(p1, p2) --[[ GetRay | Line: 150 | Upvalues: UserInputService (copy) ]]
	local v1 = if p2 then p2 else UserInputService:GetMouseLocation()

	return workspace.CurrentCamera:ViewportPointToRay(v1.X, v1.Y)
end
function t.Raycast(p1, p2, p3, p4) --[[ Raycast | Line: 178 ]]
	local v1 = p1:GetRay(p4)

	return workspace:Raycast(v1.Origin, v1.Direction * (p3 or 1000), p2)
end
function t.Project(p1, p2, p3) --[[ Project | Line: 207 ]]
	local v1 = p1:GetRay(p3)

	return v1.Origin + v1.Direction.Unit * (p2 or 1000)
end
function t.Lock(p1) --[[ Lock | Line: 222 | Upvalues: UserInputService (copy) ]]
	UserInputService.MouseBehavior = Enum.MouseBehavior.LockCurrentPosition
end
function t.LockCenter(p1) --[[ LockCenter | Line: 234 | Upvalues: UserInputService (copy) ]]
	UserInputService.MouseBehavior = Enum.MouseBehavior.LockCenter
end
function t.Unlock(p1) --[[ Unlock | Line: 242 | Upvalues: UserInputService (copy) ]]
	UserInputService.MouseBehavior = Enum.MouseBehavior.Default
end
function t.Destroy(p1) --[[ Destroy | Line: 250 ]]
	p1._trove:Destroy()
end

return t