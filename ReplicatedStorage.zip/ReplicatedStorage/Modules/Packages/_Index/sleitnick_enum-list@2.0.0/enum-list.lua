-- https://lua.expert/
local v1 = newproxy()
local v2 = newproxy()

local function CreateEnumItem(p1, p2, p3) --[[ CreateEnumItem | Line: 26 ]]
	local t = {
		Name = p1,
		Value = p2,
		EnumType = p3
	}

	table.freeze(t)

	return t
end

local t = {}

t.__index = t
function t.new(p1, p2) --[[ new | Line: 61 | Upvalues: t (copy), v1 (copy), v2 (copy) ]]
	assert(if type(p1) == "string" then true else false, "Name string required")
	assert(if type(p2) == "table" then true else false, "Enums table required")

	local v4 = setmetatable({}, t)

	v4[v1] = {}
	v4[v2] = p1

	for i, v in ipairs(p2) do
		assert(if type(v) == "string" then true else false, "Enum name must be a string")

		local t2 = {
			Name = v,
			Value = i,
			EnumType = v4
		}

		table.freeze(t2)
		v4[v] = t2
		table.insert(v4[v1], t2)
	end

	table.freeze(v4)

	return v4
end
function t.BelongsTo(p1, p2) --[[ BelongsTo | Line: 83 ]]
	return if type(p2) == "table" then p2.EnumType == p1 else false
end
function t.GetEnumItems(p1) --[[ GetEnumItems | Line: 93 | Upvalues: v1 (copy) ]]
	return p1[v1]
end
function t.GetName(p1) --[[ GetName | Line: 103 | Upvalues: v2 (copy) ]]
	return p1[v2]
end

return t