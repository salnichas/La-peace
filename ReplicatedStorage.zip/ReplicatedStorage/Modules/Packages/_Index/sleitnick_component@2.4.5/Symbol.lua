-- https://lua.expert/
return require(script.Parent.Parent["sleitnick_symbol@2.0.0"].symbol)