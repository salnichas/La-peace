-- https://lua.expert/
local v1 = require(script.Parent)
local Util = require(script.Parent.Parent.Util)

require(script.Parent.Parent.Types)

local t = {}

t.__index = t
function t.new(p1, p2) --[[ new | Line: 45 | Upvalues: Util (copy), t (copy) ]]
	assert(Util.IsServer, "ServerComm must be constructed from the server")
	assert(if typeof(p1) == "Instance" then true else false, "Parent must be of type Instance")

	local DefaultCommFolderName = Util.DefaultCommFolderName

	if p2 then
		DefaultCommFolderName = p2
	end

	assert(not p1:FindFirstChild(DefaultCommFolderName), "Parent already has another ServerComm bound to namespace " .. DefaultCommFolderName)

	local v4 = setmetatable({}, t)

	v4._instancesFolder = Instance.new("Folder")
	v4._instancesFolder.Name = DefaultCommFolderName
	v4._instancesFolder.Parent = p1

	return v4
end
function t.BindFunction(p1, p2, p3, p4, p5) --[[ BindFunction | Line: 77 | Upvalues: v1 (copy) ]]
	return v1.BindFunction(p1._instancesFolder, p2, p3, p4, p5)
end
function t.WrapMethod(p1, p2, p3, p4, p5) --[[ WrapMethod | Line: 104 | Upvalues: v1 (copy) ]]
	return v1.WrapMethod(p1._instancesFolder, p2, p3, p4, p5)
end
function t.CreateSignal(p1, p2, p3, p4) --[[ CreateSignal | Line: 132 | Upvalues: v1 (copy) ]]
	return v1.CreateSignal(p1._instancesFolder, p2, p3, p4)
end
function t.CreateProperty(p1, p2, p3, p4, p5) --[[ CreateProperty | Line: 176 | Upvalues: v1 (copy) ]]
	return v1.CreateProperty(p1._instancesFolder, p2, p3, p4, p5)
end
function t.Destroy(p1) --[[ Destroy | Line: 183 ]]
	p1._instancesFolder:Destroy()
end

return t