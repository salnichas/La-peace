-- https://lua.expert/
local Players = game:GetService("Players")
local Signal = require(script.Parent.Parent.Parent.Signal)

require(script.Parent.Parent.Types)

local t = {}

t.__index = t
function t.new(p1, p2, p3, p4) --[[ new | Line: 27 | Upvalues: t (copy), Signal (copy) ]]
	local v2 = setmetatable({}, t)

	v2._re = Instance.new("RemoteEvent")
	v2._re.Name = p2
	v2._re.Parent = p1

	if p4 and #p4 > 0 then
		v2._hasOutbound = true
		v2._outbound = p4
	else
		v2._hasOutbound = false
	end

	if p3 and #p3 > 0 then
		v2._directConnect = false
		v2._signal = Signal.new()
		v2._re.OnServerEvent:Connect(function(p1, ...) --[[ Line: 41 | Upvalues: p3 (copy), v2 (copy) ]]
			local v1 = table.pack(...)

			for i, v in ipairs(p3) do
				if not table.pack(v(p1, v1))[1] then
					return
				end

				v1.n = #v1
			end

			v2._signal:Fire(p1, table.unpack(v1, 1, v1.n))
		end)

		return v2
	end

	v2._directConnect = true

	return v2
end
function t.Connect(p1, p2) --[[ Connect | Line: 65 ]]
	if p1._directConnect then
		return p1._re.OnServerEvent:Connect(p2)
	end

	return p1._signal:Connect(p2)
end
function t._processOutboundMiddleware(p1, p2, ...) --[[ _processOutboundMiddleware | Line: 73 ]]
	if not p1._hasOutbound then
		return ...
	end

	local v1 = table.pack(...)

	for i, v in ipairs(p1._outbound) do
		local v2 = table.pack(v(p2, v1))

		if not v2[1] then
			return table.unpack(v2, 2, v2.n)
		end

		v1.n = #v1
	end

	return table.unpack(v1, 1, v1.n)
end
function t.Fire(p1, p2, ...) --[[ Fire | Line: 98 ]]
	p1._re:FireClient(p2, p1:_processOutboundMiddleware(p2, ...))
end
function t.FireAll(p1, ...) --[[ FireAll | Line: 111 ]]
	p1._re:FireAllClients(p1:_processOutboundMiddleware(nil, ...))
end
function t.FireExcept(p1, p2, ...) --[[ FireExcept | Line: 126 ]]
	p1:FireFilter(function(p1) --[[ Line: 127 | Upvalues: p2 (copy) ]]
		return p1 ~= p2
	end, ...)
end
function t.FireFilter(p1, p2, ...) --[[ FireFilter | Line: 156 | Upvalues: Players (copy) ]]
	for i, v in ipairs(Players:GetPlayers()) do
		if p2(v, ...) then
			p1._re:FireClient(v, p1:_processOutboundMiddleware(nil, ...))
		end
	end
end
function t.FireFor(p1, p2, ...) --[[ FireFor | Line: 180 ]]
	for i, v in ipairs(p2) do
		p1._re:FireClient(v, p1:_processOutboundMiddleware(nil, ...))
	end
end
function t.Destroy(p1) --[[ Destroy | Line: 189 ]]
	p1._re:Destroy()

	if not p1._signal then
		return
	end

	p1._signal:Destroy()
end

return t