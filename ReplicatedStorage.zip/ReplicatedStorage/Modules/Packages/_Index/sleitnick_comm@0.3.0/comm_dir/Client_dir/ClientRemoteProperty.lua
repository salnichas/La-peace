-- https://lua.expert/
local Promise = require(script.Parent.Parent.Parent.Promise)
local Signal = require(script.Parent.Parent.Parent.Signal)
local ClientRemoteSignal = require(script.Parent.ClientRemoteSignal)

require(script.Parent.Parent.Types)

local t = {}

t.__index = t
function t.new(p1, p2, p3) --[[ new | Line: 33 | Upvalues: t (copy), ClientRemoteSignal (copy), Signal (copy) ]]
	local v2 = setmetatable({}, t)

	v2._rs = ClientRemoteSignal.new(p1, p2, p3)
	v2._ready = false
	v2._value = nil
	v2.Changed = Signal.new()
	v2._readyPromise = v2:OnReady():andThen(function() --[[ Line: 39 | Upvalues: v2 (copy) ]]
		v2._readyPromise = nil
		v2.Changed:Fire(v2._value)
		v2._changed = v2._rs:Connect(function(p1) --[[ Line: 42 | Upvalues: v2 (ref) ]]
			if p1 ~= v2._value then
				v2._value = p1
				v2.Changed:Fire(p1)
			end
		end)
	end)
	v2._rs:Fire()

	return v2
end
function t.Get(p1) --[[ Get | Line: 60 ]]
	return p1._value
end
function t.OnReady(p1) --[[ OnReady | Line: 83 | Upvalues: Promise (copy) ]]
	if p1._ready then
		return Promise.resolve(p1._value)
	end

	return Promise.fromEvent(p1._rs, function(p12) --[[ Line: 87 | Upvalues: p1 (copy) ]]
		p1._value = p12
		p1._ready = true

		return true
	end):andThen(function() --[[ Line: 91 | Upvalues: p1 (copy) ]]
		return p1._value
	end)
end
function t.IsReady(p1) --[[ IsReady | Line: 108 ]]
	return p1._ready
end
function t.Observe(p1, p2) --[[ Observe | Line: 133 ]]
	if p1._ready then
		task.defer(p2, p1._value)
	end

	return p1.Changed:Connect(p2)
end
function t.Destroy(p1) --[[ Destroy | Line: 143 ]]
	p1._rs:Destroy()

	if p1._readyPromise then
		p1._readyPromise:cancel()
	end

	if p1._changed then
		p1._changed:Disconnect()
	end

	p1.Changed:Destroy()
end

return t