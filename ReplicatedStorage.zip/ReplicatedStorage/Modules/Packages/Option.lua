-- https://lua.expert/
return require(script.Parent._Index["sleitnick_option@1.0.3"].option)