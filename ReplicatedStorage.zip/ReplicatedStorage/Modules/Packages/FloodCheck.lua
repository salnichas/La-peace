-- https://lua.expert/
local t = {}
local t2 = {}

function t.Check(p1, p2, p3, p4, p5) --[[ Check | Line: 45 | Upvalues: t2 (copy) ]]
	local v1 = p4 or 10
	local v2 = p5 or "Identifier"

	if not t2[p2] then
		t2[p2] = {}

		local v3 = nil

		local function PlayerLeft(p1) --[[ PlayerLeft | Line: 52 | Upvalues: p2 (copy), t2 (ref), v3 (ref) ]]
			if p1 ~= p2 then
				return
			end

			t2[p2] = nil
			v3:Disconnect()
		end

		v3 = game.Players.PlayerRemoving:Connect(PlayerLeft)
	end

	if not t2[p2][p3] then
		t2[p2][p3] = {}
	end

	if not t2[p2][p3][v2] then
		t2[p2][p3][v2] = {}
	end

	if v1 > 1 then
		if not t2[p2][p3][v2].Count then
			t2[p2][p3][v2].Count = 1
			t2[p2][p3][v2].StartTime = tick()

			return true
		end

		if tick() - t2[p2][p3][v2].StartTime >= 1 then
			t2[p2][p3][v2].Count = 1
			t2[p2][p3][v2].StartTime = tick()

			return true
		end

		t2[p2][p3][v2].Count = t2[p2][p3][v2].Count + 1

		return t2[p2][p3][v2].Count <= v1
	end

	if not (v1 <= 1) then
		return
	end

	if not t2[p2][p3][v2].LastTime then
		t2[p2][p3][v2].LastTime = tick()

		return true
	end

	if 1 / v1 <= tick() - t2[p2][p3][v2].LastTime then
		t2[p2][p3][v2].LastTime = tick()

		return true
	end

	return false
end

return t