-- https://lua.expert/
if game:GetService("RunService"):IsServer() then
	return require(script.KnitServer)
end

local KnitServer = script:FindFirstChild("KnitServer")

if not KnitServer then
	return require(script.KnitClient)
end

KnitServer:Destroy()

return require(script.KnitClient)