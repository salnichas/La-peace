-- https://lua.expert/
local t = {
	ServicePromises = true,
	Middleware = nil,
	PerServiceMiddleware = {}
}
local v1 = nil
local t2 = {
	Player = game:GetService("Players").LocalPlayer,
	Util = script.Parent.Parent
}
local Promise = require(t2.Util.Promise)
local ClientComm = require(t2.Util.Comm).ClientComm
local t3 = {}
local t4 = {}
local v2 = nil
local v3 = false
local v4 = false
local v5 = Instance.new("BindableEvent")

local function DoesControllerExist(p1) --[[ DoesControllerExist | Line: 129 | Upvalues: t3 (copy) ]]
	return t3[p1] ~= nil
end

local function GetServicesFolder() --[[ GetServicesFolder | Line: 135 | Upvalues: v2 (ref) ]]
	if v2 then
		return v2
	end

	v2 = script.Parent:WaitForChild("Services")

	return v2
end

local function GetMiddlewareForService(p1) --[[ GetMiddlewareForService | Line: 143 | Upvalues: v1 (ref) ]]
	return v1.PerServiceMiddleware[p1] or (v1.Middleware or {})
end

local function BuildService(p1) --[[ BuildService | Line: 150 | Upvalues: v2 (ref), v1 (ref), ClientComm (copy), t4 (copy) ]]
	if not v2 then
		v2 = script.Parent:WaitForChild("Services")
	end

	local v3 = v1.PerServiceMiddleware[p1] or (v1.Middleware or {})
	local v4 = ClientComm.new(v2, v1.ServicePromises, p1):BuildObject(v3.Inbound, v3.Outbound)

	t4[p1] = v4

	return v4
end

function t2.CreateController(p1) --[[ CreateController | Line: 181 | Upvalues: t3 (copy) ]]
	assert(type(p1) == "table", "Controller must be a table; got " .. type(p1))
	assert(type(p1.Name) == "string", "Controller.Name must be a string; got " .. type(p1.Name))
	assert(#p1.Name > 0, "Controller.Name must be a non-empty string")
	assert(not (t3[p1.Name] ~= nil), "Controller \"" .. p1.Name .. "\" already exists")
	t3[p1.Name] = p1

	return p1
end
function t2.AddControllers(p1) --[[ AddControllers | Line: 199 ]]
	local t = {}

	for i, v in ipairs(p1:GetChildren()) do
		if v:IsA("ModuleScript") then
			table.insert(t, require(v))
		end
	end

	return t
end
function t2.AddControllersDeep(p1) --[[ AddControllersDeep | Line: 212 ]]
	local t = {}

	for i, v in ipairs(p1:GetDescendants()) do
		if v:IsA("ModuleScript") then
			table.insert(t, require(v))
		end
	end

	return t
end
function t2.GetService(p1) --[[ GetService | Line: 274 | Upvalues: t4 (copy), v3 (ref), v2 (ref), v1 (ref), ClientComm (copy) ]]
	local v12 = t4[p1]

	if v12 then
		return v12
	end

	assert(v3, "Cannot call GetService until Knit has been started")
	assert(type(p1) == "string", "ServiceName must be a string; got " .. type(p1))

	if not v2 then
		v2 = script.Parent:WaitForChild("Services")
	end

	local v7 = v1.PerServiceMiddleware[p1] or (v1.Middleware or {})
	local v8 = ClientComm.new(v2, v1.ServicePromises, p1):BuildObject(v7.Inbound, v7.Outbound)

	t4[p1] = v8

	return v8
end
function t2.GetController(p1) --[[ GetController | Line: 289 | Upvalues: t3 (copy), v3 (ref) ]]
	local v1 = t3[p1]

	if v1 then
		return v1
	end

	assert(v3, "Cannot call GetController until Knit has been started")

	local v32 = type(p1) == "string"

	assert(v32, "ControllerName must be a string; got " .. type(p1))
	error("Could not find controller \"" .. p1 .. "\". Check to verify a controller with this name exists.", 2)
end
function t2.Start(p1) --[[ Start | Line: 317 | Upvalues: v3 (ref), Promise (copy), v1 (ref), t (copy), t3 (copy), v4 (ref), v5 (copy) ]]
	if v3 then
		return Promise.reject("Knit already started")
	end

	v3 = true

	if p1 == nil then
		v1 = t
	else
		local v12 = typeof(p1) == "table"

		assert(v12, "KnitOptions should be a table or nil; got " .. typeof(p1))
		v1 = p1

		for k, v in pairs(t) do
			if p1[k] == nil then
				p1[k] = v
			end
		end
	end

	if type(v1.PerServiceMiddleware) == "table" then
		return Promise.new(function(p13) --[[ Line: 340 | Upvalues: t3 (ref), Promise (ref) ]]
			local t2 = {}

			for k2, v in pairs(t3) do
				if type(v.KnitInit) == "function" then
					table.insert(t2, Promise.new(function(p13) --[[ Line: 347 | Upvalues: v (copy) ]]
						debug.setmemorycategory(v.Name)
						v:KnitInit()
						p13()
					end))
				end
			end

			p13(Promise.all(t2))
		end):andThen(function() --[[ Line: 357 | Upvalues: t3 (ref), v4 (ref), v5 (ref) ]]
			for k2, v in pairs(t3) do
				if type(v.KnitStart) == "function" then
					task.spawn(function() --[[ Line: 362 | Upvalues: v (copy) ]]
						debug.setmemorycategory(v.Name)
						v:KnitStart()
					end)
				end
			end

			v4 = true
			v5:Fire()
			task.defer(function() --[[ Line: 372 | Upvalues: v5 (ref) ]]
				v5:Destroy()
			end)
		end)
	end

	v1.PerServiceMiddleware = {}

	return Promise.new(function(p13) --[[ Line: 340 | Upvalues: t3 (ref), Promise (ref) ]]
		local t2 = {}

		for k2, v in pairs(t3) do
			if type(v.KnitInit) == "function" then
				table.insert(t2, Promise.new(function(p13) --[[ Line: 347 | Upvalues: v (copy) ]]
					debug.setmemorycategory(v.Name)
					v:KnitInit()
					p13()
				end))
			end
		end

		p13(Promise.all(t2))
	end):andThen(function() --[[ Line: 357 | Upvalues: t3 (ref), v4 (ref), v5 (ref) ]]
		for k2, v in pairs(t3) do
			if type(v.KnitStart) == "function" then
				task.spawn(function() --[[ Line: 362 | Upvalues: v (copy) ]]
					debug.setmemorycategory(v.Name)
					v:KnitStart()
				end)
			end
		end

		v4 = true
		v5:Fire()
		task.defer(function() --[[ Line: 372 | Upvalues: v5 (ref) ]]
			v5:Destroy()
		end)
	end)
end
function t2.OnStart() --[[ OnStart | Line: 393 | Upvalues: v4 (ref), Promise (copy), v5 (copy) ]]
	if v4 then
		return Promise.resolve()
	end

	return Promise.fromEvent(v5.Event)
end

return t2