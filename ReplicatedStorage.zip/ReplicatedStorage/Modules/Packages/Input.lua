-- https://lua.expert/
return require(script.Parent._Index["sleitnick_input@1.3.3"].input)