-- https://lua.expert/
return require(script.Parent._Index["sleitnick_timer@1.1.1"].timer)