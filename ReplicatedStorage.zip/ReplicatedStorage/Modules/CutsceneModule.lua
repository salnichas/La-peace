-- https://lua.expert/
local RunService = game:GetService("RunService")
local Players = game:GetService("Players")

game:GetService("ReplicatedStorage")
game:GetService("SoundService")

local StarterGui = game:GetService("StarterGui")
local CurrentCamera = workspace.CurrentCamera

workspace:WaitForChild("Map")

local LocalPlayer = Players.LocalPlayer
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
local t = {}

t.__index = t

local v1 = nil
local v2 = nil
local t2 = { "GameUI", "DebugUI", "WorldAreas" }

local function RestoreGuis() --[[ RestoreGuis | Line: 42 | Upvalues: t2 (copy), PlayerGui (copy), StarterGui (copy) ]]
	for v1, v2 in t2 do
		if PlayerGui:FindFirstChild(v2) then
			PlayerGui[v2].Enabled = true
		end
	end

	StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, true)
end

local function DisableGuis() --[[ DisableGuis | Line: 52 | Upvalues: t2 (copy), PlayerGui (copy), StarterGui (copy) ]]
	for v1, v2 in t2 do
		if PlayerGui:FindFirstChild(v2) then
			PlayerGui[v2].Enabled = false
		end
	end

	StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false)
end

local function EndCutscene() --[[ EndCutscene | Line: 62 | Upvalues: v1 (ref), LocalPlayer (copy), StarterGui (copy), CurrentCamera (copy), v2 (ref), RestoreGuis (copy) ]]
	if v1 then
		v1:Disconnect()
		v1 = nil
	end

	local Humanoid = LocalPlayer.Character:WaitForChild("Humanoid")

	if Humanoid then
		Humanoid.AutoRotate = true
	end

	LocalPlayer:SetAttribute("InCutscene", false)
	StarterGui:SetCore("ResetButtonCallback", true)
	CurrentCamera.CameraType = Enum.CameraType.Custom

	if not v2 then
		CurrentCamera.FieldOfView = workspace:GetAttribute("DefaultFieldOfView") or 70
		RestoreGuis()

		return
	end

	CurrentCamera.CFrame = v2
	CurrentCamera.FieldOfView = workspace:GetAttribute("DefaultFieldOfView") or 70
	RestoreGuis()
end

function t.Cinematic(p1, p2, p3) --[[ Cinematic | Line: 88 | Upvalues: v2 (ref), CurrentCamera (copy), DisableGuis (copy), LocalPlayer (copy), v1 (ref), RunService (copy), EndCutscene (copy), StarterGui (copy) ]]
	v2 = CurrentCamera.CFrame
	DisableGuis()

	local Humanoid = (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("Humanoid")

	LocalPlayer:SetAttribute("InCutscene", true)
	CurrentCamera.CameraType = Enum.CameraType.Scriptable
	CurrentCamera.CameraSubject = nil

	local t = {}
	local t2 = {}

	for i, v in ipairs(p3.Frames:GetChildren()) do
		if v:IsA("CFrameValue") then
			t[tonumber(v.Name)] = v.Value
		end
	end

	for i, v in ipairs(p3.FOV:GetChildren()) do
		if v:IsA("NumberValue") then
			t2[tonumber(v.Name)] = v.Value
		end
	end

	local v4 = os.clock()

	v1 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 132 | Upvalues: v4 (copy), t (copy), EndCutscene (ref), Humanoid (copy), StarterGui (ref), p2 (copy), CurrentCamera (ref), t2 (copy) ]]
		local v2 = math.floor((os.clock() - v4) * 60)
		local v3 = t[v2]

		if not v3 then
			EndCutscene()

			return
		end

		Humanoid.AutoRotate = false
		StarterGui:SetCore("ResetButtonCallback", false)
		CurrentCamera.CFrame = p2.CFrame * v3

		local v42 = t2[v2]

		if not v42 then
			return
		end

		CurrentCamera.FieldOfView = v42
	end)
	Humanoid.Died:Once(function() --[[ Line: 160 | Upvalues: EndCutscene (ref) ]]
		EndCutscene()
	end)
end
function t.Stop(p1) --[[ Stop | Line: 170 | Upvalues: EndCutscene (copy) ]]
	EndCutscene()
end

return t