-- https://lua.expert/
return {
	Exceto = { 255 },
	Groups = {
		Principais = {
			["Ex\195\169rcito Brasileiro"] = {
				Sigla = "[EB]",
				Id = 35860776,
				Team = "[EB] Ex\195\169rcito Brasileiro"
			}
		},
		["Divis\195\181es"] = {
			["Batalh\195\163o de Pol\195\173cia do Ex\195\169rcito"] = {
				Sigla = "[BPE]",
				Id = 344555101,
				Team = "[BPE] Batalh\195\163o da Policia do Ex\195\169rcito"
			},
			["Batalh\195\163o de For\195\167as Especiais"] = {
				Sigla = "[BFE]",
				Id = 1080051865,
				Team = "[BFE] Batalh\195\163o de For\195\167as Especiais"
			},
			["Batalh\195\163o de A\195\167\195\181es de Comandos"] = {
				Sigla = "[BAC]",
				Id = 111831378,
				Team = "[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos"
			},
			["Centro de Intelig\195\170ncia do Ex\195\169rcito"] = {
				Sigla = "[CIE]",
				Id = 34766634,
				Team = "[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito"
			},
			["Brigada de Infantaria P\195\161ra-quedista"] = {
				Sigla = "[BIP]",
				Id = 353908103,
				Team = "[BIP] Brigada de Infantaria Paraquedista",
				IsCourse = true
			},
			["[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva"] = {
				Sigla = "[CIGS]",
				Id = 769836049,
				Team = "[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva"
			},
			["[CAAT] Batalh\195\163o de Infantaria de Caatinga"] = {
				Sigla = "[CAAT]",
				Id = 536507768,
				Team = "[CAAT] Batalh\195\163o de Infantaria de Caatinga"
			},
			["[REC MEC] Regimento de Cavalaria Mecanizado"] = {
				Sigla = "[REC MEC]",
				Id = 1038401574,
				Team = "[REC MEC] Regimento de Cavalaria Mecanizado"
			},
			["[CYBER] Comando de Defesa Cibern\195\169tica"] = {
				Sigla = "[CYBER]",
				Id = 572637180,
				Team = "[CYBER] Comando de Defesa Cibern\195\169tica"
			}
		}
	},
	GetGroup = function(p1, p2) --[[ GetGroup | Line: 96 ]]
		for i, v in ipairs({ "Ex\195\169rcito Brasileiro" }) do
			local v1 = p1.Groups.Principais[v]

			if v1 and p2:Async(v1.Id) then
				return v, v1
			end
		end

		return false
	end,
	GetGroupById = function(p1, p2) --[[ GetGroupById | Line: 113 ]]
		for k, v in pairs(p1.Groups.Principais) do
			if v.Id == p2 then
				return k, v
			end
		end
	end,
	GetDivision = function(p1, p2) --[[ GetDivision | Line: 121 ]]
		for k, v in pairs(p1.Exceto) do
			if p2:GetRankInGroupAsync(p1.Groups.Principais["Ex\195\169rcito Brasileiro"].Id) == v then
				return true, {
					Sigla = "Todas"
				}
			end
		end

		for k, v in pairs(p1.Groups["Divis\195\181es"]) do
			if p2:IsInGroupAsync(v.Id) then
				return k, v
			end
		end

		return false
	end,
	GetAllPlayerDivisions = function(p1, p2) --[[ GetAllPlayerDivisions | Line: 145 ]]
		local t = {}

		for k, v in pairs(p1.Exceto) do
			if p2:GetRankInGroupAsync(p1.Groups.Principais["Ex\195\169rcito Brasileiro"].Id) == v then
				table.insert(t, {
					Name = "Todas",
					Sigla = "Todas"
				})
			end
		end

		for k, v in pairs(p1.Groups["Divis\195\181es"]) do
			if p2:IsInGroupAsync(v.Id) then
				table.insert(t, {
					Name = k,
					Info = v
				})
			end
		end

		if #t == 0 then
			return false
		end

		return t
	end
}