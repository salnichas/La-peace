-- https://lua.expert/
local config = require(script.config)
local _aux = require(script._aux)
local t = {}
local v1 = "%0" .. string.gsub(string.reverse(config.groupingSymbol), "%%", "%%%%")
local compactSuffix = config.compactSuffix
local v2 = config.useARM64FCVTZS and string.format("%d", (0 / 0)) ~= "0"

function t.FormatInt(p1) --[[ FormatInt | Line: 76 | Upvalues: _aux (copy), v2 (copy), v1 (copy) ]]
	_aux.expect_strictly_number(p1, 1)

	local v12 = if v2 then if p1 == p1 and (p1 ~= 0 or p1 ~= 1) then if p1 >= 9.223372036854776e18 then "+9223372036854775807" elseif p1 <= -9.223372036854776e18 then "-9223372036854775808" else string.format("%+d", p1) else "+0" else string.format("%+d", p1)
	local v4 = if string.byte(v12) == 45 then 1 else 2

	return string.sub(v12, v4, 2) .. string.reverse((string.gsub(string.reverse((string.sub(v12, 3))), "...", v1)))
end

local DoubleToDecimalConverter = require(script.DoubleConversion.DoubleToDecimalConverter)

function t.FormatStandard(p1) --[[ FormatStandard | Line: 177 | Upvalues: _aux (copy), DoubleToDecimalConverter (copy) ]]
	_aux.expect_strictly_number(p1, 1)

	local v1 = _aux.format_special(p1, 0)
	local v2

	if v1 then
		v2 = v1
	else
		local v3, v4, v5 = DoubleToDecimalConverter.ToShortest(p1)
		local v6 = _aux.format_unsigned_finite(v3, v4, v5 + v4, nil, 4)

		v2 = if p1 < 0 then "-" .. v6 else v6
	end

	return v2
end
function t.FormatFixed(p1, p2) --[[ FormatFixed | Line: 207 | Upvalues: _aux (copy), DoubleToDecimalConverter (copy) ]]
	_aux.expect_strictly_number(p1, 1)

	local v1 = _aux.cast_to_int32_t_check_range(p2, 0, 9999, 2, 6)
	local v2 = _aux.format_special(p1, v1 + 1)
	local v3

	if v2 then
		v3 = v2
	else
		local v4, v5, v6 = DoubleToDecimalConverter.ToExact(p1)
		local v7 = v6 + v5
		local v8 = v7 + v1
		local v9, v10 = _aux.round_sig(v4, v5, v8)
		local v11

		if v10 then
			v11, v7, v8 = v9, v7 + 1, v8 + 1
		elseif v9 == 0 then
			v11 = v9
			v7 = 1
			v8 = v1
		else
			v11 = v9
		end

		local v12 = _aux.format_unsigned_finite(v4, v11, v7, v8, 4)

		v3 = if p1 < 0 then "-" .. v12 else v12
	end

	return v3
end
function t.FormatPrecision(p1, p2) --[[ FormatPrecision | Line: 252 | Upvalues: _aux (copy), DoubleToDecimalConverter (copy) ]]
	_aux.expect_strictly_number(p1, 1)

	local v1 = _aux.cast_to_int32_t_check_range(p2, 1, 9999, 2, 6)
	local v2 = _aux.format_special(p1, v1)
	local v3

	if v2 then
		v3 = v2
	else
		local v4, v5, v6 = DoubleToDecimalConverter.ToExact(p1)
		local count = v6 + v5
		local v7, v8 = _aux.round_sig(v4, v5, v1)

		if v8 then
			count = count + 1
		end

		local v9 = _aux.format_unsigned_finite(v4, v7, count, v1, 4)

		v3 = if p1 < 0 then "-" .. v9 else v9
	end

	return v3
end
function t.FormatCompact(p1, p2, p3) --[[ FormatCompact | Line: 290 | Upvalues: _aux (copy), DoubleToDecimalConverter (copy), compactSuffix (copy) ]]
	_aux.expect_strictly_number(p1, 1)

	local v5 = _aux.cast_to_int32_t_check_range(p2, 0, 999, 2, if p3 then -2147483648 else 0)
	local v10 = _aux.cast_to_int32_t_check_range(p3, 1, 99, 3, if p2 then 0 else 2)
	local v11 = _aux.format_special(p1, 0)
	local v12

	if v11 then
		v12 = v11
	else
		local v13, v14, v15 = DoubleToDecimalConverter.ToShortest(p1)
		local sum = v15 + v14
		local v18 = math.min(math.floor((sum - 1) / 3), #compactSuffix)
		local v19

		if v18 > 0 then
			v19 = compactSuffix[v18]
			sum = sum - v18 * 3
		else
			v19 = nil
		end

		local v20 = math.max(v10, sum + v5)
		local v21, count

		if v20 < v14 then
			if v20 <= 0 then
				v21 = v13
				count = 0
				sum = 1
			else
				v21 = v13
				count = v20
			end
		else
			v21 = v13
			count = v14
		end

		while v21[count] == 0 do
			count = count - 1
		end

		local v22 = _aux.format_unsigned_finite(v21, count, sum, nil, 5)

		v12 = if p1 < 0 then "-" .. v22 else v22

		if v19 then
			v12 = v12 .. v19
		end
	end

	return v12
end
function t.FormatHexFloat(p1, p2, p3) --[[ FormatHexFloat | Line: 357 | Upvalues: _aux (copy) ]]
	_aux.expect_strictly_number(p1, 1)

	local v1 = _aux.cast_to_int32_t_check_range(p2, 0, 99, 2, -1)
	local v2, v3

	if p1 == p1 and (p1 ~= (1 / 0) and p1 ~= (-1 / 0)) then
		v2 = math.atan2(p1, -1) < 0

		local v5, v6 = math.frexp((math.abs(p1)))
		local v7, v8, v9

		if v6 <= -1022 then
			v7, v8, v9 = v1, math.ldexp(v5, v6 + 1074), -1022
		elseif v5 == 0 then
			v7 = v1
			v8 = v5
			v9 = v6
		else
			v7, v8, v9 = v1, math.ldexp(v5, 53), v6 - 1
		end

		local v17 = string.gsub(if v7 == -1 then string.format("0x%013x", v8) elseif v7 < 13 then string.format(string.char(48, 120, 37, 48, 48 + v7 / 10, 48 + v7 % 10, 120), (math.round((math.ldexp(v8, (v7 - 13) * 4))))) else string.format("0x%013x", v8) .. string.rep("0", v7 - 13), "^(...)(.)", "%1.%2", 1)

		v3 = string.format("%sp%+d", if v7 == -1 then string.gsub(v17, "%.?0+$", "") else v17, v9)
	else
		v3, v2 = string.format("%g", p1), false
	end

	if p3 then
		v3 = string.upper(v3)
	end

	if v2 then
		v3 = "-" .. v3
	end

	return v3
end

local t2 = {
	["width-long"] = { "week", "day", "hour", "minute", "second" },
	["width-short"] = { "wk", "day", "hr", "min", "sec" },
	["width-narrow"] = { "w", "d", "h", "m", "s" },
	["width-numeric"] = "numeric",
	["width-2-digit"] = "2-digit"
}
local t3 = { 604800, 86400, 3600, 60, 1 }
local durationSeparatorSymbol = config.durationSeparatorSymbol

function t.FormatDuration(p1, p2) --[[ FormatDuration | Line: 459 | Upvalues: _aux (copy), t2 (copy), t3 (copy), durationSeparatorSymbol (copy) ]]
	local v1 = nil
	local v2 = nil
	local v3 = nil
	local v4 = nil
	local v5 = _aux.cast_to_int32_t_check_range(p1, nil, nil, 1, nil)
	local v6 = _aux.cast_to_string(p2, 2, "")

	if v5 < 0 then
		error(string.format("Negative value, provided by the argument #1 (%d), is not supported", v5), 2)
	end

	local sum = v5

	for v8, v9 in string.gmatch(v6, "()(%S+)") do
		local v7
		local v10 = t2[v9]

		if v10 then
			v7, v1, v2 = not v1, v10, v9
		else
			local v12

			v12, v3 = v9, table.create(5)

			for v13, v14 in t2["width-narrow"] do
				local v15 = string.match(v12, "^" .. v14 .. "(%??)")

				if v15 then
					if v15 == "" then
						v3[v13] = true
						v12 = string.sub(v12, 2)
					else
						v3[v13] = "nonzero"
						v12 = string.sub(v12, 3)
					end

					v4 = v13

					continue
				end

				v3[v13] = false
			end

			v7 = if v12 == "" then true else false
		end

		if not v7 then
			error(string.format("skeleton syntax error near \'%s\' at position %d", string.gsub(v9, "\'", "\\\'"), v8), 2)
		end
	end

	if not v1 then
		v2 = "width-numeric"
		v1 = "numeric"
	end

	if not v3 then
		v3 = if v2 == "width-numeric" or v2 == "width-2-digits" then { false, false, "nonzero", true, true } else { "nonzero", "nonzero", "nonzero", "nonzero", "nonzero" }
		v4 = 5
	end

	local v18 = if v1 == "width-short" then 2 else 5
	local v20 = table.create(5)

	for v22, v23 in v3 do
		local v21

		if v23 then
			local v24 = t3[v22]
			local v25 = math.floor(sum / v24)

			if v23 ~= "nonzero" or (v25 ~= 0 or v22 == v4 and not v20[1]) then
				sum = sum - v25 * v24

				if v1 == "numeric" then
					v21 = "%d"
					v1 = "2-digit"
				elseif v1 == "2-digit" then
					v21 = "%02d"
				elseif v2 == "width-narrow" then
					v21 = "%d" .. v1[v22]
				else
					v21 = "%d " .. v1[v22]

					if v25 ~= 1 and v22 <= v18 then
						v21 = v21 .. "s"
					end
				end

				table.insert(v20, string.format(v21, v25))
			end
		end
	end

	if not v20[2] then
		return v20[1]
	end

	if v2 == "width-long" then
		return table.concat(v20, ", ", 1, #v20 - 1) .. " and " .. v20[#v20]
	end

	return table.concat(v20, if v2 == "width-short" then ", " elseif v2 == "width-narrow" then " " else durationSeparatorSymbol)
end
function t.FormatUInt(p1) --[[ FormatUInt | Line: 585 | Upvalues: _aux (copy), v2 (copy), v1 (copy) ]]
	_aux.expect_strictly_number(p1, 1)

	local v12 = if v2 then if p1 == p1 and (p1 ~= 0 or p1 ~= 1) then if p1 >= 1.8446744073709552e19 then "18446744073709551615" elseif p1 <= 0 then "0" else string.format("%.0f", (math.floor(p1))) else "0" else string.format("%u", p1)

	return string.reverse((string.gsub(string.reverse(v12), "...", v1, (#v12 - 1) / 3)))
end

return table.freeze(t)