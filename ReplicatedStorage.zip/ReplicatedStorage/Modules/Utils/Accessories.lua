-- https://lua.expert/
local v0 = "Oculos Noturno que pode ser usado de decora\195\167\195\163o pelos Militares"
local Accessories = game:GetService("ReplicatedStorage"):WaitForChild("Assets"):WaitForChild("Fardamentos"):WaitForChild("Accessories")

return {
	[1] = {
		BOINA_VERDE = {
			Name = "Boina",
			Price = 0,
			Description = "Boina que deve ser utilizada por todos os Militares",
			Accessory = Accessories.BOINA_VERDE,
			Restriction = {
				Type = 1
			}
		},
		New_CabeloFV2 = {
			Name = "Cabelo Feminino V2",
			Price = 0,
			Description = "Utilizado por militares",
			Accessory = Accessories.New_CabeloFV2,
			Restriction = {
				Type = 1
			}
		},
		New_CabeloLoiro = {
			Name = "Cabelo Loiro",
			Price = 0,
			Description = "Utilizado por militares",
			Accessory = Accessories.New_CabeloLoiro,
			Restriction = {
				Type = 1
			}
		},
		New_CabeloMV2 = {
			Name = "Cabelo Masculino V2",
			Price = 0,
			Description = "Utilizado por militares",
			Accessory = Accessories.New_CabeloMV2,
			Restriction = {
				Type = 1
			}
		},
		New_CabeloMV3 = {
			Name = "Cabelo Masculino V3",
			Price = 0,
			Description = "Utilizado por militares",
			Accessory = Accessories.New_CabeloMV3,
			Restriction = {
				Type = 1
			}
		},
		New_CapaceteV2 = {
			Name = "Capacete V2",
			Price = 6000,
			Description = "Utilizado por militares",
			Accessory = Accessories.New_CapaceteV2,
			Restriction = {
				Type = 1
			}
		},
		New_Cinto = {
			Name = "Cinto",
			Price = 5000,
			Description = "Balaclava que pode ser usada de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.New_Cinto,
			Restriction = {
				Type = 1
			}
		},
		MASCARA_TATICA = {
			Name = "M\195\161scara T\195\161tica",
			Price = 5000,
			Description = "M\195\161scara T\195\161tica que pode ser usada de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.MASCARA_TATICA,
			Restriction = {
				Type = 1
			}
		},
		OCULOS_ESCURO = {
			Name = "Oculos Escuros",
			Price = 5000,
			Description = "Oculos escuros que podem ser usados de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.OCULOS_ESCURO,
			Restriction = {
				Type = 1
			}
		},
		New_ColeteV2 = {
			Name = "Colete V2",
			Price = 5000,
			Description = "Colete V2 que podem ser usados de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.New_ColeteV2,
			Restriction = {
				Type = 1
			}
		},
		New_Pochete = {
			Name = "Pochete",
			Price = 5000,
			Description = "Pochete que podem ser usados de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.New_Pochete,
			Restriction = {
				Type = 1
			}
		},
		ALAMARES_ = {
			Name = "Alamares",
			Price = 5000,
			Description = "Alamares que podem ser usados de decora\195\167\195\163o pelos Oficiais",
			Accessory = Accessories.ALAMARES_,
			Restriction = {
				Type = 2
			}
		},
		SABRE = {
			Name = "Sabre",
			Price = 5000,
			Description = "Sabre que pode ser usada de decora\195\167\195\163o pelos Oficiais",
			Accessory = Accessories.SABRE,
			Restriction = {
				Type = 2
			}
		},
		CABELO_MASCULINO = {
			Name = "Cabelo Masculino",
			Price = 0,
			Description = "Cabelo Masculino que pode ser usada de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.CABELO_MASCULINO,
			Restriction = {
				Type = 1
			}
		},
		MOCHILA_TATICA = {
			Name = "Mochila T\195\161tica",
			Price = 5000,
			Description = "Mochila T\195\161tica que pode ser usada de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.MOCHILA_TATICA,
			Restriction = {
				Type = 1
			}
		},
		OCULOS_TATICO = {
			Name = "\195\147culos T\195\161tico",
			Price = 5000,
			Description = "\195\147culos T\195\161tico que pode ser usada de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.OCULOS_TATICO,
			Restriction = {
				Type = 1
			}
		},
		COLETE_TATICO = {
			Name = "Colete T\195\161tico",
			Price = 5000,
			Description = "Colete T\195\161tico que pode ser usada de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.COLETE_TATICO,
			Restriction = {
				Type = 1
			}
		},
		CABELO_FEMININO = {
			Name = "Cabelo Feminino",
			Price = 0,
			Description = "Cabelo Feminino que pode ser usada de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.CABELO_FEMININO,
			Restriction = {
				Type = 1
			}
		},
		OCULOS_NOTURNO = {
			Name = "Oculos Noturno",
			Price = 5000,
			Description = v0,
			Accessory = Accessories.OCULOS_NOTURNO,
			Restriction = {
				Type = 1
			}
		},
		OCULOS_NOTURNO_PEQUENO = {
			Name = "Oculos Noturno",
			Price = 5000,
			Description = v0,
			Accessory = Accessories.OCULOS_NOTURNO_PEQUENO,
			Restriction = {
				Type = 1
			}
		},
		MICROFONE = {
			Name = "Microfone",
			Price = 5000,
			Description = "Microfone que pode ser usado de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.MICROFONE,
			Restriction = {
				Type = 1
			}
		},
		CAPACETE = {
			Name = "Capacete",
			Price = 5000,
			Description = "Capacete que pode ser usado de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.CAPACETE,
			Restriction = {
				Type = 1
			}
		},
		MASCARA = {
			Name = "M\195\161scara",
			Price = 5000,
			Description = "M\195\161scara que pode ser usado de decora\195\167\195\163o pelos Militares",
			Accessory = Accessories.MASCARA,
			Restriction = {
				Type = 1
			}
		}
	},
	[5] = {
		BOINA_BRANCA = {
			Name = "Boina Branca",
			Price = 0,
			Description = "Boina Branca que pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.BOINA_BRANCA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		},
		BOINA_PRETA = {
			Name = "Boina Preta",
			Price = 0,
			Description = "Boina Preta que pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.BOINA_PRETA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		},
		OCULOS_ESCURO_CIE = {
			Name = "Oculos Escuro",
			Price = 1000,
			Description = "Oculos Escuro que pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.OCULOS_ESCURO_CIE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		},
		CHAPEU_TATICO_CIE = {
			Name = "Chap\195\169u",
			Price = 1000,
			Description = "Chap\195\169u que pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.CHAPEU_TATICO_CIE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		},
		GRAMPO_TATICO_CIE = {
			Name = "Grampo",
			Price = 1000,
			Description = "Grampo que pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.GRAMPO_TATICO_CIE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		},
		CAPACETE_TATICO_CIE = {
			Name = "Capacete T\195\161tico",
			Price = 1000,
			Description = "Capacete T\195\161tico que pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.CAPACETE_TATICO_CIE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		},
		BONE_TATICO_CIE = {
			Name = "Bone T\195\161tico",
			Price = 1000,
			Description = "Bone T\195\161tico que pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.BONE_TATICO_CIE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		},
		MASCARA_TATICA_CIE = {
			Name = "M\195\161scara T\195\161tica",
			Price = 1000,
			Description = "M\195\161scara T\195\161tica mque pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.MASCARA_TATICA_CIE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		},
		COLETE_TATICO = {
			Name = "Colete T\195\161tico",
			Price = 1000,
			Description = "Colete T\195\161tico que pode ser usada de decora\195\167\195\163o pelo CIE",
			Accessory = Accessories.COLETE_TATICO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito")
			}
		}
	},
	[4] = {
		BOINA_PRETA = {
			Name = "Boina Preta",
			Price = 0,
			Description = "Boina Preta que pode ser usada de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.BOINA_PRETA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		},
		BOINA_VERMELHA = {
			Name = "Boina Vermelha",
			Price = 0,
			Description = "Boina Vermelha que pode ser usada de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.BOINA_VERMELHA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		},
		GORRO_FE = {
			Name = "Gorro das For\195\167as Especiais",
			Price = 0,
			Description = "Gorro das For\195\167as Especiais que pode ser usada de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.GORRO_FE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		},
		BALACLAVA_TATICA_BFE = {
			Name = "Balaclava T\195\161tica",
			Price = 1000,
			Description = "Balaclava T\195\161tica que pode ser usada de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.BALACLAVA_TATICA_BFE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		},
		MASCARA_TATICA_BFE = {
			Name = "M\195\161scara T\195\161tica",
			Price = 1000,
			Description = "M\195\161scara T\195\161tica que pode ser usada de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.MASCARA_TATICA_BFE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		},
		OCULOS_ESCURO_BFE = {
			Name = "Oculos Escuros",
			Price = 1000,
			Description = "Oculos Escuros que pode ser usado de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.OCULOS_ESCURO_BFE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		},
		OCULOS_TATICO_BFE = {
			Name = "Oculos T\195\161ticos",
			Price = 1000,
			Description = "Oculos T\195\161ticos que pode ser usado de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.OCULOS_TATICO_BFE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		},
		COLETE_TATICO = {
			Name = "Colete T\195\161tico",
			Price = 1000,
			Description = "Colete T\195\161tico que pode ser usado de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.COLETE_TATICO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		},
		CAPACETE_TATICO_BFE = {
			Name = "Capacete T\195\161tico",
			Price = 1000,
			Description = "Capacete T\195\161tico que pode ser usado de decora\195\167\195\163o pelo BFE",
			Accessory = Accessories.CAPACETE_TATICO_BFE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BFE] Batalh\195\163o de For\195\167as Especiais")
			}
		}
	},
	[3] = {
		BOINA_AZUL = {
			Name = "Boina Azul",
			Price = 0,
			Description = "Boina Azul utilizada pelos Militares do BPE",
			Accessory = Accessories.BOINA_AZUL,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		BOINA_BRANCA = {
			Name = "Boina Branca",
			Price = 0,
			Description = "Boina Branca utilizada pelos Militares do BPE",
			Accessory = Accessories.BOINA_BRANCA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		BOINA_VERDE = {
			Name = "Boina Branca",
			Price = 0,
			Description = "Boina Branca utilizada pelos Militares do BPE",
			Accessory = Accessories.BOINA_VERDE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		BALACLAVA_TATICA_BPE = {
			Name = "Balaclava T\195\161tica",
			Price = 1000,
			Description = "Balaclava T\195\161tica utilizada pelos Militares do BPE",
			Accessory = Accessories.BALACLAVA_TATICA_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		CAPA_TATICA_BPE = {
			Name = "Capa T\195\161tica",
			Price = 1000,
			Description = "Capa T\195\161tica utilizada pelos Militares do BPE",
			Accessory = Accessories.CAPA_TATICA_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		CAPACETE_TATICO_BPE = {
			Name = "Capacete T\195\161tico",
			Price = 1000,
			Description = "Capacete T\195\161tico utilizada pelos Militares do BPE",
			Accessory = Accessories.CAPACETE_TATICO_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		COLETE_TATICO_BPE = {
			Name = "Colete T\195\161tico",
			Price = 1000,
			Description = "Colete T\195\161tico utilizada pelos Militares do BPE",
			Accessory = Accessories.COLETE_TATICO_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		MOCHILA_TATICA_BPE = {
			Name = "Mochila T\195\161tica",
			Price = 1000,
			Description = "Mochila T\195\161tica utilizada pelos Militares do BPE",
			Accessory = Accessories.MOCHILA_TATICA_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		OCULOS_ESCURO_BPE = {
			Name = "Oculos Escuros",
			Price = 1000,
			Description = "Oculos Escuros utilizada pelos Militares do BPE",
			Accessory = Accessories.OCULOS_ESCURO_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		OMBREIRA_ESQUERDA_BPE = {
			Name = "Ombreira Esquerda",
			Price = 1000,
			Description = "Ombreira Esquerda utilizada pelos Militares do BPE",
			Accessory = Accessories.OMBREIRA_ESQUERDA_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		OMBREIRA_DIREITA_BPE = {
			Name = "Ombreira Direita",
			Price = 1000,
			Description = "Ombreira Direita utilizada pelos Militares do BPE",
			Accessory = Accessories.OMBREIRA_DIREITA_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		ALAMARES_BPE = {
			Name = "Alamares",
			Price = 1000,
			Description = "Alamares utilizado pelos Militares do BPE",
			Accessory = Accessories.ALAMARES_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		SABRE_BPE = {
			Name = "Sabre",
			Price = 1000,
			Description = "Sabre utilizado pelos Militares do BPE",
			Accessory = Accessories.SABRE_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		},
		ESCUDO_TATICO_BPE = {
			Name = "Escudo T\195\161tico",
			Price = 1000,
			Description = "Escudo utilizado pelos Militares do BPE",
			Accessory = Accessories.ESCUDO_TATICO_BPE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BPE] Batalh\195\163o da Policia do Ex\195\169rcito")
			}
		}
	},
	[2] = {
		CAPACETE_TATICO_BAC = {
			Name = "Capacete T\195\161tico",
			Price = 10000,
			Description = "Capacete utilizado pelos Militares do BAC",
			Accessory = Accessories.CAPACETE_TATICO_BAC,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos")
			}
		},
		OCULOS_TATICO_BAC = {
			Name = "Oculos T\195\161tico",
			Price = 10000,
			Description = "Oculos utilizado pelos Militares do BAC",
			Accessory = Accessories.OCULOS_TATICO_BAC,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos")
			}
		},
		MASCARA_TATICA_BAC = {
			Name = "M\195\161scara T\195\161tica",
			Price = 10000,
			Description = "M\195\161scara utilizado pelos Militares do BAC",
			Accessory = Accessories.MASCARA_TATICA_BAC,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos")
			}
		},
		GORRO_BAC = {
			Name = "Gorro",
			Price = 10000,
			Description = "Gorro utilizado pelos Militares do BAC",
			Accessory = Accessories.GORRO_BAC,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos")
			}
		},
		BOINA_PRETA = {
			Name = "Boina Preta",
			Price = 0,
			Description = "Boina utilizada pelos Oficiais do BAC",
			Accessory = Accessories.BOINA_PRETA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos")
			}
		},
		COLETE_TATICO_BAC = {
			Name = "Colete T\195\161tico",
			Price = 10000,
			Description = "Colete utilizado pelos Militares do BAC",
			Accessory = Accessories.COLETE_TATICO_BAC,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos")
			}
		},
		OCULOS_ESCURO_BAC = {
			Name = "Oculos Escuro",
			Price = 10000,
			Description = "Oculos Escuro utilizado pelos Militares do BAC",
			Accessory = Accessories.OCULOS_ESCURO_BAC,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos")
			}
		}
	},
	[6] = {
		BOINA_VERMELHA = {
			Name = "Boina Vermelha",
			Price = 0,
			Description = "Boina utilizada pelos Militares da BIP",
			Accessory = Accessories.BOINA_VERMELHA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		BOINA_BRANCA = {
			Name = "Boina Branca",
			Price = 0,
			Description = "Boina utilizada pelos Militares da BIP",
			Accessory = Accessories.BOINA_BRANCA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		BOINA_PRETA = {
			Name = "Boina Preta",
			Price = 0,
			Description = "Boina utilizada pelos Militares da BIP",
			Accessory = Accessories.BOINA_PRETA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		New_CabeloFV2 = {
			Name = "Cabelo Feminino V2",
			Price = 0,
			Description = "Utilizado por militares da BIP",
			Accessory = Accessories.New_CabeloFV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		New_CabeloLoiro = {
			Name = "Cabelo Loiro",
			Price = 0,
			Description = "Utilizado por militares da BIP",
			Accessory = Accessories.New_CabeloLoiro,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		New_CabeloMV2 = {
			Name = "Cabelo Masculino V2",
			Price = 0,
			Description = "Utilizado por militares da BIP",
			Accessory = Accessories.New_CabeloMV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		New_CabeloMV3 = {
			Name = "Cabelo Masculino V3",
			Price = 0,
			Description = "Utilizado por militares da BIP",
			Accessory = Accessories.New_CabeloMV3,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		CABELO_MASCULINO = {
			Name = "Cabelo Masculino",
			Price = 0,
			Description = "Utilizado por militares da BIP",
			Accessory = Accessories.CABELO_MASCULINO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		CABELO_FEMININO = {
			Name = "Cabelo Feminino",
			Price = 0,
			Description = "Utilizado por militares da BIP",
			Accessory = Accessories.CABELO_FEMININO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		New_ColeteV2 = {
			Name = "Colete V2",
			Price = 5000,
			Description = "Colete utilizado pelos Militares da BIP",
			Accessory = Accessories.New_ColeteV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		COLETE_TATICO = {
			Name = "Colete T\195\161tico",
			Price = 5000,
			Description = "Colete T\195\161tico utilizado pelos Militares da BIP",
			Accessory = Accessories.COLETE_TATICO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["Capacete T\195\161tico de Operador"] = {
			Name = "Capacete T\195\161tico de Operador",
			Price = 8000,
			Description = "Capacete utilizado pelos operadores da BIP",
			Accessory = Accessories["Capacete T\195\161tico de Operador"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["Capacete da BIP"] = {
			Name = "Capacete da BIP",
			Price = 6000,
			Description = "Capacete oficial da Brigada de Infantaria Paraquedista",
			Accessory = Accessories["Capacete da BIP"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["Fone de Operador"] = {
			Name = "Fone de Operador",
			Price = 4500,
			Description = "Fone utilizado pelos operadores da BIP",
			Accessory = Accessories["Fone de Operador"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["Gorro Mestre de Salto"] = {
			Name = "Gorro Mestre de Salto",
			Price = 0,
			Description = "Gorro exclusivo dos Mestres de Salto da BIP",
			Accessory = Accessories["Gorro Mestre de Salto"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["Gorro Precursor"] = {
			Name = "Gorro Precursor",
			Price = 0,
			Description = "Gorro utilizado pelos Precursores da BIP",
			Accessory = Accessories["Gorro Precursor"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["Gorro da BIP"] = {
			Name = "Gorro da BIP",
			Price = 0,
			Description = "Gorro oficial da Brigada de Infantaria Paraquedista",
			Accessory = Accessories["Gorro da BIP"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["Mochila de Paraquedismo"] = {
			Name = "Mochila de Paraquedismo",
			Price = 9000,
			Description = "Mochila utilizada pelos paraquedistas da BIP",
			Accessory = Accessories["Mochila de Paraquedismo"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["M\195\161scara de Piloto"] = {
			Name = "M\195\161scara de Piloto",
			Price = 7500,
			Description = "M\195\161scara utilizada pelos pilotos e operadores da BIP",
			Accessory = Accessories["M\195\161scara de Piloto"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["\195\147culos Quad"] = {
			Name = "\195\147culos Quad",
			Price = 6500,
			Description = "\195\147culos quad utilizado pelos operadores da BIP",
			Accessory = Accessories["\195\147culos Quad"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["\195\147culos Stealth"] = {
			Name = "\195\147culos Stealth",
			Price = 6500,
			Description = "\195\147culos stealth utilizado pelos operadores da BIP",
			Accessory = Accessories["\195\147culos Stealth"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["\195\147culos T\195\161tico"] = {
			Name = "\195\147culos T\195\161tico",
			Price = 5000,
			Description = "\195\147culos t\195\161tico utilizado pelos operadores da BIP",
			Accessory = Accessories["\195\147culos T\195\161tico"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		},
		["\195\147culos de Prote\195\167\195\163o"] = {
			Name = "\195\147culos de Prote\195\167\195\163o",
			Price = 5000,
			Description = "\195\147culos de prote\195\167\195\163o utilizado pelos operadores da BIP",
			Accessory = Accessories["\195\147culos de Prote\195\167\195\163o"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[BIP] Brigada de Infantaria Paraquedista")
			}
		}
	},
	[7] = {
		BOINA_VERDE = {
			Name = "Boina Verde",
			Price = 0,
			Description = "Boina utilizada pelos Militares do CAAT",
			Accessory = Accessories.BOINA_VERDE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		BOINA_BRANCA = {
			Name = "Boina Branca",
			Price = 0,
			Description = "Boina utilizada pelos Militares do CAAT",
			Accessory = Accessories.BOINA_BRANCA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		BOINA_PRETA = {
			Name = "Boina Preta",
			Price = 0,
			Description = "Boina utilizada pelos Militares do CAAT",
			Accessory = Accessories.BOINA_PRETA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		New_CabeloFV2 = {
			Name = "Cabelo Feminino V2",
			Price = 0,
			Description = "Utilizado por militares do CAAT",
			Accessory = Accessories.New_CabeloFV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		New_CabeloLoiro = {
			Name = "Cabelo Loiro",
			Price = 0,
			Description = "Utilizado por militares do CAAT",
			Accessory = Accessories.New_CabeloLoiro,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		New_CabeloMV2 = {
			Name = "Cabelo Masculino V2",
			Price = 0,
			Description = "Utilizado por militares do CAAT",
			Accessory = Accessories.New_CabeloMV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		New_CabeloMV3 = {
			Name = "Cabelo Masculino V3",
			Price = 0,
			Description = "Utilizado por militares do CAAT",
			Accessory = Accessories.New_CabeloMV3,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		CABELO_MASCULINO = {
			Name = "Cabelo Masculino",
			Price = 0,
			Description = "Utilizado por militares do CAAT",
			Accessory = Accessories.CABELO_MASCULINO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		CABELO_FEMININO = {
			Name = "Cabelo Feminino",
			Price = 0,
			Description = "Utilizado por militares do CAAT",
			Accessory = Accessories.CABELO_FEMININO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		New_ColeteV2 = {
			Name = "Colete V2",
			Price = 5000,
			Description = "Colete utilizado pelos Militares do CAAT",
			Accessory = Accessories.New_ColeteV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		COLETE_TATICO = {
			Name = "Colete T\195\161tico",
			Price = 5000,
			Description = "Colete T\195\161tico utilizado pelos Militares do CAAT",
			Accessory = Accessories.COLETE_TATICO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Balaclava Des\195\169rtica"] = {
			Name = "Balaclava Des\195\169rtica",
			Price = 5000,
			Description = "Balaclava utilizada pelos Militares do CAAT",
			Accessory = Accessories["Balaclava Des\195\169rtica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Cachecol Caat 1"] = {
			Name = "Cachecol Caat 1",
			Price = 4000,
			Description = "Cachecol utilizado pelos Militares do CAAT",
			Accessory = Accessories["Cachecol Caat 1"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Cachecol Caat 2"] = {
			Name = "Cachecol Caat 2",
			Price = 4000,
			Description = "Cachecol utilizado pelos Militares do CAAT",
			Accessory = Accessories["Cachecol Caat 2"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Cachecol Militar"] = {
			Name = "Cachecol Militar",
			Price = 4000,
			Description = "Cachecol Militar utilizado pelos Militares do CAAT",
			Accessory = Accessories["Cachecol Militar"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Chap\195\169u Camo"] = {
			Name = "Chap\195\169u Camo",
			Price = 4500,
			Description = "Chap\195\169u Camuflado utilizado pelos Militares do CAAT",
			Accessory = Accessories["Chap\195\169u Camo"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Cinto T\195\161tico"] = {
			Name = "Cinto T\195\161tico",
			Price = 4500,
			Description = "Cinto T\195\161tico utilizado pelos Militares do CAAT",
			Accessory = Accessories["Cinto T\195\161tico"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Cinto de Conduta"] = {
			Name = "Cinto de Conduta",
			Price = 4500,
			Description = "Cinto de Conduta utilizado pelos Militares do CAAT",
			Accessory = Accessories["Cinto de Conduta"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Hoodie Des\195\169rtico"] = {
			Name = "Hoodie Des\195\169rtico",
			Price = 6000,
			Description = "Hoodie Des\195\169rtico utilizado pelos Militares do CAAT",
			Accessory = Accessories["Hoodie Des\195\169rtico"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Mascara T\195\161tica Des\195\169rtica"] = {
			Name = "M\195\161scara T\195\161tica Des\195\169rtica",
			Price = 5500,
			Description = "M\195\161scara T\195\161tica Des\195\169rtica utilizada pelos Militares do CAAT",
			Accessory = Accessories["Mascara T\195\161tica Des\195\169rtica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Mochila Desert T\195\161tica"] = {
			Name = "Mochila Desert T\195\161tica",
			Price = 7000,
			Description = "Mochila Desert T\195\161tica utilizada pelos Militares do CAAT",
			Accessory = Accessories["Mochila Desert T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Mochila T\195\161tica Camo"] = {
			Name = "Mochila T\195\161tica Camo",
			Price = 7000,
			Description = "Mochila T\195\161tica Camo utilizada pelos Militares do CAAT",
			Accessory = Accessories["Mochila T\195\161tica Camo"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Ombreira Direita"] = {
			Name = "Ombreira Direita",
			Price = 4000,
			Description = "Ombreira Direita utilizada pelos Militares do CAAT",
			Accessory = Accessories["Ombreira Direita"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Ombreira Direita T\195\161tica"] = {
			Name = "Ombreira Direita T\195\161tica",
			Price = 5000,
			Description = "Ombreira Direita T\195\161tica utilizada pelos Militares do CAAT",
			Accessory = Accessories["Ombreira Direita T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Ombreira Esquerda"] = {
			Name = "Ombreira Esquerda",
			Price = 4000,
			Description = "Ombreira Esquerda utilizada pelos Militares do CAAT",
			Accessory = Accessories["Ombreira Esquerda"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["Ombreira Esquerda T\195\161tica"] = {
			Name = "Ombreira Esquerda T\195\161tica",
			Price = 5000,
			Description = "Ombreira Esquerda T\195\161tica utilizada pelos Militares do CAAT",
			Accessory = Accessories["Ombreira Esquerda T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		},
		["\195\147culos Quad Des\195\169rtico"] = {
			Name = "\195\147culos Quad Des\195\169rtico",
			Price = 6000,
			Description = "\195\147culos Quad Des\195\169rtico utilizado pelos Militares do CAAT",
			Accessory = Accessories["\195\147culos Quad Des\195\169rtico"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CAAT] Batalh\195\163o de Infantaria de Caatinga")
			}
		}
	},
	[8] = {
		BOINA_VERDE = {
			Name = "Boina Verde",
			Price = 0,
			Description = "Boina utilizada pelos Militares do CIGS",
			Accessory = Accessories.BOINA_VERDE,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		BOINA_BRANCA = {
			Name = "Boina Branca",
			Price = 0,
			Description = "Boina utilizada pelos Militares do CIGS",
			Accessory = Accessories.BOINA_BRANCA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		BOINA_PRETA = {
			Name = "Boina Preta",
			Price = 0,
			Description = "Boina utilizada pelos Militares do CIGS",
			Accessory = Accessories.BOINA_PRETA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		New_CabeloFV2 = {
			Name = "Cabelo Feminino V2",
			Price = 0,
			Description = "Utilizado por militares do CIGS",
			Accessory = Accessories.New_CabeloFV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		New_CabeloLoiro = {
			Name = "Cabelo Loiro",
			Price = 0,
			Description = "Utilizado por militares do CIGS",
			Accessory = Accessories.New_CabeloLoiro,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		New_CabeloMV2 = {
			Name = "Cabelo Masculino V2",
			Price = 0,
			Description = "Utilizado por militares do CIGS",
			Accessory = Accessories.New_CabeloMV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		New_CabeloMV3 = {
			Name = "Cabelo Masculino V3",
			Price = 0,
			Description = "Utilizado por militares do CIGS",
			Accessory = Accessories.New_CabeloMV3,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		CABELO_MASCULINO = {
			Name = "Cabelo Masculino",
			Price = 0,
			Description = "Utilizado por militares do CIGS",
			Accessory = Accessories.CABELO_MASCULINO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		CABELO_FEMININO = {
			Name = "Cabelo Feminino",
			Price = 0,
			Description = "Utilizado por militares do CIGS",
			Accessory = Accessories.CABELO_FEMININO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		New_ColeteV2 = {
			Name = "Colete V2",
			Price = 5000,
			Description = "Colete utilizado pelos Militares do CIGS",
			Accessory = Accessories.New_ColeteV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		COLETE_TATICO = {
			Name = "Colete T\195\161tico",
			Price = 5000,
			Description = "Colete T\195\161tico utilizado pelos Militares do CIGS",
			Accessory = Accessories.COLETE_TATICO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Bandana Preta"] = {
			Name = "Bandana Preta",
			Price = 4000,
			Description = "Bandana utilizada pelos Militares do CIGS",
			Accessory = Accessories["Bandana Preta"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["CIGS - Chap\195\169u"] = {
			Name = "Chap\195\169u CIGS",
			Price = 4500,
			Description = "Chap\195\169u oficial do CIGS",
			Accessory = Accessories["CIGS - Chap\195\169u"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["CIGS - Gorro Preto"] = {
			Name = "Gorro Preto CIGS",
			Price = 4500,
			Description = "Gorro Preto oficial do CIGS",
			Accessory = Accessories["CIGS - Gorro Preto"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Capacete Verde Oliva"] = {
			Name = "Capacete Verde Oliva",
			Price = 7000,
			Description = "Capacete Verde Oliva utilizado pelos Militares do CIGS",
			Accessory = Accessories["Capacete Verde Oliva"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Capuz Camuflado"] = {
			Name = "Capuz Camuflado",
			Price = 5000,
			Description = "Capuz Camuflado utilizado pelos Militares do CIGS",
			Accessory = Accessories["Capuz Camuflado"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Chap\195\169u Camuflado"] = {
			Name = "Chap\195\169u Camuflado",
			Price = 4500,
			Description = "Chap\195\169u Camuflado utilizado pelos Militares do CIGS",
			Accessory = Accessories["Chap\195\169u Camuflado"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Chap\195\169u Verde Oliva"] = {
			Name = "Chap\195\169u Verde Oliva",
			Price = 4500,
			Description = "Chap\195\169u Verde Oliva utilizado pelos Militares do CIGS",
			Accessory = Accessories["Chap\195\169u Verde Oliva"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Cinto Camuflado"] = {
			Name = "Cinto Camuflado",
			Price = 4500,
			Description = "Cinto Camuflado utilizado pelos Militares do CIGS",
			Accessory = Accessories["Cinto Camuflado"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Dispositivo de Vis\195\163o Noturna"] = {
			Name = "Dispositivo de Vis\195\163o Noturna",
			Price = 9000,
			Description = "Dispositivo de Vis\195\163o Noturna utilizado pelos Militares do CIGS",
			Accessory = Accessories["Dispositivo de Vis\195\163o Noturna"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Faca de Ombro"] = {
			Name = "Faca de Ombro",
			Price = 6000,
			Description = "Faca de Ombro utilizada pelos Militares do CIGS",
			Accessory = Accessories["Faca de Ombro"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Manto Camuflado"] = {
			Name = "Manto Camuflado",
			Price = 7500,
			Description = "Manto Camuflado utilizado pelos Militares do CIGS",
			Accessory = Accessories["Manto Camuflado"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Mochila de Guerra"] = {
			Name = "Mochila de Guerra",
			Price = 7000,
			Description = "Mochila de Guerra utilizada pelos Militares do CIGS",
			Accessory = Accessories["Mochila de Guerra"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["M\195\161scara Verde"] = {
			Name = "M\195\161scara Verde",
			Price = 5500,
			Description = "M\195\161scara Verde utilizada pelos Militares do CIGS",
			Accessory = Accessories["M\195\161scara Verde"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Ombro Direito Camuflado"] = {
			Name = "Ombro Direito Camuflado",
			Price = 4500,
			Description = "Ombreira Direita Camuflada utilizada pelos Militares do CIGS",
			Accessory = Accessories["Ombro Direito Camuflado"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Ombro Esquerdo Camuflado"] = {
			Name = "Ombro Esquerdo Camuflado",
			Price = 4500,
			Description = "Ombreira Esquerda Camuflada utilizada pelos Militares do CIGS",
			Accessory = Accessories["Ombro Esquerdo Camuflado"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["Poncho Camuflado"] = {
			Name = "Poncho Camuflado",
			Price = 6500,
			Description = "Poncho Camuflado utilizado pelos Militares do CIGS",
			Accessory = Accessories["Poncho Camuflado"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["\195\147culos Profissional"] = {
			Name = "\195\147culos Profissional",
			Price = 5500,
			Description = "\195\147culos Profissional utilizado pelos Militares do CIGS",
			Accessory = Accessories["\195\147culos Profissional"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		},
		["\195\147culos de Prote\195\167\195\163o"] = {
			Name = "\195\147culos de Prote\195\167\195\163o",
			Price = 5000,
			Description = "\195\147culos de Prote\195\167\195\163o utilizado pelos Militares do CIGS",
			Accessory = Accessories["\195\147culos de Prote\195\167\195\163o"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva")
			}
		}
	},
	[9] = {
		BOINA_VERMELHA = {
			Name = "Boina Vermelha",
			Price = 0,
			Description = "Boina utilizada pelos Militares do REC MEC",
			Accessory = Accessories.BOINA_VERMELHA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		BOINA_PRETA = {
			Name = "Boina Preta",
			Price = 0,
			Description = "Boina utilizada pelos Militares do REC MEC",
			Accessory = Accessories.BOINA_PRETA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		New_CabeloFV2 = {
			Name = "Cabelo Feminino V2",
			Price = 0,
			Description = "Utilizado por militares do REC MEC",
			Accessory = Accessories.New_CabeloFV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		New_CabeloLoiro = {
			Name = "Cabelo Loiro",
			Price = 0,
			Description = "Utilizado por militares do REC MEC",
			Accessory = Accessories.New_CabeloLoiro,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		New_CabeloMV2 = {
			Name = "Cabelo Masculino V2",
			Price = 0,
			Description = "Utilizado por militares do REC MEC",
			Accessory = Accessories.New_CabeloMV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		New_CabeloMV3 = {
			Name = "Cabelo Masculino V3",
			Price = 0,
			Description = "Utilizado por militares do REC MEC",
			Accessory = Accessories.New_CabeloMV3,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		CABELO_MASCULINO = {
			Name = "Cabelo Masculino",
			Price = 0,
			Description = "Utilizado por militares do REC MEC",
			Accessory = Accessories.CABELO_MASCULINO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		CABELO_FEMININO = {
			Name = "Cabelo Feminino",
			Price = 0,
			Description = "Utilizado por militares do REC MEC",
			Accessory = Accessories.CABELO_FEMININO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		New_ColeteV2 = {
			Name = "Colete V2",
			Price = 5000,
			Description = "Colete utilizado pelos Militares do REC MEC",
			Accessory = Accessories.New_ColeteV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		COLETE_TATICO = {
			Name = "Colete T\195\161tico",
			Price = 5000,
			Description = "Colete T\195\161tico utilizado pelos Militares do REC MEC",
			Accessory = Accessories.COLETE_TATICO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Balaclava T\195\161tica"] = {
			Name = "Balaclava T\195\161tica",
			Price = 5000,
			Description = "Balaclava T\195\161tica utilizada pelos Militares do REC MEC",
			Accessory = Accessories["Balaclava T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Balaclava de Caveira"] = {
			Name = "Balaclava de Caveira",
			Price = 5500,
			Description = "Balaclava de Caveira utilizada pelos Militares do REC MEC",
			Accessory = Accessories["Balaclava de Caveira"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Bon\195\169 T\195\161tico com Fone"] = {
			Name = "Bon\195\169 T\195\161tico com Fone",
			Price = 5000,
			Description = "Bon\195\169 T\195\161tico com Fone utilizado pelos Militares do REC MEC",
			Accessory = Accessories["Bon\195\169 T\195\161tico com Fone"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Capa Preta"] = {
			Name = "Capa Preta",
			Price = 6000,
			Description = "Capa Preta utilizada pelos Militares do REC MEC",
			Accessory = Accessories["Capa Preta"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		Cinto = {
			Name = "Cinto",
			Price = 4000,
			Description = "Cinto utilizado pelos Militares do REC MEC",
			Accessory = Accessories.Cinto,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Cinto T\195\161tico"] = {
			Name = "Cinto T\195\161tico",
			Price = 4500,
			Description = "Cinto T\195\161tico utilizado pelos Militares do REC MEC",
			Accessory = Accessories["Cinto T\195\161tico"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Cinto de Conduta"] = {
			Name = "Cinto de Conduta",
			Price = 4500,
			Description = "Cinto de Conduta utilizado pelos Militares do REC MEC",
			Accessory = Accessories["Cinto de Conduta"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Fone T\195\161tico de Opera\195\167\195\181es"] = {
			Name = "Fone T\195\161tico de Opera\195\167\195\181es",
			Price = 5000,
			Description = "Fone T\195\161tico de Opera\195\167\195\181es utilizado pelos Militares do REC MEC",
			Accessory = Accessories["Fone T\195\161tico de Opera\195\167\195\181es"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		Microfone = {
			Name = "Microfone",
			Price = 4500,
			Description = "Microfone utilizado pelos Militares do REC MEC",
			Accessory = Accessories.Microfone,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Mochila T\195\161tica"] = {
			Name = "Mochila T\195\161tica",
			Price = 7000,
			Description = "Mochila T\195\161tica utilizada pelos Militares do REC MEC",
			Accessory = Accessories["Mochila T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["M\195\161scara T\195\161tica"] = {
			Name = "M\195\161scara T\195\161tica",
			Price = 5500,
			Description = "M\195\161scara T\195\161tica utilizada pelos Militares do REC MEC",
			Accessory = Accessories["M\195\161scara T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["M\195\161scara de G\195\161s"] = {
			Name = "M\195\161scara de G\195\161s",
			Price = 6000,
			Description = "M\195\161scara de G\195\161s utilizada pelos Militares do REC MEC",
			Accessory = Accessories["M\195\161scara de G\195\161s"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["M\195\161scara de G\195\161s 2"] = {
			Name = "M\195\161scara de G\195\161s 2",
			Price = 6000,
			Description = "M\195\161scara de G\195\161s 2 utilizada pelos Militares do REC MEC",
			Accessory = Accessories["M\195\161scara de G\195\161s 2"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["M\195\161scara de Sniper"] = {
			Name = "M\195\161scara de Sniper",
			Price = 6500,
			Description = "M\195\161scara de Sniper utilizada pelos Militares do REC MEC",
			Accessory = Accessories["M\195\161scara de Sniper"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Ombreira Direita"] = {
			Name = "Ombreira Direita",
			Price = 4000,
			Description = "Ombreira Direita utilizada pelos Militares do REC MEC",
			Accessory = Accessories["Ombreira Direita"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["Ombreira Esquerda"] = {
			Name = "Ombreira Esquerda",
			Price = 4000,
			Description = "Ombreira Esquerda utilizada pelos Militares do REC MEC",
			Accessory = Accessories["Ombreira Esquerda"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		Pochete = {
			Name = "Pochete",
			Price = 4500,
			Description = "Pochete utilizada pelos Militares do REC MEC",
			Accessory = Accessories.Pochete,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["\195\147culos Noturno"] = {
			Name = "\195\147culos Noturno",
			Price = 7000,
			Description = "\195\147culos Noturno utilizado pelos Militares do REC MEC",
			Accessory = Accessories["\195\147culos Noturno"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["\195\147culos Prata"] = {
			Name = "\195\147culos Prata",
			Price = 5500,
			Description = "\195\147culos Prata utilizado pelos Militares do REC MEC",
			Accessory = Accessories["\195\147culos Prata"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		},
		["\195\147culos T\195\161tico"] = {
			Name = "\195\147culos T\195\161tico",
			Price = 5000,
			Description = "\195\147culos T\195\161tico utilizado pelos Militares do REC MEC",
			Accessory = Accessories["\195\147culos T\195\161tico"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[REC MEC] Regimento de Cavalaria Mecanizado")
			}
		}
	},
	[11] = {
		BOINA_AZUL = {
			Name = "Boina Azul",
			Price = 0,
			Description = "Boina utilizada pelos Militares da Cyber",
			Accessory = Accessories.BOINA_AZUL,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		BOINA_PRETA = {
			Name = "Boina Preta",
			Price = 0,
			Description = "Boina utilizada pelos Militares da Cyber",
			Accessory = Accessories.BOINA_PRETA,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		New_CabeloFV2 = {
			Name = "Cabelo Feminino V2",
			Price = 0,
			Description = "Utilizado por militares da Cyber",
			Accessory = Accessories.New_CabeloFV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		New_CabeloLoiro = {
			Name = "Cabelo Loiro",
			Price = 0,
			Description = "Utilizado por militares da Cyber",
			Accessory = Accessories.New_CabeloLoiro,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		New_CabeloMV2 = {
			Name = "Cabelo Masculino V2",
			Price = 0,
			Description = "Utilizado por militares da Cyber",
			Accessory = Accessories.New_CabeloMV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		New_CabeloMV3 = {
			Name = "Cabelo Masculino V3",
			Price = 0,
			Description = "Utilizado por militares da Cyber",
			Accessory = Accessories.New_CabeloMV3,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		CABELO_MASCULINO = {
			Name = "Cabelo Masculino",
			Price = 0,
			Description = "Utilizado por militares da Cyber",
			Accessory = Accessories.CABELO_MASCULINO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		CABELO_FEMININO = {
			Name = "Cabelo Feminino",
			Price = 0,
			Description = "Utilizado por militares da Cyber",
			Accessory = Accessories.CABELO_FEMININO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		New_ColeteV2 = {
			Name = "Colete V2",
			Price = 5000,
			Description = "Colete utilizado pelos Militares da Cyber",
			Accessory = Accessories.New_ColeteV2,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		COLETE_TATICO = {
			Name = "Colete T\195\161tico",
			Price = 5000,
			Description = "Colete T\195\161tico utilizado pelos Militares da Cyber",
			Accessory = Accessories.COLETE_TATICO,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Balaclava T\195\161tica"] = {
			Name = "Balaclava T\195\161tica",
			Price = 5000,
			Description = "Balaclava T\195\161tica utilizada pelos Militares da Cyber",
			Accessory = Accessories["Balaclava T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Balaclava de Caveira"] = {
			Name = "Balaclava de Caveira",
			Price = 5500,
			Description = "Balaclava de Caveira utilizada pelos Militares da Cyber",
			Accessory = Accessories["Balaclava de Caveira"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Bon\195\169 T\195\161tico com Fone"] = {
			Name = "Bon\195\169 T\195\161tico com Fone",
			Price = 5000,
			Description = "Bon\195\169 T\195\161tico com Fone utilizado pelos Militares da Cyber",
			Accessory = Accessories["Bon\195\169 T\195\161tico com Fone"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Capa Preta"] = {
			Name = "Capa Preta",
			Price = 6000,
			Description = "Capa Preta utilizada pelos Militares da Cyber",
			Accessory = Accessories["Capa Preta"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		Cinto = {
			Name = "Cinto",
			Price = 4000,
			Description = "Cinto utilizado pelos Militares da Cyber",
			Accessory = Accessories.Cinto,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Cinto T\195\161tico"] = {
			Name = "Cinto T\195\161tico",
			Price = 4500,
			Description = "Cinto T\195\161tico utilizado pelos Militares da Cyber",
			Accessory = Accessories["Cinto T\195\161tico"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Cinto de Conduta"] = {
			Name = "Cinto de Conduta",
			Price = 4500,
			Description = "Cinto de Conduta utilizado pelos Militares da Cyber",
			Accessory = Accessories["Cinto de Conduta"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Fone T\195\161tico de Opera\195\167\195\181es"] = {
			Name = "Fone T\195\161tico de Opera\195\167\195\181es",
			Price = 5000,
			Description = "Fone T\195\161tico de Opera\195\167\195\181es utilizado pelos Militares da Cyber",
			Accessory = Accessories["Fone T\195\161tico de Opera\195\167\195\181es"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		Microfone = {
			Name = "Microfone",
			Price = 4500,
			Description = "Microfone utilizado pelos Militares da Cyber",
			Accessory = Accessories.Microfone,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Mochila T\195\161tica"] = {
			Name = "Mochila T\195\161tica",
			Price = 7000,
			Description = "Mochila T\195\161tica utilizada pelos Militares da Cyber",
			Accessory = Accessories["Mochila T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["M\195\161scara T\195\161tica"] = {
			Name = "M\195\161scara T\195\161tica",
			Price = 5500,
			Description = "M\195\161scara T\195\161tica utilizada pelos Militares da Cyber",
			Accessory = Accessories["M\195\161scara T\195\161tica"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["M\195\161scara de G\195\161s"] = {
			Name = "M\195\161scara de G\195\161s",
			Price = 6000,
			Description = "M\195\161scara de G\195\161s utilizada pelos Militares da Cyber",
			Accessory = Accessories["M\195\161scara de G\195\161s"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["M\195\161scara de G\195\161s 2"] = {
			Name = "M\195\161scara de G\195\161s 2",
			Price = 6000,
			Description = "M\195\161scara de G\195\161s 2 utilizada pelos Militares da Cyber",
			Accessory = Accessories["M\195\161scara de G\195\161s 2"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["M\195\161scara de Sniper"] = {
			Name = "M\195\161scara de Sniper",
			Price = 6500,
			Description = "M\195\161scara de Sniper utilizada pelos Militares da Cyber",
			Accessory = Accessories["M\195\161scara de Sniper"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Ombreira Direita"] = {
			Name = "Ombreira Direita",
			Price = 4000,
			Description = "Ombreira Direita utilizada pelos Militares da Cyber",
			Accessory = Accessories["Ombreira Direita"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["Ombreira Esquerda"] = {
			Name = "Ombreira Esquerda",
			Price = 4000,
			Description = "Ombreira Esquerda utilizada pelos Militares da Cyber",
			Accessory = Accessories["Ombreira Esquerda"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		Pochete = {
			Name = "Pochete",
			Price = 4500,
			Description = "Pochete utilizada pelos Militares da Cyber",
			Accessory = Accessories.Pochete,
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["\195\147culos Noturno"] = {
			Name = "\195\147culos Noturno",
			Price = 7000,
			Description = "\195\147culos Noturno utilizado pelos Militares da Cyber",
			Accessory = Accessories["\195\147culos Noturno"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["\195\147culos Prata"] = {
			Name = "\195\147culos Prata",
			Price = 5500,
			Description = "\195\147culos Prata utilizado pelos Militares da Cyber",
			Accessory = Accessories["\195\147culos Prata"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		},
		["\195\147culos T\195\161tico"] = {
			Name = "\195\147culos T\195\161tico",
			Price = 5000,
			Description = "\195\147culos T\195\161tico utilizado pelos Militares da Cyber",
			Accessory = Accessories["\195\147culos T\195\161tico"],
			Restriction = {
				Type = 3,
				Team = game.Teams:WaitForChild("[CYBER] Comando de Defesa Cibern\195\169tica")
			}
		}
	}
}