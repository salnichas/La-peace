-- https://lua.expert/
return {
	{ "Low", 1, 1 },
	{ "Medium", 2, 0.5 },
	{ "High", 3, 0.1 },
	{ "Precise", 4, 0 }
}