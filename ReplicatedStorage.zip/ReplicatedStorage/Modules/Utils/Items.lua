-- https://lua.expert/
return {
	["AK-47"] = {
		Description = "Rifle de assalto mais utilizado no mundo. Robusto, confi\195\161vel e altamente letal.",
		Price = 13500
	},
	BERETTA = {
		Description = "Pistola semiautom\195\161tica italiana, conhecida pela precis\195\163o e confiabilidade.",
		Price = 4000
	},
	DEAGLE = {
		Description = "Pistola poderosa de alto calibre, famosa por seu impacto e precis\195\163o.",
		Price = 10000
	},
	FAMAS = {
		Description = "Rifle de assalto franc\195\170s, com disparo r\195\161pido e ideal para combates de curta e m\195\169dia dist\195\162ncia.",
		Price = 9000
	},
	G36C = {
		Description = "Carabina alem\195\163 compacta com alta cad\195\170ncia de tiro e \195\179timo controle.",
		Price = 15000
	},
	HK416 = {
		Description = "Rifle de assalto moderno e confi\195\161vel, com alto desempenho em combates t\195\161ticos.",
		Price = 17500
	},
	M16 = {
		Description = "Rifle militar americano de alta precis\195\163o, ideal para m\195\169dio e longo alcance.",
		Price = 11000
	},
	M4A1 = {
		Description = "Rifle autom\195\161tico leve e vers\195\161til, muito utilizado por for\195\167as armadas modernas.",
		Price = 12500
	},
	MP40 = {
		Description = "Submetralhadora alem\195\163 usada na Segunda Guerra Mundial, eficaz em combate pr\195\179ximo.",
		Price = 10000
	},
	MP5 = {
		Description = "Submetralhadora alem\195\163 cl\195\161ssica, amplamente utilizada por for\195\167as especiais.",
		Price = 8000
	},
	P90 = {
		Description = "Submetralhadora belga compacta com alta cad\195\170ncia e boa capacidade de penetra\195\167\195\163o.",
		Price = 7000
	},
	SKS = {
		Description = "Rifle semiautom\195\161tico sovi\195\169tico, confi\195\161vel e f\195\161cil de manusear, ideal para m\195\169dia dist\195\162ncia.",
		Price = 20000
	},
	Revolver = {
		Description = "Arma de fogo de a\195\167\195\163o simples e confi\195\161vel, potente e precisa, ideal para combates de curta e m\195\169dia dist\195\162ncia.",
		Price = 2500
	},
	["Sawed-Off"] = {
		Description = "Espingarda de cano serrado, compacta e devastadora, ideal para combates de curta dist\195\162ncia.",
		Price = 5000
	},
	["Remington 870"] = {
		Description = "Espingarda de a\195\167\195\163o por bombeamento americana, robusta e confi\195\161vel, ideal para combates de curta dist\195\162ncia.",
		Price = 10000
	},
	["Saiga-12"] = {
		Description = "Espingarda semiautom\195\161tica russa, potente e de alta cad\195\170ncia, ideal para combates de curta e m\195\169dia dist\195\162ncia.",
		Price = 17500
	},
	C4 = {
		Description = "Explosivo potente usado somente para assaltos.",
		Price = 3000
	}
}