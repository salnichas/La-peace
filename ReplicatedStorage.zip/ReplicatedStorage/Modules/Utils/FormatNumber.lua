-- https://lua.expert/
return {
	Format = function(p1, p2) --[[ Format | Line: 3 ]]
		local v1, v2 = string.format("%.2f", p2):match("^(%d+)%.(%d%d)$")
		local v3 = v1:reverse():gsub("(%d%d%d)", "%1."):reverse()

		return ("R$ %s,%s"):format(if v3:sub(1, 1) == "." then v3:sub(2) else v3, v2)
	end
}