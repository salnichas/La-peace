-- https://lua.expert/
return {
	groupingSymbol = ",",
	decimalSymbol = ".",
	infinitySymbol = "\226\136\158",
	quietNaNSymbol = "NaNQ",
	signalingNaNSymbol = "NaNS",
	showNaNPayload = true,
	subnormalsAsZero = false,
	durationSeparatorSymbol = ":",
	useARM64FCVTZS = false,
	compactSuffix = { "K", "M", "B", "T" }
}