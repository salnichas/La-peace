-- https://lua.expert/
local uint64_t = require(script.Parent.uint64_t)
local diy_fp = require(script.Parent.diy_fp)

return {
	normalized_boundaries = function(p1, p2, p3) --[[ normalized_boundaries | Line: 6 | Upvalues: uint64_t (copy), diy_fp (copy) ]]
		local v1, v2 = uint64_t.add(1, 0, uint64_t.sal(p1, p2, 1))
		local v3, v4, v5 = diy_fp.normalize(v1, v2, p3 - 1)
		local v6, v7, v8

		if p1 == 0 and p2 == 0 then
			local v9, v10 = uint64_t.sal(p1, p2, 2)
			local v11, v12 = uint64_t.sub(v9, v10, 1)

			v6 = v11
			v7 = v12
			v8 = p3 - 2
		else
			local v13, v14 = uint64_t.sal(p1, p2, 1)
			local v15, v16 = uint64_t.sub(v13, v14, 1)

			v6 = v15
			v7 = v16
			v8 = p3 - 1
		end

		local v17, v18 = uint64_t.sal(v6, v7, v8 - v5)

		return v17, v18, v5, v3, v4, v5
	end
}