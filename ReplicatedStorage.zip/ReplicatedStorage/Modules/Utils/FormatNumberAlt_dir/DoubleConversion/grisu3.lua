-- https://lua.expert/
local uint64_t = require(script.Parent.uint64_t)
local diy_fp = require(script.Parent.diy_fp)
local cached_power = require(script.Parent.cached_power)
local ieee = require(script.Parent.ieee)

local function round_weed(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12) --[[ round_weed | Line: 8 | Upvalues: uint64_t (copy) ]]
	local v1, v2 = uint64_t.sub(p3, p4, p11, p12)
	local v3, v4 = uint64_t.add(p3, p4, p11, p12)

	while uint64_t.compare(p7, p8, v1, v2) < 0 and uint64_t.compare(p9, p10, uint64_t.sub(p5, p6, p7, p8)) <= 0 do
		local v5, v6 = uint64_t.add(p7, p8, p9, p10)
		local v7, v8 = uint64_t.sub(v5, v6, v1, v2)

		if uint64_t.compare(v1, v2, uint64_t.add(p7, p8, p9, p10)) <= 0 and uint64_t.compare(v7, v8, uint64_t.sub(v1, v2, p7, p8)) > 0 then
			break
		end

		p1[p2] = p1[p2] - 1

		local v9, v10 = uint64_t.add(p7, p8, p9, p10)

		p7, p8 = v9, v10
	end

	if uint64_t.compare(p7, p8, v3, v4) < 0 and uint64_t.compare(p9, p10, uint64_t.sub(p5, p6, p7, p8)) <= 0 then
		local v11, v12 = uint64_t.add(p7, p8, p9, p10)
		local v13, v14 = uint64_t.sub(v11, v12, v3, v4)
		local _, _2 = uint64_t.sub(v3, v4, p7, p8)

		if uint64_t.compare(v3, v4, uint64_t.add(p7, p8, p9, p10)) > 0 or uint64_t.compare(v13, v14, uint64_t.sub(v3, v4, p7, p8)) < 0 then
			return false
		end
	end

	return if uint64_t.compare(p7, p8, uint64_t.sal(p11, p12, 1)) >= 0 then uint64_t.compare(p7, p8, uint64_t.sub(p5, p6, uint64_t.sal(p11, p12, 2))) <= 0 else false
end

local t = {
	[0] = 0,
	1,
	10,
	100,
	1000,
	10000,
	100000,
	1000000,
	10000000,
	100000000,
	1000000000
}

local function biggest_power_10(p1, p2) --[[ biggest_power_10 | Line: 85 | Upvalues: t (copy) ]]
	local count = bit32.rshift((p2 + 1) * 1233, 12) + 1

	if p1 < t[count] then
		count = count - 1
	end

	return t[count], count
end

local function digit_gen(p1, p2, p3, p4, p5, p6, p7, p8, p9) --[[ digit_gen | Line: 96 | Upvalues: uint64_t (copy), t (copy), round_weed (copy) ]]
	local v1 = 1
	local v2 = 0
	local v3, v4 = uint64_t.sub(p1, p2, v1)
	local v5, v6 = uint64_t.add(p7, p8, v1)
	local v7, v8 = uint64_t.sub(v5, v6, v3, v4)
	local v9, v10 = uint64_t.sal(1, 0, -p6)
	local v11, v12 = uint64_t.sub(v9, v10, 1)
	local v13 = bit32.band(v5, v11)
	local v14 = bit32.band(v6, v12)
	local v15 = uint64_t.sal(v5, v6, p6)
	local count = bit32.rshift((p6 + 64 + 1) * 1233, 12) + 1

	if v15 < t[count] then
		count = count - 1
	end

	local v16 = t[count]
	local v17 = table.create(17)
	local v18, count2, count3 = v13, count, 0

	while count2 > 0 do
		count3 = count3 + 1
		v17[count3] = math.floor(v15 / v16)
		v15 = v15 % v16
		count2 = count2 - 1

		local v19, v20 = uint64_t.add(v18, v14, uint64_t.sal(v15, 0, -p6))

		if uint64_t.compare(v19, v20, v7, v8) < 0 then
			local v21, v22 = uint64_t.sub(v5, v6, p4, p5)
			local v23, v24 = uint64_t.sal(v16, 0, -p6)

			return round_weed(v17, count3, v21, v22, v7, v8, v19, v20, v23, v24, v1, v2), v17, count3, count2
		end

		v16 = v16 / 10
	end

	local v25, v26, v27, v28, v29, v30

	while true do
		local v31, v32 = uint64_t.mul(v18, v14, 10, 0)

		v25, v26 = uint64_t.mul(v1, v2, 10, 0)
		v27, v28 = uint64_t.mul(v7, v8, 10, 0)
		count3 = count3 + 1
		v17[count3] = uint64_t.sal(v31, v32, p6)
		v29 = bit32.band(v31, v11)
		v30 = bit32.band(v32, v12)
		count2 = count2 - 1

		if uint64_t.compare(v29, v30, v27, v28) < 0 then
			break
		end

		v7, v8, v1, v2, v18, v14 = v27, v28, v25, v26, v29, v30
	end

	local v33, v34 = uint64_t.mul(v25, v26, uint64_t.sub(v5, v6, p4, p5))

	return round_weed(v17, count3, v33, v34, v27, v28, v29, v30, v9, v10, v25, v26), v17, count3, count2
end

return function(p1) --[[ Line: 182 | Upvalues: diy_fp (copy), ieee (copy), cached_power (copy), digit_gen (copy) ]]
	local v1, v2, v3 = diy_fp.create_normalized(p1)
	local v4, v5, v6, v7, v8, v9 = ieee.normalized_boundaries(diy_fp.create(p1))
	local v10, v11, v12, v13 = cached_power.bin_expt_range(-60 - (v3 + 64))
	local v14, v15 = diy_fp.mul128(v1, v2, v10, v11)
	local v16, v17 = diy_fp.mul128(v4, v5, v10, v11)
	local v18, v19 = diy_fp.mul128(v7, v8, v10, v11)
	local v20, v21, v22, v23 = digit_gen(v16, v17, v6 + v12 + 64, v14, v15, v3 + v12 + 64, v18, v19, v9 + v12 + 64)

	if v20 then
		return v21, v22, -v13 + v23
	end

	return nil
end