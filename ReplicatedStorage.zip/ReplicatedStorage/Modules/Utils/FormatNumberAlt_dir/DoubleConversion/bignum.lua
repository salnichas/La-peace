-- https://lua.expert/
local uint64_t = require(script.Parent.uint64_t)
local t = {}
local t2 = {
	5,
	25,
	125,
	625,
	3125,
	15625,
	78125,
	390625,
	1953125,
	9765625,
	48828125,
	244140625
}

function t.sal(p1, p2) --[[ sal | Line: 10 ]]
	local v1 = p2 % 28

	p1.expt = p1.expt + (p2 - v1) / 28

	local v2 = 0

	for i, v in ipairs(p1) do
		local v4 = bit32.band(v2 + bit32.lshift(v, v1), 268435455)
		local v5 = bit32.rshift(v, 28 - v1)

		p1[i] = v4
		v2 = v5
	end

	if v2 == 0 then
		return
	end

	table.insert(p1, v2)
end
function t.clamp(p1) --[[ clamp | Line: 25 ]]
	while p1[#p1] == 0 do
		table.remove(p1)
	end
end
function t.align(p1, p2) --[[ align | Line: 31 ]]
	local v1 = p1.expt - p2.expt

	for i = 1, v1 do
		table.insert(p1, 1, 0)
	end

	p1.expt = p1.expt - math.max(v1, 0)
end
function t.assign_uint64_t(p1, p2, p3) --[[ assign_uint64_t | Line: 39 | Upvalues: t (copy) ]]
	local v1 = bit32.band(p2, 268435455)
	local v2 = bit32.rshift(p2, 28)
	local v4 = v2 + bit32.lshift(bit32.band(p3, 16777215), 4)
	local v5 = bit32.rshift(p3, 24)

	p1[1] = v1
	p1[2] = v4
	p1[3] = v5
	t.clamp(p1)
end
function t.square(p1) --[[ square | Line: 47 | Upvalues: uint64_t (copy), t (copy) ]]
	local v1 = #p1
	local v2 = 0
	local v3 = 0

	for i = 1, v1 do
		p1[v1 + i] = p1[i]
	end

	for j = 1, v1 do
		local count, v4 = j, 1

		while count > 0 do
			local v5, v6 = uint64_t.add(v2, v3, uint64_t.mul32(p1[v1 + count], p1[v1 + v4]))

			count, v2, v3, v4 = count - 1, v5, v6, v4 + 1
		end

		p1[j] = bit32.band(v2, 268435455)

		local v7, v8 = uint64_t.sal(v2, v3, -28)

		v2, v3 = v7, v8
	end

	for k = v1 + 1, v1 * 2 do
		local count, v9 = k - v1 + 1, v1

		while count <= v1 do
			local v10, v11 = uint64_t.add(v2, v3, uint64_t.mul32(p1[v1 + v9], p1[v1 + count]))

			count, v2, v3, v9 = count + 1, v10, v11, v9 - 1
		end

		p1[k] = bit32.band(v2, 268435455)

		local v12, v13 = uint64_t.sal(v2, v3, -28)

		v2, v3 = v12, v13
	end

	p1.expt = p1.expt * 2
	t.clamp(p1)
end
function t.add(p1, p2) --[[ add | Line: 91 | Upvalues: t (copy) ]]
	t.align(p1, p2)

	local v1 = p2.expt - p1.expt
	local count = 1
	local v3 = 0

	while count <= #p2 or v3 ~= 0 do
		local v4 = (p1[count + v1] or 0) + (p2[count] or 0) + v3

		p1[count + v1] = bit32.band(v4, 268435455)
		count, v3 = count + 1, bit32.rshift(v4, 28)
	end

	t.clamp(p1)
end
function t.sub(p1, p2) --[[ sub | Line: 108 | Upvalues: t (copy) ]]
	t.align(p1, p2)

	local v1 = p2.expt - p1.expt
	local count = 1
	local v3 = 0

	while count <= #p2 or v3 ~= 0 do
		local v4 = p1[count + v1] - (p2[count] or 0) - v3

		p1[count + v1] = bit32.band(v4, 268435455)
		count, v3 = count + 1, bit32.rshift(v4, 31)
	end

	t.clamp(p1)
end
function t.sub_times(p1, p2, p3) --[[ sub_times | Line: 125 | Upvalues: t (copy), uint64_t (copy) ]]
	if p3 < 3 then
		for i = 1, p3 do
			t.sub(p1, p2)
		end
	else
		local v1 = p2.expt - p1.expt
		local v2 = #p2
		local v3 = 0

		for j = 1, v2 do
			local v4, v5 = uint64_t.mul32(p3, p2[j])
			local v6, v7 = uint64_t.add(v4, v5, v3)
			local v8 = p1[j + v1] - bit32.band(v6, 268435455)

			p1[j + v1] = bit32.band(v8, 268435455)
			v3 = uint64_t.add(bit32.rshift(v8, 31), 0, uint64_t.sal(v6, v7, -28))
		end

		for k = v2 + v1 + 1, #p1 do
			if v3 == 0 then
				return
			end

			local v10 = p1[k] - v3

			p1[k] = bit32.band(v10, 268435455)
			v3 = bit32.rshift(v10, 31)
		end

		t.clamp(p1)
	end
end
function t.mul_uint32_t(p1, p2) --[[ mul_uint32_t | Line: 153 | Upvalues: uint64_t (copy) ]]
	local v1 = 0
	local v2 = 0

	for i, v in ipairs(p1) do
		local v3, v4 = uint64_t.add(v1, v2, uint64_t.mul32(p2, v))

		p1[i] = bit32.band(v3, 268435455)

		local v5, v6 = uint64_t.sal(v3, v4, -28)

		v1, v2 = v5, v6
	end

	while v1 ~= 0 or v2 ~= 0 do
		table.insert(p1, (bit32.band(v1, 268435455)))

		local v8, v9 = uint64_t.sal(v1, v2, -28)

		v1, v2 = v8, v9
	end
end
function t.mul_uint64_t(p1, p2, p3) --[[ mul_uint64_t | Line: 166 | Upvalues: uint64_t (copy) ]]
	local v1 = 0
	local v2 = 0

	for i, v in ipairs(p1) do
		local v3, v4 = uint64_t.mul32(p2, v)
		local v5, v6 = uint64_t.mul32(p3, v)
		local v7, v8 = uint64_t.add(bit32.band(v1, 268435455), 0, v3, v4)

		p1[i] = bit32.band(v7, 268435455)

		local v9, v10 = uint64_t.sal(v1, v2, -28)
		local v11, v12 = uint64_t.add(v9, v10, uint64_t.sal(v7, v8, -28))
		local v13, v14 = uint64_t.add(v11, v12, uint64_t.sal(v5, v6, 4))

		v1, v2 = v13, v14
	end

	while v1 ~= 0 or v2 ~= 0 do
		table.insert(p1, (bit32.band(v1, 268435455)))

		local v16, v17 = uint64_t.sal(v1, v2, -28)

		v1, v2 = v16, v17
	end
end
function t.from_power(p1, p2) --[[ from_power | Line: 183 | Upvalues: uint64_t (copy), t (copy) ]]
	if p2 == 0 then
		return {
			expt = 0,
			1
		}
	end

	local v1 = 0

	while bit32.band(p1, 1) == 0 do
		p1, v1 = bit32.rshift(p1, 1), v1 + 1
	end

	local v3, v4 = p1, 0

	while v3 ~= 0 do
		v3, v4 = bit32.rshift(v3, 1), v4 + 1
	end

	local v6 = table.create(v4 * p2 / 28 + 2)

	v6.expt = 0

	local v7 = 1

	while v7 <= p2 do
		v7 = v7 * 2
	end

	local v9, v10, v11, v12 = bit32.rshift(v7, 2), 0, p1, false

	while v9 ~= 0 and v10 == 0 do
		local v13, v14 = uint64_t.mul(v11, v10, v11, v10)

		if bit32.band(p2, v9) == 0 then
			v10 = v14
			v11 = v13
		else
			local v15, v16 = uint64_t.sal(1, 0, 64 - v4)
			local v17, v18 = uint64_t.sub(v15, v16, 1)

			if bit32.band(v13, (bit32.bnot(v17))) == 0 then
				if bit32.band(v14, (bit32.bnot(v18))) == 0 then
					local v21, v22 = uint64_t.mul(v13, v14, p1, 0)

					v10 = v22
					v11 = v21
				else
					v10 = v14
					v11 = v13
					v12 = true
				end
			else
				v10 = v14
				v11 = v13
				v12 = true
			end
		end

		v9 = bit32.rshift(v9, 1)
	end

	t.assign_uint64_t(v6, v11, v10)

	if v12 then
		t.mul_uint32_t(v6, p1)
	end

	while v9 ~= 0 do
		t.square(v6)

		if bit32.band(p2, v9) ~= 0 then
			t.mul_uint32_t(v6, p1)
		end

		v9 = bit32.rshift(v9, 1)
	end

	t.sal(v6, v1 * p2)

	return v6
end
function t.compare(p1, p2) --[[ compare | Line: 248 ]]
	local v1 = #p1 + p1.expt
	local v2 = #p2 + p2.expt

	if v1 < v2 then
		return -1
	end

	if v2 < v1 then
		return 1
	end

	for i = v1, math.min(p1.expt, p2.expt) + 1, -1 do
		local v3 = p1[i - p1.expt] or 0
		local v4 = p2[i - p2.expt] or 0

		if v3 < v4 then
			return -1
		end

		if v4 < v3 then
			return 1
		end
	end

	return 0
end
function t.plus_compare(p1, p2, p3) --[[ plus_compare | Line: 266 ]]
	local v1 = #p1 + p1.expt
	local v2 = #p2 + p2.expt
	local v3 = #p3 + p3.expt

	if v1 < v2 then
		v1, p1, v2, p2 = v2, p2, v1, p1
	end

	if v1 + 1 < v3 then
		return -1
	end

	if v3 < v1 then
		return 1
	end

	if v2 <= p1.expt and v1 < v3 then
		return -1
	end

	local v4 = 0

	for i = v3, math.min(p1.expt, p2.expt, p3.expt) + 1, -1 do
		local v7 = p3[i - p3.expt] or 0
		local v8 = (p1[i - p1.expt] or 0) + (p2[i - p2.expt] or 0)

		if v7 + v4 < v8 then
			return 1
		end

		local v9 = v7 + v4 - v8

		if v9 > 1 then
			return -1
		end

		v4 = bit32.lshift(v9, 28)
	end

	if v4 == 0 then
		return 0
	end

	return -1
end
function t.divmod(p1, p2) --[[ divmod | Line: 305 | Upvalues: t (copy) ]]
	local v1 = #p1 + p1.expt
	local v2 = #p2 + p2.expt

	if v1 < v2 then
		return 0
	end

	t.align(p1, p2)

	local v3 = #p1
	local sum = 0

	while v2 < v1 do
		sum = sum + p1[v3]
		t.sub_times(p1, p2, p1[v3])
		v3 = #p1
		v1 = v3 + p1.expt
	end

	local v4 = p1[v3]
	local v5 = p2[#p2]

	if not p2[2] then
		local v6 = math.floor(v4 / v5)

		p1[v3] = v4 - v5 * v6
		t.clamp(p1)

		return sum + v6
	end

	local v7 = math.floor(v4 / (v5 + 1))
	local count = sum + v7

	t.sub_times(p1, p2, v7)

	if v4 < v5 * (v7 + 1) then
		return count
	end

	while t.compare(p2, p1) <= 0 do
		t.sub(p1, p2)
		count = count + 1
	end

	return count
end
function t.mult_pow10(p1, p2) --[[ mult_pow10 | Line: 351 | Upvalues: t (copy), t2 (copy) ]]
	if p2 == 0 then
		return
	end

	local sum = p2

	while sum >= 27 do
		t.mul_uint64_t(p1, 4195354525, 1734723475)
		sum = sum - 27
	end

	while sum >= 13 do
		t.mul_uint32_t(p1, 1220703125)
		sum = sum - 13
	end

	if sum > 0 then
		t.mul_uint32_t(p1, t2[sum])
	end

	t.sal(p1, p2)
end
function t.assign_decimal(p1, p2, p3) --[[ assign_decimal | Line: 370 | Upvalues: t (copy), uint64_t (copy) ]]
	local sum = 1

	while sum > 19 do
		local t2 = {
			expt = 0
		}

		sum = sum + 19
		t.mult_pow10(p1, 19)

		local v1, v2 = uint64_t.read(p2, sum, sum + 18)

		t.assign_uint64_t(t2, v1, v2)
		t.add(p1, t2)
		p3 = p3 - 19
	end

	local t2 = {}
	local v3, v4 = uint64_t.read(p2, sum, sum + p3 - 1)

	t2.expt = 0
	t.mult_pow10(p1, p3)
	t.assign_uint64_t(t2, v3, v4)
	t.add(p1, t2)
	t.clamp(p1)
end

return t