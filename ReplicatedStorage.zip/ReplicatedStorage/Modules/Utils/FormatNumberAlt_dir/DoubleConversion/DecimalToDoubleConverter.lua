-- https://lua.expert/
require(script.Parent.proxy)

local strtod = require(script.Parent.strtod)

return {
	ToDouble = function(p1, p2, p3, p4) --[[ ToDouble | Line: 9 | Upvalues: strtod (copy) ]]
		if type(p1) ~= "table" then
			error("Argument #1 provided must be a table", 2)
		end

		local v1

		if p2 == nil then
			v1 = 1
		else
			local v2 = tonumber(p2)

			if not v2 then
				error("Argument #1 provided must be a number", 2)
			end

			v1 = v2
		end

		local v3

		if p3 == nil then
			v3 = 1
		else
			local v4 = tonumber(p3)

			if not v4 then
				error("Argument #3 provided must be a number", 2)
			end

			v3 = v4
		end

		local v5

		if p4 == nil then
			v5 = 1
		else
			local v6 = tonumber(p4)

			if not v6 then
				error("Argument #4 provided must be a number", 2)
			end

			v5 = v6
		end

		local v7 = v5 - v3 + 1
		local v8 = table.create(v7)
		local count = 0

		for i = v3, v5 do
			local v10 = tonumber((rawget(v8, i)))

			if v10 then
				if v10 <= -1 or v10 >= 10 then
					error(string.format("Index %d in table must be in the bounds of 0 and 10", i), 2)
				end
			else
				error(string.format("Index %d in table must be a number", i), 2)
			end

			count = count + 1
			p1[count] = v10 < 0 and math.ceil(v10) or math.floor(v10)
		end

		return strtod(v8, v7, v7 + v1)
	end
}