-- https://lua.expert/
local uint64_t = require(script.Parent.uint64_t)
local diy_fp = require(script.Parent.diy_fp)
local bignum = require(script.Parent.bignum)
local cached_power = require(script.Parent.cached_power)
local t = {
	[0] = 1,
	10,
	100,
	1000,
	10000,
	100000,
	1000000,
	10000000,
	100000000,
	1000000000,
	10000000000,
	100000000000,
	1000000000000,
	10000000000000,
	100000000000000,
	1000000000000000,
	1e16,
	1e17,
	1e18,
	1e19,
	1e20,
	1e21,
	1e22
}

local function adjust_power_of_ten(p1) --[[ adjust_power_of_ten | Line: 33 ]]
	if p1 == 1 then
		return 2684354560, -60
	end

	if p1 == 2 then
		return 3355443200, -57
	end

	if p1 == 3 then
		return 4194304000, -54
	end

	if p1 == 4 then
		return 2621440000, -50
	end

	if p1 == 5 then
		return 3276800000, -47
	end

	if p1 == 6 then
		return 4096000000, -44
	end

	if p1 == 7 then
		return 2560000000, -40
	end

	error("unreachable", 0)
end

local function significand_size_for_order_of_magnitude(p1) --[[ significand_size_for_order_of_magnitude | Line: 54 ]]
	if p1 >= -1021 then
		return 53
	end

	if p1 <= -1074 then
		return 0
	end

	return p1 + 1074
end

local function read_diy_fp(p1, p2) --[[ read_diy_fp | Line: 63 | Upvalues: uint64_t (copy) ]]
	local v1, v2, v3 = uint64_t.read(p1, 1, p2)

	if p2 ~= v3 - 1 and p1[v3] >= 5 then
		local v4, v5 = uint64_t.add(v1, v2, 1)

		v1 = v4
		v2 = v5
	end

	return v1, v2, p2 - (v3 - 1)
end

local function double_strtod(p1, p2, p3) --[[ double_strtod | Line: 72 | Upvalues: uint64_t (copy), t (copy) ]]
	if not (p2 <= 15) then
		return nil
	end

	if p3 < 0 and -p3 < 23 then
		local v1, v2 = uint64_t.read(p1, 1, p2)

		return uint64_t.to_double(v1, v2, false) / t[-p3]
	end

	if p3 >= 0 and p3 < 23 then
		local v3, v4 = uint64_t.read(p1, 1, p2)

		return uint64_t.to_double(v3, v4, false) * t[p3]
	end

	local v5 = 15 - p2

	if p3 > 0 and p3 - v5 < 23 then
		local v6, v7 = uint64_t.read(p1, 1, p2)

		return uint64_t.to_double(v6, v7, false) * t[v5] * t[p3 - v5]
	end

	return nil
end

local function diy_fp_strtod(p1, p2, p3) --[[ diy_fp_strtod | Line: 95 | Upvalues: uint64_t (copy), diy_fp (copy), cached_power (copy) ]]
	local v2, v3, v4 = uint64_t.read(p1, 1, p2)

	if p2 ~= v4 - 1 and p1[v4] >= 5 then
		local v5, v6 = uint64_t.add(v2, v3, 1)

		v2 = v5
		v3 = v6
	end

	local v7 = p2 - (v4 - 1)
	local v8 = p3 + v7
	local v10, v11, v12 = diy_fp.normalize(v2, v3, 0)
	local v13, v14 = uint64_t.sal(if v7 == 0 then 0 else 4, 0, 0 - v12)

	if v8 < -348 then
		return true, 0
	end

	local v15, v16, v17, v18 = cached_power.for_decimal_expt(v8)
	local v19, v20, v21, v22, v23

	if v18 == v8 then
		v19 = v13
		v20 = v14
		v21 = v10
		v22 = v11
		v23 = v12
	else
		local v24 = v8 - v18
		local v25, v26

		if v24 == 1 then
			v25 = 2684354560
			v26 = -60
		elseif v24 == 2 then
			v25 = 3355443200
			v26 = -57
		elseif v24 == 3 then
			v25 = 4194304000
			v26 = -54
		elseif v24 == 4 then
			v25 = 2621440000
			v26 = -50
		elseif v24 == 5 then
			v25 = 3276800000
			v26 = -47
		elseif v24 == 6 then
			v25 = 4096000000
			v26 = -44
		elseif v24 == 7 then
			v25 = 2560000000
			v26 = -40
		else
			error("unreachable", 0)
		end

		local v27, v28 = diy_fp.mul128(v10, v11, 0, v25)

		v23 = v12 + (v26 + 64)

		if 19 - p2 < v26 then
			local v29, v30 = uint64_t.add(v13, v14, 4)

			v19 = v29
			v20 = v30
			v21 = v27
			v22 = v28
		else
			v19 = v13
			v20 = v14
			v21 = v27
			v22 = v28
		end
	end

	local v31, v32 = diy_fp.mul128(v21, v22, v15, v16)
	local v33 = v23 + (v17 + 64)
	local v40, v41 = uint64_t.add(v19, v20, 8 + (if v19 == 0 and v20 == 0 then 0 else 1))
	local v42, v43, v44 = diy_fp.normalize(v31, v32, v33)
	local v45, v46 = uint64_t.sal(v40, v41, v33 - v44)
	local v47 = v44 + 64
	local sum = 64 - (if v47 >= -1021 then 53 elseif v47 <= -1074 then 0 else v47 + 1074)
	local v49, v50, v51, v52, v53

	if sum >= 61 then
		local v54 = sum - 62
		local v55, v56 = uint64_t.sal(v42, v43, -v54)

		v49 = v44 + v54

		local v57, v58 = uint64_t.add(9, 0, uint64_t.sal(v45, v46, v54))

		sum, v50, v51, v52, v53 = sum - v54, v55, v56, v57, v58
	else
		v50 = v42
		v51 = v43
		v49 = v44
		v52 = v45
		v53 = v46
	end

	local v59, v60 = uint64_t.sal(1, 0, sum)
	local v61, v62 = uint64_t.sub(v59, v60, 1)
	local v63 = bit32.band(v50, v61)
	local v64 = bit32.band(v51, v62)
	local v65, v66 = uint64_t.sal(1, 0, sum - 1)
	local v67, v68 = uint64_t.sal(v63, v64, 3)
	local v69, v70 = uint64_t.sal(v65, v66, 3)
	local v71, v72 = uint64_t.sal(v50, v51, -sum)

	if uint64_t.compare(v67, v68, uint64_t.add(v69, v70, v52, v53)) >= 0 then
		local v74, v75 = uint64_t.add(v71, v72, 1)

		v71 = v74
		v72 = v75
	end

	return if uint64_t.compare(v67, v68, uint64_t.sub(v69, v70, v52, v53)) <= 0 then true else uint64_t.compare(v67, v68, uint64_t.add(v69, v70, v52, v53)) >= 0, diy_fp.to_double(v71, v72, v49 + sum)
end

local function compute_guess(p1, p2, p3) --[[ compute_guess | Line: 171 | Upvalues: double_strtod (copy), diy_fp_strtod (copy) ]]
	if p2 <= 0 then
		return true, 0
	end

	if p2 + p3 - 1 >= 309 then
		return true, (1 / 0)
	end

	if p2 + p3 <= -324 then
		return true, 0
	end

	local v1 = double_strtod(p1, p2, p3)

	if v1 then
		return true, v1
	end

	return diy_fp_strtod(p1, p2, p3)
end

local function next_double(p1) --[[ next_double | Line: 190 ]]
	local v1, v2 = math.frexp(p1)

	return math.ldexp(v1 + 1.1102230246251565e-16, v2)
end

local function double_upper_boundary(p1) --[[ double_upper_boundary | Line: 195 | Upvalues: diy_fp (copy), uint64_t (copy) ]]
	local v1, v2, v3 = diy_fp.create(p1)
	local v4, v5 = uint64_t.add(1, 0, uint64_t.sal(v1, v2, 1))

	return v4, v5, v3 - 106
end

local function compare_buffer_with_diy_fp(p1, p2, p3, p4, p5, p6) --[[ compare_buffer_with_diy_fp | Line: 201 | Upvalues: bignum (copy) ]]
	local t = {
		expt = 0
	}
	local t2 = {
		expt = 0
	}

	bignum.assign_decimal(t, p1, p2)
	bignum.assign_uint64_t(t2, p4, p5)

	if p3 >= 0 then
		bignum.mult_pow10(t, p3)
	else
		bignum.mult_pow10(t2, -p3)
	end

	if p6 > 0 then
		bignum.sal(t2, p6)
	else
		bignum.sal(t, -p6)
	end

	return bignum.compare(t, t2)
end

return function(p1, p2, p3) --[[ Line: 224 | Upvalues: double_strtod (copy), diy_fp_strtod (copy), diy_fp (copy), uint64_t (copy), compare_buffer_with_diy_fp (copy) ]]
	local v1, v2

	if p2 <= 0 then
		v1 = true
		v2 = 0
	elseif p2 + p3 - 1 >= 309 then
		v1 = true
		v2 = (1 / 0)
	elseif p2 + p3 <= -324 then
		v1 = true
		v2 = 0
	else
		local v3 = double_strtod(p1, p2, p3)

		if v3 then
			v1 = true
			v2 = v3
		else
			local v4, v5 = diy_fp_strtod(p1, p2, p3)

			v1 = v4
			v2 = v5
		end
	end

	if not v1 and v2 ~= (1 / 0) then
		local v6, v7, v8 = diy_fp.create(v2)
		local v9, v10 = uint64_t.add(1, 0, uint64_t.sal(v6, v7, 1))
		local v11 = compare_buffer_with_diy_fp(p1, p2, p3, v9, v10, v8 - 106)

		if not (v11 < 0) then
			if v11 == 0 and bit32.band(diy_fp.create(v2), 1) == 0 then
				return v2
			end

			local v13, v14 = math.frexp(v2)

			return math.ldexp(v13 + 1.1102230246251565e-16, v14)
		end
	end

	return v2
end