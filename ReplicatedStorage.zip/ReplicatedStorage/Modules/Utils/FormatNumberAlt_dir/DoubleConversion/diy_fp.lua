-- https://lua.expert/
local uint64_t = require(script.Parent.uint64_t)

return {
	create = function(p1) --[[ create | Line: 5 ]]
		local v1, v2 = math.frexp(p1)

		if v2 < -1021 then
			v1 = v1 * 2 ^ (v2 + 1021)
			v2 = -1021
		end

		local v3, v4 = math.modf(v1 * 2097152)

		return v4 * 4294967296, v3, v2 + 52
	end,
	create_normalized = function(p1) --[[ create_normalized | Line: 17 ]]
		local v1, v2 = math.frexp(p1)
		local v3, v4 = math.modf(v1 * 4294967296)

		return v4 * 4294967296, v3, v2 - 64
	end,
	normalize = function(p1, p2, p3) --[[ normalize | Line: 24 | Upvalues: uint64_t (copy) ]]
		while bit32.band(p2, 4290772992) == 0 do
			local v1, v2 = uint64_t.sal(p1, p2, 10)

			p2, p1, p3 = v2, v1, p3 - 10
		end

		while bit32.band(p2, 2147483648) == 0 do
			local v3, v4 = uint64_t.sal(p1, p2, 1)

			p2, p1, p3 = v4, v3, p3 - 1
		end

		return p1, p2, p3
	end,
	mul128 = function(p1, p2, p3, p4) --[[ mul128 | Line: 40 | Upvalues: uint64_t (copy) ]]
		local v1, v2 = uint64_t.mul32(p1, p4)
		local v3, v4 = uint64_t.mul32(p2, p3)
		local v6, v7 = uint64_t.add(select(2, uint64_t.add(2147483648, 0, uint64_t.add(v1, 0, uint64_t.add(v3, 0, select(2, uint64_t.mul32(p1, p3)))))), 0, uint64_t.add(v2, 0, v4))

		return uint64_t.add(v6, v7, uint64_t.mul32(p2, p4))
	end,
	to_double = function(p1, p2, p3) --[[ to_double | Line: 65 ]]
		return math.ldexp(p1 / 4503599627370496 + p2 / 1048576, p3 + 52)
	end
}