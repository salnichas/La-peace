-- https://lua.expert/
local proxy = require(script.Parent.proxy)
local grisu3 = require(script.Parent.grisu3)
local bignum_dtoa = require(script.Parent.bignum_dtoa)
local t = {}
local t2 = {}

local function double_to_ascii(p1, p2, p3, p4) --[[ double_to_ascii | Line: 28 | Upvalues: bignum_dtoa (copy), grisu3 (copy) ]]
	if p1 ~= p1 then
		return p2.nan_symbol
	end

	if p1 == (1 / 0) then
		return p2.infinity_symbol
	end

	if p1 == (-1 / 0) then
		local infinity_symbol = p2.infinity_symbol

		if infinity_symbol then
			return "-" .. infinity_symbol
		end

		return nil
	end

	local v1 = math.abs(p1)
	local flags = p2.flags
	local v2 = if p4 == 2 then true else false
	local v3, v4

	if v1 == 0 then
		v3, v4 = if bit32.band(flags, 1) == 0 then math.atan2(p1, -1) < 0 else false, if v2 then "0E0" else "0"
	else
		local v7, v8, v9

		if p3 then
			local v10, v11, v12 = bignum_dtoa(v1, true)

			v7 = v12
			v8 = v11
			v9 = v10
		else
			local v13, v14, v15 = grisu3(v1)

			if v13 then
				v7 = v15
				v8 = v14
				v9 = v13
			else
				local v16, v17, v18 = bignum_dtoa(v1, false)

				v7 = v18
				v8 = v17
				v9 = v16
			end
		end

		local v19 = v7 + v8

		v3 = if p1 == v1 then false else true

		for i = 1, v8 do
			v9[i] = v9[i] + 48
		end

		if p4 == 0 then
			v2 = if v19 <= p2.decimal_in_shortest_low then true elseif p2.decimal_in_shortest_high < v19 then true else false
		end

		if v2 then
			local v21 = string.format("%d", (math.abs(v19 - 1)))
			local v22 = string.rep("0", p2.min_exponent_width - #v21) .. v21

			if v19 <= 0 then
				v22 = "-" .. v22
			elseif bit32.band(flags, 1) ~= 0 then
				v22 = "+" .. v22
			end

			local v25 = string.char(v9[1], 46, table.unpack(v9, 2, v8))

			v4 = (if v8 < 2 then string.sub(v25, 1, 1) else v25) .. p2.exponent_symbol .. v22
		else
			local v28 = math.min(v19, v8)
			local v29 = table.unpack

			v4 = string.char(v29(v9, 1, v28)) .. string.rep("0", v19 - v8)

			if v4 == "" then
				v4 = "0"
			end

			if v8 <= v19 then
				if bit32.band(flags, 2) ~= 0 then
					v4 = v4 .. (if bit32.band(flags, 4) == 0 then "." else ".0")
				end
			else
				local v31 = string.rep("0", -v19)
				local v32 = math.max(v19 + 1, 1)

				v4 = v4 .. "." .. v31 .. string.char(table.unpack(v9, v32, v8))
			end
		end
	end

	return v3 and "-" .. v4 or v4
end

function t2.ToShortest(p1, p2, p3) --[[ ToShortest | Line: 122 | Upvalues: proxy (copy), double_to_ascii (copy) ]]
	local v1 = proxy[p1]

	if not v1 or v1.__name ~= "DoubleToStringConverter" then
		error("Argument #1 provided must be a DoubleToStringConverter", 2)
	end

	local v2 = tonumber(p2)

	if not v2 then
		error("Argument #2 provided must be a number", 2)
	end

	local v3, v4

	if p3 == nil then
		v3 = v2
		v4 = 0
	else
		local v5 = tonumber(p3)

		if v5 then
			if v5 < 0 or v5 > 2 then
				v4 = v5
				error("Invalid argument #3", 2)
			end

			v3 = v2
			v4 = v5
		else
			error("Argument #3 provided must be a number", 2)
		end
	end

	return double_to_ascii(v3, v1, false, v4)
end
function t2.ToExact(p1, p2, p3) --[[ ToExact | Line: 147 | Upvalues: proxy (copy), double_to_ascii (copy) ]]
	local v1 = proxy[p1]

	if not v1 or v1.__name ~= "DoubleToStringConverter" then
		error("Argument #1 provided must be a DoubleToStringConverter", 2)
	end

	local v2 = tonumber(p2)

	if not v2 then
		error("Argument #2 provided must be a number", 2)
	end

	local v3, v4

	if p3 == nil then
		v3 = v2
		v4 = 0
	else
		local v5 = tonumber(p3)

		if v5 then
			if v5 < 0 or v5 > 2 then
				v4 = v5
				error("Invalid argument #3", 2)
			end

			v3 = v2
			v4 = v5
		else
			error("Argument #3 provided must be a number", 2)
		end
	end

	return double_to_ascii(v3, v1, true, v4)
end
t.Flags = {
	NO_FLAGS = 0,
	EMIT_POSITIVE_EXPONENT_SIGN = 1,
	EMIT_TRAILING_DECIMAL_POINT = 2,
	EMIT_TRAILING_ZERO_AFTER_POINT = 4,
	UNIQUE_ZERO = 8
}
t.Format = {
	AUTO = 0,
	DECIMAL = 1,
	EXPONENTIAL = 2
}
function t.new(p1, p2, p3, p4, p5, p6, p7) --[[ new | Line: 210 | Upvalues: t2 (copy), proxy (copy) ]]
	local v1 = tonumber(p1)
	local v2

	if v1 then
		if v1 < 0 or (v1 > 255 or bit32.band(v1, 6) == 4) then
			v2 = v1
			error("Invalid argument #1", 2)
		end

		v2 = v1
	else
		error("Argument #1 provided must be a number", 2)
	end

	if type(p2) ~= "string" and p2 ~= nil then
		error("Argument #2 provided must be a string", 2)
	end

	if type(p3) ~= "string" and p3 ~= nil then
		error("Argument #3 provided must be a string", 2)
	end

	if type(p4) ~= "string" then
		error("Argument #4 provided must be a string", 2)
	end

	local v3 = tonumber(p5)
	local v4

	if v3 then
		v4 = v3

		if v3 <= -1000 or v3 >= 1000 then
			error("Argument #5 provided must be in the bounds of -999 to 999", 2)
		end
	else
		error("Argument #5 provided must be a number", 2)
	end

	local v5 = tonumber(p6)
	local v6

	if v5 then
		v6 = v5

		if v5 <= -1000 or v5 >= 1000 then
			error("Argument #6 provided must be in the bounds of -999 to 999", 2)
		end
	else
		error("Argument #6 provided must be a number", 2)
	end

	local v7 = tonumber(p7)
	local v8

	if v7 then
		v8 = v7

		if v7 < 1 or v7 >= 6 then
			error("Argument #7 provided must be in the bounds of 1 to 5", 2)
		end
	else
		error("Argument #7 provided must be a number", 2)
	end

	local v9 = newproxy(true)
	local v10 = getmetatable(v9)

	v10.__index = t2
	v10.__name = "DoubleToStringConverter"
	v10.__metatable = "The metatable is locked"
	v10.flags = v2
	v10.infinity_symbol = p2
	v10.nan_symbol = p3
	v10.exponent_symbol = p4
	v10.decimal_in_shortest_low = v4
	v10.decimal_in_shortest_high = v6
	v10.min_exponent_width = v8
	proxy[v9] = v10

	return v9
end

return t