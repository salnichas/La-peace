-- https://lua.expert/
local t = {
	add = function(p1, p2, p3, p4) --[[ add | Line: 6 ]]
		local sum = p1 + p3

		if sum > 4294967295 then
			p2 = p2 + 1
			sum = sum - 4294967296
		end

		if p4 then
			p2 = p2 + p4

			if p2 > 4294967295 then
				return sum, p2 - 4294967296
			end
		elseif p2 == 4294967296 then
			p2 = 0
		end

		return sum, p2
	end,
	sub = function(p1, p2, p3, p4) --[[ sub | Line: 23 ]]
		local sum = p1 - p3

		if sum < 0 then
			p2 = p2 - 1
			sum = sum + 4294967296
		end

		if p4 then
			p2 = p2 - p4

			if p2 < 0 then
				return sum, p2 + 4294967296
			end
		elseif p2 == -1 then
			p2 = 4294967296
		end

		return sum, p2
	end,
	sal = function(p1, p2, p3) --[[ sal | Line: 40 ]]
		if p3 < 0 then
			return bit32.rshift(p2, -32 - p3) + bit32.lshift(p1, p3), bit32.lshift(p2, p3)
		end

		return bit32.lshift(p1, p3), bit32.rshift(p1, 32 - p3) + bit32.lshift(p2, p3)
	end
}

function t.mul32(p1, p2) --[[ mul32 | Line: 51 | Upvalues: t (copy) ]]
	local v1 = bit32.rshift(p1, 16)
	local v2 = bit32.band(p1, 65535)
	local v3 = bit32.rshift(p2, 16)
	local v4 = bit32.band(p2, 65535)
	local v5, v6 = t.add(v1 * v4, 0, v2 * v3)

	return t.add(v2 * v4, v1 * v3, t.sal(v5, v6, 16))
end
function t.mul(p1, p2, p3, p4) --[[ mul | Line: 61 | Upvalues: t (copy) ]]
	local v1, v2 = t.mul32(p2, p3)

	return t.add(0, t.add(v1, v2, t.mul32(p1, p4)), t.mul32(p1, p3))
end
function t.compare(p1, p2, p3, p4) --[[ compare | Line: 72 ]]
	if p2 == p4 then
		if p1 == p3 then
			return 0
		end

		if p1 < p3 then
			return -1
		end

		return 1
	end

	if p2 < p4 then
		return -1
	end

	return 1
end
function t.to_double(p1, p2, p3) --[[ to_double | Line: 78 | Upvalues: t (copy) ]]
	if p3 and p2 >= 2147483648 then
		local v1, v2 = t.add(bit32.bnot(p1), bit32.bnot(p2), 1)

		if v1 == 0 and v2 == 0 then
			return -9.223372036854776e18
		end

		return -(v1 + v2 * 4294967296)
	end

	return p1 + p2 * 4294967296
end
function t.read(p1, p2, p3) --[[ read | Line: 89 | Upvalues: t (copy) ]]
	local v1 = 0
	local v2 = 0

	while p2 <= p3 and (v1 < 429496729 or v1 == 429496729 and v2 <= 2576980376) do
		local v3, v4 = t.add(p1[p2], 0, t.mul(v2, v1, 10, 0))

		p2, v1, v2 = p2 + 1, v4, v3
	end

	return v2, v1, p2
end

return t