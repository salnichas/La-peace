-- https://lua.expert/
local uint64_t = require(script.Parent.uint64_t)
local bignum = require(script.Parent.bignum)
local diy_fp = require(script.Parent.diy_fp)
local v1 = nil

local function normalized_exponent(p1, p2, p3) --[[ normalized_exponent | Line: 10 | Upvalues: uint64_t (copy) ]]
	while bit32.band(p2, 1048576) == 0 do
		local v1, v2 = uint64_t.sal(p1, p2, 1)

		p2, p3, p1 = v2, p3 - 1, v1
	end

	return p3
end

local function estimate_power(p1) --[[ estimate_power | Line: 18 ]]
	return math.ceil((p1 + 52) * 0.30102999566398114 - 1e-10)
end

local function initial_scaled_start_values_positive_exponent(p1, p2, p3, p4, p5) --[[ initial_scaled_start_values_positive_exponent | Line: 22 | Upvalues: bignum (copy) ]]
	local v1 = p3 / 28
	local v2 = table.create(v1 + 2)

	v2.expt = 0
	bignum.assign_uint64_t(v2, p1, p2)
	bignum.sal(v2, p3)

	local v3 = bignum.from_power(10, p4)

	if p5 then
		bignum.sal(v2, 1)
		bignum.sal(v3, 1)

		local v4 = table.create(v1)

		v4.expt = 0
		v4[1] = 1
		bignum.sal(v4, p3)

		return v2, v3, {
			expt = v4.expt,
			table.unpack(v4)
		}, v4
	end

	return v2, v3
end

local function initial_scaled_start_values_negative_exponent_positive_power(p1, p2, p3, p4, p5) --[[ initial_scaled_start_values_negative_exponent_positive_power | Line: 52 | Upvalues: bignum (copy) ]]
	local t = {
		expt = 0
	}

	bignum.assign_uint64_t(t, p1, p2)

	local v1 = bignum.from_power(10, p4)

	bignum.sal(v1, -p3)

	if p5 then
		bignum.sal(t, 1)
		bignum.sal(v1, 1)

		return t, v1, {
			expt = 0,
			1
		}, {
			expt = 0,
			1
		}
	end

	return t, v1
end

local function initial_scaled_start_values_negative_exponent_negative_power(p1, p2, p3, p4, p5) --[[ initial_scaled_start_values_negative_exponent_negative_power | Line: 73 | Upvalues: bignum (copy) ]]
	local v1 = bignum.from_power(10, -p4)
	local v2, v3

	if p5 then
		local t = {
			expt = v1.expt,
			table.unpack(v1)
		}

		v2, v3 = {
			expt = v1.expt,
			table.unpack(v1)
		}, t
	else
		v2 = nil
		v3 = nil
	end

	bignum.mul_uint64_t(v1, p1, p2)

	local t = {
		expt = 0,
		1
	}

	bignum.sal(t, -p3)

	if p5 then
		bignum.sal(v1, 1)
		bignum.sal(t, 1)
	end

	return v1, t, v2, v3
end

local function initial_scaled_start_values(p1, p2, p3, p4, p5, p6) --[[ initial_scaled_start_values | Line: 100 | Upvalues: initial_scaled_start_values_positive_exponent (copy), initial_scaled_start_values_negative_exponent_positive_power (copy), initial_scaled_start_values_negative_exponent_negative_power (copy), bignum (copy) ]]
	local v1, v2, v3, v4

	if p3 >= 0 then
		local v5, v6, v7, v8 = initial_scaled_start_values_positive_exponent(p1, p2, p3, p5, p6)

		v1 = v6
		v2 = v5
		v3 = v8
		v4 = v7
	elseif p5 >= 0 then
		local v9, v10, v11, v12 = initial_scaled_start_values_negative_exponent_positive_power(p1, p2, p3, p5, p6)

		v1 = v10
		v2 = v9
		v3 = v12
		v4 = v11
	else
		local v13, v14, v15, v16 = initial_scaled_start_values_negative_exponent_negative_power(p1, p2, p3, p5, p6)

		v1 = v14
		v2 = v13
		v3 = v16
		v4 = v15
	end

	if p6 and p4 then
		bignum.sal(v1, 1)
		bignum.sal(v2, 1)
		bignum.sal(v3, 1)
	end

	return v2, v1, v4, v3
end

local function fixup_mult_10(p1, p2, p3, p4, p5, p6) --[[ fixup_mult_10 | Line: 129 | Upvalues: bignum (copy) ]]
	if if (if p2 then 0 else 1) <= (p6 and bignum.plus_compare(p3, p6, p4) or bignum.compare(p3, p4)) then true else false then
		return p1 + 1, p3, p4, p5, p6
	end

	bignum.mul_uint32_t(p3, 10)

	if p5 then
		bignum.mul_uint32_t(p5, 10)
	end

	if p6 then
		bignum.mul_uint32_t(p6, 10)
	end

	return p1, p3, p4, p5, p6
end

local function digit_gen(p1, p2, p3, p4, p5, p6) --[[ digit_gen | Line: 151 | Upvalues: bignum (copy) ]]
	if bignum.compare(p5, p6) == 0 then
		p6 = p5
	end

	local v1 = table.create(17)
	local count = 0

	while true do
		count = count + 1
		v1[count] = bignum.divmod(p3, p4)

		local v4 = if bignum.compare(p3, p5) <= (if p1 then 0 else -1) then true else false
		local v7 = if (if p1 then 0 else 1) <= bignum.plus_compare(p3, p6, p4) then true else false

		if v4 or v7 then
			if v4 and v7 then
				local v8 = bignum.plus_compare(p3, p3, p4)

				if v8 > 0 or v8 == 0 and v1[count] % 2 ~= 0 then
					v1[count] = v1[count] + 1
				end
			elseif not v4 then
				v1[count] = v1[count] + 1
			end

			return v1, count, p2 - count
		end

		bignum.mul_uint32_t(p3, 10)
		bignum.mul_uint32_t(p5, 10)

		if p5 ~= p6 then
			bignum.mul_uint32_t(p6, 10)
		end
	end
end

local function digit_gen_long(p1, p2, p3) --[[ digit_gen_long | Line: 195 | Upvalues: bignum (copy), v1 (ref) ]]
	local t = { bignum.divmod(p2, p3) }
	local count = 1

	while p2[1] do
		count = count + 1
		bignum.mul_uint32_t(p2, 10)
		t[count] = bignum.divmod(p2, p3)
	end

	for i = count, 2, -1 do
		if t[i] ~= 10 then
			break
		end

		t[i] = 0

		local v12 = i - 1

		t[v12] = t[v12] + 1
	end

	if t[1] == 10 then
		t[1] = 0
		table.insert(t, 1, 1)
		count = count + 1
		p1 = p1 + 1
	end

	while t[count] == 0 do
		t[count] = v1
		count = count - 1
	end

	return t, count, p1 - count
end

return function(p1, p2) --[[ Line: 233 | Upvalues: diy_fp (copy), normalized_exponent (copy), initial_scaled_start_values (copy), fixup_mult_10 (copy), digit_gen_long (copy), digit_gen (copy) ]]
	local v1, v2, v3 = diy_fp.create(p1)
	local v4 = v3 - 105
	local v6 = if bit32.band(v1, 1) == 0 then true else false
	local v8 = math.ceil((normalized_exponent(v1, v2, v4) + 52) * 0.30102999566398114 - 1e-10)
	local v9, v10, v11, v12 = initial_scaled_start_values(v1, v2, v4, if v1 == 0 then if v2 == 0 then true else false else false, v8, not p2)
	local v13, v14, v15, v16, v17 = fixup_mult_10(v8, v6, v9, v10, v11, v12)

	if p2 then
		return digit_gen_long(v13, v14, v15)
	end

	return digit_gen(v6, v13, v14, v15, v16, v17)
end