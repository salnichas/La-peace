-- https://lua.expert/
require(script.Parent.proxy)

local grisu3 = require(script.Parent.grisu3)
local bignum_dtoa = require(script.Parent.bignum_dtoa)

return {
	ToShortest = function(p1) --[[ ToShortest | Line: 11 | Upvalues: grisu3 (copy), bignum_dtoa (copy) ]]
		local v1 = tonumber(p1)

		if not v1 then
			error("Argument #2 provided must be a number", 2)
		end

		local v2 = math.abs(v1)

		if v2 ~= v2 or (v2 == 0 or v2 == (1 / 0)) then
			return nil, nil, nil
		end

		local v3, v4, v5 = grisu3(v2)

		if v3 then
			return v3, v4, v5
		end

		return bignum_dtoa(v2, false)
	end,
	ToExact = function(p1) --[[ ToExact | Line: 33 | Upvalues: bignum_dtoa (copy) ]]
		local v1 = tonumber(p1)

		if not v1 then
			error("Argument #2 provided must be a number", 2)
		end

		local v2 = math.abs(v1)

		if v2 == v2 and (v2 ~= 0 and v2 ~= (1 / 0)) then
			return bignum_dtoa(v2, true)
		end

		return nil, nil, nil
	end
}