-- https://lua.expert/
return setmetatable({}, {
	__mode = "k"
})