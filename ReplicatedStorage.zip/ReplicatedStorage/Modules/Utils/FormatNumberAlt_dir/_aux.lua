-- https://lua.expert/
local config = require(script.Parent.config)
local t = {}
local v1 = string.gsub(config.groupingSymbol, "%%", "%%%%") .. "%0"
local decimalSymbol = config.decimalSymbol
local infinitySymbol = config.infinitySymbol
local quietNaNSymbol = config.quietNaNSymbol
local signalingNaNSymbol = config.signalingNaNSymbol
local showNaNPayload = config.showNaNPayload
local subnormalsAsZero = config.subnormalsAsZero

function t.round_sig(p1, p2, p3) --[[ round_sig | Line: 14 ]]
	local v1 = false

	if p3 <= 0 then
		p2 = 0
	elseif p3 < p2 then
		local v2 = if p1[p3 + 1] > 5 then true elseif p1[p3 + 1] == 5 then if p3 + 1 < p2 then true elseif p1[p3] % 2 == 1 then true else false else false

		p2 = p3

		if v2 then
			while p1[p2] == 9 and p2 > 0 do
				p2 = p2 - 1
			end

			if p2 == 0 then
				p1[1] = 1
				p2 = 1
				v1 = true
			else
				p1[p2] = p1[p2] + 1
			end
		end
	end

	while p1[p2] == 0 do
		p2 = p2 - 1
	end

	return p2, v1
end

local function internal_get_digits(p1, p2, p3, p4) --[[ internal_get_digits | Line: 49 ]]
	local v1

	if p3 <= 0 then
		p3, v1 = 1, string.rep("0", -p3 + 1)
	else
		v1 = ""
	end

	local v3 = p4 - math.max(p2, p3 - 1)
	local v4

	if v3 <= 0 then
		v4 = ""
	else
		p4, v4 = p2, string.rep("0", v3)
	end

	return v1 .. (if p2 < p3 then "" else string.char(table.unpack(p1, p3, p4))) .. v4
end

function t.format_unsigned_finite(p1, p2, p3, p4, p5) --[[ format_unsigned_finite | Line: 76 | Upvalues: internal_get_digits (copy), v1 (copy), decimalSymbol (copy) ]]
	for i = 1, p2 do
		p1[i] = p1[i] + 48
	end

	local v12 = internal_get_digits(p1, p2, p3 + 1, p4 or p2)
	local v2

	if p3 <= 0 then
		v2 = "0"
	elseif p5 <= p3 then
		local v3 = (p3 - 1) % 3 + 1
		local v4 = internal_get_digits(p1, p2, 1, v3)

		v2 = v4 .. string.gsub(internal_get_digits(p1, p2, v3 + 1, p3), "...", v1)
	else
		v2 = internal_get_digits(p1, p2, 1, p3)
	end

	if v12 == "" then
		return v2
	end

	return v2 .. decimalSymbol .. v12
end
function t.format_special(p1, p2) --[[ format_special | Line: 110 | Upvalues: signalingNaNSymbol (copy), quietNaNSymbol (copy), showNaNPayload (copy), infinitySymbol (copy), subnormalsAsZero (copy), decimalSymbol (copy) ]]
	local v1 = nil
	local v2 = if p1 == (1 / 0) then true else false
	local v3 = if p1 == (-1 / 0) then true else false

	if p1 == p1 and not (v2 and v3) then
		if v2 then
			return infinitySymbol
		end

		if v3 then
			return "-" .. infinitySymbol
		end

		if p1 == 0 or subnormalsAsZero and p1 * 1 == 0 then
			v1 = if math.atan2(p1, -1) < 0 then "-0" else "0"

			if p2 > 1 then
				v1 = v1 .. decimalSymbol .. string.rep("0", p2 - 1)
			end
		end
	else
		local v5, v6, v7, v8, v9, v10, v11, v12 = string.byte(string.pack("<d", p1), 1, 8)

		v1 = if bit32.band(v11, 8) == 0 then signalingNaNSymbol else quietNaNSymbol

		if v12 > 127 then
			v1 = "-" .. v1
		end

		if showNaNPayload then
			return v1 .. string.format(" 0x%01X%02X%02X%02X%02X%02X%02X", bit32.band(v11, 15), v10, v9, v8, v7, v6, v5)
		end
	end

	return v1
end

local function arg_error_msg(p1, p2, p3) --[[ arg_error_msg | Line: 157 ]]
	if p1 == nil then
		return string.format("Expected %s in argument #%d, got nil or is missing", p2, p3)
	end

	return string.format("Expected %s in argument #%d, got %s", p2, p3, (typeof(p1)))
end

function t.expect_strictly_number(p1, p2) --[[ expect_strictly_number | Line: 174 ]]
	if type(p1) == "string" and tostring(p1) then
		error(string.format("Argument #%d won\'t be implicitly casted to number, please use explicit casting", p2), 3)
	end

	if type(p1) == "number" then
		return
	end

	error(if p1 == nil then string.format("Expected %s in argument #%d, got nil or is missing", "number", p2) else string.format("Expected %s in argument #%d, got %s", "number", p2, (typeof(p1))), 3)
end
function t.cast_to_string(p1, p2, p3) --[[ cast_to_string | Line: 185 ]]
	if p1 == nil and p3 then
		return p3
	end

	if type(p1) == "number" then
		return p1 .. ""
	end

	if type(p1) ~= "string" then
		error(if p1 == nil then string.format("Expected %s in argument #%d, got nil or is missing", "string", p2) else string.format("Expected %s in argument #%d, got %s", "string", p2, (typeof(p1))), 3)
	end

	return p1
end
function t.cast_to_int32_t_check_range(p1, p2, p3, p4, p5) --[[ cast_to_int32_t_check_range | Line: 199 ]]
	if p1 == nil and p5 then
		return p5
	end

	local v1 = tonumber(p1)
	local v2 = false

	if not v1 then
		error(if p1 == nil then string.format("Expected %s in argument #%d, got nil or is missing", "number", p4) else string.format("Expected %s in argument #%d, got %s", "number", p4, (typeof(p1))), 3)
	end

	if v1 <= -1 then
		if v1 <= -2147483649 then
			v2 = true
		else
			v1 = math.ceil(v1)
		end
	elseif v1 >= 1 then
		if v1 >= 2147483648 then
			v2 = true
		else
			v1 = math.floor(v1)
		end
	elseif v1 == v1 then
		v1 = 0
	else
		v2 = true
	end

	if v2 then
		v1 = UDim.new(nil, v1).Offset
	end

	if p2 and (p3 and (v1 < p2 or p3 < v1)) then
		error(string.format("Expected value in range (%d..%d) in argument #%d, got %d", p2, p3, p4, v1), 3)
	end

	return v1
end

return table.freeze(t)