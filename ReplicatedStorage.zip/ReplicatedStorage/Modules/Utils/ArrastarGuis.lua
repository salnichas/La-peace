-- https://lua.expert/
local v1 = UDim2.new
local UserInputService = game:GetService("UserInputService")
local t = {}

t.__index = t
function t.new(p1) --[[ new | Line: 17 | Upvalues: t (copy) ]]
	local t2 = {
		Object = p1,
		DragStarted = nil,
		DragEnded = nil,
		Dragged = nil,
		Dragging = false
	}

	setmetatable(t2, t)

	return t2
end
function t.Enable(p1) --[[ Enable | Line: 31 | Upvalues: v1 (copy), UserInputService (copy) ]]
	local Object = p1.Object
	local v12 = nil
	local v2 = nil
	local v3 = nil
	local v4 = false

	local function update(p1) --[[ update | Line: 39 | Upvalues: v2 (ref), v1 (ref), v3 (ref), Object (copy) ]]
		local v12 = p1.Position - v2
		local v22 = v1(v3.X.Scale, v3.X.Offset + v12.X, v3.Y.Scale, v3.Y.Offset + v12.Y)

		Object.Position = v22

		return v22
	end

	p1.InputBegan = Object.InputBegan:Connect(function(p12) --[[ Line: 47 | Upvalues: v4 (ref), p1 (copy) ]]
		if p12.UserInputType ~= Enum.UserInputType.MouseButton1 and p12.UserInputType ~= Enum.UserInputType.Touch then
			return
		end

		v4 = true

		local v1 = nil

		v1 = p12.Changed:Connect(function() --[[ Line: 60 | Upvalues: p12 (copy), p1 (ref), v4 (ref), v1 (ref) ]]
			if p12.UserInputState ~= Enum.UserInputState.End or not (p1.Dragging or v4) then
				return
			end

			p1.Dragging = false
			v1:Disconnect()

			if p1.DragEnded and not v4 then
				p1.DragEnded()
			end

			v4 = false
		end)
	end)
	p1.InputChanged = Object.InputChanged:Connect(function(p1) --[[ Line: 75 | Upvalues: v12 (ref) ]]
		if p1.UserInputType ~= Enum.UserInputType.MouseMovement and p1.UserInputType ~= Enum.UserInputType.Touch then
			return
		end

		v12 = p1
	end)
	p1.InputChanged2 = UserInputService.InputChanged:Connect(function(p12) --[[ Line: 81 | Upvalues: Object (copy), p1 (copy), v4 (ref), v2 (ref), v3 (ref), v12 (ref), v1 (ref) ]]
		if Object.Parent == nil then
			p1:Disable()

			return
		end

		if v4 then
			v4 = false

			if p1.DragStarted then
				p1.DragStarted()
			end

			p1.Dragging = true
			v2 = p12.Position
			v3 = Object.Position
		end

		if p12 ~= v12 or not p1.Dragging then
			return
		end

		local v13 = p12.Position - v2
		local v22 = v1(v3.X.Scale, v3.X.Offset + v13.X, v3.Y.Scale, v3.Y.Offset + v13.Y)

		Object.Position = v22

		if not p1.Dragged then
			return
		end

		p1.Dragged(v22)
	end)
end
function t.Disable(p1) --[[ Disable | Line: 110 ]]
	p1.InputBegan:Disconnect()
	p1.InputChanged:Disconnect()
	p1.InputChanged2:Disconnect()

	if not p1.Dragging then
		return
	end

	p1.Dragging = false

	if not p1.DragEnded then
		return
	end

	p1.DragEnded()
end

return t