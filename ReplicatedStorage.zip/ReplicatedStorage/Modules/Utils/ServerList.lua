-- https://lua.expert/
local Players = game:GetService("Players")
local TeleportService = game:GetService("TeleportService")
local MessagingService = game:GetService("MessagingService")

game:GetService("Chat")

local LocalizationService = game:GetService("LocalizationService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local t = {}
local t2 = {}
local v1 = os.time()

t.ServerStartTime = v1
t.DataTransferRemote = ReplicatedStorage.Remotes.Events.GETServers.DataTransfer

local function UpdateAllClients(p1) --[[ UpdateAllClients | Line: 20 | Upvalues: t (copy) ]]
	t.DataTransferRemote:FireAllClients(p1)
end

local function cleanupDeadServers() --[[ cleanupDeadServers | Line: 24 | Upvalues: t2 (ref), t (copy) ]]
	for k, v in pairs(t2) do
		if #v.plrs == 0 then
			t2[k] = nil
			print("Removed dead server:", k)
		end
	end

	t.DataTransferRemote:FireAllClients(t2)
end

task.spawn(function() --[[ Line: 34 | Upvalues: cleanupDeadServers (copy) ]]
	while task.wait(30) do
		cleanupDeadServers()
	end
end)

local function v2(p1) --[[ ArrayToString | Line: 40 | Upvalues: v2 (copy) ]]
	local count = 0
	local count2 = 1
	local v1 = "{"

	for k, v in pairs(p1) do
		count = count + 1
	end

	for k, v in pairs(p1) do
		local v22

		v22 = if type(v) == "table" then v2(v) else tostring(v)
		v1 = if count2 < count then v1 .. k .. " = " .. v22 .. ", " else v1 .. k .. " = " .. v22
		count2 = count2 + 1
	end

	return v1 .. "}"
end

local function Send(p1, p2, p3) --[[ Send | Line: 69 | Upvalues: HttpService (copy), MessagingService (copy) ]]
	MessagingService:PublishAsync(p3, (HttpService:JSONEncode({
		sender = p2,
		message = p1
	})))
end

local v3 = nil
local t3 = {}

for i, v in ipairs(Players:GetPlayers()) do
	MessagingService:PublishAsync("SList", (HttpService:JSONEncode({
		sender = game.JobId,
		message = {
			Type = "Added",
			UserId = v.UserId,
			ServerStartTime = v1,
			RegionName = v3
		}
	})))
	table.insert(t3, v.UserId)
	t.DataTransferRemote:FireClient(v, t2)
end

local function getFlag(p1) --[[ getFlag | Line: 86 | Upvalues: LocalizationService (copy) ]]
	local v1 = LocalizationService:GetCountryRegionForPlayerAsync(p1)
	local v3 = string.byte(string.upper((string.sub(v1, 1, 1)))) - 65 + 127462
	local v5 = string.byte(string.upper((string.sub(v1, 2, 2)))) - 65 + 127462

	return utf8.char(v3) .. utf8.char(v5)
end

Players.PlayerAdded:Connect(function(p1) --[[ Line: 93 | Upvalues: v3 (ref), LocalizationService (copy), getFlag (copy), v1 (copy), HttpService (copy), MessagingService (copy), t3 (copy), t (copy), t2 (ref) ]]
	if v3 == nil then
		v3 = LocalizationService:GetCountryRegionForPlayerAsync(p1) .. " " .. getFlag(p1)
	end

	MessagingService:PublishAsync("SList", (HttpService:JSONEncode({
		sender = game.JobId,
		message = {
			Type = "Added",
			UserId = p1.UserId,
			ServerStartTime = v1,
			RegionName = v3
		}
	})))
	table.insert(t3, p1.UserId)
	t.DataTransferRemote:FireClient(p1, t2)
end)
Players.PlayerRemoving:Connect(function(p1) --[[ Line: 102 | Upvalues: HttpService (copy), MessagingService (copy), t3 (copy) ]]
	MessagingService:PublishAsync("SList", (HttpService:JSONEncode({
		sender = game.JobId,
		message = {
			Type = "Removed",
			UserId = p1.UserId
		}
	})))

	for i, v in ipairs(t3) do
		if v == p1.UserId then
			table.remove(t3, i)

			return
		end
	end
end)
function t.Init() --[[ Init | Line: 114 | Upvalues: v3 (ref), t (copy), HttpService (copy), v2 (copy), t2 (ref), t3 (copy), v1 (copy), MessagingService (copy) ]]
	repeat
		task.wait(0.1)
	until v3

	t.RegionName = v3

	local function callback(p1) --[[ callback | Line: 120 | Upvalues: HttpService (ref), v2 (ref), t2 (ref), t3 (ref), v3 (ref), v1 (ref), MessagingService (ref), t (ref) ]]
		local v12 = HttpService:JSONDecode(p1.Data)

		if not v12 then
			return
		end

		local sender = v12.sender
		local message = v12.message

		if sender == game.JobId then
			return
		end

		print("Callback: ")
		print("Decoded Data: ", (v2(v12)))

		if t2[sender] == nil then
			t2[sender] = {
				data = {},
				plrs = {}
			}
		end

		if message.Type == "RequestInfo" then
			t2[sender].data.RegionName = message.RegionName
			t2[sender].data.ServerStartTime = message.ServerStartTime
			MessagingService:PublishAsync(sender, (HttpService:JSONEncode({
				sender = game.JobId,
				message = {
					Type = "SendInfo",
					List = t3,
					RegionName = v3,
					ServerStartTime = v1
				}
			})))
		end

		if message.Type == "Added" then
			t2[sender].data.RegionName = message.RegionName
			t2[sender].data.ServerStartTime = message.ServerStartTime
			table.insert(t2[sender].plrs, message.UserId)
		end

		if message.Type == "ShuttingDown" then
			t2[sender] = nil
		end

		if message.Type == "Removed" then
			for i, v in ipairs(t2[sender].plrs) do
				if v == message.UserId then
					table.remove(t2[sender].plrs, i)

					break
				end
			end
		end

		print("Current Array: ", (v2(t2)))
		t.DataTransferRemote:FireAllClients(t2)
		print("")
	end

	local function private_callback(p1) --[[ private_callback | Line: 166 | Upvalues: HttpService (ref), v2 (ref), t2 (ref), t (ref) ]]
		local v1 = HttpService:JSONDecode(p1.Data)

		if not v1 then
			return
		end

		local sender = v1.sender
		local message = v1.message

		if sender == game.JobId then
			return
		end

		print("Callback! Data: ")
		print((v2(p1)))

		if t2[sender] == nil then
			t2[sender] = {
				data = {},
				plrs = {}
			}
		end

		if message.Type == "SendInfo" then
			t2[sender].plrs = message.List
			t2[sender].data.RegionName = message.RegionName
			t2[sender].data.ServerStartTime = message.ServerStartTime
		end

		t.DataTransferRemote:FireAllClients(t2)
	end

	if game.JobId == "" then
		return
	end

	MessagingService:SubscribeAsync("SList", callback)
	MessagingService:SubscribeAsync(game.JobId, private_callback)
	coroutine.wrap(function() --[[ Line: 191 | Upvalues: v3 (ref), v1 (ref), HttpService (ref), MessagingService (ref) ]]
		task.wait(5)
		MessagingService:PublishAsync("SList", (HttpService:JSONEncode({
			sender = game.JobId,
			message = {
				Type = "RequestInfo",
				RegionName = v3,
				ServerStartTime = v1
			}
		})))
	end)()
	coroutine.wrap(function() --[[ Line: 195 | Upvalues: t2 (ref), v3 (ref), v1 (ref), HttpService (ref), MessagingService (ref) ]]
		while task.wait(60) do
			t2 = {}
			MessagingService:PublishAsync("SList", (HttpService:JSONEncode({
				sender = game.JobId,
				message = {
					Type = "RequestInfo",
					RegionName = v3,
					ServerStartTime = v1
				}
			})))
		end
	end)()
end

local function FindPlayer(p1) --[[ FindPlayer | Line: 206 | Upvalues: t2 (ref) ]]
	for k, v in pairs(t2) do
		for i, v2 in ipairs(v) do
			if v2.Name == p1 then
				return k
			end
		end
	end
end

function t.TeleportToPlayer(p1, p2) --[[ TeleportToPlayer | Line: 216 | Upvalues: FindPlayer (copy), TeleportService (copy) ]]
	local v1 = FindPlayer(p2)

	if v1 then
		TeleportService:TeleportToPlaceInstance(game.PlaceId, v1, p1)
	else
		print("There is no such player")
	end
end
function t.PrintServerList() --[[ PrintServerList | Line: 225 | Upvalues: v2 (copy), t2 (ref) ]]
	print((v2(t2)))
end
game:BindToClose(function() --[[ Line: 228 | Upvalues: HttpService (copy), MessagingService (copy) ]]
	MessagingService:PublishAsync("SList", (HttpService:JSONEncode({
		sender = game.JobId,
		message = {
			Type = "ShuttingDown"
		}
	})))
end)

return t