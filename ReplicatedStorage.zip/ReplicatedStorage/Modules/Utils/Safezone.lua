-- https://lua.expert/
local Players = game:GetService("Players")
local Notification = game.ReplicatedStorage.Remotes.Notification
local t = {}
local t2 = {}
local t3 = {
	Motocicleta = true,
	["Contin\195\170ncia"] = true,
	Descansar = true,
	Prancheta = true,
	PranchetaCDP = true,
	Foice = true,
	Lixo = true,
	["Render-se"] = true
}

function t.Init() --[[ Init | Line: 25 | Upvalues: Players (copy), t (copy), t2 (copy) ]]
	for k, v in pairs(Players:GetPlayers()) do
		t.Setup(v)
	end

	Players.PlayerAdded:Connect(t.Setup)
	Players.PlayerRemoving:Connect(function(p1) --[[ Line: 30 | Upvalues: t2 (ref) ]]
		t2[p1] = nil
	end)
end
function t.Setup(p1) --[[ Setup | Line: 35 | Upvalues: t2 (copy), t3 (copy) ]]
	local t = {
		UnsafeUntil = 0,
		PKKills = 0,
		Notified = false,
		ActiveTimer = nil,
		LastPKReset = os.time()
	}

	t2[p1] = t

	local function resetTimer() --[[ resetTimer | Line: 45 | Upvalues: t (copy), p1 (copy), t3 (ref) ]]
		if not t.ActiveTimer then
			t.ActiveTimer = game:GetService("RunService").Heartbeat:Connect(function() --[[ Line: 51 | Upvalues: p1 (ref), t3 (ref), t (ref) ]]
				local Character = p1.Character

				if not Character then
					return
				end

				for i2, v in ipairs(Character:GetChildren()) do
					if v:IsA("Tool") and not t3[v.Name] then
						t.UnsafeUntil = tick() + 60

						return
					end
				end
			end)

			return
		end

		t.ActiveTimer:Disconnect()
		t.ActiveTimer = nil
		t.ActiveTimer = game:GetService("RunService").Heartbeat:Connect(function() --[[ Line: 51 | Upvalues: p1 (ref), t3 (ref), t (ref) ]]
			local Character = p1.Character

			if not Character then
				return
			end

			for i2, v in ipairs(Character:GetChildren()) do
				if v:IsA("Tool") and not t3[v.Name] then
					t.UnsafeUntil = tick() + 60

					return
				end
			end
		end)
	end

	local function onToolCheck(p1) --[[ onToolCheck | Line: 64 | Upvalues: t3 (ref), t (copy), resetTimer (copy) ]]
		if not p1:IsA("Tool") or t3[p1.Name] then
			return
		end

		t.UnsafeUntil = tick() + 60
		resetTimer()
	end

	p1.CharacterAdded:Connect(function(p1) --[[ Line: 71 | Upvalues: t3 (ref), t (copy), resetTimer (copy), onToolCheck (copy) ]]
		for i, v in ipairs(p1:GetChildren()) do
			if v:IsA("Tool") and not t3[v.Name] then
				t.UnsafeUntil = tick() + 60
				resetTimer()
			end
		end

		p1.ChildAdded:Connect(onToolCheck)
		p1.ChildRemoved:Connect(onToolCheck)
	end)
end
function t.IsSafe(p1) --[[ IsSafe | Line: 81 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	return if v1 then tick() > v1.UnsafeUntil else v1
end
function t.Notify(p1, p2) --[[ Notify | Line: 86 | Upvalues: t2 (copy), Notification (copy) ]]
	local v1 = t2[p1]

	if v1 and not v1.Notified then
		v1.Notified = true
		Notification:FireClient(p1, "Safezone", p2)
		task.delay(1.5, function() --[[ Line: 91 | Upvalues: t2 (ref), p1 (copy) ]]
			if not t2[p1] then
				return
			end

			t2[p1].Notified = false
		end)
	end
end
function t.CanAttack(p1, p2) --[[ CanAttack | Line: 96 | Upvalues: t (copy) ]]
	if p1:GetAttribute("InPVPZone") and p2:GetAttribute("InPVPZone") then
		return true
	end

	local v1 = p1:GetAttribute("Patente") or 0
	local v2 = p2:GetAttribute("Patente") or 0
	local v3 = p1.Team and p1.Team.Name or ""
	local v4 = p2.Team and p2.Team.Name or ""

	if v3 == "[CI] Cidad\195\163o" and v4 == "[CI] Cidad\195\163o" then
		return not t.IsSafe(p1)
	end

	if v1 >= 1 and (v1 <= 4 and (v4 == "[CI] Cidad\195\163o" and not p2:GetAttribute("ToolProibidaEquipada"))) then
		t.Notify(p1, "Voc\195\170 n\195\163o pode atacar este civil pois ele n\195\163o possui uma arma equipada.")

		return false
	end

	if v1 <= 3 and (v4 == "[CI] Cidad\195\163o" and t.IsSafe(p2)) then
		t.Notify(p1, "O jogador est\195\161 na safezone")

		return false
	end

	if v3 == "[CI] Cidad\195\163o" and (v2 >= 1 and t.IsSafe(p2)) then
		t.Notify(p1, "Esse jogador est\195\161 em safezone, n\195\163o pode ser atacado.")

		return false
	end

	return true
end
function t.OnPlayerKilled(p1, p2) --[[ OnPlayerKilled | Line: 139 | Upvalues: t2 (copy), t (copy) ]]
	if not (p1 and p2) then
		return
	end

	local v1 = p1:GetAttribute("Patente") or 0
	local v3 = t2[p1]

	if not (v1 >= 4) or ((p2.Team and p2.Team.Name or "") ~= "[CI] Cidad\195\163o" or not t.IsSafe(p2)) then
		return
	end

	if not v3 then
		return
	end

	if tick() - v3.LastPKReset >= 120 then
		v3.PKKills = 0
		v3.LastPKReset = tick()
	end

	v3.PKKills = v3.PKKills + 1
end
function t.ReachedPKLimit(p1) --[[ ReachedPKLimit | Line: 158 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return false
	end

	if tick() - v1.LastPKReset >= 120 then
		v1.PKKills = 0
		v1.LastPKReset = tick()
	end

	return v1.PKKills >= 3
end
t.IGNORE_TOOLS = t3

return t