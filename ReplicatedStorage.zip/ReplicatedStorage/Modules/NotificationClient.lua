-- https://lua.expert/
local TweenService = game:GetService("TweenService")

game:GetService("UserInputService")
game:GetService("StarterGui")

local ReplicatedStorage = game:GetService("ReplicatedStorage")

game:GetService("ContentProvider")

local SoundService = game:GetService("SoundService")
local Players = game:GetService("Players")
local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui")

SoundService:WaitForChild("UISounds")
require(ReplicatedStorage:WaitForChild("HDAdminSetup")):GetMain()

local t = {}
local t2 = {}

function t.Notification(p1, p2, p3, p4, ...) --[[ Notification | Line: 38 | Upvalues: t2 (copy), PlayerGui (copy), Players (copy), TweenService (copy) ]]
	if p3 and not p4 or p2 and not p3 then
		p3, p4, p2 = "Notifica\195\167\195\163o", p3, "Normal"
	end

	if not (p3 and p4) then
		return
	end

	local v1 = p3 .. "|" .. p4

	if t2[v1] then
		return
	end

	t2[v1] = true
	task.delay(3, function() --[[ Line: 72 | Upvalues: t2 (ref), v1 (copy) ]]
		t2[v1] = nil
	end)

	local Player = PlayerGui:WaitForChild("GameUI"):WaitForChild("Player")
	local t = { ... }
	local v2 = if p2 == "DisplayPlayer" then script:WaitForChild("RobberyNotificationTemplate"):Clone() else script:WaitForChild("NormalNotificationTemplate"):Clone()
	local NotificationHud = Player:WaitForChild("NotificationHud")
	local Title = v2:WaitForChild("Title")
	local Description = v2:WaitForChild("Description")
	local UIScale = v2:WaitForChild("UIScale")
	local v3 = p2 == "DisplayPlayer" and v2:FindFirstChild("PlayerLogo") or nil

	v2.Visible = true
	v2.Parent = NotificationHud
	Title.Text = p3
	Description.Text = p4
	UIScale.Scale = 0.6
	v2.BackgroundTransparency = 1
	Title.TextTransparency = 1
	Description.TextTransparency = 1

	if v3 then
		local v4 = t[1]

		if v4 then
			v3.Image = Players:GetUserThumbnailAsync(v4.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size420x420)
		end

		v3.ImageTransparency = 1
	end

	local v5 = v2.Position + UDim2.fromOffset(0, 20)
	local Position = v2.Position

	v2.Position = v5

	if v3 then
		TweenService:Create(v3, TweenInfo.new(0.35), {
			ImageTransparency = 0
		}):Play()
	end

	TweenService:Create(UIScale, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Scale = 1
	}):Play()
	TweenService:Create(v2, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		BackgroundTransparency = 0.2,
		Position = Position
	}):Play()
	TweenService:Create(Title, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		TextTransparency = 0
	}):Play()
	TweenService:Create(Description, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		TextTransparency = 0
	}):Play()
	task.wait(3)

	if v3 then
		TweenService:Create(v3, TweenInfo.new(0.35), {
			ImageTransparency = 1
		}):Play()
	end

	TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		Scale = 0.7
	}):Play()
	TweenService:Create(v2, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		BackgroundTransparency = 1,
		Position = Position + UDim2.fromOffset(0, 15)
	}):Play()
	TweenService:Create(Title, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		TextTransparency = 1
	}):Play()
	TweenService:Create(Description, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		TextTransparency = 1
	}):Play()
	task.delay(0.25, function() --[[ Line: 193 | Upvalues: v2 (ref) ]]
		v2:Destroy()
	end)
end

return t