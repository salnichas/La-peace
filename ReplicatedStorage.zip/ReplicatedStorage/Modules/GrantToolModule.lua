-- https://lua.expert/
game:GetService("Players")
game:GetService("ReplicatedStorage")

local ServerStorage = game:GetService("ServerStorage")
local Tools = ServerStorage:WaitForChild("Tools")
local Guns = Tools:WaitForChild("Guns")
local Evento = ServerStorage.Tools.Evento

return {
	GivePermItem = function(p1, p2, p3) --[[ GivePermItem | Line: 23 | Upvalues: Tools (copy), Guns (copy) ]]
		local v1 = Tools:FindFirstChild(p3)

		if not v1 then
			v1 = Guns:FindFirstChild(p3)
		end

		if v1 then
			local v3 = v1:Clone()

			v3.Parent = p2:WaitForChild("Backpack")
			v3:Clone().Parent = p2:WaitForChild("StarterGear")
		else
			warn("Tool not found: " .. p3)
		end
	end,
	GiveItem = function(p1, p2, p3) --[[ GiveItem | Line: 48 | Upvalues: Tools (copy), Evento (copy) ]]
		print("GrantToolModule: GiveItem", p2, p3)

		local v1 = Tools:FindFirstChild(p3)
		local v2 = Evento:FindFirstChild(p3)

		if v1 then
			v1:Clone().Parent = p2:WaitForChild("Backpack")

			return
		end

		if v2 then
			v2:Clone().Parent = p2:WaitForChild("Backpack")
		end
	end,
	RemovePermItem = function(p1, p2, p3) --[[ RemovePermItem | Line: 75 ]]
		if not p2 then
			return
		end

		local Character = p2.Character

		if not Character then
			return
		end

		local Humanoid = Character:FindFirstChildOfClass("Humanoid")

		local function RemoveTool(p1) --[[ RemoveTool | Line: 83 | Upvalues: p3 (copy) ]]
			if not p1 then
				return
			end

			local v1 = p1:FindFirstChild(p3)

			if not (v1 and v1:IsA("Tool")) then
				return
			end

			v1:Destroy()
		end

		if Humanoid then
			local v1 = Character:FindFirstChild(p3)

			if v1 and v1:IsA("Tool") then
				Humanoid:UnequipTools()

				local sum = 0

				while Character:FindFirstChild(p3) and sum < 1 do
					sum = sum + task.wait()
				end
			end
		end

		local StarterGear = p2:FindFirstChild("StarterGear")

		if StarterGear then
			local v2 = StarterGear:FindFirstChild(p3)

			if v2 and v2:IsA("Tool") then
				v2:Destroy()
			end
		end

		local Backpack = p2:FindFirstChild("Backpack")

		if Backpack then
			local v3 = Backpack:FindFirstChild(p3)

			if v3 and v3:IsA("Tool") then
				v3:Destroy()
			end
		end

		if not Character then
			return
		end

		local v4 = Character:FindFirstChild(p3)

		if not (v4 and v4:IsA("Tool")) then
			return
		end

		v4:Destroy()
	end
}