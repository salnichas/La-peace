-- https://lua.expert/
return {
	Setup = function(p1) --[[ Setup | Line: 3 ]]
		p1:WaitForChild("Humanoid").BreakJointsOnDeath = false
	end,
	Enable = function(p1) --[[ Enable | Line: 8 ]]
		local Humanoid = p1:FindFirstChild("Humanoid")

		if not Humanoid then
			return
		end

		Humanoid.PlatformStand = true
		Humanoid.AutoRotate = false

		for k, v in pairs(p1:GetDescendants()) do
			if v:IsA("Motor6D") then
				local Attachment = Instance.new("Attachment")
				local Attachment2 = Instance.new("Attachment")

				Attachment.CFrame = v.C0
				Attachment2.CFrame = v.C1
				Attachment.Parent = v.Part0
				Attachment2.Parent = v.Part1

				local BallSocketConstraint = Instance.new("BallSocketConstraint")

				BallSocketConstraint.Attachment0 = Attachment
				BallSocketConstraint.Attachment1 = Attachment2
				BallSocketConstraint.LimitsEnabled = true
				BallSocketConstraint.TwistLimitsEnabled = true
				BallSocketConstraint.Parent = v.Part0
				v.Enabled = false
			end
		end
	end,
	Disable = function(p1) --[[ Disable | Line: 38 ]]
		local Humanoid = p1:FindFirstChild("Humanoid")

		if not Humanoid then
			return
		end

		for k, v in pairs(p1:GetDescendants()) do
			if v:IsA("BallSocketConstraint") or v:IsA("Attachment") then
				v:Destroy()
			end
		end

		for k, v in pairs(p1:GetDescendants()) do
			if v:IsA("Motor6D") then
				v.Enabled = true
			end
		end

		Humanoid.PlatformStand = false
		Humanoid.AutoRotate = true
	end
}