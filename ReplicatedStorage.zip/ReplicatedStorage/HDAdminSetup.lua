-- https://lua.expert/
local t = {
	GetClientFolder = function(p1) --[[ GetClientFolder | Line: 3 ]]
		return game:GetService("ReplicatedStorage"):WaitForChild("HDAdminClient")
	end
}

function t.GetMain(p1, p2) --[[ GetMain | Line: 7 | Upvalues: t (copy) ]]
	local MainFramework = require(t:GetClientFolder():WaitForChild("SharedModules").MainFramework)

	if p2 ~= true then
		MainFramework = MainFramework:CheckInitialized()
	end

	return MainFramework
end

return t