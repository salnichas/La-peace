-- https://lua.expert/
return {
	Apply = function(p1, p2, p3, p4) --[[ Apply | Line: 3 ]]
		if not p2 then
			return
		end

		local HumanoidRootPart = p2:FindFirstChild("HumanoidRootPart")

		if HumanoidRootPart then
			local ImpulseAttachment = Instance.new("Attachment")

			ImpulseAttachment.Name = "ImpulseAttachment"
			ImpulseAttachment.Parent = HumanoidRootPart

			local ImpulseVelocity = Instance.new("LinearVelocity")

			ImpulseVelocity.Name = "ImpulseVelocity"
			ImpulseVelocity.Attachment0 = ImpulseAttachment
			ImpulseVelocity.RelativeTo = Enum.ActuatorRelativeTo.World
			ImpulseVelocity.VectorVelocity = p3.Unit
			ImpulseVelocity.MaxForce = (1 / 0)
			ImpulseVelocity.Parent = HumanoidRootPart
			task.delay(p4 or 0.2, function() --[[ Line: 24 | Upvalues: ImpulseVelocity (copy), ImpulseAttachment (copy) ]]
				if ImpulseVelocity then
					ImpulseVelocity:Destroy()
				end

				if not ImpulseAttachment then
					return
				end

				ImpulseAttachment:Destroy()
			end)
		end
	end
}