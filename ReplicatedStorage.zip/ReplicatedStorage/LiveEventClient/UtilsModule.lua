-- https://lua.expert/
local Players = game:GetService("Players")

game:GetService("RunService")

local TweenService = game:GetService("TweenService")
local Debris = game:GetService("Debris")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

game:GetService("RunService")

return {
	ObjectLook = function(p1, p2) --[[ ObjectLook | Line: 10 ]]
		p1.CFrame = CFrame.lookAt(p1.Position, (Vector3.new(p2.X, p2.Y, p2.Z)))
	end,
	LinearVelocity = function(p1, p2, p3, p4, p5) --[[ LinearVelocity | Line: 14 | Upvalues: Debris (copy) ]]
		local Attachment = Instance.new("Attachment")

		Attachment.Parent = p1

		local LinearVelocity = Instance.new("LinearVelocity")

		LinearVelocity.RelativeTo = Enum.ActuatorRelativeTo.World
		LinearVelocity.VelocityConstraintMode = Enum.VelocityConstraintMode.Vector
		LinearVelocity.MaxForce = 100000
		LinearVelocity.Attachment0 = Attachment
		LinearVelocity.VectorVelocity = p3
		LinearVelocity.Parent = p1
		Debris:AddItem(LinearVelocity, p2)
	end,
	quadraticBezier = function(p1, p2, p3, p4) --[[ quadraticBezier | Line: 44 ]]
		return (1 - p1) ^ 2 * p2 + (1 - p1) * 2 * p1 * p3 + p1 ^ 2 * p4
	end,
	cubicBezier = function(p1, p2, p3, p4, p5) --[[ cubicBezier | Line: 48 ]]
		return (1 - p1) ^ 3 * p2 + (1 - p1) ^ 2 * 3 * p1 * p3 + (1 - p1) * 3 * p1 ^ 2 * p4 + p1 ^ 3 * p5
	end,
	MathSphere = function(p1) --[[ MathSphere | Line: 52 ]]
		local t = {}

		for i = 1, p1 do
			local v1 = math.asin(i * 2 / (p1 + 1) + -1)
			local v2 = 2.399963229728653 * i

			table.insert(t, (Vector3.new(math.cos(v2) * math.cos(v1), math.sin(v2) * math.cos(v1), (math.sin(v1)))))
		end

		return t
	end,
	RaycastParams = function(p1, p2, p3) --[[ RaycastParams | Line: 70 ]]
		local v1 = RaycastParams.new()

		v1.IgnoreWater = p2 or true
		v1.FilterType = Enum.RaycastFilterType[p3] or Enum.RaycastFilterType.Exclude
		v1.FilterDescendantsInstances = p1

		return v1
	end,
	OverlapParams = function(p1, p2, p3) --[[ OverlapParams | Line: 78 ]]
		local v1 = OverlapParams.new()

		v1.FilterType = Enum.RaycastFilterType[p2] or Enum.RaycastFilterType.Exclude
		v1.FilterDescendantsInstances = p1
		v1.MaxParts = p3 or 0
		v1.CollisionGroup = "Default"

		return v1
	end,
	GetDistance = function(p1, p2) --[[ GetDistance | Line: 87 ]]
		return (p1 - p2).Magnitude
	end,
	GetPositionWithRaycastAndResult = function(p1, p2, p3) --[[ GetPositionWithRaycastAndResult | Line: 91 ]]
		local v1 = workspace:Raycast(p1, p2, p3)

		if v1 then
			return {
				Result = v1,
				Position = v1.Position
			}
		end

		return {
			Result = false,
			Position = p1 + p2
		}
	end,
	GetPositionWithRaycast = function(p1, p2, p3) --[[ GetPositionWithRaycast | Line: 101 ]]
		local v1 = workspace:Raycast(p1, p2, p3)

		return if v1 then v1.Position or p1 + p2 else p1 + p2
	end,
	GetRaycastResult = function(p1, p2, p3) --[[ GetRaycastResult | Line: 106 ]]
		return workspace:Raycast(p1, p2, p3) or false
	end,
	ChangeAllColors = function(p1, p2, p3) --[[ ChangeAllColors | Line: 111 ]]
		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("Beam") or (v2:IsA("Trail") or v2:IsA("ParticleEmitter") and not table.find(p3, v2.Name)) then
				v2.Color = ColorSequence.new(p2)
			end
		end
	end,
	TweenAllLight = function(p1, p2, p3) --[[ TweenAllLight | Line: 119 | Upvalues: TweenService (copy) ]]
		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("PointLight") or (v2:IsA("SpotLight") or v2:IsA("SurfaceLight")) then
				TweenService:Create(v2, TweenInfo.new(p3, Enum.EasingStyle.Linear), {
					Brightness = p2
				}):Play()
			end
		end
	end,
	TweenAllDecal = function(p1, p2, p3) --[[ TweenAllDecal | Line: 127 | Upvalues: TweenService (copy) ]]
		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("Decal") or v2:IsA("Texture") then
				TweenService:Create(v2, TweenInfo.new(p3, Enum.EasingStyle.Linear), {
					Transparency = p2
				}):Play()
			end
		end
	end,
	SetObjectProperties = function(p1, p2) --[[ SetObjectProperties | Line: 135 ]]
		for k, v in pairs(p2) do
			p1[k] = v
		end
	end,
	EnableAll = function(p1) --[[ EnableAll | Line: 141 ]]
		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("ParticleEmitter") or v2:IsA("Beam") then
				v2.Enabled = true
			end
		end
	end,
	DisableAll = function(p1) --[[ DisableAll | Line: 149 ]]
		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("ParticleEmitter") or (v2:IsA("Trail") or v2:IsA("Beam")) then
				v2.Enabled = false
			end
		end
	end,
	EmitAll = function(p1) --[[ EmitAll | Line: 157 ]]
		task.spawn(function() --[[ Line: 158 | Upvalues: p1 (copy) ]]
			for v1, v2 in p1:GetDescendants() do
				if v2:IsA("ParticleEmitter") then
					if v2:GetAttribute("EmitDelay") and v2:GetAttribute("EmitDelay") ~= 0 then
						task.delay(v2:GetAttribute("EmitDelay"), function() --[[ Line: 162 | Upvalues: v2 (copy) ]]
							if v2:GetAttribute("EmitDuration") and v2:GetAttribute("EmitDuration") ~= 0 then
								v2.Enabled = true
								task.delay(v2:GetAttribute("EmitDuration"), function() --[[ Line: 166 | Upvalues: v2 (ref) ]]
									v2.Enabled = false
								end)
							else
								v2:Emit(v2:GetAttribute("EmitCount"))
							end
						end)

						continue
					end

					if v2:GetAttribute("EmitDuration") and v2:GetAttribute("EmitDuration") ~= 0 then
						v2.Enabled = true
						task.delay(v2:GetAttribute("EmitDuration"), function() --[[ Line: 175 | Upvalues: v2 (copy) ]]
							v2.Enabled = false
						end)

						continue
					end

					if v2:GetAttribute("EmitCount") and v2:GetAttribute("EmitCount") ~= 0 then
						v2:Emit(v2:GetAttribute("EmitCount"))
					end
				end
			end
		end)
	end,
	GetCharacterInRange = function(p1, p2) --[[ GetCharacterInRange | Line: 187 ]]
		local v1 = workspace:GetDescendants()
		local t = {}

		for i = 1, #v1 do
			local v2 = v1[i]

			if v2:IsA("BasePart") and (v2.Name == "HumanoidRootPart" and (v2.Position - p1).Magnitude <= p2) then
				table.insert(t, v2.Parent)
			end
		end

		return t
	end,
	TweenAllBeams = function(p1, p2, p3, p4, p5, p6, p7) --[[ TweenAllBeams | Line: 205 | Upvalues: TweenService (copy) ]]
		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("Beam") then
				local v4 = TweenInfo.new
				local v5 = if p4 then p4 else Enum.EasingStyle.Linear

				TweenService:Create(v2, v4(p3, v5, if p5 then p5 else Enum.EasingDirection.Out, p6 or 0, p7 or false), p2):Play()
			end
		end
	end,
	SetNetworkOwner = function(p1, p2) --[[ SetNetworkOwner | Line: 213 | Upvalues: Players (copy) ]]
		local v1 = Players:GetPlayerFromCharacter(p2.Parent)

		if p2.Anchored then
			return
		end

		if v1 then
			p2:SetNetworkOwner(v1)
		else
			p2:SetNetworkOwner(p1)
		end
	end,
	GetPlayer = function(p1) --[[ GetPlayer | Line: 224 | Upvalues: Players (copy) ]]
		return Players:GetPlayerFromCharacter(p1)
	end,
	CharacterTransparency = function(p1, p2) --[[ CharacterTransparency | Line: 229 ]]
		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("Decal") or (v2:IsA("Texture") or v2:IsA("BasePart") and v2.Name ~= "HumanoidRootPart") then
				v2.Transparency = p2
			end
		end
	end,
	CreateFakeCharacter = function(p1, p2, p3, p4, p5) --[[ CreateFakeCharacter | Line: 237 | Upvalues: ReplicatedStorage (copy), TweenService (copy) ]]
		task.spawn(function() --[[ Line: 238 | Upvalues: ReplicatedStorage (ref), p1 (copy), p2 (copy), p4 (copy), TweenService (ref), p5 (copy) ]]
			local v1 = ReplicatedStorage.Assets.VFx:FindFirstChild("Player"):FindFirstChild("FakeCharacter"):Clone()

			if not (v1 and p1) then
				return
			end

			local Torso = v1:WaitForChild("Torso")
			local Head = v1:WaitForChild("Head")
			local v2 = v1:WaitForChild("Right Arm")
			local v3 = v1:WaitForChild("Left Arm")
			local v4 = v1:WaitForChild("Right Leg")
			local v5 = v1:WaitForChild("Left Leg")

			Torso.CFrame = p1:WaitForChild("Torso").CFrame
			Head.CFrame = p1:WaitForChild("Head").CFrame
			v2.CFrame = p1:WaitForChild("Right Arm").CFrame
			v3.CFrame = p1:WaitForChild("Left Arm").CFrame
			v4.CFrame = p1:WaitForChild("Right Leg").CFrame
			v5.CFrame = p1:WaitForChild("Left Leg").CFrame
			v1.Parent = game.Workspace.Map.VisualEffects

			if p2 then
				Torso.Color = p2
				Head.Color = p2
				v2.Color = p2
				v3.Color = p2
				v4.Color = p2
				v5.Color = p2
			end

			if p4 then
				task.wait(p4)
			end

			for v6, v7 in v1:GetDescendants() do
				if v7:IsA("BasePart") then
					TweenService:Create(v7, TweenInfo.new(p5 or 0.5), {
						Transparency = 1
					}):Play()
				end
			end

			task.wait(p4 + p5 or 1.5)
			v1:Destroy()
		end)
	end,
	CreateAndTweenPointLight = function(p1, ...) --[[ CreateAndTweenPointLight | Line: 276 | Upvalues: TweenService (copy) ]]
		task.spawn(function() --[[ Line: 277 | Upvalues: p1 (copy), TweenService (ref) ]]
			local Range = p1.Range
			local Brightness = p1.Brightness
			local RangeTweenOne = p1.RangeTweenOne
			local BrightnessTweenOne = p1.BrightnessTweenOne
			local RangeTweenTwo = p1.RangeTweenTwo
			local BrightnessTweenTwo = p1.BrightnessTweenTwo
			local PointLight = Instance.new("PointLight")

			PointLight.Parent = p1.Origin
			PointLight.Color = p1.LightColor

			if p1.Shadow == true then
				PointLight.Shadows = true
			end

			if p1.Skip == true then
				PointLight.Range = Range
				PointLight.Brightness = Brightness
			else
				TweenService:Create(PointLight, TweenInfo.new(RangeTweenOne), {
					Range = Range
				}):Play()
				TweenService:Create(PointLight, TweenInfo.new(BrightnessTweenOne), {
					Brightness = Brightness
				}):Play()
			end

			task.wait(p1.Duration)
			TweenService:Create(PointLight, TweenInfo.new(RangeTweenTwo), {
				Range = 0
			}):Play()
			TweenService:Create(PointLight, TweenInfo.new(BrightnessTweenTwo), {
				Brightness = 0
			}):Play()
			task.wait(RangeTweenTwo + BrightnessTweenTwo or 30)
			PointLight:Destroy()
		end)
	end,
	SetCharacterVisibility = function(p1, p2) --[[ SetCharacterVisibility | Line: 320 ]]
		local FaceObject = p1:FindFirstChild("FaceObject")

		if FaceObject then
			for v1, v2 in FaceObject.Value:GetDescendants() do
				if v2:IsA("Decal") then
					if p2 then
						local v3 = v2:GetAttribute("OriginalTransparency")

						if v3 ~= nil then
							v2.Transparency = v3
							v2:SetAttribute("OriginalTransparency", nil)
						end

						continue
					end

					if v2.Transparency < 1 then
						v2:SetAttribute("OriginalTransparency", v2.Transparency)
						v2.Transparency = 1
					end
				end
			end
		end

		for i, v in ipairs(p1:GetDescendants()) do
			if v:IsA("BasePart") or v:IsA("Decal") then
				if p2 then
					local v4 = v:GetAttribute("OriginalTransparency")

					if v4 ~= nil then
						v.Transparency = v4
						v:SetAttribute("OriginalTransparency", nil)
					end

					continue
				end

				if v.Transparency < 1 then
					v:SetAttribute("OriginalTransparency", v.Transparency)
					v.Transparency = 1
				end

				continue
			end

			if v:IsA("BillboardGui") then
				if p2 then
					local v5 = v:GetAttribute("OriginalEnabled")

					if v5 ~= nil then
						v.Enabled = v5
						v:SetAttribute("OriginalEnabled", nil)
					end

					continue
				end

				v:SetAttribute("OriginalEnabled", v.Enabled)
				v.Enabled = false
			end
		end
	end
}