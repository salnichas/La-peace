-- https://lua.expert/
local PhysicsService = game:GetService("PhysicsService")
local Players = game:GetService("Players")
local StarterPlayer = game:GetService("StarterPlayer")
local t = {
	PlayersCollisionGroup = "Players",
	CanCollide = false
}

if not PhysicsService:IsCollisionGroupRegistered("Uncollidable") then
	PhysicsService:RegisterCollisionGroup("Uncollidable")
	PhysicsService:CollisionGroupSetCollidable("Uncollidable", t.PlayersCollisionGroup, false)
	PhysicsService:CollisionGroupSetCollidable("Uncollidable", "Uncollidable", t.CanCollide)
end

if not PhysicsService:IsCollisionGroupRegistered(t.PlayersCollisionGroup) then
	PhysicsService:RegisterCollisionGroup(t.PlayersCollisionGroup)
	PhysicsService:CollisionGroupSetCollidable("Uncollidable", t.PlayersCollisionGroup, false)
end

function t.Ragdoll(p1, p2) --[[ Ragdoll | Line: 23 | Upvalues: Players (copy) ]]
	if p2:GetAttribute("Ragdoll") then
		return
	end

	local v1 = if Players:GetPlayerFromCharacter(p2) == nil then true else false
	local v2 = p2:FindFirstChildWhichIsA("Humanoid")

	if v2.Health <= 0 then
		return
	end

	if p2:GetAttribute("Dead") then
		return
	end

	if not v2 then
		return
	end

	for v3, v4 in v2:FindFirstChildWhichIsA("Animator"):GetPlayingAnimationTracks() do
		v4:Stop()
	end

	if p2:FindFirstChild("AirComboAlignPosition") then
		p2:FindFirstChild("AirComboAlignPosition"):Destroy()
	end

	p2:SetAttribute("Ragdoll", true)
	v2.BreakJointsOnDeath = false
	v2.AutoRotate = false
	v2.RequiresNeck = false
	v2.WalkSpeed = 0
	v2.JumpPower = 0
	v2:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, true)
	v2:SetStateEnabled(Enum.HumanoidStateType.Jumping, false)
	v2:SetStateEnabled(Enum.HumanoidStateType.Running, false)
	v2:SetStateEnabled(Enum.HumanoidStateType.GettingUp, false)
	p2:FindFirstChild("HumanoidRootPart").CanCollide = false

	if v1 then
		local function v5() --[[ PushCharacter | Line: 58 | Upvalues: v2 (copy), p2 (copy), v5 (copy) ]]
			v2:ChangeState(Enum.HumanoidStateType.Ragdoll)
			v2:SetStateEnabled(Enum.HumanoidStateType.GettingUp, false)
			v2:SetStateEnabled(Enum.HumanoidStateType.Running, false)
			p2.PrimaryPart:ApplyImpulse(-p2.PrimaryPart.CFrame.LookVector * 200)
			task.delay(0.1, function() --[[ Line: 65 | Upvalues: v2 (ref), v5 (ref) ]]
				if v2:GetState() == Enum.HumanoidStateType.Ragdoll then
					return
				end

				v5()
			end)
		end

		v2.PlatformStand = true
		v5()
	end

	p1:ReplaceJoints(p2)
end
function t.unRagdoll(p1, p2) --[[ unRagdoll | Line: 81 | Upvalues: Players (copy), StarterPlayer (copy) ]]
	if not p2:GetAttribute("Ragdoll") or p2:GetAttribute("Downed") and not p2:GetAttribute("BeingCarried") then
		return
	end

	local v1 = if Players:GetPlayerFromCharacter(p2) == nil then true else false
	local v2 = p2:FindFirstChildWhichIsA("Humanoid")

	if v2.Health <= 0 then
		return
	end

	if p2:GetAttribute("Dead") then
		return
	end

	if not v2 then
		return
	end

	if v2.Health <= 0.1 then
		return
	end

	p1:ResetJoints(p2)
	p2:SetAttribute("Ragdoll", false)
	v2.AutoRotate = true
	v2.RequiresNeck = true
	v2.WalkSpeed = StarterPlayer.CharacterWalkSpeed
	v2.JumpPower = StarterPlayer.CharacterJumpPower
	v2:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
	v2:SetStateEnabled(Enum.HumanoidStateType.GettingUp, true)
	v2:SetStateEnabled(Enum.HumanoidStateType.Jumping, true)
	v2:SetStateEnabled(Enum.HumanoidStateType.Running, true)
	p2:FindFirstChild("HumanoidRootPart").CanCollide = true

	if not v1 then
		return
	end

	if not p2:GetAttribute("BeingCarried") then
		v2:ChangeState(Enum.HumanoidStateType.GettingUp)
	end

	v2.PlatformStand = false
end

local t2 = {
	Neck = { CFrame.new(0, 1, 0, 0, -1, 0, 1, 0, -0, 0, 0, 1), CFrame.new(0, -0.5, 0, 0, -1, 0, 1, 0, -0, 0, 0, 1) },
	["Left Shoulder"] = { CFrame.new(-1.3, 0.75, 0, -1, 0, 0, 0, -1, 0, 0, 0, 1), CFrame.new(0.2, 0.75, 0, -1, 0, 0, 0, -1, 0, 0, 0, 1) },
	["Right Shoulder"] = { CFrame.new(1.3, 0.75, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.2, 0.75, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1) },
	["Left Hip"] = { CFrame.new(-0.5, -1, 0, 0, 1, -0, -1, 0, 0, 0, 0, 1), CFrame.new(0, 1, 0, 0, 1, -0, -1, 0, 0, 0, 0, 1) },
	["Right Hip"] = { CFrame.new(0.5, -1, 0, 0, 1, -0, -1, 0, 0, 0, 0, 1), CFrame.new(0, 1, 0, 0, 1, -0, -1, 0, 0, 0, 0, 1) }
}
local t3 = {
	RagdollAttachment = true,
	RagdollConstraint = true,
	ColliderPart = true
}

function t.CreateColliderPart(p1, p2, p3) --[[ CreateColliderPart | Line: 135 | Upvalues: Players (copy) ]]
	if not p3 then
		return
	end

	local ColliderPart = Instance.new("Part")

	ColliderPart.Name = "ColliderPart"
	ColliderPart.Size = p3.Size / 1.7
	ColliderPart.Massless = true
	ColliderPart.CanCollide = true
	ColliderPart.CFrame = p3.CFrame
	ColliderPart.Transparency = 1
	ColliderPart.CollisionGroup = "Uncollidable"

	local WeldConstraint = Instance.new("WeldConstraint")

	WeldConstraint.Part0 = ColliderPart
	WeldConstraint.Part1 = p3
	WeldConstraint.Parent = ColliderPart
	ColliderPart.Parent = p3

	if not Players:GetPlayerFromCharacter(p2) then
		return
	end

	ColliderPart:SetNetworkOwner(Players:GetPlayerFromCharacter(p2))
end
function t.ReplaceJoints(p1, p2) --[[ ReplaceJoints | Line: 160 | Upvalues: t2 (copy) ]]
	p2:FindFirstChildWhichIsA("Humanoid")

	for v1, v2 in p2:GetDescendants() do
		if v2:IsA("Motor6D") and t2[v2.Name] then
			v2.Enabled = false

			local RagdollAttachment = Instance.new("Attachment")
			local RagdollAttachment2 = Instance.new("Attachment")

			RagdollAttachment.CFrame = t2[v2.Name][1]
			RagdollAttachment2.CFrame = t2[v2.Name][2]
			RagdollAttachment.Name = "RagdollAttachment"
			RagdollAttachment2.Name = "RagdollAttachment"
			p1:CreateColliderPart(p2, v2.Part1)

			local RagdollConstraint = Instance.new("BallSocketConstraint")

			RagdollConstraint.Attachment0 = RagdollAttachment
			RagdollConstraint.Attachment1 = RagdollAttachment2
			RagdollConstraint.Name = "RagdollConstraint"
			RagdollConstraint.Radius = 0.15
			RagdollConstraint.LimitsEnabled = true
			RagdollConstraint.TwistLimitsEnabled = true
			RagdollConstraint.MaxFrictionTorque = 1000
			RagdollConstraint.Restitution = 0
			RagdollConstraint.UpperAngle = 45
			RagdollConstraint.TwistLowerAngle = -70
			RagdollConstraint.TwistUpperAngle = 70
			RagdollAttachment.Parent = v2.Part0
			RagdollAttachment2.Parent = v2.Part1
			RagdollConstraint.Parent = v2.Parent
		end
	end
end
function t.ResetJoints(p1, p2) --[[ ResetJoints | Line: 197 | Upvalues: t3 (copy) ]]
	local v1 = p2:FindFirstChildWhichIsA("Humanoid")

	if not v1 then
		return
	end

	if v1.Health < 0.1 then
		return
	end

	for v2, v3 in p2:GetDescendants() do
		if t3[v3.Name] then
			v3:Destroy()
		end

		if v3:IsA("Motor6D") then
			v3.Enabled = true
		end
	end
end

return t