-- https://lua.expert/
return {
	["9x39mm"] = Vector3.new(0.5, 0.5, 0.01),
	["7.62"] = Vector3.new(0.5, 0.5, 0.01),
	["5.56"] = Vector3.new(0.4, 0.4, 0.01),
	[".223 Rem"] = Vector3.new(0.35, 0.35, 0.01),
	["9mm"] = Vector3.new(0.25, 0.25, 0.01),
	[".38 TPC"] = Vector3.new(0.24, 0.24, 0.01),
	["5,7x28mm"] = Vector3.new(0.24, 0.24, 0.01),
	[".50 AE"] = Vector3.new(0.4, 0.4, 0.01),
	[".40 S&W"] = Vector3.new(0.3, 0.3, 0.01),
	[".44 Magnum"] = Vector3.new(0.4, 0.4, 0.01),
	[".38 SPL"] = Vector3.new(0.22, 0.22, 0.01),
	[".32 S&W"] = Vector3.new(0.2, 0.2, 0.01)
}