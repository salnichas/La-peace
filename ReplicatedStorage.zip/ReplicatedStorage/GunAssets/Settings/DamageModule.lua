-- https://lua.expert/
local t = {}
local t2 = {
	["[CI] Cidad\195\163o"] = "Civil",
	["[EB] Ex\195\169rcito Brasileiro"] = "Militar",
	["[OF] Oficiais"] = "Militar",
	["[BAC] Batalh\195\163o de A\195\167\195\181es de Comandos"] = "Militar",
	["[BPE] Batalh\195\163o da Policia do Ex\195\169rcito"] = "Militar",
	["[BFE] Batalh\195\163o de For\195\167as Especiais"] = "Militar",
	["[CIE] Centro de Intelig\195\170ncia do Ex\195\169rcito"] = "Militar",
	["[AVEx] - Avia\195\167\195\163o do Ex\195\169rcito"] = "Militar",
	["[BIP] Brigada de Infantaria Paraquedista"] = "Militar",
	["[CAAT] Batalh\195\163o de Infantaria de Caatinga"] = "Militar",
	["[CIGS] Centro de Instru\195\167\195\163o de Guerra na Selva"] = "Militar",
	["[REC MEC] Regimento de Cavalaria Mecanizado"] = "Militar",
	["[CYBER] Comando de Defesa Cibern\195\169tica"] = "Militar"
}
local t3 = { game.CreatorId, 294926722, 9995428601 }

function t.CanDamage(p1, p2) --[[ CanDamage | Line: 33 | Upvalues: t3 (copy), t2 (copy) ]]
	if not (p1 and p2) then
		return false
	end

	if p1:GetAttribute("SpawnSafe") or p2:GetAttribute("SpawnSafe") then
		return false
	end

	local Character2 = p2.Character

	if not (p1.Character and Character2) then
		return false
	end

	if table.find(t3, p1.UserId) then
		return true
	end

	if p1:GetAttribute("Nadando") then
		return false
	end

	if not (p1.Team and p2.Team) then
		return false
	end

	local v1 = t2[p1.Team.Name]
	local v2 = t2[p2.Team.Name]

	if not (v1 and v2) then
		return false
	end

	if p1:GetAttribute("InPVPZone") and p2:GetAttribute("InPVPZone") then
		return true
	end

	if p1:GetAttribute("SendoRecrutadoPor") and v1 == "Civil" then
		return false
	end

	if v1 == v2 then
		return false
	end

	local v3 = 0
	local PlayerInfos = p1:FindFirstChild("PlayerInfos")

	if not PlayerInfos then
		return false
	end

	local v4 = PlayerInfos:GetAttribute("EB_Rank")

	if p1:GetAttribute("Safezone") or p2:GetAttribute("Safezone") then
		return p2:GetAttribute("Procurado") and true or false
	end

	if v1 == "Militar" and v2 == "Civil" then
		local RoubosInfos = p2:FindFirstChild("RoubosInfos")

		if RoubosInfos and RoubosInfos:GetAttribute("RouboAtivo") ~= "N/A" then
			return true
		end

		if Character2:GetAttribute("Procurado") then
			return true
		end
	end

	if v1 == "Militar" and p2:GetAttribute("MilitaryZone") then
		local Gamepasses = p2:FindFirstChild("Gamepasses")

		if v4 >= 4 then
			if Gamepasses and Gamepasses:GetAttribute("PASSELIVRE") then
				return false
			end

			return (not p2:GetAttribute("SendoRecrutadoPor") or p2:GetAttribute("SendoRecrutadoPor") == p1.Name) and true or false
		end
	end

	if v1 == "Militar" and v4 and typeof(v4) == "number" then
		v3 = v4
	end

	if v1 == "Militar" and (v3 >= 9 and v2 == "Civil") then
		return true
	end

	if v1 == "Militar" and (v3 >= 4 and (v3 <= 8 and (v2 == "Civil" and (p1:GetAttribute("GraduadoKills") or 0) < 2))) then
		return true
	end

	return v1 == "Civil" and (v2 == "Militar" and Character2:GetAttribute("Procurado")) and true or false
end

return t