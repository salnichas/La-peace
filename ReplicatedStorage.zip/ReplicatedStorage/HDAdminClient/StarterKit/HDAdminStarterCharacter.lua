-- https://lua.expert/
local v1 = require(game:GetService("ReplicatedStorage"):WaitForChild("HDAdminSetup")):GetMain()

v1.humanoidRigType = (v1.player.Character or v1.player.CharacterAdded:Wait()):WaitForChild("Humanoid").RigType
wait(1)

for k, v in pairs(v1.commandSpeeds) do
	if v1.commandsActive[k] then
		v1.commandsActive[k] = nil
		v1:GetModule("cf"):ActivateClientCommand(k)
	end
end