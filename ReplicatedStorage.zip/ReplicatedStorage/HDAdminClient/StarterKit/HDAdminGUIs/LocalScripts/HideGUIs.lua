-- https://lua.expert/
local t = {
	Notices = true
}

for k, v in pairs(script.Parent.Parent:GetChildren()) do
	if v:IsA("Frame") then
		if t[v.Name] then
			v.Visible = true

			continue
		end

		v.Visible = false

		continue
	end

	if v:IsA("Folder") then
		for k2, v2 in pairs(v:GetChildren()) do
			if v2:IsA("Frame") then
				v2.Visible = false
			end
		end
	end
end