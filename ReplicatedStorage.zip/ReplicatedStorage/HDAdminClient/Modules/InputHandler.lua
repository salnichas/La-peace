-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local MouseMovement = Enum.UserInputType.MouseMovement
local MouseButton1 = Enum.UserInputType.MouseButton1
local Touch = Enum.UserInputType.Touch

HDAdminMain.chatting = false
HDAdminMain.userInputService.TextBoxFocused:connect(function() --[[ Line: 18 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain.chatting = true
end)
HDAdminMain.userInputService.TextBoxFocusReleased:connect(function() --[[ Line: 21 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain.chatting = false
end)

local ChatInputBarConfiguration = game:GetService("TextChatService"):FindFirstChildOfClass("ChatInputBarConfiguration")

if ChatInputBarConfiguration then
	ChatInputBarConfiguration:GetPropertyChangedSignal("IsFocused"):Connect(function() --[[ Line: 27 | Upvalues: HDAdminMain (copy), ChatInputBarConfiguration (copy) ]]
		HDAdminMain.chatting = ChatInputBarConfiguration.IsFocused
	end)
end

local v1 = nil
local v2 = nil
local v3 = nil

local function dragFrame(p1, p2) --[[ dragFrame | Line: 39 | Upvalues: v2 (ref), v3 (ref) ]]
	local v1 = p1.Position - v2

	p2.Position = UDim2.new(v3.X.Scale, v3.X.Offset + v1.X, v3.Y.Scale, v3.Y.Offset + v1.Y)

	if not (p2.AbsolutePosition.Y < -80) then
		return
	end

	p2.Position = p2.Position + UDim2.new(0, 0, 0, -p2.AbsolutePosition.Y)
end

function t.MakeFrameDraggable(p1, p2) --[[ MakeFrameDraggable | Line: 46 | Upvalues: MouseButton1 (copy), Touch (copy), v1 (ref), v2 (ref), v3 (ref) ]]
	p2.DragBar.Drag.InputBegan:Connect(function(p1) --[[ Line: 48 | Upvalues: MouseButton1 (ref), Touch (ref), v1 (ref), p2 (copy), v2 (ref), v3 (ref) ]]
		if p1.UserInputType ~= MouseButton1 and p1.UserInputType ~= Touch then
			return
		end

		v1 = p2
		v2 = p1.Position
		v3 = p2.Position
		p1.Changed:Connect(function() --[[ Line: 53 | Upvalues: p1 (copy), v1 (ref) ]]
			if p1.UserInputState ~= Enum.UserInputState.End then
				return
			end

			v1 = nil
		end)
	end)
end

for k, v in pairs({ HDAdminMain.gui.MainFrame }) do
	t:MakeFrameDraggable(v)
end

local t2 = { "laserEyes" }

local function checkPressFunctions(p1) --[[ checkPressFunctions | Line: 70 | Upvalues: HDAdminMain (copy), t2 (copy) ]]
	HDAdminMain.lastHitPosition = p1

	for k, v in pairs(t2) do
		HDAdminMain:GetModule("cf"):ActivateClientCommand(v)
	end
end

HDAdminMain.userInputService.InputChanged:Connect(function(p1, p2) --[[ Line: 78 | Upvalues: MouseMovement (copy), Touch (copy), v1 (ref), HDAdminMain (copy), dragFrame (copy), checkPressFunctions (copy) ]]
	if p1.UserInputType ~= MouseMovement and p1.UserInputType ~= Touch then
		return
	end

	if p2 and not v1 or (not HDAdminMain.mouseDown or not ((HDAdminMain.lastHitPosition - p1.Position).magnitude < 150) and HDAdminMain.device == "Mobile") then
		return
	end

	if v1 then
		dragFrame(p1, v1)
	end

	checkPressFunctions(p1.Position)
end)

local CmdBar = HDAdminMain.gui.CmdBar
local TextBox = CmdBar.SearchFrame.TextBox
local t3 = {
	[Enum.KeyCode.Left] = true,
	[Enum.KeyCode.Right] = true,
	[Enum.KeyCode.Up] = true,
	[Enum.KeyCode.Down] = true
}
local t4 = {
	[Enum.KeyCode.Left] = "Left",
	[Enum.KeyCode.Right] = "Right",
	[Enum.KeyCode.Up] = "Forwards",
	[Enum.KeyCode.Down] = "Backwards",
	[Enum.KeyCode.A] = "Left",
	[Enum.KeyCode.D] = "Right",
	[Enum.KeyCode.W] = "Forwards",
	[Enum.KeyCode.S] = "Backwards",
	[Enum.KeyCode.Space] = "Up",
	[Enum.KeyCode.R] = "Up",
	[Enum.KeyCode.Q] = "Down",
	[Enum.KeyCode.LeftControl] = "Down",
	[Enum.KeyCode.F] = "Down"
}

HDAdminMain.movementKeysPressed = {}
HDAdminMain.userInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 98 | Upvalues: MouseButton1 (copy), Touch (copy), v1 (ref), HDAdminMain (copy), checkPressFunctions (copy), CmdBar (copy), TextBox (copy), t4 (copy), t3 (copy) ]]
	local v12, v2

	if p1.UserInputType == MouseButton1 or p1.UserInputType == Touch then
		if p2 and not v1 or HDAdminMain.mouseDown then
			if not HDAdminMain.chatting or CmdBar.Visible and #TextBox.Text < 2 then
				v12 = t4[p1.KeyCode]

				if v12 then
					v2 = HDAdminMain.movementKeysPressed
					table.insert(v2, v12)
				elseif p1.KeyCode == Enum.KeyCode.E then
					for k2, v in pairs(HDAdminMain.commandSpeeds) do
						if HDAdminMain.commandsActive[k2] then
							HDAdminMain:GetModule("cf"):EndCommand(k2)

							continue
						end

						HDAdminMain:GetModule("cf"):ActivateClientCommand(k2)
					end
				elseif p1.KeyCode == Enum.KeyCode.Quote or p1.KeyCode == Enum.KeyCode.Semicolon then
					HDAdminMain:GetModule("CmdBar"):ToggleBar(p1.KeyCode)
				end
			end
		else
			HDAdminMain.mouseDown = true
			checkPressFunctions(p1.Position)
		end
	elseif not HDAdminMain.chatting or CmdBar.Visible and #TextBox.Text < 2 then
		v12 = t4[p1.KeyCode]

		if v12 then
			v2 = HDAdminMain.movementKeysPressed
			table.insert(v2, v12)
		elseif p1.KeyCode == Enum.KeyCode.E then
			for k2, v in pairs(HDAdminMain.commandSpeeds) do
				if HDAdminMain.commandsActive[k2] then
					HDAdminMain:GetModule("cf"):EndCommand(k2)

					continue
				end

				HDAdminMain:GetModule("cf"):ActivateClientCommand(k2)
			end
		elseif p1.KeyCode == Enum.KeyCode.Quote or p1.KeyCode == Enum.KeyCode.Semicolon then
			HDAdminMain:GetModule("CmdBar"):ToggleBar(p1.KeyCode)
		end
	end

	if not t3[p1.KeyCode] then
		return
	end

	HDAdminMain:GetModule("CmdBar"):PressedArrowKey(p1.KeyCode)
end)
HDAdminMain.userInputService.InputEnded:Connect(function(p1, p2) --[[ Line: 123 | Upvalues: t4 (copy), MouseButton1 (copy), Touch (copy), HDAdminMain (copy) ]]
	local v1 = t4[p1.KeyCode]

	if p1.UserInputType == MouseButton1 or p1.UserInputType == Touch then
		HDAdminMain.mouseDown = false

		return
	end

	if not v1 then
		return
	end

	for k, v in pairs(HDAdminMain.movementKeysPressed) do
		if v == v1 then
			table.remove(HDAdminMain.movementKeysPressed, k)
		end
	end
end)

local Humanoid = (HDAdminMain.player.Character or HDAdminMain.player.CharacterAdded:Wait()):WaitForChild("Humanoid")
local v5 = HDAdminMain:GetModule("Events")

if HDAdminMain.device == "Computer" then
	return t
end

v5:New("DoubleJumped", Humanoid).Event:Connect(function() --[[ Line: 142 | Upvalues: HDAdminMain (copy) ]]
	for k, v in pairs(HDAdminMain.commandSpeeds) do
		if HDAdminMain.commandsActive[k] then
			HDAdminMain:GetModule("cf"):EndCommand(k)

			continue
		end

		HDAdminMain:GetModule("cf"):ActivateClientCommand(k)
	end
end)

return t