-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain
local t2 = {
	custom = HDAdminMain.gui.MainFrame.Pages.Settings.Custom
}
local v1 = HDAdminMain.settings.ThemeColors or {
	{ "Red", Color3.fromRGB(150, 0, 0) },
	{ "Orange", Color3.fromRGB(150, 75, 0) },
	{ "Brown", Color3.fromRGB(120, 80, 30) },
	{ "Yellow", Color3.fromRGB(130, 120, 0) },
	{ "Green", Color3.fromRGB(0, 120, 0) },
	{ "Blue", Color3.fromRGB(0, 100, 150) },
	{ "Purple", Color3.fromRGB(100, 0, 150) },
	{ "Pink", Color3.fromRGB(150, 0, 100) },
	{ "Black", Color3.fromRGB(60, 60, 60) }
}
local v2 = t2.custom["AB ThemeSelection"]

local function updateThemeSelection(p1, p2) --[[ updateThemeSelection | Line: 33 | Upvalues: v1 (copy), HDAdminMain (copy), v2 (copy) ]]
	if p1 == nil then
		for k, v in pairs(v1) do
			if v[1] == HDAdminMain.pdata.Theme then
				p1 = v[1]
				p2 = v[2]

				break
			end
		end
	end

	if not p1 then
		return
	end

	local tbl = {}

	for k, v in pairs(HDAdminMain.gui:GetDescendants()) do
		if v:IsA("BoolValue") and v.Name == "Theme" then
			table.insert(tbl, v.Parent)
		end
	end

	for k, v in pairs(tbl) do
		local v22

		if v.Theme.Value then
			local v3, v4, v5 = Color3.toHSV(p2)

			v22 = Color3.fromHSV(v3, v4, v5 * 1.35)
		else
			v22 = p2
		end

		if v:IsA("TextLabel") then
			local v7, v8, v9 = Color3.toHSV(p2)

			v.TextColor3 = Color3.fromHSV(v7, v8, v9 * 2)

			continue
		end

		v.BackgroundColor3 = v22
	end

	for k, v in pairs(v2:GetChildren()) do
		if v:IsA("TextButton") then
			if v.Name == p1 then
				v.BorderSizePixel = 1

				continue
			end

			v.BorderSizePixel = 0
		end
	end
end

local v3 = 6.1 / #v1
local v4 = true

for k, v in pairs(v1) do
	local v5 = v[1]
	local v6 = v[2]
	local v7 = v2.ThemeTemplate:Clone()

	v7.Name = v5
	v7.UIAspectRatioConstraint.AspectRatio = v3
	v7.BackgroundColor3 = v6
	v7.MouseButton1Down:Connect(function() --[[ Line: 82 | Upvalues: v4 (ref), HDAdminMain (copy), v5 (copy), updateThemeSelection (copy), v6 (copy) ]]
		if not v4 then
			return
		end

		v4 = false
		HDAdminMain.signals.ChangeSetting:InvokeServer({ "Theme", v5 })
		updateThemeSelection(v5, v6)
		v4 = true
	end)
	v7.Visible = true
	v7.Parent = v2
end

local function updateSettings() --[[ updateSettings | Line: 106 | Upvalues: t2 (copy), HDAdminMain (copy), updateThemeSelection (copy) ]]
	for k, v in pairs(t2.custom:GetChildren()) do
		local v2 = string.sub(v.Name, 5)

		if v:FindFirstChild("SettingValue") then
			v.SettingName.TextLabel.Text = v2 .. "o:"

			local v3 = HDAdminMain.pdata[v2]

			v.SettingValue.TextBox.Text = tostring(v3)

			local v4 = nil
			local v5 = nil

			if string.sub(v2, 1, 5) == "Error" then
				v4 = "Error"
				v5 = 6
			elseif string.sub(v2, 1, 6) == "Notice" then
				v4 = "Notice"
				v5 = 7
			end

			if v4 then
				local v7 = string.sub(v2, v5)

				if v7 == "SoundId" then
					v3 = "rbxassetid://" .. v3
				end

				HDAdminMain.audio[v4][v7] = v3
			end
		end
	end

	updateThemeSelection()
end

for k, v in pairs(t2.custom:GetChildren()) do
	local v9 = string.sub(v.Name, 5)

	if v:FindFirstChild("SettingValue") then
		local v10 = true
		local TextBox = v.SettingValue.TextBox
		local TextLabel = v.SettingValue.TextLabel

		v.SettingValue.TextBox.FocusLost:connect(function(p1) --[[ Line: 140 | Upvalues: v10 (ref), v (copy), TextBox (copy), TextLabel (copy), HDAdminMain (copy), v9 (copy), updateSettings (copy) ]]
			if not v10 then
				return
			end

			local Text = v.SettingValue.TextBox.Text

			v10 = false
			TextBox.Visible = false
			TextLabel.Visible = true
			TextLabel.Text = "Carregando..."

			local v1 = HDAdminMain.signals.ChangeSetting:InvokeServer({ v9, Text })

			if v1 == "Sucesso" then
				updateSettings()

				local v3 = string.sub(v9, 1, 5)
				local v4 = if v3 == "Error" or v3 == "Alert" then v3 else "Notice"

				if v9 == "Prefixo" then
					HDAdminMain:GetModule("PageCommands"):CreateCommands()
				end

				local v5 = "Trocado com sucesso \'" .. v9 .. "\' para \'" .. Text .. "\'"

				if v4 == "Alert" then
					HDAdminMain:GetModule("cf"):CreateNewCommandMenu("settings", { "Settings Alert", v5 }, 8, true)
				else
					HDAdminMain:GetModule("Notices"):Notice(v4, "Settings", v5)
				end
			else
				TextLabel.Text = v1
				wait(1)
			end

			TextBox.Visible = true
			TextLabel.Visible = false
			v.SettingValue.TextBox.Text = tostring(HDAdminMain.pdata[v9])
			v10 = true
		end)
	end
end

updateSettings()

local v11 = t2.custom["AX Restore"]
local Loading = v11.Loading
local v12 = 0

v11.MouseButton1Down:Connect(function() --[[ Line: 182 | Upvalues: v12 (ref), v11 (copy), Loading (copy), HDAdminMain (copy), updateSettings (copy) ]]
	if not (v12 < 2) then
		return
	end

	local v1, v2, v3 = Color3.toHSV(v11.BackgroundColor3)

	Loading.BackgroundColor3 = Color3.fromHSV(v1, v2, v3 * 0.5)
	Loading.Visible = true

	if v12 == 0 then
		v12 = 1
		Loading.Blocker.Visible = false
		Loading.TextLabel.Text = "CONFIRMA?"
		wait(1)
	elseif v12 == 1 then
		v12 = 2
		Loading.Blocker.Visible = true
		Loading.TextLabel.Text = "CARREGANDO..."

		local v4 = HDAdminMain.signals.RestoreDefaultSettings:InvokeServer()

		if v4 == "RESTAURADO!" then
			updateSettings()
			HDAdminMain:GetModule("PageCommands"):CreateCommands()

			local v5 = HDAdminMain:GetModule("cf"):FormatNotice("RestoreDefaultSettings")

			HDAdminMain:GetModule("Notices"):Notice("Notice", v5[1], v5[2])
		else
			v11.TextLabel.Text = v4
		end

		wait(1)
	end

	v12 = 0
	Loading.Visible = false
	Loading.Blocker.Visible = false
end)

local v14 = t2.custom["AZ Space"]

t2.custom.CanvasSize = UDim2.new(0, 0, 0, v14.AbsolutePosition.Y - t2.custom["AA Space"].AbsolutePosition.Y + v14.AbsoluteSize.Y * 1)

return {}