-- https://lua.expert/
return {
	{
		{ 5, "Criadores" },
		{
			"deltafisical",
			{ "Criador", "Programador, Ui Designer e Construtor" }
		},
		{
			"uDavidII",
			{ "Programador" }
		}
	},
	{
		{ 5, "Contribuidores" }
	}
}