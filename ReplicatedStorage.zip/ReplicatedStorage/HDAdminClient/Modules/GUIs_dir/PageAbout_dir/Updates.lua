-- https://lua.expert/
return {
	{
		{ 9972071991, "06/04/2026" },
		{ "comando ;char corrigido" }
	}
}