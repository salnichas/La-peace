-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local Admin = HDAdminMain.gui.MainFrame.Pages.Admin
local BuyFrame = HDAdminMain.warnings.BuyFrame
local UnBan = HDAdminMain.warnings.UnBan
local t2 = {
	ranks = Admin.Ranks,
	serverRanks = Admin["Server Ranks"],
	banland = Admin.Banland
}
local t3 = {
	rankTitle = t2.ranks.TemplateRankTitle,
	rankItem = t2.ranks.TemplateRankItem,
	space = t2.ranks.TemplateSpace,
	admin = t2.serverRanks.TemplateAdmin,
	ban = t2.banland.TemplateBan,
	banTitle = t2.banland.TemplateTitle
}
local t4 = {
	{ "friends", HDAdminMain.ownerName .. "\'s Friends", "Para amigos do criador" },
	{ "freeadmin", "Free Admin", "For everyone" },
	{ "vipserverowner", "VIP Server Owner", "For VIP Server owners" },
	{ "vipserverplayer", "VIP Server Player", "For VIP Server players" }
}

function t.SetupRanks(p1) --[[ SetupRanks | Line: 37 | Upvalues: t (copy) ]]
	t:CreateRanks()
end
function t.CreateRanks(p1) --[[ CreateRanks | Line: 44 | Upvalues: HDAdminMain (copy), t4 (copy), t2 (copy), t3 (copy), BuyFrame (copy) ]]
	coroutine.wrap(function() --[[ Line: 45 | Upvalues: HDAdminMain (ref), t4 (ref), t2 (ref), t3 (ref), BuyFrame (ref) ]]
		local v1 = HDAdminMain.signals.RetrieveRanksInfo:InvokeServer()
		local PermRanks = v1.PermRanks
		local Permissions = v1.Permissions
		local tbl = {}
		local t = {}

		for k, v in pairs(v1.Ranks) do
			table.insert(tbl, 1, {
				v[1],
				v[2],
				{}
			})
		end

		for k, v in pairs(tbl) do
			t[v[1]] = k
		end

		for k, v in pairs(Permissions) do
			if k == "owner" and t[5] then
				table.insert(tbl[t[5]][3], { HDAdminMain.ownerName, "Owner", HDAdminMain:GetModule("cf"):GetUserImage(HDAdminMain.ownerId) })

				continue
			end

			if k == "specificusers" then
				for k2, v2 in pairs(v) do
					if #k2 > 1 then
						local t5 = { k2, "Specific User", HDAdminMain:GetModule("cf"):GetUserImage(HDAdminMain:GetModule("cf"):GetUserId(k2)) }

						table.insert(tbl[t[v2]][3], t5)
					end
				end

				for k2, v2 in pairs(PermRanks) do
					if not v2.RemoveRank then
						local v5 = tbl[t[v2.Rank]]

						if v5 then
							local t5 = {
								HDAdminMain:GetModule("cf"):GetName(v2.UserId),
								"PermRank",
								HDAdminMain:GetModule("cf"):GetUserImage(v2.UserId),
								v2
							}

							table.insert(v5[3], t5)
						end
					end
				end

				continue
			end

			if k == "gamepasses" then
				for k2, v2 in pairs(v) do
					if not HDAdminMain:GetModule("cf"):FindValue(HDAdminMain.products, k2) then
						local v7 = tbl[t[v2.Rank]]

						if v7 then
							local t5 = {
								v2.Name,
								"Gamepass",
								v2.IconImageAssetId,
								tonumber(k2),
								v2.PriceInRobux
							}

							table.insert(v7[3], t5)
						end
					end
				end

				continue
			end

			if k == "assets" then
				for k2, v2 in pairs(v) do
					local v9 = tbl[t[v2.Rank]]

					if v9 then
						local t5 = {
							v2.Name,
							"Asset",
							HDAdminMain:GetModule("cf"):GetAssetImage(k2),
							tonumber(k2),
							v2.PriceInRobux
						}

						table.insert(v9[3], t5)
					end
				end

				continue
			end

			if k == "groups" then
				for k2, v2 in pairs(v) do
					for k3, v3 in pairs(v2.Roles) do
						if v3.Rank then
							local v11 = tbl[t[v3.Rank]]

							if v11 then
								local t5 = {
									v2.Name .. " | " .. k3,
									"Group",
									v2.EmblemUrl,
									(tonumber(k2))
								}

								table.insert(v11[3], t5)
							end
						end
					end
				end

				continue
			end

			if t4[k] then
				local v13 = t4[k]
				local v14 = Permissions[v13[1]]

				if v14 > 0 then
					local v15 = tbl[t[v14]]

					if v15 then
						local t5 = {}
						local upper = string.upper

						t5[1] = v13[2]
						t5[2] = v13[3]
						t5[3] = upper((string.sub(v13[1], 1, 1)))
						table.insert(v15[3], t5)
					end
				end
			end
		end

		local v20 = HDAdminMain.pdata.Rank >= (HDAdminMain.commandRanks.permrank or 4)

		HDAdminMain:GetModule("cf"):ClearPage(t2.ranks)

		local count = 0

		for k, v in pairs(tbl) do
			local v22 = v[2]

			count = count + 1

			local v24 = t3.rankTitle:Clone()

			v24.Name = "Label" .. count
			v24.RankIdFrame.TextLabel.Text = v[1]
			v24.RankName.Text = v22
			v24.Visible = true
			v24.Parent = t2.ranks

			for k2, v2 in pairs(v[3]) do
				local v25

				count = count + 1

				local v26 = v2[1]
				local v27 = v2[2]
				local v28 = v2[3]
				local v29 = t3.rankItem:Clone()

				v29.Name = "Label" .. count
				v29.ItemTitle.Text = v26
				v29.ItemDesc.Text = v27

				if #tostring(v28) == 1 then
					v29.ItemIcon.Text = v28
					v29.ItemIcon.Visible = true
					v29.ItemImage.Visible = false
				else
					if tonumber(v28) then
						v28 = "rbxassetid://" .. v28
					end

					v29.ItemImage.Image = tostring(v28)
				end

				v29.Unlock.Visible = false
				v29.ViewMore.Visible = false

				if v27 == "Gamepass" or v27 == "Asset" then
					local v30 = v2[4]
					local v31 = v2[5]

					v29.ItemImage.BackgroundTransparency = 1
					v29.Unlock.Visible = true
					v29.Unlock.MouseButton1Down:Connect(function() --[[ Line: 184 | Upvalues: BuyFrame (ref), v26 (copy), v28 (ref), v22 (copy), HDAdminMain (ref), v31 (copy), v30 (copy), v27 (copy) ]]
						BuyFrame.ProductName.Text = v26
						BuyFrame.ProductImage.Image = v28
						BuyFrame.PurchaseToUnlock.TextLabel.Text = v22
						BuyFrame.InGame.TextLabel.Text = HDAdminMain.gameName
						BuyFrame.MainButton.Price.Text = (v31 or 0) .. " "
						BuyFrame.MainButton.ProductId.Value = v30
						BuyFrame.MainButton.ProductType.Value = v27
						HDAdminMain:GetModule("cf"):ShowWarning("BuyFrame")
					end)
					v25 = 0.4
				elseif v27 == "PermRank" then
					local v32 = v2[4]

					if v20 then
						local ViewMore = v29.ViewMore

						ViewMore.Visible = true
						ViewMore.MouseButton1Down:Connect(function() --[[ Line: 200 | Upvalues: HDAdminMain (ref), v26 (copy), v32 (copy) ]]
							HDAdminMain:GetModule("cf"):ShowPermRankedUser({ v26, v32.UserId, v32.RankedBy })
						end)
					end

					v25 = 0.6
				else
					v25 = 0.7
				end

				v29.ItemTitle.Size = UDim2.new(v25, 0, v29.ItemTitle.Size.Y.Scale, 0)
				v29.ItemDesc.Size = UDim2.new(v25, 0, v29.ItemDesc.Size.Y.Scale, 0)
				v29.Visible = true
				v29.Parent = t2.ranks
			end
		end

		if not (count >= 2) then
			return
		end

		for i = 1, 2 do
			local v33 = t2.ranks["Label" .. count]

			t2.ranks.CanvasSize = UDim2.new(0, 0, 0, v33.AbsolutePosition.Y + v33.AbsoluteSize.Y - t2.ranks.Label1.AbsolutePosition.Y)
		end
	end)()
end
function t.CreateServerRanks(p1) --[[ CreateServerRanks | Line: 230 | Upvalues: HDAdminMain (copy), t2 (copy), t3 (copy) ]]
	coroutine.wrap(function() --[[ Line: 231 | Upvalues: HDAdminMain (ref), t2 (ref), t3 (ref) ]]
		local v1 = HDAdminMain.signals.RetrieveServerRanks:InvokeServer()
		local tbl = {}
		local t = {}

		for k, v in pairs(HDAdminMain.settings.Ranks) do
			table.insert(tbl, 1, {
				v[1],
				v[2],
				{}
			})
		end

		for k, v in pairs(tbl) do
			t[v[1]] = k
		end

		for k, v in pairs(v1) do
			local Player = v.Player
			local RankType = v.RankType
			local v2 = tbl[t[v.RankId]]

			if v2 then
				table.insert(v2[3], { Player, RankType })
			end
		end

		for k, v in pairs(tbl) do
			table.sort(v[3], function(p1, p2) --[[ Line: 262 ]]
				return p1[2] < p2[2]
			end)
		end

		HDAdminMain:GetModule("cf"):ClearPage(t2.serverRanks)

		local t4 = {}

		for k, v in pairs(HDAdminMain.rankTypes) do
			t4[v] = k
		end

		local count = 0

		for k, v in pairs(tbl) do
			local _ = v[1]
			local v5 = v[2]

			for k2, v2 in pairs(v[3]) do
				count = count + 1

				local v7 = v2[1]
				local v9 = t3.admin:Clone()

				v9.Name = "Label" .. count
				v9.PlrName.Text = v7.Name
				v9.PlrRank.Text = v5 .. " (" .. t4[v2[2]] .. ")"
				v9.PlayerImage.Image = HDAdminMain:GetModule("cf"):GetUserImage(v7.UserId)
				v9.BackgroundColor3 = HDAdminMain:GetModule("cf"):GetLabelBackgroundColor(count)
				v9.Visible = true
				v9.Parent = t2.serverRanks
			end
		end

		t2.serverRanks.CanvasSize = UDim2.new(0, 0, 0, count * t3.admin.AbsoluteSize.Y)
	end)()
end

local v1 = true

function t.CreateBanland(p1) --[[ CreateBanland | Line: 304 | Upvalues: v1 (ref), HDAdminMain (copy), t2 (copy), t3 (copy) ]]
	coroutine.wrap(function() --[[ Line: 305 | Upvalues: v1 (ref), HDAdminMain (ref), t2 (ref), t3 (ref) ]]
		if not v1 then
			return
		end

		v1 = false

		local sum = 0

		if HDAdminMain.pdata.Rank < HDAdminMain.settings.ViewBanland then
			HDAdminMain:GetModule("cf"):ClearPage(t2.banland)

			local TitleLabel = t3.banTitle:Clone()

			TitleLabel.BackgroundColor3 = Color3.fromRGB(95, 95, 95)
			TitleLabel.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
			TitleLabel.TextLabel.Text = "Must be rank \'" .. HDAdminMain:GetModule("cf"):GetRankName(HDAdminMain.settings.ViewBanland) .. "\' or higher to view the Banland"
			TitleLabel.Name = "TitleLabel"
			TitleLabel.Visible = true
			TitleLabel.Parent = t2.banland
		else
			local v12 = HDAdminMain.signals.RetrieveBanland:InvokeServer()
			local v2 = HDAdminMain.pdata.Rank >= (HDAdminMain.commandRanks.directban or 4)

			HDAdminMain:GetModule("cf"):ClearPage(t2.banland)

			local t = { "Current Server", "All Servers" }

			for k, v in pairs(v12) do
				if #v > 0 then
					local TitleLabel = t3.banTitle:Clone()

					TitleLabel.BackgroundColor3 = Color3.fromRGB(95, 95, 95)
					TitleLabel.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
					TitleLabel.TextLabel.Text = t[k]
					TitleLabel.Name = "TitleLabel"
					sum = sum + t3.banTitle.AbsoluteSize.Y
					TitleLabel.Visible = true
					TitleLabel.Parent = t2.banland
				end

				for k2, v4 in pairs(v) do
					local v3
					local UserId = v4.UserId

					if UserId > 0 then
						sum = sum + t3.ban.AbsoluteSize.Y

						local SettingsBan = v4.SettingsBan
						local BanLabel = t3.ban:Clone()

						BanLabel.Name = "BanLabel"
						BanLabel.PlrName.Text = HDAdminMain:GetModule("cf"):GetName(UserId)

						local BanTime = v4.BanTime

						v3 = if tonumber(BanTime) then HDAdminMain:GetModule("cf"):GetBanDateString(os.date("*t", BanTime)) elseif SettingsBan then "Auto Settings Ban" else "Infinite"
						BanLabel.BanLength.Text = v3
						BanLabel.PlayerImage.Image = HDAdminMain:GetModule("cf"):GetUserImage(UserId)
						BanLabel.BackgroundColor3 = HDAdminMain:GetModule("cf"):GetLabelBackgroundColor(k2)

						local ViewMore = BanLabel.ViewMore

						if v2 and not SettingsBan then
							ViewMore.Visible = true
							ViewMore.MouseButton1Down:Connect(function() --[[ Line: 372 | Upvalues: HDAdminMain (ref), BanLabel (copy), UserId (copy), v4 (copy) ]]
								HDAdminMain:GetModule("cf"):ShowBannedUser({
									BanLabel.PlrName.Text,
									UserId,
									v4.Reason,
									v4.BannedBy
								})
							end)
						else
							ViewMore.Visible = false
						end

						BanLabel.Visible = true
						BanLabel.Parent = t2.banland
					end
				end
			end
		end

		t2.banland.CanvasSize = UDim2.new(0, 0, 0, sum)
		v1 = true
	end)()
end
function t.UpdatePages(p1) --[[ UpdatePages | Line: 395 | Upvalues: t (copy) ]]
	t:CreateServerRanks()
	t:CreateBanland()
	t:CreateRanks()
end
spawn(function() --[[ Line: 404 | Upvalues: Admin (copy), HDAdminMain (copy), t (copy) ]]
	while wait(20) do
		if not (Admin.Visible and HDAdminMain.gui.MainFrame.Visible) then
			continue
		end

		t:UpdatePages()
	end
end)

return t