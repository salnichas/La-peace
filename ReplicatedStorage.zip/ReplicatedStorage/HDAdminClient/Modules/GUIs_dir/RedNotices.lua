-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain

return {}