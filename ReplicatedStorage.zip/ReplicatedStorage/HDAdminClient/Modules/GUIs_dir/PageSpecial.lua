-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain
local t = {
	donor = HDAdminMain.gui.MainFrame.Pages.Special.Donor
}
local TemplateGame = t.donor.TemplateGame
local v1 = t.donor["A Space"]
local v2 = t.donor["AZ Space"]
local v3 = t.donor["AG Unlock"]
local Teleport = HDAdminMain.warnings.Teleport
local t2 = {}
local t3 = {}

for k, v in pairs(HDAdminMain.commandInfo) do
	if v.RankName == "Donor" then
		table.insert(t2, v)
	end
end

local v4

repeat
	wait()
	v4 = HDAdminMain:GetModule("cf")
until v4.RandomiseTable

for k, v in pairs((v4:RandomiseTable({}, 86400))) do
	local v6
	local v7 = v[1]
	local v8 = v[2]
	local v9 = math.ceil(k / 2)
	local v10 = k % 2

	if v10 == 1 then
		local v11 = TemplateGame:Clone()

		v11.Name = "AI Game" .. v9
		v11.Visible = true
		v11.Parent = t.donor
		v6 = v11
	else
		v6 = t.donor["AI Game" .. v9]
	end

	local v12 = v6["GameImage" .. v10]
	local v13 = v6["GameName" .. v10]
	local v14 = "https://assetgame.roblox.com/Game/Tools/ThumbnailAsset.ashx?aid=" .. v7 .. "&fmt=png&wd=420&ht=420"

	v12.Image = v14
	v13.Text = v8
	v12.Visible = true
	v13.Visible = true

	local Select = v12.Select
	local ClickFrame = v12.ClickFrame

	Select.MouseButton1Click:Connect(function() --[[ Line: 80 | Upvalues: Teleport (copy), v14 (copy), v8 (copy), v7 (copy), HDAdminMain (copy) ]]
		Teleport.ImageLabel.Image = v14
		Teleport.TeleportTo.TextLabel.Text = v8 .. "?"
		Teleport.MainButton.PlaceId.Value = v7
		HDAdminMain:GetModule("cf"):ShowWarning("Teleport")
	end)
	Select.MouseEnter:Connect(function() --[[ Line: 86 | Upvalues: HDAdminMain (copy), ClickFrame (copy) ]]
		if HDAdminMain.warnings.Visible then
			return
		end

		ClickFrame.Visible = true
	end)
	Select.MouseLeave:Connect(function() --[[ Line: 91 | Upvalues: ClickFrame (copy) ]]
		ClickFrame.Visible = false
	end)
	Teleport.Visible = true
end

t.donor["AG Unlock"].Unlock.MouseButton1Down:Connect(function() --[[ Line: 100 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain.marketplaceService:PromptGamePassPurchase(HDAdminMain.player, HDAdminMain.products.Donor)
end)
function t3.SetupDonorCommands(p1) --[[ SetupDonorCommands | Line: 107 | Upvalues: HDAdminMain (copy), t2 (copy), t (copy), t3 (copy) ]]
	HDAdminMain:GetModule("PageCommands"):SetupCommands(t2, t.donor, 0)
	t3:UpdateDonorFrame()
end
function t3.UpdateDonorFrame(p1) --[[ UpdateDonorFrame | Line: 112 | Upvalues: HDAdminMain (copy), v3 (copy), t (copy), v2 (copy), v1 (copy) ]]
	if HDAdminMain.pdata.Donor then
		v3.Visible = false
	else
		v3.Visible = true
	end

	t.donor.CanvasSize = UDim2.new(0, 0, 0, v2.AbsolutePosition.Y - v1.AbsolutePosition.Y + v2.AbsoluteSize.Y * 1)
end

return t3