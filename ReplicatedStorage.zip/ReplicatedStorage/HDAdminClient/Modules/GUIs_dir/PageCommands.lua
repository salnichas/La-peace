-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local Commands = HDAdminMain.gui.MainFrame.Pages.Commands
local t2 = {
	commands = Commands.Commands,
	morphs = Commands.Morphs,
	details = Commands.Details
}
local TemplateOne = t2.commands.TemplateOne
local TemplateTwo = t2.commands.TemplateTwo
local Template = t2.morphs.Template
local t3 = { "Aliases", "Undo", "Desc", "Rank", "Loop", "Tags", "Credit" }
local t4 = { "Aliases", "UnFunction", "Description", "Rank", "Loopable", "Tags", "Contributors" }
local v1 = true

Commands.SearchBar.Frame.TextBox.FocusLost:connect(function(p1) --[[ Line: 26 | Upvalues: v1 (ref), t2 (copy), t (copy) ]]
	if not v1 then
		return
	end

	v1 = false

	local v12 = nil

	for k, v in pairs(t2) do
		if v.Position.X.Scale == 0 then
			v12 = v
		end
	end

	if v12 then
		t["Create" .. v12.Name]()
	end

	wait(0.5)
	v1 = true
end)

local v2 = false

function t.SetupCommands(p1, p2, p3, p4) --[[ SetupCommands | Line: 49 | Upvalues: TemplateOne (copy), HDAdminMain (copy), TemplateTwo (copy), t3 (copy), t4 (copy) ]]
	local Y = TemplateOne.TextLabel.TextBounds.Y

	for k, v in pairs(p2) do
		string.lower(v.Name)
		p4 = p4 + 1

		local v1 = if p3.Name == "Donor" then "AE Command" .. p4 else HDAdminMain:GetModule("cf"):GenerateTagFromId(p4)
		local v2 = TemplateOne:Clone()

		v2.BackgroundColor3 = HDAdminMain:GetModule("cf"):GetLabelBackgroundColor(k)
		v2.TextLabel.TextColor3 = Color3.fromRGB(235, 235, 235)

		local v3 = false

		if v.Prefixes[1] == HDAdminMain.settings.UniversalPrefix then
			v2.TextLabel.Text = HDAdminMain.settings.UniversalPrefix .. v.Name
			v3 = true
		else
			v2.TextLabel.Text = HDAdminMain.pdata.Prefix .. v.Name
		end

		local TextLabel = v2.TextLabel
		local v4 = HDAdminMain.textService:GetTextSize(TextLabel.Text, Y, TextLabel.Font, TextLabel.AbsoluteSize)

		if v.SpecialColor then
			TextLabel.Text = v.OriginalName

			local v5 = HDAdminMain.textService:GetTextSize(TextLabel.Text, Y, TextLabel.Font, TextLabel.AbsoluteSize)
			local ColorLabel = TextLabel:Clone()

			ColorLabel.ZIndex = ColorLabel.ZIndex + 2
			ColorLabel.Position = TextLabel.Position + UDim2.new(0, v5.X, 0, 0)
			ColorLabel.TextColor3 = v.SpecialColor
			ColorLabel.Name = "ColorLabel"
			ColorLabel.Text = v.SpecialColorName
			ColorLabel.Parent = v2
		end

		local DetailsLabel = TextLabel:Clone()

		DetailsLabel.Position = TextLabel.Position + UDim2.new(0, v4.X + 5, 0, 0)
		DetailsLabel.TextColor3 = Color3.fromRGB(175, 175, 175)
		DetailsLabel.Name = "DetailsLabel"

		local t = {}

		for k2, v5 in pairs(v.Args) do
			if (not v3 or v5 ~= "player") and v5 ~= "details" then
				if v5 == "playerarg" then
					v5 = "player"
				elseif v5 == "userid" then
					v5 = "userId/username"
				end

				table.insert(t, "<" .. v5 .. ">")
			end
		end

		DetailsLabel.Text = table.concat(t, "  ")
		DetailsLabel.Parent = v2
		v2.Name = v1
		v2.Arrow.Text = "\226\150\186"
		v2.Visible = true

		local t2 = {}
		local TextButton = Instance.new("TextButton")

		TextButton.BackgroundTransparency = 1
		TextButton.ZIndex = v2.ZIndex + 5
		TextButton.Size = UDim2.new(1, 0, 1, 0)
		TextButton.Text = ""

		local function pressButton() --[[ pressButton | Line: 157 | Upvalues: t2 (ref), p3 (copy), TemplateTwo (ref), v2 (copy), t3 (ref), v (copy), t4 (ref), v1 (ref), HDAdminMain (ref), v3 (ref) ]]
			if #t2 > 0 then
				p3.CanvasSize = p3.CanvasSize - UDim2.new(0, 0, 0, #t2 * TemplateTwo.AbsoluteSize.Y)

				for k, v4 in pairs(t2) do
					v4:Destroy()
				end

				t2 = {}
			end

			if v2.Arrow.Text == "\226\150\186" then
				v2.Arrow.Text = "\226\150\188"

				local count = 0

				for k, v4 in pairs(t3) do
					local v12 = v[t4[k]]

					if v12 then
						local v22, v32, v42, v5, v6, v7, v8, v9, v10, v11, v122, v13, v14, v15, v16, v17, v18, v19

						if type(v12) == "table" or type(v12) == "string" then
							if #v12 > 0 then
								count = count + 1
								v22 = TemplateTwo:Clone()
								v22.Name = v1 .. " Info" .. HDAdminMain.alphabet[count]
								v22.Title.Text = v4 .. ":"

								if count % 2 == 0 then
									v22.BackgroundColor3 = Color3.fromRGB(10, 10, 10)
								else
									v22.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
								end

								v32 = v22.TextLabel
								v22.Parent = p3
								v42 = HDAdminMain.pdata.Prefix

								if v3 then
									v42 = HDAdminMain.settings.UniversalPrefix
								end

								if v4 == "Loop" then
									if v12 == true then
										v32.Text = "Sim"
									else
										v32.Text = "N\195\163o"
									end
								elseif v4 == "Undo" then
									v32.Text = v42 .. v.UnFunction
								elseif v4 == "Alias" then
									v5 = {}

									for k2, v21 in pairs(v12) do
										table.insert(v5, v42 .. v21)
									end

									v32.Text = table.concat(v5, " | ")
								elseif type(v12) == "table" then
									v32.Text = table.concat(v12, ", ")
								elseif v4 == "Rank" then
									if v.RankName == "Donor" then
										v32.Text = v.Rank
									else
										v32.Text = v.Rank .. " (" .. v.RankName .. ")"
									end
								else
									v32.Text = v12

									if v4 == "Desc" then
										v6 = v22.Title.AbsoluteSize
										v7 = v22.AbsoluteSize
										v8 = (v22.Title.AbsolutePosition.Y - v22.AbsolutePosition.Y) / 2
										v9 = v32.AbsoluteSize
										v10 = v9.Y
										v11 = v32.Font
										v122 = Vector2.new(v9.X, v9.Y * 100)
										v13 = HDAdminMain.textService:GetTextSize(v12, v10, v11, v122)
										v22.UIAspectRatioConstraint:Destroy()
										v32.Size = UDim2.new(0, v13.X, 0, v13.Y)
										v22.Title.Size = UDim2.new(0, v6.X, 0, v6.Y)
										v14 = UDim2.new
										v15 = v7.X
										v16 = v7.Y
										v17 = v13.Y
										v18 = v9.Y
										v22.Size = v14(0, v15, 0, v16 + (v17 - math.ceil(v18)))
										v22.Title.Position = UDim2.new(v22.Title.Position.X.Scale, 0, 0, v8)
										v22.TextLabel.Position = UDim2.new(v22.TextLabel.Position.X.Scale, 0, 0, v8)
									end
								end

								v22.Visible = true
								v19 = t2
								table.insert(t2, v22)
							end
						else
							count = count + 1
							v22 = TemplateTwo:Clone()
							v22.Name = v1 .. " Info" .. HDAdminMain.alphabet[count]
							v22.Title.Text = v4 .. ":"

							if count % 2 == 0 then
								v22.BackgroundColor3 = Color3.fromRGB(10, 10, 10)
							else
								v22.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
							end

							v32 = v22.TextLabel
							v22.Parent = p3
							v42 = HDAdminMain.pdata.Prefix

							if v3 then
								v42 = HDAdminMain.settings.UniversalPrefix
							end

							if v4 == "Loop" then
								if v12 == true then
									v32.Text = "Sim"
								else
									v32.Text = "N\195\163o"
								end
							elseif v4 == "Undo" then
								v32.Text = v42 .. v.UnFunction
							elseif v4 == "Alias" then
								v5 = {}

								for k2, v21 in pairs(v12) do
									table.insert(v5, v42 .. v21)
								end

								v32.Text = table.concat(v5, " | ")
							elseif type(v12) == "table" then
								v32.Text = table.concat(v12, ", ")
							elseif v4 == "Rank" then
								if v.RankName == "Donor" then
									v32.Text = v.Rank
								else
									v32.Text = v.Rank .. " (" .. v.RankName .. ")"
								end
							else
								v32.Text = v12

								if v4 == "Desc" then
									v6 = v22.Title.AbsoluteSize
									v7 = v22.AbsoluteSize
									v8 = (v22.Title.AbsolutePosition.Y - v22.AbsolutePosition.Y) / 2
									v9 = v32.AbsoluteSize
									v10 = v9.Y
									v11 = v32.Font
									v122 = Vector2.new(v9.X, v9.Y * 100)
									v13 = HDAdminMain.textService:GetTextSize(v12, v10, v11, v122)
									v22.UIAspectRatioConstraint:Destroy()
									v32.Size = UDim2.new(0, v13.X, 0, v13.Y)
									v22.Title.Size = UDim2.new(0, v6.X, 0, v6.Y)
									v14 = UDim2.new
									v15 = v7.X
									v16 = v7.Y
									v17 = v13.Y
									v18 = v9.Y
									v22.Size = v14(0, v15, 0, v16 + (v17 - math.ceil(v18)))
									v22.Title.Position = UDim2.new(v22.Title.Position.X.Scale, 0, 0, v8)
									v22.TextLabel.Position = UDim2.new(v22.TextLabel.Position.X.Scale, 0, 0, v8)
								end
							end

							v22.Visible = true
							v19 = t2
							table.insert(t2, v22)
						end
					end
				end

				local v20 = #t2 * TemplateTwo.AbsoluteSize.Y

				p3.CanvasSize = p3.CanvasSize + UDim2.new(0, 0, 0, v20)

				if v2.AbsolutePosition.Y > p3.AbsolutePosition.Y + p3.AbsoluteSize.Y - v20 / 1.5 then
					p3.CanvasPosition = p3.CanvasPosition + Vector2.new(0, v20)
				end
			else
				v2.Arrow.Text = "\226\150\186"
			end
		end

		if HDAdminMain.device == "Mobile" then
			TextButton.MouseButton1Click:Connect(function() --[[ Line: 243 | Upvalues: pressButton (copy) ]]
				pressButton()
			end)
		else
			TextButton.MouseButton1Down:Connect(function() --[[ Line: 247 | Upvalues: pressButton (copy) ]]
				pressButton()
			end)
		end

		TextButton.Parent = v2
		v2.Parent = p3
	end

	return p4
end
function t.CreateCommands(p1) --[[ CreateCommands | Line: 258 | Upvalues: v2 (ref), HDAdminMain (copy), t2 (copy), Commands (copy), TemplateOne (copy), t (copy) ]]
	if v2 then
		return
	end

	v2 = true
	HDAdminMain:GetModule("cf"):ClearPage(t2.commands)

	local Text = Commands.SearchBar.Frame.TextBox.Text
	local tbl = {}
	local t3 = {}
	local v1 = 0

	for k, v in pairs(HDAdminMain.settings.Ranks) do
		local v3 = v[2]

		table.insert(tbl, {
			v[1],
			v3,
			{}
		})
		t3[v3] = k
	end

	for k, v in pairs(HDAdminMain.commandInfo) do
		local v4 = string.lower(v.Name)

		if v.RankName ~= "Donor" then
			local v5 = false

			if #Text > 0 then
				for k2, v3 in pairs(v.Aliases) do
					if string.lower((string.sub(Text, 1, #v3))) == v3 then
						v5 = true

						break
					end
				end
			end

			if string.match(v4, Text) or v5 then
				local v6 = t3[v.RankName]

				if not v6 then
					local Rank = v.Rank

					for k2, v3 in pairs(HDAdminMain.settings.Ranks) do
						local v8 = v3[2]

						if Rank < v3[1] then
							v6 = t3[v8]

							break
						end
					end
				end

				if v6 then
					table.insert(tbl[v6][3], v)
				end
			end
		end
	end

	for k, v in pairs(tbl) do
		local v10 = v[1]
		local v11 = v[2]
		local v12 = v[3]

		if #v12 > 0 and (not HDAdminMain.settings.OnlyShowUsableCommands or v10 <= HDAdminMain.pdata.Rank) then
			local v13 = TemplateOne:Clone()

			v13.BackgroundColor3 = Color3.fromRGB(95, 95, 95)
			v13.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)

			if v10 == 5 then
				v13.TextLabel.Text = v11
			else
				v13.TextLabel.Text = v11 .. " +"
			end

			local v14 = v1 + 1

			v13.Name = HDAdminMain:GetModule("cf"):GenerateTagFromId(v14)
			v13.TextLabel.Position = v13.Arrow.Position
			v13.Arrow:Destroy()
			v13.Visible = true
			v13.Parent = t2.commands
			v1 = t:SetupCommands(v12, t2.commands, v14)
		end
	end

	t2.commands.CanvasSize = UDim2.new(0, 0, 0, v1 * TemplateOne.AbsoluteSize.Y)
	coroutine.wrap(function() --[[ Line: 337 | Upvalues: v2 (ref) ]]
		wait(0.5)
		v2 = false
	end)()
end
function t.CreateVoiceChat(p1) --[[ CreateVoiceChat | Line: 347 ]] end
function t.CreateMorphs(p1) --[[ CreateMorphs | Line: 387 | Upvalues: HDAdminMain (copy), t2 (copy), Commands (copy), Template (copy) ]]
	HDAdminMain:GetModule("cf"):ClearPage(t2.morphs)

	local Text = Commands.SearchBar.Frame.TextBox.Text
	local tbl = {}

	for k, v in pairs(HDAdminMain.morphNames) do
		if string.match(string.lower(k), Text) then
			table.insert(tbl, k)
		end
	end

	table.sort(tbl)
	table.insert(tbl, 1, HDAdminMain.pdata.Prefix .. "morph <player> <morphName>")

	for k, v in pairs(tbl) do
		local v3 = Template:Clone()

		if k == 1 then
			v3.BackgroundColor3 = Color3.fromRGB(95, 95, 95)
			v3.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
		else
			v3.BackgroundColor3 = HDAdminMain:GetModule("cf"):GetLabelBackgroundColor(k)
			v3.TextLabel.TextColor3 = Color3.fromRGB(235, 235, 235)
		end

		v3.TextLabel.Text = v
		v3.Name = v
		v3.Visible = true
		v3.Parent = t2.morphs
	end

	t2.morphs.CanvasSize = UDim2.new(0, 0, 0, #tbl * Template.AbsoluteSize.Y)
end

local tbl = {
	{
		{ 0, "Colors" }
	},
	{
		{ 0, "Prefixos" },
		{ "Me" }
	},
	{
		{ 0, "Atalhos" },
		{ "\' (Quote) para alternar cmdbar (computador)" },
		{ "; (Ponto e v\195\173rgula) para alternar cmdbar2 (computador)" }
	},
	{
		{ 0, "Dicas" },
		{ "/e para comandos silenciosos   (/e ;jump me)" },
		{ "Comandos em excesso   (;jump me ;kill me)" },
		{ "Seleciona v\195\161rios jogadores  (;jump me,bc,r15)" },
		{ "Nomes mais pequenos   (;jump delta_imperaodr = ;jump for)" },
		{ "Caixa alta n\195\163o muda nada  (;jUmP mE = ;jump me)" }
	}
}
local v3 = nil

for k, v in pairs(tbl) do
	if v[1][1] == 0 and v[1][2] == "Colors" then
		v3 = k
	end
end

for k, v in pairs(HDAdminMain.settings.Colors) do
	local v5 = v[2]

	table.insert(tbl[v3], { v5 .. " (" .. v[1] .. ")" })
	table.insert(HDAdminMain.colors, v5)
end

function t.CreateDetails(p1) --[[ CreateDetails | Line: 468 | Upvalues: HDAdminMain (copy), t2 (copy), tbl (copy), Template (copy) ]]
	HDAdminMain:GetModule("cf"):ClearPage(t2.details)

	local count = 0

	for k, v in pairs(tbl) do
		for k2, v2 in pairs(v) do
			local v1 = Template:Clone()

			if k2 == 1 then
				v1.BackgroundColor3 = Color3.fromRGB(95, 95, 95)
				v1.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
				v1.TextLabel.Text = v2[2]
			else
				v1.BackgroundColor3 = HDAdminMain:GetModule("cf"):GetLabelBackgroundColor(k2)
				v1.TextLabel.TextColor3 = Color3.fromRGB(235, 235, 235)
				v1.TextLabel.Text = v2[1]
			end

			v1.Visible = true
			v1.Parent = t2.details
			count = count + 1
		end
	end

	t2.details.CanvasSize = UDim2.new(0, 0, 0, count * Template.AbsoluteSize.Y)
end

return t