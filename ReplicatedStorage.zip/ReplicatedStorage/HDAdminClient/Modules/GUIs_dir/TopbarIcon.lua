-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain
local playerGui = HDAdminMain.playerGui
local HDAdmin = game:GetService("ReplicatedStorage"):FindFirstChild("HDAdmin")
local v1 = if HDAdmin then HDAdmin:FindFirstChild("Topbar+") else HDAdmin

if v1 then
	local v2 = require(v1.IconController):createIcon("HDAdmin", 99965555742910, 0)

	v2:setToggleMenu(HDAdminMain.gui.MainFrame)

	return v2
end

local v3 = require(HDAdminMain.client.Assets.Icon).new():setImage(99965555742910, "deselected"):setImage(99965555742910, "selected"):setImageScale(0.6, "deselected"):setImageScale(0.5, "selected"):bindToggleItem(HDAdminMain.gui.MainFrame):setOrder(0)

task.defer(function() --[[ Line: 28 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain:GetModule("cf"):RankChangedUpdater()
end)

return v3