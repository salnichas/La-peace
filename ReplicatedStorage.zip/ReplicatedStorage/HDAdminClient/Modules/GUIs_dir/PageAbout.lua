-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local loadModule = HDAdminMain.loadModule
local v1 = loadModule("cf")
local v2 = loadModule("Credits")
local v3 = loadModule("Updates")
local About = HDAdminMain.gui.MainFrame.Pages.About
local Info = About.Info
local Updates = About.Updates
local Credits = About.Credits

Info.m1.Text = "Bem vindo, " .. HDAdminMain.player.Name .. "!"
function t.UpdateProfileIcon(p1) --[[ UpdateProfileIcon | Line: 21 | Upvalues: Info (copy), v1 (copy), HDAdminMain (copy) ]]
	Info.PlayerImage.Image = v1:GetUserImage(HDAdminMain.player.UserId)
end
function t.UpdateRankName(p1) --[[ UpdateRankName | Line: 24 | Upvalues: Info (copy), v1 (copy), HDAdminMain (copy) ]]
	Info.m2RankName.Text = "\'" .. v1:GetRankName(HDAdminMain.pdata.Rank) .. "\'"
end

local Template = Updates.Template

Template.Visible = false
function t.CreateUpdates(p1) --[[ CreateUpdates | Line: 34 | Upvalues: v1 (copy), Updates (copy), v3 (copy), Template (copy) ]]
	v1:ClearPage(Updates)

	local sum = 0

	for k, v in pairs(v3) do
		sum = sum + #v

		local v12 = 0

		for k2, v2 in pairs(v) do
			local v22 = Template:Clone()

			if k2 == 1 then
				v12 = v2[1]
				v22.BackgroundColor3 = Color3.fromRGB(95, 95, 95)
				v22.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
				v22.TextLabel.Text = v2[2]
			else
				v22.BackgroundColor3 = v1:GetLabelBackgroundColor(k2)
				v22.TextLabel.TextColor3 = Color3.fromRGB(235, 235, 235)
				v22.TextLabel.Text = v2[1]

				if os.time() - 907200 < v12 then
					v22.New.Visible = true
					v22.TextLabel.Position = UDim2.new(0.16, 0, 0.15, 0)
					v22.TextLabel.Size = UDim2.new(0.8, 0, 0.7, 0)
				end
			end

			v22.Visible = true
			v22.Parent = Updates
		end
	end

	Updates.CanvasSize = UDim2.new(0, 0, 0, sum * Template.AbsoluteSize.Y)
end

local Template2 = Credits.Template

Template2.Visible = false
function t.UpdateContributors(p1) --[[ UpdateContributors | Line: 70 | Upvalues: HDAdminMain (copy), v2 (copy) ]]
	local tbl = {}

	for k, v in pairs(HDAdminMain.infoOnAllCommands.Contributors) do
		table.insert(tbl, { k, v })
	end

	table.sort(tbl, function(p1, p2) --[[ Line: 84 ]]
		return p1[2] > p2[2]
	end)

	for k, v in pairs(tbl) do
		local t = {
			v[1],
			{ "Commands: " .. v[2] }
		}

		if v2[3] then
			table.insert(v2[3], t)
		end
	end
end
function t.CreateCredits(p1) --[[ CreateCredits | Line: 95 | Upvalues: v1 (copy), Credits (copy), v2 (copy), Template (copy), Template2 (copy) ]]
	v1:ClearPage(Credits)

	local sum = 0

	for k, v in pairs(v2) do
		local v12 = 6

		for k2, v3 in pairs(v) do
			local Label

			if k2 == 1 then
				local v22 = Template:Clone()

				v12 = v3[1]
				v22.BackgroundColor3 = Color3.fromRGB(95, 95, 95)
				v22.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
				v22.TextLabel.Text = v3[2]
				v22.Parent = Credits
				Label = v22
			else
				local v32 = Template2:Clone()

				v32.Parent = Credits
				v32.UIAspectRatioConstraint.AspectRatio = v12
				v32.BackgroundColor3 = v1:GetLabelBackgroundColor(k2)
				v32.PlrName.Text = v3[1]
				v32.PlayerImage.Image = v1:GetUserImage(v1:GetUserId(v3[1]))

				local Y = v32.PlayerImage.AbsoluteSize.Y

				v32.PlayerImage.Size = UDim2.new(0, Y, 1, 0)
				Label = v32

				for i = 1, 3 do
					local v4, v5, v6
					local v7 = v32:FindFirstChild("Desc" .. i)

					if v7 then
						local v8 = v3[2][i]

						if v8 then
							v7.Text = v8
						else
							v7.Text = ""
						end

						local v9 = Y * 1.15

						if v12 <= 5 then
							v4 = (i - 1) * 0.25 + 0.33
							v5 = 0.255
							v6 = 0.31
						else
							v4 = (i - 1) * 0.25 + 0.36
							v5 = 0.26
							v6 = 0.32
						end

						v7.Position = UDim2.new(0, v9, v4, 0)
						v7.Size = UDim2.new(0.75, 0, v5, 0)
						v32.PlrName.Position = UDim2.new(0, v9, v32.PlrName.Position.Y.Scale, v32.PlrName.Position.Y.Offset)
						v32.PlrName.Size = UDim2.new(0.75, 0, v6, 0)
					end
				end
			end

			Label.Name = "Label"
			Label.Visible = true
			sum = sum + Label.AbsoluteSize.Y
		end
	end

	Credits.CanvasSize = UDim2.new(0, 0, 0, sum)
end

return t