-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain
local v1 = 0
local t = {
	[HDAdminMain.gui.MainFrame] = 0.78,
	[HDAdminMain.gui.MenuTemplates.Template5] = 0.78,
	[HDAdminMain.gui.MenuTemplates.Template6] = 0.78,
	[HDAdminMain.gui.MenuTemplates.Template7] = 0.78,
	[HDAdminMain.gui.MenuTemplates.Template9] = 0.78,
	[HDAdminMain.gui.MenuTemplates.Template10] = 1.17,
	[HDAdminMain.gui.MenuTemplates.Template11] = 1.17,
	[HDAdminMain.gui.MenuTemplates.Template12] = 0.78
}

local function updateUIs() --[[ updateUIs | Line: 31 | Upvalues: HDAdminMain (copy), t (copy) ]]
	local v1 = if HDAdminMain.device == "Mobile" then if HDAdminMain.tablet then 0.8 else 1 else 0.6

	for k, v in pairs(t) do
		local v2 = if v > 1 then v1 / 1.5 else v1

		k.Position = UDim2.new(0, 0, (1 - v2) / 2, 0)
		k.Size = UDim2.new(0, 0, v2, 0)

		local v3 = k.AbsoluteSize.Y * v

		k.Position = UDim2.new(0.5, -v3 / 2, k.Position.Y.Scale, k.Position.Y.Offset)
		k.Size = UDim2.new(0, v3, k.Size.Y.Scale, k.Size.Y.Offset)
	end
end

local function screenChanged() --[[ screenChanged | Line: 53 | Upvalues: v1 (ref), updateUIs (copy), HDAdminMain (copy) ]]
	v1 = v1 + 1
	wait(0.5)
	v1 = v1 - 1

	if v1 ~= 0 then
		return
	end

	updateUIs()
	HDAdminMain:GetModule("PageAbout"):CreateCredits()
end

HDAdminMain.gui.Changed:Connect(function(p1) --[[ Line: 68 | Upvalues: v1 (ref), updateUIs (copy), HDAdminMain (copy) ]]
	if p1 ~= "AbsoluteSize" then
		return
	end

	v1 = v1 + 1
	wait(0.5)
	v1 = v1 - 1

	if v1 ~= 0 then
		return
	end

	updateUIs()
	HDAdminMain:GetModule("PageAbout"):CreateCredits()
end)
updateUIs()

return {}