-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain

function t.SetTopbarTransparency(p1, p2) --[[ SetTopbarTransparency | Line: 17 ]]
	local _ = tonumber(p2) or 0.5
end
function t.SetTopbarEnabled(p1, p2) --[[ SetTopbarEnabled | Line: 22 | Upvalues: HDAdminMain (copy) ]]
	if type(p2) ~= "boolean" then
		p2 = true
	end

	local v1 = HDAdminMain:GetModule("TopbarIcon")

	if not v1 then
		return
	end

	v1:setEnabled(p2)
end

return t