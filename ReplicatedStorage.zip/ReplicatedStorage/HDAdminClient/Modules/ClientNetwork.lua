-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain
local CustomTopBar = HDAdminMain.gui.CustomTopBar

for k, v in pairs(HDAdminMain.signals:GetChildren()) do
	if v:IsA("RemoteEvent") then
		v.OnClientEvent:Connect(function(p1) --[[ Line: 17 | Upvalues: HDAdminMain (copy), v (copy) ]]
			if not HDAdminMain.initialized then
				HDAdminMain.client.Signals.Initialized.Event:Wait()
			end

			if v.Name == "ChangeStat" then
				local v1 = p1[1]

				HDAdminMain.pdata[v1] = p1[2]

				if v1 == "Donor" then
					HDAdminMain:GetModule("PageSpecial"):UpdateDonorFrame()
				end
			else
				if v.Name == "InsertStat" then
					table.insert(HDAdminMain.pdata[p1[1]], p1[2])

					return
				end

				if v.Name == "RemoveStat" then
					local v6 = p1[1]
					local v7 = p1[2]

					for k, v2 in pairs(HDAdminMain.pdata[v6]) do
						if tostring(v2) == tostring(v7) then
							table.remove(HDAdminMain.pdata[v6], k)

							return
						end
					end

					return
				end

				if v.Name == "Notice" or v.Name == "Error" then
					HDAdminMain:GetModule("Notices"):Notice(v.Name, p1[1], p1[2], p1[3])

					return
				end

				if v.Name == "ShowPage" then
					HDAdminMain:GetModule("GUIs"):ShowSpecificPage(p1[1], p1[2])

					return
				end

				if v.Name == "ShowBannedUser" then
					HDAdminMain:GetModule("GUIs"):ShowSpecificPage("Admin", "Banland")

					if type(p1) == "table" then
						HDAdminMain:GetModule("cf"):ShowBannedUser(p1)
					end
				else
					if v.Name == "SetCameraSubject" then
						HDAdminMain:GetModule("cf"):SetCameraSubject(p1)

						return
					end

					if v.Name == "Clear" then
						HDAdminMain:GetModule("Messages"):ClearMessageContainer()

						return
					end

					if v.Name == "ShowWarning" then
						HDAdminMain:GetModule("cf"):ShowWarning(p1)

						return
					end

					if v.Name == "Message" then
						HDAdminMain:GetModule("Messages"):Message(p1)

						return
					end

					if v.Name == "Hint" then
						HDAdminMain:GetModule("Messages"):Hint(p1)

						return
					end

					if v.Name == "GlobalAnnouncement" then
						HDAdminMain:GetModule("Messages"):GlobalAnnouncement(p1)

						return
					end

					if v.Name == "SetCoreGuiEnabled" then
						HDAdminMain.starterGui:SetCoreGuiEnabled(Enum.CoreGuiType[p1[1]], p1[2])

						return
					end

					if v.Name == "CreateLog" then
						HDAdminMain:GetModule("cf"):CreateNewCommandMenu(p1[1], p1[2], 5)

						return
					end

					if v.Name == "CreateAlert" then
						HDAdminMain:GetModule("cf"):CreateNewCommandMenu("alert", p1, 8, true)

						return
					end

					if v.Name == "CreateBanMenu" then
						HDAdminMain:GetModule("cf"):CreateNewCommandMenu("banMenu", p1, 6)

						return
					end

					if v.Name == "CreatePollMenu" then
						HDAdminMain:GetModule("cf"):CreateNewCommandMenu("pollMenu", p1, 9)

						return
					end

					if v.Name == "CreateMenu" then
						HDAdminMain:GetModule("cf"):CreateNewCommandMenu(p1.MenuName, p1.Data, p1.TemplateId)

						return
					end

					if v.Name == "CreateCommandMenu" then
						HDAdminMain:GetModule("cf"):CreateNewCommandMenu(p1[1], p1[2], p1[3])

						return
					end

					if v.Name == "RankChanged" then
						HDAdminMain:GetModule("cf"):RankChangedUpdater()

						return
					end

					if v.Name == "ExecuteClientCommand" then
						local v11 = p1[1]
						local v12 = p1[2]
						local v14 = if p1[4].UnFunction then "UnFunction" else "Function"
						local v15 = HDAdminMain:GetModule("ClientCommands")[p1[3]]

						if not v15 then
							return
						end

						local v16 = v15[v14]

						if v16 then
							v16(v11, v12, v15)
						end
					elseif v.Name == "ReplicationEffectClientCommand" then
						local v18 = p1[2]
						local v19 = p1[3]
						local v20 = HDAdminMain:GetModule("ClientCommands")[p1[1]]

						if not v20 then
							return
						end

						local ReplicationEffect = v20.ReplicationEffect

						if ReplicationEffect then
							ReplicationEffect(v18, v19, v20)
						end
					elseif v.Name == "ActivateClientCommand" then
						local v21 = p1[1]
						local v22 = p1[2]
						local v23 = if v22 then v22.Speed ~= 0 and v22.Speed or nil else v22

						if v23 then
							HDAdminMain.commandSpeeds[v21] = v23

							local CommandMenufly = HDAdminMain.gui:FindFirstChild("CommandMenufly")

							HDAdminMain:GetModule("cf"):DestroyCommandMenuFrame(CommandMenufly)
						end

						if HDAdminMain.commandSpeeds[v21] then
							for k, v2 in pairs(HDAdminMain.commandSpeeds) do
								if k ~= v21 then
									HDAdminMain:GetModule("cf"):DeactivateCommand(k)
								end
							end
						end

						HDAdminMain.commandsAllowedToUse[v21] = true
						HDAdminMain:GetModule("cf"):ActivateClientCommand(v21, v22)

						local v24 = nil
						local v25 = nil

						for k, v2 in pairs(HDAdminMain.commandsWithMenus) do
							v24 = v2[v21]

							if v24 then
								v25 = tonumber(k:match("%d+"))

								break
							end
						end

						if v24 then
							HDAdminMain:GetModule("cf"):CreateNewCommandMenu(v21, v24, v25)
						end
					else
						if v.Name == "DeactivateClientCommand" then
							HDAdminMain:GetModule("cf"):DeactivateCommand(p1[1])

							return
						end

						if v.Name == "FadeInIcon" then
							return
						end

						if v.Name ~= "ChangeMainVariable" then
							return
						end

						HDAdminMain[p1[1]] = p1
					end
				end
			end
		end)

		continue
	end

	if v:IsA("RemoteFunction") then
		function v.OnClientInvoke(p1) --[[ OnClientInvoke | Line: 188 | Upvalues: HDAdminMain (copy), v (copy) ]]
			if not HDAdminMain.initialized then
				HDAdminMain.client.Signals.Initialized.Event:Wait()
			end

			if v.Name == "GetLocalDate" then
				return os.date("*t", p1)
			end
		end
	end
end

return {}