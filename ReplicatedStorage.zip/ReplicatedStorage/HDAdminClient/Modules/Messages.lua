-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain
local MessageContainer = Instance.new("Folder")

MessageContainer.Name = "MessageContainer"
MessageContainer.Parent = HDAdminMain.gui

local t = {}

for k, v in pairs({ "Messages", "Hints" }) do
	local Frame = Instance.new("Frame")

	Frame.Size = UDim2.new(1, 0, 1, 0)
	Frame.Position = UDim2.new(0, 0, 0, 0)
	Frame.BackgroundTransparency = 1
	Frame.Name = v

	if v == "Hints" then
		Instance.new("UIListLayout").Parent = Frame
	end

	Frame.Parent = MessageContainer
end

local function getTargetProp(p1) --[[ getTargetProp | Line: 30 ]]
	if p1:IsA("Frame") then
		return "BackgroundTransparency"
	end

	if p1:IsA("TextLabel") then
		return "TextTransparency"
	end

	if p1:IsA("ImageLabel") then
		return "ImageTransparency"
	end
end

local function displayMessages(p1, p2, p3) --[[ displayMessages | Line: 40 | Upvalues: HDAdminMain (copy) ]]
	for k, v in pairs(p1) do
		local v1 = if v:IsA("Frame") and p2 < 0.35 then 0.35 else p2
		local t = {}

		t[if v:IsA("Frame") then "BackgroundTransparency" elseif v:IsA("TextLabel") then "TextTransparency" elseif v:IsA("ImageLabel") then "ImageTransparency" else nil] = v1
		HDAdminMain.tweenService:Create(v, TweenInfo.new(p3), t):Play()
	end

	wait(p3)
end

local function getMessageAppearOrder(p1) --[[ getMessageAppearOrder | Line: 52 ]]
	return {
		{ p1.Bg },
		{ p1.Title, p1.SubTitle, p1.Pic },
		{ p1.Desc }
	}
end

function t.Message(p1, p2) --[[ Message | Line: 64 | Upvalues: MessageContainer (copy), HDAdminMain (copy), displayMessages (copy), getMessageAppearOrder (copy) ]]
	local Messages = MessageContainer.Messages
	local v1 = p2[1]
	local v2 = p2[2]
	local v3 = p2[3]
	local v4 = p2[4]
	local v5 = p2[5]
	local v6 = p2[6]
	local v7 = HDAdminMain.templates.Message:Clone()

	for k, v in pairs(v7:GetChildren()) do
		v[if v:IsA("Frame") then "BackgroundTransparency" elseif v:IsA("TextLabel") then "TextTransparency" elseif v:IsA("ImageLabel") then "ImageTransparency" else nil] = 1
	end

	v7.Visible = true

	if v2 == "Countdown" then
		local t = { v7.Bg, v7.Title, v7.Desc }

		v7.Title.Text = "Aguarde"
		v7.Title.TextColor3 = Color3.fromRGB(200, 200, 200)
		v7.Desc.TextColor3 = v6
		v7.Parent = Messages
		spawn(function() --[[ Line: 87 | Upvalues: displayMessages (ref), t (copy) ]]
			displayMessages(t, 0, 0.4)
		end)

		for i = 1, v5 do
			v7.Desc.Text = v5 + 1 - i
			wait(1)
		end

		displayMessages(t, 1, 0.4)
	else
		v7.Title.Text = v3
		v7.SubTitle.Text = v3
		v7.Desc.Text = v5
		v7.Desc.TextColor3 = v6

		if v2 == "Server" or v1 == nil then
			v7.Pic.Visible = false
			v7.SubTitle.Visible = false
		else
			v7.Pic.Position = UDim2.new(0.5, -(HDAdminMain.textService:GetTextSize(v3, v7.Title.TextSize, v7.Title.Font, Vector2.new(0, 0)).X / 2 + 75))
			v7.Pic.Image = HDAdminMain:GetModule("cf"):GetUserImage(v1.UserId)
			v7.SubTitle.Text = v4
		end

		v7.Parent = Messages

		local v10 = getMessageAppearOrder(v7)

		for j = 1, #v10 do
			displayMessages(v10[j], 0, 0.4)
		end

		wait(HDAdminMain:GetModule("cf"):GetMessageTime(v5))

		for k = 1, #v10 do
			displayMessages(v10[#v10 + 1 - k], 1, 0.4)
		end
	end

	v7:Destroy()
end
function t.Hint(p1, p2) --[[ Hint | Line: 125 | Upvalues: MessageContainer (copy), HDAdminMain (copy), displayMessages (copy) ]]
	local Hints = MessageContainer.Hints
	local v2 = p2[2]
	local v3 = p2[3]
	local v4 = HDAdminMain.templates.Hint:Clone()
	local t = {}

	for k, v in pairs(v4:GetChildren()) do
		v[if v:IsA("Frame") then "BackgroundTransparency" elseif v:IsA("TextLabel") then "TextTransparency" elseif v:IsA("ImageLabel") then "ImageTransparency" else nil] = 1
		table.insert(t, v)
	end

	v4.Desc.Text = v2
	v4.Desc.TextColor3 = v3
	v4.Parent = Hints
	v4.Visible = true

	if p2[1] == "Countdown" then
		spawn(function() --[[ Line: 145 | Upvalues: displayMessages (ref), t (copy) ]]
			displayMessages(t, 0, 0.6)
		end)

		for i = 1, v2 do
			v4.Desc.Text = v2 + 1 - i
			wait(1)
		end
	else
		v4.Desc.Text = v2
		v4.Desc.TextColor3 = v3
		v4.Parent = Hints
		displayMessages(t, 0, 0.6)
		wait(HDAdminMain:GetModule("cf"):GetMessageTime(v2))
	end

	displayMessages(t, 1, 0.6)
	v4:Destroy()
end
function t.GlobalAnnouncement(p1, p2) --[[ GlobalAnnouncement | Line: 168 | Upvalues: MessageContainer (copy), HDAdminMain (copy), getMessageAppearOrder (copy), displayMessages (copy) ]]
	local v1 = HDAdminMain.templates.GlobalAnnouncement:Clone()
	local DisplayFrom = p2.DisplayFrom

	for k, v in pairs(v1:GetChildren()) do
		v[if v:IsA("Frame") then "BackgroundTransparency" elseif v:IsA("TextLabel") then "TextTransparency" elseif v:IsA("ImageLabel") then "ImageTransparency" else nil] = 1
	end

	v1.Visible = true
	v1.Title.Text = p2.Title
	v1.Pic.Visible = DisplayFrom
	v1.SubTitle.Visible = DisplayFrom
	v1.Pic.Position = UDim2.new(0.5, -(HDAdminMain.textService:GetTextSize(v1.SubTitle.Text, v1.SubTitle.TextSize, v1.SubTitle.Font, Vector2.new(0, 0)).X / 2 + 30), 0, 60)

	if DisplayFrom then
		v1.Pic.Image = HDAdminMain:GetModule("cf"):GetUserImage(p2.SenderId)
		v1.SubTitle.Text = "de " .. p2.SenderName
	end

	v1.Desc.TextColor3 = Color3.new(p2.Color[1], p2.Color[2], p2.Color[3])
	v1.Desc.Text = p2.Message
	v1.Parent = MessageContainer.Messages

	local v4 = getMessageAppearOrder(v1)

	for i = 1, #v4 do
		displayMessages(v4[i], 0, 0.4)
	end

	wait(HDAdminMain:GetModule("cf"):GetMessageTime(p2.Message) * 1.5)

	for j = 1, #v4 do
		displayMessages(v4[#v4 + 1 - j], 1, 0.4)
	end

	v1:Destroy()
end
function t.ClearMessageContainer(p1) --[[ ClearMessageContainer | Line: 206 | Upvalues: MessageContainer (copy) ]]
	for k, v in pairs(MessageContainer:GetChildren()) do
		for k2, v2 in pairs(v:GetChildren()) do
			if v2:IsA("Frame") then
				v2.Visible = false
			end
		end
	end
end

return t