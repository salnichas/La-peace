-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local CustomTopBar = HDAdminMain.gui.CustomTopBar
local t2 = { "Chat", "PlayerList" }
local t3 = {}
local CmdBar = HDAdminMain.gui.CmdBar
local v1 = false
local t4 = {}
local v2 = 1
local v3 = true
local t5 = {
	maxSuggestions = 5,
	suggestionPos = 1,
	suggestionDisplayed = 0,
	forceExecute = false,
	currentBarCommand = nil,
	mainParent = CmdBar,
	textBox = CmdBar.SearchFrame.TextBox,
	rframe = CmdBar.ResultsFrame,
	highlightColor = Color3.fromRGB(50, 50, 50),
	otherColor = Color3.fromRGB(80, 80, 80),
	suggestionLabels = {}
}

local function selectSuggestion(p1) --[[ selectSuggestion | Line: 36 | Upvalues: HDAdminMain (copy) ]]
	local v1 = ""
	local v2 = p1.suggestionLabels["Label" .. p1.suggestionPos]

	if p1.specificArg then
		local v3 = v2.Name .. " "

		p1.textBox.Text = v3
		coroutine.wrap(function() --[[ Line: 43 | Upvalues: p1 (copy) ]]
			for i = 1, 10 do
				p1.textBox:ReleaseFocus()
				wait()
			end
		end)()
		wait()
		p1.textBox.Text = v3

		return
	end

	local t = {}
	local v4 = -1
	local v5 = string.sub(p1.textBox.Text, 1, 1)

	p1.textBox.Text:gsub("([^" .. HDAdminMain.pdata.SplitKey .. "]+)", function(p1) --[[ Line: 55 | Upvalues: v4 (ref), v2 (copy), t (copy) ]]
		v4 = v4 + 1

		if not (v4 > v2.ArgPos - 1) then
			table.insert(t, p1 .. " ")
		end
	end)

	if v4 == 0 and (v5 == HDAdminMain.settings.UniversalPrefix or v5 == HDAdminMain.pdata.Prefix) then
		v1 = v5
	end

	local v6 = ((v1 .. table.concat(t, "")) .. v2.Name) .. HDAdminMain.pdata.SplitKey

	p1.textBox.Text = v6
	wait()
	p1.textBox.Text = v6
	p1.textBox:CaptureFocus()
	p1.textBox.CursorPosition = #v6 + 1
end

CmdBar.Visible = false

local function createSuggestionLabels(p1) --[[ createSuggestionLabels | Line: 80 | Upvalues: selectSuggestion (copy) ]]
	for i = 1, p1.maxSuggestions do
		local v1 = p1.rframe.LabelTemplate:Clone()

		v1.Name = "Label" .. i
		v1.Visible = false
		v1.Parent = p1.rframe
		v1.MouseEnter:Connect(function() --[[ Line: 86 | Upvalues: p1 (copy), i (copy) ]]
			p1.suggestionPos = i
		end)
		v1.MouseButton1Up:Connect(function() --[[ Line: 89 | Upvalues: p1 (copy), i (copy), selectSuggestion (ref) ]]
			p1.suggestionPos = i
			selectSuggestion(p1)
		end)
	end
end

local function setupEnterPress(p1) --[[ setupEnterPress | Line: 97 | Upvalues: selectSuggestion (copy), HDAdminMain (copy), t (copy) ]]
	p1.textBox.FocusLost:connect(function(p1) --[[ Line: 98 | Upvalues: p1 (copy), selectSuggestion (ref), HDAdminMain (ref), t (ref) ]]
		if p1.mainParent.Name == "CmdBar" and not p1.specificArg then
			if p1.suggestionDisplayed > 0 and (not forceExecute and HDAdminMain.device ~= "Mobile") then
				selectSuggestion(p1)

				return
			end

			if not p1 then
				return
			end

			if forceExecute then
				selectSuggestion(p1)
			end

			t:CloseCmdBar()

			if not (#p1.textBox.Text > 1) then
				return
			end

			local Text = p1.textBox.Text
			local v1 = string.sub(Text, 1, 1)

			if v1 ~= HDAdminMain.settings.UniversalPrefix and v1 ~= HDAdminMain.pdata.Prefix then
				Text = HDAdminMain.pdata.Prefix .. Text
			end

			if string.sub(Text, -1) == " " then
				Text = string.sub(Text, 1, -1)
			end

			HDAdminMain.signals.RequestCommand:InvokeServer(Text)
		elseif p1.suggestionDisplayed > 0 then
			selectSuggestion(p1, p1.specificArg)
		end
	end)
end

function t.SetupTextbox(p1, p2, p3) --[[ SetupTextbox | Line: 130 | Upvalues: t4 (copy), createSuggestionLabels (copy), selectSuggestion (copy), HDAdminMain (copy), t (copy) ]]
	local function collectArguments(p1, p2, p32, p4) --[[ collectArguments | Line: 131 | Upvalues: p3 (copy) ]]
		if string.sub(string.lower(p4), 1, #p2) ~= p2 then
			return
		end

		table.insert(p1, {
			Name = p4,
			ArgPos = p32
		})

		if #p1 == p3.maxSuggestions then
			return true
		end
	end

	local specificArg = p3.specificArg

	t4[p2] = p3
	createSuggestionLabels(p3)
	p3.textBox.FocusLost:connect(function(p1) --[[ Line: 98 | Upvalues: p3 (copy), selectSuggestion (ref), HDAdminMain (ref), t (ref) ]]
		if p3.mainParent.Name == "CmdBar" and not p3.specificArg then
			if p3.suggestionDisplayed > 0 and (not forceExecute and HDAdminMain.device ~= "Mobile") then
				selectSuggestion(p3)

				return
			end

			if not p1 then
				return
			end

			if forceExecute then
				selectSuggestion(p3)
			end

			t:CloseCmdBar()

			if not (#p3.textBox.Text > 1) then
				return
			end

			local Text = p3.textBox.Text
			local v1 = string.sub(Text, 1, 1)

			if v1 ~= HDAdminMain.settings.UniversalPrefix and v1 ~= HDAdminMain.pdata.Prefix then
				Text = HDAdminMain.pdata.Prefix .. Text
			end

			if string.sub(Text, -1) == " " then
				Text = string.sub(Text, 1, -1)
			end

			HDAdminMain.signals.RequestCommand:InvokeServer(Text)
		elseif p3.suggestionDisplayed > 0 then
			selectSuggestion(p3, p3.specificArg)
		end
	end)

	local v1 = nil

	p3.textBox.Changed:connect(function(p1) --[[ Line: 144 | Upvalues: specificArg (copy), p3 (copy), HDAdminMain (ref), collectArguments (copy), v1 (ref) ]]
		if p1 ~= "Text" then
			return
		end

		local v12 = -1
		local v2 = nil
		local t = {}

		if specificArg then
			table.insert(t, p3.textBox.Text)
			v12 = 1
		else
			p3.textBox.Text:gsub("([^" .. HDAdminMain.pdata.SplitKey .. "]+)", function(p1) --[[ Line: 153 | Upvalues: v12 (ref), v2 (ref), t (copy) ]]
				v12 = v12 + 1

				if v12 == 0 then
					v2 = p1

					return
				end

				if not (v12 > 0) then
					return
				end

				table.insert(t, p1)
			end)

			if v12 > 0 and not p3.currentBarCommand then
				local v3 = string.sub(v2, 1, 1)

				if v3 == HDAdminMain.settings.UniversalPrefix or v3 == HDAdminMain.pdata.Prefix then
					v2 = string.sub(v2, 2)
				end

				v2 = string.lower(v2)

				for k, v in pairs(HDAdminMain.commandInfo) do
					if string.lower(v.Name) == v2 then
						p3.currentBarCommand = v

						continue
					end

					if v.Aliases then
						for k2, v4 in pairs(v.Aliases) do
							if string.lower(v4) == v2 then
								p3.currentBarCommand = v
							end
						end
					end
				end
			elseif v12 <= 0 then
				p3.currentBarCommand = nil
			end
		end

		local t2 = {}

		p3.suggestionPos = 1

		if #p3.textBox.Text > 1 or specificArg and #p3.textBox.Text > 0 then
			if v12 == 0 then
				local v4 = string.lower((string.sub(p3.textBox.Text, 2)))
				local v5 = string.lower((string.sub(p3.textBox.Text, 1, 1)))

				for k, v in pairs(HDAdminMain.commandInfo) do
					local v6 = string.lower(v.Name)
					local v7 = v.Prefixes[1]

					if string.sub(v6, 1, #v4) == v4 and v7 == v5 then
						table.insert(t2, {
							ArgPos = 0,
							Name = v.Name,
							Args = v.Args,
							Prefixes = v.Prefixes
						})

						if #t2 == p3.maxSuggestions then
							break
						end
					end

					local UnFunction = v.UnFunction

					if UnFunction and (string.sub(string.lower(UnFunction), 1, #v4) == v4 and v7 == v5) then
						table.insert(t2, {
							ArgPos = 0,
							Name = UnFunction,
							Args = {},
							Prefixes = v.Prefixes
						})

						if #t2 == p3.maxSuggestions then
							break
						end
					end
				end
			elseif p3.currentBarCommand or specificArg then
				local v9 = if specificArg then specificArg else p3.currentBarCommand.Args[v12]
				local v10 = string.lower(t[v12])
				local v11 = string.sub(p3.textBox.Text, -1)

				if v11 ~= " " and v11 ~= HDAdminMain.pdata.SplitKey then
					if v9 == "player" or v9 == "playerarg" then
						for k, v in pairs(HDAdminMain.qualifiers) do
							if collectArguments(t2, v10, v12, v) then
								break
							end
						end

						if #t2 < p3.maxSuggestions then
							for k, v in pairs(HDAdminMain.players:GetChildren()) do
								if collectArguments(t2, v10, v12, v.Name) then
									break
								end
							end
						end
					elseif v9 == "colour" or (v9 == "color" or v9 == "color3") then
						for k, v in pairs(HDAdminMain.colors) do
							if collectArguments(t2, v10, v12, v) then
								break
							end
						end
					elseif v9 == "material" then
						for k, v in pairs(HDAdminMain.materials) do
							if collectArguments(t2, v10, v12, v) then
								break
							end
						end
					elseif v9 == "rank" then
						for k, v in pairs(HDAdminMain.settings.Ranks) do
							if collectArguments(t2, v10, v12, v[2]) then
								break
							end
						end
					elseif v9 == "team" or v9 == "teamcolor" then
						for k, v in pairs(HDAdminMain.teams:GetChildren()) do
							if collectArguments(t2, v10, v12, v.Name) then
								break
							end
						end
					elseif v9 == "morph" then
						for k, v in pairs(HDAdminMain.morphNames) do
							if collectArguments(t2, v10, v12, k) then
								break
							end
						end
					elseif v9 == "tools" or (v9 == "gears" or (v9 == "tool" or v9 == "gear")) then
						for k, v in pairs(HDAdminMain.toolNames) do
							if collectArguments(t2, v10, v12, k) then
								break
							end
						end
					end
				end
			end
		end

		p3.suggestionDisplayed = #t2

		if p3.currentBarCommand and (#p3.currentBarCommand.Args == v12 and p3.suggestionDisplayed > 0) then
			forceExecute = true
		else
			forceExecute = false
		end

		for i = 1, p3.maxSuggestions do
			local v122 = t2[i]
			local v13 = p3.rframe["Label" .. i]

			if v122 then
				local v14 = v122.Args and true or false
				local v15 = if v14 and v122.Prefixes[1] == HDAdminMain.settings.UniversalPrefix then true else false
				local t3 = {}

				if v14 then
					for k, v in pairs(v122.Args) do
						if not v15 or (v ~= "player" or v == "playerarg") then
							table.insert(t3, "<" .. v .. ">")
						end
					end
				end

				v13.TextLabel.Text = v122.Name .. " " .. table.concat(t3, " ")

				if i == p3.suggestionPos then
					v13.BackgroundColor3 = p3.highlightColor
				else
					v13.BackgroundColor3 = p3.otherColor
				end

				p3.suggestionLabels["Label" .. i] = v122

				if p3.mainParent.Name ~= "CmdBar" then
					local Y = p3.rframe.LabelTemplate.AbsoluteSize.Y

					if HDAdminMain.gui.Notices.AbsoluteSize.Y < p3.rframe.AbsolutePosition.Y + Y * i + 5 then
						if not v1 then
							v1 = p3.mainParent.Position
						end

						p3.mainParent.Position = p3.mainParent.Position - UDim2.new(0, 0, 0, Y)
					end
				end

				v13.Visible = true

				continue
			end

			v13.Visible = false
		end

		if v1 and #t2 < 1 then
			p3.mainParent.Position = v1
			v1 = nil
		end

		if #t2 < 1 and p3.mainParent.Name ~= "CmdBar" then
			p3.mainParent.ClipsDescendants = true
		else
			p3.mainParent.ClipsDescendants = false
		end
	end)
end
t:SetupTextbox("cmdbar1", t5)
function t.ToggleBar(p1, p2) --[[ ToggleBar | Line: 340 | Upvalues: HDAdminMain (copy), t4 (copy) ]]
	if p2 == Enum.KeyCode.Quote then
		if HDAdminMain.gui.CmdBar.Visible then
			HDAdminMain:GetModule("CmdBar"):CloseCmdBar()
		else
			HDAdminMain:GetModule("CmdBar"):OpenCmdBar()
		end
	else
		if p2 ~= Enum.KeyCode.Semicolon then
			return
		end

		local Cmdbar2 = HDAdminMain.settings.Cmdbar2

		if not (HDAdminMain.pdata.Rank > 0 or Cmdbar2 <= 0) then
			return
		end

		if HDAdminMain.pdata.Rank < Cmdbar2 then
			local v1 = HDAdminMain:GetModule("cf"):FormatNotice("CommandBarLocked", "2", HDAdminMain:GetModule("cf"):GetRankName(Cmdbar2))

			HDAdminMain:GetModule("Notices"):Notice("Error", v1[1], v1[2])

			return
		end

		local cmdbar2 = t4.cmdbar2

		if not cmdbar2 then
			HDAdminMain:GetModule("ClientCommands").cmdbar2.Function()

			return
		end

		if cmdbar2.mainParent.Visible then
			cmdbar2.mainParent.Visible = false

			return
		end

		cmdbar2.mainParent.Visible = true
	end
end
function t.OpenCmdBar(p1) --[[ OpenCmdBar | Line: 370 | Upvalues: t5 (ref), HDAdminMain (copy), v1 (ref), t2 (copy), t3 (copy), CustomTopBar (copy), v2 (ref), v3 (ref), CmdBar (copy) ]]
	local v12 = t5
	local Cmdbar = HDAdminMain.settings.Cmdbar

	if not (HDAdminMain.pdata.Rank > 0 or Cmdbar <= 0) then
		return
	end

	if v1 then
		return
	end

	v1 = true

	if HDAdminMain.pdata.Rank < Cmdbar then
		local v22 = HDAdminMain:GetModule("cf"):FormatNotice("CommandBarLocked", "", HDAdminMain:GetModule("cf"):GetRankName(Cmdbar))

		HDAdminMain:GetModule("Notices"):Notice("Error", v22[1], v22[2])

		return
	end

	v12.textBox:CaptureFocus()

	for k, v in pairs(t2) do
		t3[v] = HDAdminMain.starterGui:GetCoreGuiEnabled(v)
		HDAdminMain.starterGui:SetCoreGuiEnabled(Enum.CoreGuiType[v], false)
	end

	CustomTopBar.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
	v2 = CustomTopBar.BackgroundTransparency
	v3 = CustomTopBar.Visible
	CustomTopBar.BackgroundTransparency = 0
	CustomTopBar.Visible = true
	v12.textBox.Text = ""
	CmdBar.Visible = true
	wait()
	v12.textBox.Text = HDAdminMain.pdata.Prefix
	v12.textBox.CursorPosition = 3
end
function t.CloseCmdBar(p1) --[[ CloseCmdBar | Line: 400 | Upvalues: v1 (ref), t5 (ref), CmdBar (copy), t2 (copy), t3 (copy), HDAdminMain (copy), CustomTopBar (copy), v2 (ref), v3 (ref) ]]
	if not v1 then
		return
	end

	v1 = false

	local v12 = t5

	CmdBar.Visible = false

	for k, v in pairs(t2) do
		local v22 = t3[v]

		if v22 then
			HDAdminMain.starterGui:SetCoreGuiEnabled(Enum.CoreGuiType[v], v22)
		end
	end

	CustomTopBar.BackgroundColor3 = Color3.fromRGB(31, 31, 31)
	CustomTopBar.BackgroundTransparency = v2
	CustomTopBar.Visible = v3
	coroutine.wrap(function() --[[ Line: 415 | Upvalues: v12 (copy) ]]
		for i = 1, 10 do
			v12.textBox:ReleaseFocus()
			wait()
		end
	end)()
end
function t.PressedArrowKey(p1, p2) --[[ PressedArrowKey | Line: 423 | Upvalues: t4 (copy), selectSuggestion (copy) ]]
	for k, v in pairs(t4) do
		if v.mainParent.Visible and v.textBox:IsFocused() then
			local v1 = v.rframe:FindFirstChild("Label" .. v.suggestionPos)

			if p2 == Enum.KeyCode.Down then
				v.suggestionPos = v.suggestionPos + 1

				if v.suggestionPos > v.suggestionDisplayed then
					v.suggestionPos = 1
				end
			elseif p2 == Enum.KeyCode.Up then
				v.suggestionPos = v.suggestionPos - 1

				if v.suggestionPos < 1 then
					v.suggestionPos = v.suggestionDisplayed
				end
			elseif p2 == Enum.KeyCode.Right then
				selectSuggestion(v)
			end

			local v2 = v.rframe["Label" .. v.suggestionPos]

			if v2 ~= v1 then
				v1.BackgroundColor3 = v.otherColor
				v2.BackgroundColor3 = v.highlightColor
			end
		end
	end
end

return t