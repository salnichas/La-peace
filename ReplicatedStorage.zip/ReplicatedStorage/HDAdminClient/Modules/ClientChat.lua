-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain

HDAdminMain.TextChatService.SendingMessage:Connect(function(p1) --[[ Line: 25 | Upvalues: HDAdminMain (copy) ]]
	local TextSource = p1.TextSource
	local v1 = if TextSource then HDAdminMain.players:FindFirstChild(TextSource.Name) else TextSource

	if not v1 then
		return
	end

	local v2 = v1:GetAttribute("ChatTag")
	local v3 = v1:GetAttribute("ChatTagColor")
	local v4 = v1:GetAttribute("ChatName")
	local v5 = v1:GetAttribute("ChatNameColor")

	if p1.TextSource then
		local v6 = if v2 then ("[%*]"):format(v2) else v2

		if v6 and v3 then
			v6 = ("<font color=\'#%*\'>%*</font>"):format(v3:ToHex(), v6)
		end

		local v10 = ("%*:"):format(if v4 then v4 else v1.DisplayName)

		if v10 and v5 then
			v10 = ("<font color=\'#%*\'>%*</font>"):format(v5:ToHex(), v10)
		end

		local v12 = if v6 then v6 .. " " .. v10 else v10
		local PrefixText = p1.PrefixText
		local v13 = string.match(PrefixText, "<.*>(.*)<.*>")

		if not v2 and v13 then
			local v14, v15 = string.find(string.reverse(PrefixText), string.reverse(v13))
			local v16 = string.len(PrefixText) - v15 + 1
			local v17 = string.len(PrefixText) - v14 + 1

			if v16 and v17 then
				local v18 = string.sub(PrefixText, 1, v16 - 1)
				local v19 = string.match(v18, "<.*>(.*)<.*>")
				local v20 = string.sub(PrefixText, v17 + 1)

				if v19 then
					v18 = v18 .. " "
				end

				v12 = v18 .. v12 .. v20
			end
		end

		p1.PrefixText = v12
	end

	return p1
end)

return {}