-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain
local tbl = {
	commandName1 = {
		Function = function(p1, p2) --[[ Function | Line: 11 | Upvalues: HDAdminMain (copy) ]]
			HDAdminMain:GetModule("cf"):ReplicateEffect(pianoKey)
			self.a = 0
		end,
		ReplicationEffect = function(p1, p2) --[[ ReplicationEffect | Line: 16 ]] end
	},
	commandName2 = {
		Function = function(p1, p2) --[[ Function | Line: 26 ]] end
	}
}

for k, v in pairs(tbl) do
	v.Name = k
end

return tbl