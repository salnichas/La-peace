-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local t2 = {
	About = { "Info", "Updates", "Credits" },
	Commands = { "Commands", "Morphs", "Details" },
	Special = { "Donor" },
	Admin = { "Ranks", "Server Ranks", "Banland" },
	Settings = { "Custom" }
}
local MainFrame = HDAdminMain.gui.MainFrame
local ImageButton = HDAdminMain.gui.CustomTopBar.ImageButton
local Pages = MainFrame.Pages
local Home = Pages.Home

local function displayHomeArrowIcons(p1) --[[ displayHomeArrowIcons | Line: 26 | Upvalues: MainFrame (copy) ]]
	for k, v in pairs(MainFrame.Pages.Home:GetChildren()) do
		if v:FindFirstChild("Arrow") then
			v.Arrow.Visible = p1
		end
	end
end

local function updateDragBar() --[[ updateDragBar | Line: 34 | Upvalues: Home (ref), HDAdminMain (copy), MainFrame (copy), displayHomeArrowIcons (copy) ]]
	if Home.Name == "Home" then
		local v1 = HDAdminMain.hdAdminCoreName:find(" ")

		MainFrame.DragBar.Title.Text = HDAdminMain.hdAdminCoreName:sub(1, v1 - 1) .. HDAdminMain.hdAdminCoreName:sub(v1):upper()
		MainFrame.DragBar.Back.Visible = false
		MainFrame.DragBar.Title.Position = UDim2.new(0.04, 0, 0.15, 0)
		displayHomeArrowIcons(true)

		return
	end

	local t = {
		About = "Sobre",
		Admin = "Admin",
		Commands = "Comandos",
		Home = "Menu",
		Settings = "Configura\195\167\195\181es",
		Special = "Especiais"
	}

	MainFrame.DragBar.Title.Text = string.upper(t[Home.Name] and t[Home.Name] or Home.Name)
	MainFrame.DragBar.Back.Visible = true
	MainFrame.DragBar.Title.Position = UDim2.new(0.15, 0, 0.15, 0)
	displayHomeArrowIcons(false)
end

local function tweenPages(p1, p2, p3) --[[ tweenPages | Line: 58 | Upvalues: Home (ref), HDAdminMain (copy), updateDragBar (copy) ]]
	local v2 = TweenInfo.new(if p3 then 0 else 0.3, Enum.EasingStyle.Quad)
	local v3 = Home
	local v4 = HDAdminMain.tweenService:Create(Home, v2, {
		Position = p1
	})
	local v5 = HDAdminMain.tweenService:Create(p2, v2, {
		Position = UDim2.new(0, 0, 0, 0)
	})

	if p2.Name == "Home" then
		p2.Position = UDim2.new(-1, 0, 0, 0)
	else
		p2.Position = UDim2.new(1, 0, 0, 0)

		if p2.Name == "Admin" then
			spawn(function() --[[ Line: 74 | Upvalues: HDAdminMain (ref) ]]
				HDAdminMain:GetModule("PageAdmin"):UpdatePages()
			end)
		end
	end

	p2.Visible = true
	v4:Play()
	v5:Play()
	Home = p2
	updateDragBar()
	v5.Completed:Wait()
	v3.Visible = false
end

MainFrame.Visible = false

local v1 = true

for k, v in pairs(Pages.Home:GetChildren()) do
	if v:IsA("TextButton") then
		local Fade = v.Fade

		local function pressButton() --[[ pressButton | Line: 95 | Upvalues: v1 (ref), Pages (copy), v (copy), tweenPages (copy) ]]
			if not v1 then
				return
			end

			v1 = false

			local v12 = Pages:FindFirstChild(v.Name)

			if v12 then
				tweenPages(UDim2.new(-1, 0, 0, 0), v12)
			end

			v1 = true
		end

		if HDAdminMain.device == "Mobile" then
			v.MouseButton1Up:Connect(function() --[[ Line: 106 | Upvalues: v1 (ref), Pages (copy), v (copy), tweenPages (copy) ]]
				if not v1 then
					return
				end

				v1 = false

				local v12 = Pages:FindFirstChild(v.Name)

				if v12 then
					tweenPages(UDim2.new(-1, 0, 0, 0), v12)
				end

				v1 = true
			end)
		else
			v.MouseButton1Down:Connect(function() --[[ Line: 110 | Upvalues: v1 (ref), Pages (copy), v (copy), tweenPages (copy) ]]
				if not v1 then
					return
				end

				v1 = false

				local v12 = Pages:FindFirstChild(v.Name)

				if v12 then
					tweenPages(UDim2.new(-1, 0, 0, 0), v12)
				end

				v1 = true
			end)
		end

		v.InputBegan:Connect(function(p1) --[[ Line: 114 | Upvalues: v (copy), HDAdminMain (copy), Fade (copy) ]]
			if v.RankBlocker.Visible then
				return
			end

			HDAdminMain.tweenService:Create(Fade, TweenInfo.new(0.2), {
				BackgroundTransparency = 0.8
			}):Play()
		end)
		v.InputEnded:Connect(function(p1) --[[ Line: 119 | Upvalues: HDAdminMain (copy), Fade (copy) ]]
			HDAdminMain.tweenService:Create(Fade, TweenInfo.new(0.2), {
				BackgroundTransparency = 1
			}):Play()
		end)
	end
end

local function navigateNewPage(p1, p2, p3, p4, p5) --[[ navigateNewPage | Line: 126 | Upvalues: t2 (copy), HDAdminMain (copy) ]]
	local v2 = TweenInfo.new(if p5 then 0 else 0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v3 = t2[p1.Name]
	local v4 = if tonumber(p2) then p1[v3[p2]] else nil
	local v5 = p1[v3[p3]]
	local v6 = nil

	if v4 and v4:IsA("ScrollingFrame") then
		v4.ScrollBarImageTransparency = 1
	end

	if v5:IsA("ScrollingFrame") then
		v5.ScrollBarImageTransparency = 0
	end

	local SearchBar = p1:FindFirstChild("SearchBar")

	if SearchBar and v5.Size.Y.Scale < 0.85 then
		SearchBar.Visible = true
	elseif SearchBar then
		SearchBar.Visible = false
	end

	for k, v in pairs(v3) do
		local v7 = p1[v]

		if v7 ~= v5 and v7 ~= v4 then
			v7.Position = UDim2.new(-2, 0, v7.Position.Y.Scale, 0)
		end
	end

	if p4 == "Right" then
		v6 = 1
	elseif p4 == "Left" then
		v6 = -1
	end

	local v8 = v6 * -1

	p1.NavigateButtons.TextLabel.Text = string.upper(v5.Name)
	v5.Position = UDim2.new(v6, 0, v5.Position.Y.Scale, v5.Position.Y.Offset)
	HDAdminMain.tweenService:Create(v5, v2, {
		Position = UDim2.new(0, 0, v5.Position.Y.Scale, 0)
	}):Play()

	if v4 then
		local v9 = HDAdminMain.tweenService:Create(v4, v2, {
			Position = UDim2.new(v8, 0, v4.Position.Y.Scale, 0)
		})

		v9:Play()
		spawn(function() --[[ Line: 176 | Upvalues: v9 (copy), v4 (ref), v8 (copy) ]]
			v9.Completed:Wait()

			if v4.Position.X.Scale ~= v8 then
				return
			end

			v4.Position = UDim2.new(-2, 0, v4.Position.Y.Scale, 0)
		end)
	end
end

for k, v in pairs(Pages:GetChildren()) do
	if v:FindFirstChild("NavigateButtons") then
		local v2 = t2[v.Name]
		local v3 = 0
		local v4 = 1

		for k2, v5 in pairs(v2) do
			local v52 = v[v5]

			if k2 == 1 then
				v.NavigateButtons.TextLabel.Text = string.upper(v5)
			else
				v3 = 1
			end

			v52.Position = UDim2.new(v3, 0, v52.Position.Y.Scale, 0)
			v52.Visible = true
		end

		for k2, v5 in pairs(v.NavigateButtons:GetChildren()) do
			if v5:IsA("TextButton") then
				v5.MouseButton1Down:Connect(function() --[[ Line: 201 | Upvalues: v4 (ref), v5 (copy), v2 (copy), navigateNewPage (copy), v (copy) ]]
					local v1 = v4

					if v5.Name == "Right" then
						v4 = v4 + 1

						if #v2 < v4 then
							v4 = 1
						end
					elseif v5.Name == "Left" then
						v4 = v4 - 1

						if v4 < 1 then
							v4 = #v2
						end
					end

					navigateNewPage(v, v1, v4, v5.Name)
				end)
			end
		end
	end
end

for k, v in pairs(MainFrame.DragBar:GetChildren()) do
	if v:IsA("TextButton") then
		v.MouseButton1Down:Connect(function() --[[ Line: 223 | Upvalues: v1 (ref), v (copy), HDAdminMain (copy), Pages (copy), t (copy), tweenPages (copy) ]]
			if not v1 then
				return
			end

			v1 = false

			if v.Name == "Minimise" then
				if v.TextLabel.Text == "-" then
					HDAdminMain.tweenService:Create(Pages, TweenInfo.new(0.5), {
						Position = UDim2.new(0, 0, -0.8, 0)
					}):Play()
					v.TextLabel.Text = "+"
				else
					Pages.Parent.Visible = true
					HDAdminMain.tweenService:Create(Pages, TweenInfo.new(0.5), {
						Position = UDim2.new(0, 0, 0.1, 0)
					}):Play()
					v.TextLabel.Text = "-"
				end
			elseif v.Name == "Close" then
				t:CloseMainFrame()
			elseif v.Name == "Back" then
				tweenPages(UDim2.new(1, 0, 0, 0), Pages.Home)
			end

			v1 = true
		end)
	end
end

function t.OpenMainFrame(p1) --[[ OpenMainFrame | Line: 250 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain:GetModule("TopbarIcon"):select()
end
function t.CloseMainFrame(p1) --[[ CloseMainFrame | Line: 255 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain:GetModule("TopbarIcon"):deselect()
end
t:CloseMainFrame()
updateDragBar()
function t.ShowSpecificPage(p1, p2, p3) --[[ ShowSpecificPage | Line: 262 | Upvalues: Pages (copy), Home (ref), tweenPages (copy), t2 (copy), HDAdminMain (copy), t (copy), navigateNewPage (copy) ]]
	for k, v in pairs(Pages:GetChildren()) do
		if v.Name == p2 then
			if Home == v then
				v.Visible = true
			else
				tweenPages(UDim2.new(-1, 0, 0, 0), v, true)
			end

			local v1 = t2[v.Name]

			if v1 then
				local v2 = nil
				local v3 = nil

				for k2, v4 in pairs(v1) do
					local v42 = v[v4]

					if v42.Name == p3 then
						v3 = k2

						continue
					end

					if v42.Position.X.Scale == 0 then
						v2 = k2
					end
				end

				if v2 == nil then
					for i = 1, #v1 do
						if i ~= v3 then
							v2 = i
						end
					end
				end

				if p2 == "Admin" and Home.Name == "Admin" then
					spawn(function() --[[ Line: 292 | Upvalues: HDAdminMain (ref) ]]
						HDAdminMain:GetModule("PageAdmin"):UpdatePages()
					end)
				end

				t:OpenMainFrame()

				if v:FindFirstChild("NavigateButtons") then
					navigateNewPage(v, v2, v3, "Left", true)
				end
			end

			continue
		end

		if not v:IsA("UICorner") then
			v.Visible = false
		end
	end
end
t:ShowSpecificPage("Home")

local function showLoading(p1, p2) --[[ showLoading | Line: 311 ]]
	if p2 then
		p1.LoadingButton.Visible = true
		p1.MainButton.Visible = false
	else
		p1.LoadingButton.Visible = false
		p1.MainButton.Visible = true
	end
end

for k, v in pairs(HDAdminMain.warnings:GetChildren()) do
	v.CloseX.MouseButton1Down:Connect(function() --[[ Line: 321 | Upvalues: HDAdminMain (copy) ]]
		HDAdminMain.warnings.Visible = false
	end)

	local MainButton = v:FindFirstChild("MainButton")

	if MainButton then
		local v6 = true

		MainButton.MouseButton1Down:Connect(function() --[[ Line: 327 | Upvalues: v6 (ref), v (copy), MainButton (copy), HDAdminMain (copy) ]]
			if not v6 then
				return
			end

			v6 = false

			if v.Name == "BuyFrame" then
				local ProductId = MainButton.ProductId.Value

				if MainButton.ProductType.Value == "Gamepass" then
					HDAdminMain.marketplaceService:PromptGamePassPurchase(HDAdminMain.player, ProductId)
				else
					HDAdminMain.marketplaceService:PromptPurchase(HDAdminMain.player, ProductId)
				end
			elseif v.Name == "UnBan" then
				local v1 = v

				v1.LoadingButton.Visible = true
				v1.MainButton.Visible = false
				HDAdminMain.signals.RequestCommand:InvokeServer(HDAdminMain.pdata.Prefix .. "undirectban " .. v.PlrName.Text)
				HDAdminMain:GetModule("PageAdmin"):CreateBanland()

				local v2 = v

				v2.LoadingButton.Visible = false
				v2.MainButton.Visible = true
				HDAdminMain.warnings.Visible = false
			elseif v.Name == "PermRank" then
				local v3 = v

				v3.LoadingButton.Visible = true
				v3.MainButton.Visible = false

				local Text = v.PlrName.Text

				HDAdminMain.signals.RemovePermRank:InvokeServer({ HDAdminMain:GetModule("cf"):GetUserId(Text), Text })
				HDAdminMain:GetModule("PageAdmin"):CreateRanks()

				local v4 = v

				v4.LoadingButton.Visible = false
				v4.MainButton.Visible = true
				HDAdminMain.warnings.Visible = false
			elseif v.Name == "Teleport" then
				local v5 = v

				v5.LoadingButton.Visible = true
				v5.MainButton.Visible = false
				HDAdminMain.teleportService:Teleport(v.MainButton.PlaceId.Value)
				HDAdminMain.teleportService.TeleportInitFailed:Wait()

				local v62 = v

				v62.LoadingButton.Visible = false
				v62.MainButton.Visible = true
			end

			v6 = true
		end)
	end
end

HDAdminMain.warnings.Visible = false
function t.DisplayPagesAccordingToRank(p1, p2) --[[ DisplayPagesAccordingToRank | Line: 370 | Upvalues: HDAdminMain (copy), Pages (copy) ]]
	for k, v in pairs(HDAdminMain.settings.RankRequiredToViewPage) do
		local v1 = Pages.Home:FindFirstChild(k)
		local v2 = tonumber(v)
		local v3 = if v2 then v2 else 0

		if v1 then
			if k == "About" or (k == "Special" or not (HDAdminMain.pdata.Rank < v3)) then
				v1.RankBlocker.Visible = false

				continue
			end

			v1.RankBlocker.Visible = true
			v1.RankBlocker.TextLabel.Text = HDAdminMain:GetModule("cf"):GetRankName(v3) .. "+"
		end
	end
end

for k, v in pairs(HDAdminMain.gui.MenuTemplates:GetChildren()) do
	if v:IsA("Frame") then
		v.Visible = false
	end
end

return t