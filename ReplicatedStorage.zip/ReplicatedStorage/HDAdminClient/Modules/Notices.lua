-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local Notices = HDAdminMain.gui.Notices
local Template = Notices.Template
local v1 = true
local t2 = {}
local t3 = {}
local v2 = TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v3 = TweenInfo.new(0.625, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v4 = TweenInfo.new(0.625, Enum.EasingStyle.Back, Enum.EasingDirection.In)

if HDAdminMain.device ~= "Mobile" then
	Template.Position = UDim2.new(1, 0, 1, -90)
	Template.Size = UDim2.new(0, 245.7, 0, 90)
	Template.Desc.UITextSizeConstraint.MaxTextSize = 20.25
end

local function updateNotices(p1) --[[ updateNotices | Line: 35 | Upvalues: t3 (copy), v2 (copy), Template (copy), v3 (copy), HDAdminMain (copy) ]]
	for k, v in pairs(t3) do
		local v1

		if not v.Complete.Value then
			local v22 = v2

			if k == 1 then
				v1 = Template.Position + UDim2.new(0, -v.Size.X.Offset, 0, 0)
			else
				local _ = t3[k - 1]

				v1 = UDim2.new(v.Position.X.Scale, v.Position.X.Offset, v.Position.Y.Scale, Template.Position.Y.Offset - (k - 1) * (Template.Size.Y.Offset + 5))
			end

			if v1.Y.Offset > v.Position.Y.Offset then
				v22 = v3
			end

			if v1 then
				HDAdminMain.tweenService:Create(v, v22, {
					Position = v1
				}):Play()
			end
		end
	end
end

local function endNotice(p1) --[[ endNotice | Line: 56 | Upvalues: t3 (copy), HDAdminMain (copy), v4 (copy), updateNotices (copy) ]]
	if not p1:FindFirstChild("Complete") or p1.Complete.Value then
		updateNotices()

		return
	end

	p1.Complete.Value = true

	for k, v in pairs(t3) do
		if v == p1 then
			table.remove(t3, k)

			local v1 = HDAdminMain.tweenService:Create(p1, v4, {
				Position = p1.Position + UDim2.new(0, p1.Size.X.Offset - 0, 0, 0)
			})

			v1:Play()
			v1.Completed:Wait()
			p1:Destroy()
		end
	end

	updateNotices()
end

local function Queue() --[[ Queue | Line: 72 | Upvalues: v1 (ref), t2 (copy), Notices (copy), HDAdminMain (copy), t3 (copy), endNotice (copy), updateNotices (copy) ]]
	if not v1 then
		return
	end

	v1 = false

	repeat
		wait()

		if not (#t2 > 0) then
			continue
		end

		local v12 = t2[1]

		v12.Parent = Notices

		if v12.NoticeType.Value == "Error" then
			HDAdminMain.audio.Error:Play()
		else
			HDAdminMain.audio.Notice:Play()
		end

		table.insert(t3, 1, v12)

		if v12.Countdown.Value < 900 then
			spawn(function() --[[ Line: 87 | Upvalues: v12 (copy), endNotice (ref) ]]
				if v12.Countdown.Value > 0 then
					local v1 = os.time()

					repeat
						wait()
					until os.time() ~= v1

					local Text = v12.Desc.Text

					for i = 1, v12.Countdown.Value do
						if not v12:FindFirstChild("Desc") or v12.Desc.Text == "Teleportando..." then
							break
						end

						v12.Desc.Text = Text .. " (" .. v12.Countdown.Value + 1 - i .. ")"
						wait(1)
					end
				else
					local v2 = tick()

					repeat
						wait(0.1)
					until tick() - v2 >= 7
				end

				endNotice(v12)
			end)
		end

		updateNotices(true)
		wait(0.5)
		table.remove(t2, 1)
	until #t2 < 1

	v1 = true
end

function t.Notice(p1, p2, p3, p4, p5) --[[ Notice | Line: 119 ]]
	require(game:WaitForChild("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("NotificationClient")):Notification(p2, p3, p4, p5)
end

return t