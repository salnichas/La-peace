-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local UnBan = HDAdminMain.warnings.UnBan
local PermRank = HDAdminMain.warnings.PermRank
local MenuTemplates = HDAdminMain.gui.MenuTemplates
local v1 = 1

local function setupOriginalZIndex(p1, p2) --[[ setupOriginalZIndex | Line: 20 ]]
	for k, v in pairs(p1:GetDescendants()) do
		if v:IsA("GuiObject") and v:FindFirstChild("OriginalZIndex") == nil then
			local OriginalZIndex = Instance.new("IntValue")

			OriginalZIndex.Name = "OriginalZIndex"

			local ZIndex = v.ZIndex

			if p2 then
				ZIndex = ZIndex + 10000
			end

			OriginalZIndex.Value = ZIndex
			OriginalZIndex.Parent = v
		end
	end
end

local function updateZIndex(p1, p2) --[[ updateZIndex | Line: 34 | Upvalues: HDAdminMain (copy) ]]
	for k, v in pairs(HDAdminMain.commandMenus) do
		for k2, v2 in pairs(v:GetDescendants()) do
			if v2:IsA("GuiObject") and (v2:FindFirstChild("OriginalZIndex") and (not p2 or v == p2)) then
				v2.ZIndex = v2.OriginalZIndex.Value + (k - 1) * 10 - 1000
			end
		end
	end
end

function t.ReplicateEffect(p1, p2, p3) --[[ ReplicateEffect | Line: 49 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain.signals.ReplicateEffect:FireServer(p2, p3)
end
function t.RankChangedUpdater(p1) --[[ RankChangedUpdater | Line: 53 | Upvalues: t (copy), HDAdminMain (copy) ]]
	t:UpdateIconVisiblity()
	HDAdminMain:GetModule("PageAbout"):UpdateRankName()
	HDAdminMain:GetModule("GUIs"):DisplayPagesAccordingToRank(true)

	if not HDAdminMain.initialized then
		return
	end

	HDAdminMain:GetModule("PageCommands"):CreateCommands()
end
function t.UpdateIconVisiblity(p1) --[[ UpdateIconVisiblity | Line: 62 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain:GetModule("TopbarIcon"):setEnabled(HDAdminMain.pdata.Rank >= HDAdminMain.settings.RankRequiredToViewIcon)
end
function t.DeactivateCommand(p1, p2) --[[ DeactivateCommand | Line: 72 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain.commandsAllowedToUse[p2] = nil
	HDAdminMain.commandsActive[p2] = nil

	if HDAdminMain.commandsToDisableCompletely[p2] then
		return
	end

	local v1 = HDAdminMain.gui:FindFirstChild("CommandMenu" .. p2)

	HDAdminMain:GetModule("cf"):DestroyCommandMenuFrame(v1)
end
function t.EndCommand(p1, p2) --[[ EndCommand | Line: 81 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain.commandsActive[p2] = nil
	HDAdminMain:GetModule("cf"):UpdateCommandMenu(p2)
end
function t.ActivateClientCommand(p1, p2, p3) --[[ ActivateClientCommand | Line: 86 | Upvalues: HDAdminMain (copy) ]]
	if not HDAdminMain.commandsAllowedToUse[p2] or (HDAdminMain.commandsActive[p2] or p3 and (p3.DontForceActivate and HDAdminMain.gui:FindFirstChild("CommandMenu" .. p2))) then
		return
	end

	HDAdminMain.commandsActive[p2] = true
	spawn(function() --[[ Line: 90 | Upvalues: HDAdminMain (ref), p2 (copy) ]]
		HDAdminMain:GetModule("cf"):UpdateCommandMenu(p2)

		local v1 = HDAdminMain:GetModule("ClientCommands")[p2]

		if v1 then
			local Activate = v1.Activate

			if Activate then
				Activate(v1)
			end
		end

		HDAdminMain.commandsActive[p2] = nil
	end)
end
function t.GetCF(p1, p2, p3) --[[ GetCF | Line: 105 ]]
	local v2 = CFrame.new(p2.CFrame.p)
	local v3, v4, v5 = (workspace.CurrentCamera.CFrame - workspace.CurrentCamera.CFrame.p):toEulerAnglesXYZ()

	return v2 * CFrame.Angles(if p3 and v5 then v5 else v3, v4, v5)
end
function t.GetNextMovement(p1, p2, p3) --[[ GetNextMovement | Line: 113 | Upvalues: HDAdminMain (copy), t (copy) ]]
	local sum = Vector3.new()
	local tbl = {
		Left = Vector3.new(-1, 0, 0),
		Right = Vector3.new(1, 0, 0),
		Forwards = Vector3.new(0, 0, -1),
		Backwards = Vector3.new(0, 0, 1),
		Up = Vector3.new(0, 1, 0),
		Down = Vector3.new(0, -1, 0)
	}

	if HDAdminMain.device == "Computer" then
		for k, v in pairs(HDAdminMain.movementKeysPressed) do
			local v1 = tbl[v]

			if v1 then
				sum = sum + v1
			end
		end
	else
		local v2 = HDAdminMain:GetModule("cf"):GetHumanoid()
		local v3 = HDAdminMain:GetModule("cf"):GetHRP()

		if v2 then
			local MoveDirection = v2.MoveDirection

			for k, v in pairs(tbl) do
				if ((t:GetCF(v3, true) * CFrame.new(v) - v3.CFrame.p).p - MoveDirection).magnitude <= 1.05 and MoveDirection ~= Vector3.new(0, 0, 0) then
					sum = sum + v
				end
			end
		end
	end

	return CFrame.new(sum * p3 * p2), sum
end
function t.GetAssetImage(p1, p2) --[[ GetAssetImage | Line: 150 ]]
	return "https://www.roblox.com/asset-thumbnail/image?assetId=" .. p2 .. "&width=420&height=420&format=png"
end
function t.GetUserImage(p1, p2) --[[ GetUserImage | Line: 154 ]]
	return "https://www.roblox.com/headshot-thumbnail/image?userId=" .. p2 .. "&width=420&height=420&format=png"
end
function t.ShowPermRankedUser(p1, p2) --[[ ShowPermRankedUser | Line: 158 | Upvalues: PermRank (copy), t (copy), HDAdminMain (copy) ]]
	PermRank.PlrName.Text = p2[1]
	PermRank.PlrImage.Image = t:GetUserImage(p2[2])
	PermRank.RankedBy.TextLabel.Text = HDAdminMain:GetModule("cf"):GetName(p2[3])
	HDAdminMain:GetModule("cf"):ShowWarning("PermRank")
end
function t.ShowBannedUser(p1, p2) --[[ ShowBannedUser | Line: 166 | Upvalues: UnBan (copy), t (copy), HDAdminMain (copy) ]]
	local TextLabel = UnBan.Reason.TextLabel

	UnBan.PlrName.Text = p2[1]
	UnBan.PlrImage.Image = t:GetUserImage(p2[2])
	UnBan.BannedBy.TextLabel.Text = HDAdminMain:GetModule("cf"):GetName(p2[4])
	TextLabel.Text = "\'" .. p2[3] .. "\'"

	if TextLabel.Text == "" or TextLabel.Text == " " then
		TextLabel.Text = "Empty"
		TextLabel.Font = Enum.Font.SourceSansItalic
	else
		TextLabel.Font = Enum.Font.SourceSans
	end

	HDAdminMain:GetModule("cf"):ShowWarning("UnBan")
end
function t.ShowWarning(p1, p2) --[[ ShowWarning | Line: 182 | Upvalues: HDAdminMain (copy) ]]
	for k, v in pairs(HDAdminMain.warnings:GetChildren()) do
		if v.Name == p2 then
			v.Visible = true
			HDAdminMain.warnings.Visible = true

			continue
		end

		v.Visible = false
	end
end
function t.SetCameraSubject(p1, p2) --[[ SetCameraSubject | Line: 193 | Upvalues: HDAdminMain (copy) ]]
	local v1 = HDAdminMain:GetModule("cf"):GetFace()

	if not v1 then
		return
	end

	HDAdminMain.camera.CameraSubject = p2
	v1.Transparency = v1.Transparency
end
function t.DestroyCommandMenuFrame(p1, p2) --[[ DestroyCommandMenuFrame | Line: 202 | Upvalues: HDAdminMain (copy) ]]
	if not p2 then
		return
	end

	for k, v in pairs(HDAdminMain.commandMenus) do
		if v == p2 then
			table.remove(HDAdminMain.commandMenus, k)
		end
	end

	p2:Destroy()
end
function t.UpdateCommandMenu(p1, p2, p3) --[[ UpdateCommandMenu | Line: 213 | Upvalues: HDAdminMain (copy) ]]
	if p3 == nil then
		p3 = HDAdminMain.gui:FindFirstChild("CommandMenu" .. p2)
	end

	if not p3 then
		return
	end

	local MainFrame = p3.MainFrame

	if not MainFrame:FindFirstChild("Status") then
		return
	end

	if not (HDAdminMain.commandsToDisableCompletely[p2] and HDAdminMain.commandsAllowedToUse[p2] or HDAdminMain.commandsActive[p2]) then
		MainFrame.Status.TextLabel.Text = "OFF"
		MainFrame.Status.TextLabel.TextColor3 = Color3.fromRGB(255, 0, 0)
		MainFrame.ChangeStatus.TextLabel.Text = "ATIVAR"

		return
	end

	MainFrame.Status.TextLabel.Text = "ON"
	MainFrame.Status.TextLabel.TextColor3 = Color3.fromRGB(0, 225, 0)
	MainFrame.ChangeStatus.TextLabel.Text = "DESATIVAR"
end
function t.CreateNewCommandMenu(p1, p2, p3, p4, p5) --[[ CreateNewCommandMenu | Line: 233 | Upvalues: HDAdminMain (copy), v1 (ref), MenuTemplates (copy), t (copy), setupOriginalZIndex (copy), updateZIndex (copy) ]]
	local v12 = tonumber(p4)
	local v2 = HDAdminMain:GetModule("cf"):FindValue({ 4, 5, 8, 11, 12 }, v12)
	local v3 = HDAdminMain:GetModule("cf"):FindValue({ 4 }, v12)
	local v4 = HDAdminMain:GetModule("cf"):FindValue({ 5, 6, 7, 9, 12 }, v12)
	local v5

	if v3 then
		v5 = "CommandMenu" .. p2 .. v1
		v1 = v1 + 1
	else
		v5 = "CommandMenu" .. p2
	end

	local v6 = HDAdminMain.gui:FindFirstChild(v5)

	if v6 and v4 then
		v6:Destroy()
		v6 = nil
	end

	if not v6 then
		local v7 = MenuTemplates["Template" .. v12]
		local MainFrame = v7.MainFrame

		v6 = v7:Clone()
		v6.Name = v5

		local DragBar = v6.DragBar
		local MainFrame2 = v6.MainFrame

		DragBar.Title.Text = string.upper(string.gsub(p2, "%u", function(p1) --[[ Line: 260 ]]
			return " " .. p1
		end))
		HDAdminMain:GetModule("InputHandler"):MakeFrameDraggable(v6)
		DragBar.Close.MouseButton1Down:Connect(function() --[[ Line: 263 | Upvalues: v2 (copy), t (ref), v6 (ref) ]]
			if v2 then
				t:DestroyCommandMenuFrame(v6)
			else
				v6.Visible = false
			end
		end)

		local Scale = MainFrame2.Position.Y.Scale
		local v9 = -(1 - DragBar.Size.Y.Scale - Scale)
		local Minimise = DragBar:FindFirstChild("Minimise")

		if Minimise then
			Minimise.MouseButton1Down:Connect(function() --[[ Line: 274 | Upvalues: Minimise (copy), HDAdminMain (ref), MainFrame2 (copy), v9 (copy), Scale (copy) ]]
				if Minimise.TextLabel.Text == "-" then
					HDAdminMain.tweenService:Create(MainFrame2, TweenInfo.new(0.5), {
						Position = UDim2.new(0, 0, v9, -1)
					}):Play()
					Minimise.TextLabel.Text = "+"
				else
					HDAdminMain.tweenService:Create(MainFrame2, TweenInfo.new(0.5), {
						Position = UDim2.new(0, 0, Scale, 0)
					}):Play()
					Minimise.TextLabel.Text = "-"
				end
			end)
		end

		local function updateCanvasSize(p1, p2, p3) --[[ updateCanvasSize | Line: 287 ]]
			p1.CanvasSize = UDim2.new(0, 0, 0, p2.AbsolutePosition.Y - p3.AbsolutePosition.Y + p2.AbsoluteSize.Y)
		end

		local function selectToggle(p1, p2, p3) --[[ selectToggle | Line: 291 | Upvalues: HDAdminMain (ref) ]]
			local v1 = p3[1]
			local v2 = p3[2]
			local v4 = p3[4]
			local v5 = p3[5]

			if not p1:FindFirstChild(p2) then
				p2 = v1[p1.Name]
			end

			if p1.Name == "AC Server" and (p2 == "All" and HDAdminMain.pdata.Rank < HDAdminMain.commandRanks.globalvote) then
				HDAdminMain:GetModule("Notices"):Notice("Error", HDAdminMain.hdAdminCoreName, "Must be \'" .. HDAdminMain:GetModule("cf"):GetRankName(HDAdminMain.commandRanks.globalvote) .. "\' to use ;globalVote")

				return
			end

			for k, v in pairs(p1:GetChildren()) do
				if v:IsA("TextButton") then
					v2(v, p2, p1)
				end
			end

			if not (v4 and v5) then
				return
			end

			p3[3].CanvasSize = UDim2.new(0, 0, 0, v4.AbsolutePosition.Y - v5.AbsolutePosition.Y + v4.AbsoluteSize.Y)
		end

		local function setupDefaultToggles(p1, p2, p3, p4, p5, p6, p7) --[[ setupDefaultToggles | Line: 313 | Upvalues: selectToggle (copy), HDAdminMain (ref) ]]
			local v1 = false

			p3.Focused:Connect(function() --[[ Line: 315 | Upvalues: v1 (ref) ]]
				v1 = true
			end)
			p3.FocusLost:Connect(function() --[[ Line: 318 | Upvalues: v1 (ref) ]]
				wait()
				v1 = false
			end)

			for k, v in pairs(p1) do
				local v2 = p2[k]

				for k2, v3 in pairs(v2:GetChildren()) do
					if v3:IsA("TextButton") then
						v3.MouseButton1Down:Connect(function() --[[ Line: 326 | Upvalues: v1 (ref), selectToggle (ref), v2 (copy), v3 (copy), p4 (copy) ]]
							if v1 then
								return
							end

							selectToggle(v2, v3.Name, p4)
						end)
					end
				end

				p5(v2)
			end

			if p6 then
				for k, v in pairs(p6:GetChildren()) do
					local TextBox = v:FindFirstChild("TextBox")

					if TextBox then
						local Text = TextBox.Text

						TextBox.Focused:Connect(function() --[[ Line: 340 | Upvalues: v1 (ref) ]]
							v1 = true
						end)
						TextBox.FocusLost:connect(function(p1) --[[ Line: 343 | Upvalues: TextBox (copy), v (copy), Text (ref), v1 (ref) ]]
							local v12 = tonumber(TextBox.Text)

							if v12 then
								if v12 < 0 then
									v12 = 0
								elseif v.Name == "Minutes" and v12 > 60 then
									v12 = 60
								elseif v.Name == "Hours" and v12 > 24 then
									v12 = 24
								elseif v.Name == "Days" and v12 > 100000 then
									v12 = 100000
								end

								Text = v12
							end

							TextBox.Text = Text
							wait()
							v1 = false
						end)
					end
				end
			end

			if not p7 then
				return
			end

			local v3 = string.lower(p7)
			local v4 = p7

			for k, v in pairs(HDAdminMain.qualifiers) do
				if v == v3 then
					v4 = v

					break
				end
			end

			if not v4 then
				for k, v in pairs(HDAdminMain.players:GetChildren()) do
					if string.sub(string.lower(v.Name), 1, #v3) == v3 then
						v4 = v.Name

						break
					end
				end
			end

			p3.Text = v4 or ""
		end

		local function setupFinalResult(p1, p2, p3, p4, p5, p6) --[[ setupFinalResult | Line: 385 | Upvalues: t (ref) ]]
			local FinalResult = p1.FinalResult
			local Frame = FinalResult.Frame
			local Example = Frame.Example
			local Loading = Frame.Loading
			local Broadcast = Frame.Broadcast

			FinalResult.Visible = false
			Frame.CloseX.MouseButton1Down:Connect(function() --[[ Line: 392 | Upvalues: FinalResult (copy) ]]
				FinalResult.Visible = false
			end)
			Broadcast.MouseButton1Down:Connect(function() --[[ Line: 395 | Upvalues: Loading (copy), Broadcast (copy), p6 (copy), t (ref), p1 (copy) ]]
				Loading.Visible = true
				Broadcast.Visible = false
				p6()
				t:DestroyCommandMenuFrame(p1)
			end)
			p2.MouseButton1Down:Connect(function() --[[ Line: 401 | Upvalues: p3 (copy), p2 (copy), p4 (copy), p5 (copy) ]]
				p3.Visible = true
				p2.Visible = false

				local v1 = p4()

				if type(v1) == "table" then
					p5(v1)
				else
					p3.TextLabel.Text = tostring(v1) or "Error"
					wait(1)
					p3.TextLabel.Text = "Loading..."
				end

				p3.Visible = false
				p2.Visible = true
			end)
		end

		local function setupPollResults(p1, p2) --[[ setupPollResults | Line: 418 | Upvalues: t (ref), HDAdminMain (ref) ]]
			local AnswerTemplate = p1.AnswerTemplate

			AnswerTemplate.Visible = false
			p1.Question.TextLabel.Text = p2.Question

			for k, v in pairs(p1:GetChildren()) do
				if v:IsA("TextButton") and v ~= AnswerTemplate then
					v:Destroy()
				end
			end

			for k, v in pairs(p2.Answers) do
				local v1 = AnswerTemplate:Clone()

				v1.Visible = true
				v1.Name = "Answer" .. k
				v1.TextLabel.Text = k .. ". " .. v
				v1.BackgroundColor3 = t:GetLabelBackgroundColor(k)

				local Fade = v1.Fade

				if p2.Remote then
					v1.MouseButton1Up:Connect(function() --[[ Line: 437 | Upvalues: p1 (copy), p2 (copy), k (copy) ]]
						p1.Parent.Parent.Visible = false
						pcall(function() --[[ Line: 439 | Upvalues: p2 (ref), k (ref) ]]
							p2.Remote:FireServer(k)
						end)
					end)
				end

				v1.InputBegan:Connect(function(p1) --[[ Line: 442 | Upvalues: HDAdminMain (ref), Fade (copy) ]]
					HDAdminMain.tweenService:Create(Fade, TweenInfo.new(0.2), {
						BackgroundTransparency = 0.8
					}):Play()
				end)
				v1.InputEnded:Connect(function(p1) --[[ Line: 445 | Upvalues: HDAdminMain (ref), Fade (copy) ]]
					HDAdminMain.tweenService:Create(Fade, TweenInfo.new(0.2), {
						BackgroundTransparency = 1
					}):Play()
				end)
				v1.Parent = p1
			end

			spawn(function() --[[ Line: 451 | Upvalues: p1 (copy), p2 (copy) ]]
				wait(0.1)

				local v2 = p1["Answer" .. #p2.Answers]

				p1.CanvasSize = UDim2.new(0, 0, 0, v2.AbsolutePosition.Y - p1.Question.AbsolutePosition.Y + v2.AbsoluteSize.Y)
			end)
		end

		if v12 == 1 then
			local v10 = UDim2.new(1, -255, 1, -155)

			if HDAdminMain.device ~= "Mobile" and v6.Position ~= v10 then
				v6.Position = v10
				v6.Size = UDim2.new(0, 250, 0, 150)
			end

			local InfoFrame = MainFrame2.InfoFrame

			InfoFrame.Visible = false
			MainFrame2.Desc.Visible = false
			MainFrame2.InputFrame.Visible = false

			local v11 = p3[1]

			if v11 == "Info" then
				MainFrame2.Desc.Text = p3[2]
				MainFrame2.Desc.Visible = true
			elseif v11 == "Input" then
				local v122 = p3[2]
				local TextBox = MainFrame2.InputFrame.Frame.TextBox
				local v13 = HDAdminMain.commandSpeeds[p2]

				MainFrame2.InputFrame.InputName.Text = v122 .. ":"
				TextBox.Text = v13

				if HDAdminMain.infoFramesViewed[v122] then
					HDAdminMain.infoFramesViewed[v122] = nil

					if v122 == "Speed" then
						local v14 = if HDAdminMain.device == "Computer" then {
	{ "Movement", "WASD" },
	{ "Toggle flight", "E" },
	{ "Up & Down", "R & F" }
} else {
	{ "Movement", "Thumbstick" },
	{ "Toggle flight", "Double-jump" }
}

						for i = 1, 3 do
							local v15 = InfoFrame["Info" .. i]
							local v16 = v14[i]

							if v16 then
								v15.Text = v16[1] .. ":"
								v15.TextLabel.Text = v16[2]
								v15.Visible = true

								continue
							end

							v15.Visible = false
						end

						InfoFrame.Okay.MouseButton1Down:Connect(function() --[[ Line: 509 | Upvalues: InfoFrame (copy) ]]
							InfoFrame.Visible = false
						end)
						InfoFrame.Visible = true
					end
				end

				local Text = TextBox.Text

				TextBox.FocusLost:Connect(function() --[[ Line: 516 | Upvalues: TextBox (copy), v13 (copy), HDAdminMain (ref), p2 (copy), Text (ref) ]]
					local v1 = tonumber(TextBox.Text) or v13

					TextBox.Text = "..."

					if HDAdminMain.signals.RequestCommand:InvokeServer(HDAdminMain.pdata.Prefix .. p2 .. " me " .. v1) then
						Text = TextBox.Text

						return
					end

					TextBox.Text = Text
					Text = TextBox.Text
				end)
				MainFrame2.InputFrame.Visible = true
			end

			t:UpdateCommandMenu(p2, v6)
			MainFrame2.ChangeStatus.MouseButton1Down:Connect(function() --[[ Line: 532 | Upvalues: MainFrame2 (copy), HDAdminMain (ref), p2 (copy), t (ref), v6 (ref) ]]
				MainFrame2.Loading.Visible = true

				if HDAdminMain.commandsToDisableCompletely[p2] then
					HDAdminMain.signals.RequestCommand:InvokeServer(if MainFrame2.ChangeStatus.TextLabel.Text == "DESATIVAR" then "!Un" .. p2 else "!" .. p2)
					wait(1)
				elseif HDAdminMain.commandsActive[p2] then
					HDAdminMain.commandsActive[p2] = nil
				else
					HDAdminMain:GetModule("cf"):ActivateClientCommand(p2)
					wait(0.5)
				end

				t:UpdateCommandMenu(p2, v6)
				MainFrame2.Loading.Visible = false
			end)
		elseif v12 == 2 then
			if p2 == "cmdbar2" then
				DragBar.Title.Text = "CMDBAR2"
			end

			if HDAdminMain.device ~= "Mobile" then
				v6.Position = UDim2.new(0, 5, 1, -75)
				v6.Size = UDim2.new(0, 315, 0, 70)
			end

			local SearchFrame = MainFrame2.SearchFrame
			local TextBox = SearchFrame.TextBox
			local t2 = {
				maxSuggestions = 3,
				suggestionPos = 1,
				suggestionDisplayed = 0,
				forceExecute = false,
				currentBarCommand = nil,
				mainParent = MainFrame2.Parent,
				textBox = TextBox,
				rframe = SearchFrame.ResultsFrame,
				highlightColor = Color3.fromRGB(50, 50, 50),
				otherColor = Color3.fromRGB(80, 80, 80),
				suggestionLabels = {}
			}

			HDAdminMain:GetModule("CmdBar"):SetupTextbox(p2, t2)

			local Loading = MainFrame2.Loading

			MainFrame2.Execute.MouseButton1Down:Connect(function() --[[ Line: 581 | Upvalues: Loading (copy), TextBox (copy), HDAdminMain (ref) ]]
				Loading.Visible = true

				if #TextBox.Text > 1 then
					local Text = TextBox.Text
					local v1 = string.sub(Text, 1, 1)

					if v1 ~= HDAdminMain.settings.UniversalPrefix and v1 ~= HDAdminMain.pdata.Prefix then
						Text = HDAdminMain.pdata.Prefix .. Text
					end

					if string.sub(Text, -1) == " " then
						Text = string.sub(Text, 1, -1)
					end

					HDAdminMain.signals.RequestCommand:InvokeServer(Text)
				end

				Loading.Visible = false
			end)
		elseif v12 == 3 then
			if p2 == "cmdbar2" then
				DragBar.Title.Text = "CMDBAR2"
			end

			if HDAdminMain.device ~= "Mobile" then
				v6.Position = UDim2.new(0, 5, 1, -110)
				v6.Size = UDim2.new(0, 315, 0, 105)
			end

			local SearchFrame = MainFrame2.PlayerFrame.SearchFrame
			local TextBox = SearchFrame.TextBox

			TextBox.Text = HDAdminMain.player.Name

			local t2 = {
				maxSuggestions = 3,
				suggestionPos = 1,
				suggestionDisplayed = 0,
				forceExecute = false,
				currentBarCommand = nil,
				specificArg = "player",
				mainParent = MainFrame2.Parent,
				textBox = TextBox,
				rframe = SearchFrame.ResultsFrame,
				highlightColor = Color3.fromRGB(50, 50, 50),
				otherColor = Color3.fromRGB(80, 80, 80),
				suggestionLabels = {}
			}

			HDAdminMain:GetModule("CmdBar"):SetupTextbox(p2, t2)

			local TextBox2 = MainFrame2.MessageFrame.SearchFrame.TextBox

			TextBox2.FocusLost:connect(function(p1) --[[ Line: 633 | Upvalues: TextBox (copy), HDAdminMain (ref), TextBox2 (copy) ]]
				if not p1 then
					return
				end

				local Text = TextBox.Text

				if string.sub(Text, -1) == " " then
					Text = string.sub(Text, 1, -1)
				end

				local v2 = HDAdminMain.pdata.Prefix .. "talk" .. HDAdminMain.pdata.SplitKey .. Text .. HDAdminMain.pdata.SplitKey .. TextBox2.Text

				TextBox2.Text = ""
				HDAdminMain.signals.RequestCommand:InvokeServer(v2)
			end)
		elseif v12 == 4 then
			local v17 = p3[1]
			local TextBox = MainFrame2.ReplyFrame.TextBox
			local Send = MainFrame2.Send

			DragBar.Title.Text = "Message from " .. v17.Name
			MainFrame2.MessageFrame.Message.Text = p3[2]
			TextBox.Changed:connect(function(p1) --[[ Line: 656 | Upvalues: TextBox (copy), Send (copy) ]]
				if p1 ~= "Text" then
					return
				end

				if #TextBox.Text > 0 then
					Send.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
					Send.AutoButtonColor = true

					return
				end

				Send.TextLabel.TextColor3 = Color3.fromRGB(125, 125, 125)
				Send.AutoButtonColor = false
			end)
			Send.MouseButton1Down:Connect(function() --[[ Line: 667 | Upvalues: Send (copy), t (ref), v6 (ref), HDAdminMain (ref), v17 (copy), TextBox (copy) ]]
				if not Send.AutoButtonColor then
					return
				end

				t:DestroyCommandMenuFrame(v6)
				HDAdminMain.signals.ReplyToPrivateMessage:InvokeServer({ v17, TextBox.Text })
			end)
		elseif v12 == 5 then
			local v20 = math.ceil(MainFrame.ScrollFrame.AbsoluteSize.Y / 11)
			local Template = MainFrame.ScrollFrame.Template
			local v21 = v20 / 3
			local ScrollFrame = MainFrame2.ScrollFrame
			local LoadMore = MainFrame2.LoadMore
			local Displaying = LoadMore.Displaying
			local Load = LoadMore.Load

			ScrollFrame.Template:Destroy()
			v6.Parent = HDAdminMain.gui

			local function getLabelText(p1) --[[ getLabelText | Line: 689 ]]
				local v1 = os.date("*t", p1.timeAdded)
				local hour = v1.hour
				local min = v1.min

				if hour < 10 then
					hour = "0" .. hour
				end

				if min < 10 then
					min = "0" .. min
				end

				return "[" .. hour .. ":" .. min .. "] " .. p1.speakerName .. ": " .. p1.message
			end

			local t2 = {}
			local v22 = 0
			local v23 = 0

			local function displayElements(p1, p2) --[[ displayElements | Line: 708 | Upvalues: v22 (ref), t2 (ref), HDAdminMain (ref), v20 (copy), v23 (ref), ScrollFrame (copy), Displaying (copy), LoadMore (copy) ]]
				v22 = math.min(p1 + p2 - 1, #t2)

				for i = p1, v22 do
					local v2 = t2[i]
					local TextLabel = v2.TextLabel
					local X = HDAdminMain.textService:GetTextSize(TextLabel.Text, tonumber(TextLabel.TextSize), TextLabel.Font, Vector2.new((1 / 0), v20)).X

					if v23 < X then
						v23 = X
					end

					v2.Parent = ScrollFrame
				end

				Displaying.Text = ("%d/%d"):format(v22, #t2)

				local v3 = v22 < #t2

				LoadMore.Visible = v3
				ScrollFrame.Size = v3 and UDim2.new(1, 0, 0.84, 0) or UDim2.new(1, 0, 0.92, 0)
				ScrollFrame.CanvasSize = UDim2.new(0, v23, 0, v22 * v20)
			end

			Load.MouseButton1Click:Connect(function() --[[ Line: 726 | Upvalues: displayElements (copy), v22 (ref) ]]
				displayElements(v22 + 1, 20)
			end)

			local function clearLogElements() --[[ clearLogElements | Line: 729 | Upvalues: t2 (ref), ScrollFrame (copy), Displaying (copy), v22 (ref), v23 (ref), Load (copy) ]]
				t2 = {}

				for k, v in pairs(ScrollFrame:GetChildren()) do
					if v.Name ~= "UIListLayout" then
						v:Destroy()
					end
				end

				Displaying.Text = "0/0"
				v22 = 0
				v23 = 0
				Load.Visible = true
			end

			local function updateLog(p1) --[[ updateLog | Line: 741 | Upvalues: clearLogElements (copy), Template (copy), t (ref), v20 (copy), v21 (copy), t2 (ref), displayElements (copy) ]]
				clearLogElements()

				for k, v in pairs(p1) do
					local v1 = Template:Clone()
					local TextLabel = v1.TextLabel
					local v2 = os.date("*t", v.timeAdded)
					local hour = v2.hour
					local min = v2.min

					if hour < 10 then
						hour = "0" .. hour
					end

					if min < 10 then
						min = "0" .. min
					end

					TextLabel.Text = "[" .. hour .. ":" .. min .. "] " .. v.speakerName .. ": " .. v.message
					v1.BackgroundColor3 = t:GetLabelBackgroundColor(k)
					v1.Visible = true
					v1.Name = "Record" .. k
					v1.Size = UDim2.new(1, 0, 0, v20)
					TextLabel.Position = UDim2.new(0, v21, 0.15, 0)
					TextLabel.Size = UDim2.new(1, -v21 * 2, 0.7, 0)
					t2[#t2 + 1] = v1
				end

				displayElements(1, 20)
			end

			updateLog(p3)

			local v24 = true
			local TextBox = MainFrame2.SearchBar.Frame.TextBox

			TextBox.FocusLost:connect(function(p1) --[[ Line: 763 | Upvalues: v24 (ref), TextBox (copy), p3 (copy), updateLog (copy), setupOriginalZIndex (ref), ScrollFrame (copy), updateZIndex (ref), HDAdminMain (ref) ]]
				if not v24 then
					return
				end

				v24 = false

				local v1 = string.lower(TextBox.Text)
				local t = {}

				for k, v in pairs(p3) do
					local lower = string.lower
					local v2 = os.date("*t", v.timeAdded)
					local hour = v2.hour
					local min = v2.min

					if hour < 10 then
						hour = "0" .. hour
					end

					if min < 10 then
						min = "0" .. min
					end

					if string.find(lower("[" .. hour .. ":" .. min .. "] " .. v.speakerName .. ": " .. v.message), v1, 1, true) then
						table.insert(t, v)
					end
				end

				updateLog(t)
				setupOriginalZIndex(ScrollFrame)
				updateZIndex(HDAdminMain.commandMenus, ScrollFrame)
				wait(0.5)
				v24 = true
			end)
		elseif v12 == 6 then
			local ScrollFrame = MainFrame2.ScrollFrame
			local t2 = {
				["AG Server"] = "All",
				["AJ Length"] = "Infinite",
				["AHB Alts Decide"] = "Yes"
			}
			local t3 = {}
			local SearchFrame = ScrollFrame["AC Target Player"].SearchFrame
			local TextBox = SearchFrame.TextBox
			local v25 = ScrollFrame["AJA Time"]
			local v26 = ScrollFrame["AA Space"]
			local v27 = ScrollFrame["AZ Space"]
			local TextBox2 = ScrollFrame["AM Reason"].SearchFrame.TextBox
			local v29 = ScrollFrame["AHA Alts Title"]
			local v30 = ScrollFrame["AHB Alts Decide"]
			local v31 = ScrollFrame["AHC Alts Space"]
			local t4 = {
				t2,
				function(p1, p2, p3) --[[ Line: 801 | Upvalues: t3 (copy), v25 (copy), v29 (copy), v30 (copy), v31 (copy), t2 (copy) ]]
					if p1.Name == p2 then
						p1.BackgroundTransparency = 0.1
						p1.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
						t3[p3.Name] = p2

						if p3.Name == "AJ Length" then
							if p1.Name == "Time" then
								v25.Visible = true
							else
								v25.Visible = false
							end

							return
						end

						if p3.Name ~= "AG Server" then
							return
						end

						local isName = p1.Name == "All"

						v29.Visible = isName
						v30.Visible = isName
						v31.Visible = isName

						if not t3["AHB Alts Decide"] then
							t3["AHB Alts Decide"] = t2["AHB Alts Decide"]
						end
					else
						p1.BackgroundTransparency = 0.8
						p1.TextLabel.TextColor3 = Color3.fromRGB(150, 150, 150)
					end
				end,
				ScrollFrame,
				v27,
				v26
			}

			setupDefaultToggles(t2, ScrollFrame, TextBox, t4, function(p1) --[[ Line: 827 | Upvalues: selectToggle (copy), p3 (copy), t4 (copy) ]]
				if p1.Name == "AG Server" then
					selectToggle(p1, p3.server, t4)

					return
				end

				if p1.Name ~= "AJ Length" then
					return
				end

				selectToggle(p1, p3.length, t4)
			end, v25, p3.targetPlayer)

			local t5 = {
				maxSuggestions = 3,
				suggestionPos = 1,
				suggestionDisplayed = 0,
				forceExecute = false,
				currentBarCommand = nil,
				specificArg = "player",
				mainParent = MainFrame2.Parent,
				textBox = TextBox,
				rframe = SearchFrame.ResultsFrame,
				highlightColor = Color3.fromRGB(50, 50, 50),
				otherColor = Color3.fromRGB(80, 80, 80),
				suggestionLabels = {}
			}

			HDAdminMain:GetModule("CmdBar"):SetupTextbox(p2, t5)

			local timeDetails = p3.timeDetails

			if timeDetails then
				timeDetails:gsub("%d+%a", function(p1) --[[ Line: 853 | Upvalues: HDAdminMain (ref), v25 (copy) ]]
					local v1 = tonumber(p1:match("%d+"))

					if not v1 then
						return
					end

					local v2 = p1:match("%a")
					local _, v3, v4 = HDAdminMain:GetModule("cf"):GetTimeAmount(v2, v1)

					v25[v3].TextBox.Text = v4
				end)
			end

			local reason = p3.reason

			if reason and (reason ~= "" and reason ~= " ") then
				TextBox2.Text = reason
			end

			ScrollFrame["AX Ban"].MouseButton1Down:Connect(function() --[[ Line: 868 | Upvalues: TextBox2 (copy), TextBox (copy), v25 (copy), t3 (copy), t (ref), v6 (ref), HDAdminMain (ref) ]]
				t:DestroyCommandMenuFrame(v6)
				HDAdminMain.signals.RequestCommand:InvokeServer(HDAdminMain.pdata.Prefix .. "directBan" .. HDAdminMain.pdata.SplitKey .. TextBox.Text .. HDAdminMain.pdata.SplitKey .. TextBox2.Text, {
					server = t3["AG Server"],
					length = t3["AJ Length"],
					lengthTime = v25.Minutes.TextBox.Text .. "m" .. v25.Hours.TextBox.Text .. "h" .. v25.Days.TextBox.Text .. "d",
					banAlts = t3["AHB Alts Decide"]
				})
			end)
			spawn(function() --[[ Line: 876 | Upvalues: ScrollFrame (copy), v27 (copy), v26 (copy) ]]
				wait(0.1)

				local v1 = v27

				ScrollFrame.CanvasSize = UDim2.new(0, 0, 0, v1.AbsolutePosition.Y - v26.AbsolutePosition.Y + v1.AbsoluteSize.Y)
			end)
		elseif v12 == 7 then
			local ScrollFrame = MainFrame2.ScrollFrame
			local t2 = {
				["AG DisplayFrom"] = "Enabled"
			}
			local t3 = {}
			local SearchFrame = ScrollFrame["AJ MessageColor"].SearchFrame
			local TextBox = SearchFrame.TextBox
			local TextBox2 = ScrollFrame["AC MessageTitle"].SearchFrame.TextBox
			local TextBox3 = ScrollFrame["AM Message"].SearchFrame.TextBox
			local t4 = { t2, function(p1, p2, p3) --[[ Line: 894 | Upvalues: t3 (copy) ]]
					if p1.Name == p2 then
						p1.BackgroundTransparency = 0.1
						p1.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
						t3[p3.Name] = p2
					else
						p1.BackgroundTransparency = 0.8
						p1.TextLabel.TextColor3 = Color3.fromRGB(150, 150, 150)
					end
				end, ScrollFrame }

			ScrollFrame["AF Title"].TextLabel.Text = "Display \'From " .. HDAdminMain.player.Name .. "\'"
			setupDefaultToggles(t2, ScrollFrame, TextBox, t4, function(p1) --[[ Line: 906 | Upvalues: selectToggle (copy), t4 (copy) ]]
				if p1.Name ~= "AG DisplayFrom" then
					return
				end

				selectToggle(p1, "Enabled", t4)
			end)

			local t5 = {
				maxSuggestions = 3,
				suggestionPos = 1,
				suggestionDisplayed = 0,
				forceExecute = false,
				currentBarCommand = nil,
				specificArg = "color",
				mainParent = MainFrame2.Parent,
				textBox = TextBox,
				rframe = SearchFrame.ResultsFrame,
				highlightColor = Color3.fromRGB(50, 50, 50),
				otherColor = Color3.fromRGB(80, 80, 80),
				suggestionLabels = {}
			}

			HDAdminMain:GetModule("CmdBar"):SetupTextbox(p2, t5)

			local FinalResult = v6.FinalResult
			local Example = FinalResult.Frame.Example

			setupFinalResult(v6, ScrollFrame["AX Submit"], ScrollFrame["AZ Loading"], function() --[[ Line: 932 | Upvalues: t3 (copy), HDAdminMain (ref), TextBox2 (copy), TextBox (copy), TextBox3 (copy) ]]
				return HDAdminMain.signals.RetrieveBroadcastData:InvokeServer({
					Title = TextBox2.Text,
					DisplayFrom = t3["AG DisplayFrom"] == "Enabled",
					Color = TextBox.Text,
					Message = TextBox3.Text
				})
			end, function(p1) --[[ Line: 940 | Upvalues: Example (copy), t (ref), FinalResult (copy) ]]
				Example.Title.Text = p1.Title

				local DisplayFrom = p1.DisplayFrom

				Example.Pic.Visible = DisplayFrom
				Example.SubTitle.Visible = DisplayFrom

				if DisplayFrom then
					Example.Pic.Image = t:GetUserImage(p1.SenderId)
					Example.SubTitle.Text = "From " .. p1.SenderName
				end

				Example.Desc.TextColor3 = Color3.new(p1.Color[1], p1.Color[2], p1.Color[3])
				Example.Desc.Text = p1.Message
				FinalResult.Visible = true
			end, function() --[[ Line: 953 | Upvalues: HDAdminMain (ref) ]]
				HDAdminMain.signals.ExecuteBroadcast:InvokeServer()
			end)
		elseif v12 == 8 then
			local v35 = p3[1]
			local v36 = p3[2]
			local v37 = p3[3] or {}
			local Mute = DragBar.Mute
			local TextLabel = Mute.TextLabel
			local Sound = Instance.new("Sound")

			Sound.SoundId = "rbxassetid://" .. HDAdminMain.pdata.AlertSoundId
			Sound.Volume = HDAdminMain.pdata.AlertVolume
			Sound.Pitch = HDAdminMain.pdata.AlertPitch
			Sound.Looped = true
			Sound.Parent = v6
			Sound:Play()
			DragBar.Title.Text = v35
			MainFrame2.MessageFrame.Message.Text = v36
			Mute.MouseButton1Down:Connect(function() --[[ Line: 979 | Upvalues: TextLabel (copy), Sound (copy) ]]
				if TextLabel.Text == "\240\159\148\138" then
					TextLabel.Text = "\240\159\148\135"
					Sound:Pause()
				else
					TextLabel.Text = "\240\159\148\138"
					Sound:Play()
				end
			end)

			local v38 = print

			v38(("Alert \'%s\' with message \'%s\' was broadcasted by \'%s\' (@%s, %s) who is rank \'%s\' in game %s"):format(v35, v36, tostring(v37[1]), tostring(v37[2]), tostring(v37[3]), tostring(v37[4]), game.PlaceId))
		elseif v12 == 9 then
			local ScrollFrame = MainFrame2.ScrollFrame
			local t2 = {
				["AC Server"] = "Current",
				["AG ShowResultsTo"] = "You"
			}
			local t3 = {}
			local v46 = ScrollFrame["AD Target Player"]
			local SearchFrame = v46.SearchFrame
			local TextBox = SearchFrame.TextBox
			local v47 = ScrollFrame["AA Space"]
			local v48 = ScrollFrame["AZ Space"]
			local TextBox2 = ScrollFrame["AP Question"].SearchFrame.TextBox
			local t4 = {
				t2,
				function(p1, p2, p3) --[[ Line: 1006 | Upvalues: t3 (copy), v46 (copy) ]]
					local v1 = p3.Name

					if p1.Name == p2 then
						p1.BackgroundTransparency = 0.1
						p1.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
						t3[p3.Name] = p2

						if v1 ~= "AC Server" then
							return
						end

						if p1.Name == "Current" then
							v46.Visible = true
						else
							v46.Visible = false
						end

						return
					end

					p1.BackgroundTransparency = 0.8
					p1.TextLabel.TextColor3 = Color3.fromRGB(150, 150, 150)
				end,
				ScrollFrame,
				v48,
				v47
			}

			setupDefaultToggles(t2, ScrollFrame, TextBox, t4, function(p1) --[[ Line: 1025 | Upvalues: selectToggle (copy), p3 (copy), t4 (copy), t2 (copy) ]]
				if p1.Name == "AC Server" then
					selectToggle(p1, p3.server, t4)

					return
				end

				if not t2[p1.Name] then
					return
				end

				selectToggle(p1, t2[p1.Name], t4)
			end, nil, p3.targetPlayer)

			local t5 = {
				maxSuggestions = 3,
				suggestionPos = 1,
				suggestionDisplayed = 0,
				forceExecute = false,
				currentBarCommand = nil,
				specificArg = "player",
				mainParent = MainFrame2.Parent,
				textBox = TextBox,
				rframe = SearchFrame.ResultsFrame,
				highlightColor = Color3.fromRGB(50, 50, 50),
				otherColor = Color3.fromRGB(80, 80, 80),
				suggestionLabels = {}
			}

			HDAdminMain:GetModule("CmdBar"):SetupTextbox(p2, t5)

			local question = p3.question

			if question and (question ~= "" and question ~= " ") then
				TextBox2.Text = question
			end

			local v51 = ScrollFrame["AS Answer"]
			local t6 = {}

			v51.Visible = false

			local function removeAnswerBox(p1) --[[ removeAnswerBox | Line: 1058 | Upvalues: t6 (copy), ScrollFrame (copy), v48 (copy), v47 (copy) ]]
				for k, v in pairs(t6) do
					if v == p1 then
						table.remove(t6, k)

						break
					end
				end

				p1:Destroy()

				local v1 = v48

				ScrollFrame.CanvasSize = UDim2.new(0, 0, 0, v1.AbsolutePosition.Y - v47.AbsolutePosition.Y + v1.AbsoluteSize.Y)
			end

			local function createAnswerBox() --[[ createAnswerBox | Line: 1068 | Upvalues: v51 (copy), ScrollFrame (copy), removeAnswerBox (copy), t6 (copy), v48 (copy), v47 (copy) ]]
				local v1 = v51:Clone()

				v1.Visible = true
				v1.Parent = ScrollFrame
				v1.RemoveBox.MouseButton1Down:Connect(function() --[[ Line: 1072 | Upvalues: removeAnswerBox (ref), v1 (copy) ]]
					removeAnswerBox(v1)
				end)
				table.insert(t6, v1)

				local v3 = v48

				ScrollFrame.CanvasSize = UDim2.new(0, 0, 0, v3.AbsolutePosition.Y - v47.AbsolutePosition.Y + v3.AbsoluteSize.Y)

				return v1
			end

			local answers = p3.answers

			if type(answers) == "table" then
				for k, v in pairs(answers) do
					if v and (v ~= "" and v ~= " ") then
						createAnswerBox().SearchFrame.TextBox.Text = v

						if #t6 >= 10 then
							break
						end
					end
				end
			end

			ScrollFrame["AT AddAnswer"].Add.MouseButton1Down:Connect(function() --[[ Line: 1091 | Upvalues: t6 (copy), HDAdminMain (ref), createAnswerBox (copy), ScrollFrame (copy) ]]
				if #t6 >= 10 then
					HDAdminMain:GetModule("Notices"):Notice("Error", HDAdminMain.hdAdminCoreName, "Cannot exceed " .. 10 .. " answers!")
				else
					ScrollFrame.CanvasPosition = Vector2.new(0, ScrollFrame.CanvasPosition.Y + createAnswerBox().AbsoluteSize.Y)
				end
			end)

			local TextBox3 = ScrollFrame["AC VoteTime"].SearchFrame.TextBox
			local Text = TextBox3.Text

			TextBox3.FocusLost:connect(function(p1) --[[ Line: 1103 | Upvalues: TextBox3 (copy), Text (ref) ]]
				local v1 = tonumber(TextBox3.Text)

				if v1 then
					if v1 < 1 then
						v1 = 1
					elseif v1 > 60 then
						v1 = 60
					end
				else
					v1 = Text
				end

				TextBox3.Text = v1
				Text = v1
			end)
			spawn(function() --[[ Line: 1118 | Upvalues: ScrollFrame (copy), v48 (copy), v47 (copy) ]]
				wait(0.1)

				local v1 = v48

				ScrollFrame.CanvasSize = UDim2.new(0, 0, 0, v1.AbsolutePosition.Y - v47.AbsolutePosition.Y + v1.AbsoluteSize.Y)
			end)

			local FinalResult = v6.FinalResult
			local Example = FinalResult.Frame.Example

			setupFinalResult(v6, ScrollFrame["AX Submit"], ScrollFrame["AZ Loading"], function() --[[ Line: 1127 | Upvalues: TextBox3 (copy), TextBox2 (copy), t3 (copy), TextBox (copy), t6 (copy), HDAdminMain (ref) ]]
				local v3 = TextBox.Text:gsub(" ", function(p1) --[[ Line: 1132 ]]
					return ""
				end)
				local t = {}

				for k, v in pairs(t6) do
					table.insert(t, v.SearchFrame.TextBox.Text)
				end

				return HDAdminMain.signals.RetrievePollData:InvokeServer({
					VoteTime = TextBox3.Text,
					Question = TextBox2.Text,
					Answers = t,
					Server = t3["AC Server"],
					ShowResultsTo = t3["AG ShowResultsTo"],
					PlayerArg = v3
				})
			end, function(p1) --[[ Line: 1142 | Upvalues: setupPollResults (copy), Example (copy), FinalResult (copy) ]]
				setupPollResults(Example, p1)
				FinalResult.Visible = true
			end, function() --[[ Line: 1146 | Upvalues: HDAdminMain (ref) ]]
				HDAdminMain.signals.ExecutePoll:InvokeServer()
			end)
		elseif v12 == 10 then
			HDAdminMain.audio.Notice:Play()

			local ScrollFrame = MainFrame2.ScrollFrame
			local Title = DragBar.Title
			local VoteTime = p3.VoteTime
			local v53 = VoteTime + 1

			setupPollResults(ScrollFrame, p3)
			ScrollFrame.Question.TextLabel.Text = p3.Question
			coroutine.wrap(function() --[[ Line: 1165 | Upvalues: VoteTime (copy), Title (copy), p3 (copy), v53 (copy), t (ref), v6 (ref) ]]
				for i = 1, VoteTime do
					Title.Text = string.upper(p3.SenderName) .. "\'S POLL (" .. v53 - i .. ")"
					wait(1)
				end

				t:DestroyCommandMenuFrame(v6)
			end)()
		elseif v12 == 11 then
			HDAdminMain.audio.Notice:Play()

			local v54 = HDAdminMain:GetModule("cf"):RandomiseTable({
				Color3.fromRGB(220, 30, 30),
				Color3.fromRGB(220, 93, 29),
				Color3.fromRGB(188, 161, 23),
				Color3.fromRGB(107, 186, 22),
				Color3.fromRGB(19, 179, 46),
				Color3.fromRGB(20, 197, 197),
				Color3.fromRGB(24, 120, 255),
				Color3.fromRGB(101, 24, 255),
				Color3.fromRGB(217, 24, 255),
				Color3.fromRGB(255, 24, 128)
			})
			local ScrollFrame = MainFrame2.ScrollFrame
			local Title = DragBar.Title

			ScrollFrame.Question.TextLabel.Text = p3.Question

			local ResultTemplate = ScrollFrame.ResultTemplate

			ResultTemplate.Visible = false

			local v55 = #p3.Results

			for k, v in pairs(p3.Results) do
				local v56 = ResultTemplate:Clone()

				v56.Visible = true
				v56.Name = "Answer" .. k
				v56.Bar.BackgroundColor3 = v54[k]

				local v57 = k .. ". " .. v.Answer .. " ("

				if k == v55 then
					v57 = v.Answer .. " ("
					v56.Bar.BackgroundColor3 = Color3.fromRGB(175, 175, 175)
				end

				v56.TextLabel.Text = v57 .. "0)"
				v56.BackgroundColor3 = t:GetLabelBackgroundColor(k)
				v56.Bar.Size = UDim2.new(0, 0, 1, 0)
				delay((k - 1) / 10, function() --[[ Line: 1211 | Upvalues: HDAdminMain (ref), v56 (copy), v (copy), v57 (ref) ]]
					local v1 = TweenInfo.new(2, Enum.EasingStyle.Quart)
					local v2 = Instance.new("IntValue")

					v2.Value = 0
					HDAdminMain.tweenService:Create(v56.Bar, v1, {
						Size = UDim2.new(v.Percentage, 0, 1, 0)
					}):Play()
					HDAdminMain.tweenService:Create(v2, v1, {
						Value = v.Votes
					}):Play()
					v2.Changed:Connect(function(p1) --[[ Line: 1218 | Upvalues: v56 (ref), v57 (ref) ]]
						v56.TextLabel.Text = v57 .. p1 .. ")"
					end)
					wait(2)
					v2:Destroy()
				end)
				v56.Parent = ScrollFrame
			end

			spawn(function() --[[ Line: 1226 | Upvalues: ScrollFrame (copy), p3 (copy) ]]
				wait(0.1)

				local v2 = ScrollFrame["Answer" .. #p3.Answers]

				ScrollFrame.CanvasSize = UDim2.new(0, 0, 0, v2.AbsolutePosition.Y - ScrollFrame.Question.AbsolutePosition.Y + v2.AbsoluteSize.Y)
			end)
		elseif v12 == 12 then
			local ScrollFrame = MainFrame2.ScrollFrame
			local t2 = {
				["AC Server"] = "Current"
			}
			local t3 = {}
			local v58 = ScrollFrame["AD Target Player"]
			local SearchFrame = v58.SearchFrame
			local TextBox = SearchFrame.TextBox
			local v61 = ScrollFrame["AX Space"]
			local TextBox2 = ScrollFrame["AG MessageTitle"].SearchFrame.TextBox
			local TextBox3 = ScrollFrame["AM Message"].SearchFrame.TextBox
			local t4 = {
				t2,
				function(p1, p2, p3) --[[ Line: 1250 | Upvalues: t3 (copy), v58 (copy), v61 (copy) ]]
					local v1 = p3.Name

					if p1.Name == p2 then
						p1.BackgroundTransparency = 0.1
						p1.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
						t3[p3.Name] = p2

						if v1 ~= "AC Server" then
							return
						end

						if p1.Name == "Current" then
							v58.Visible = true
							v61.Visible = false
						else
							v58.Visible = false
							v61.Visible = true
						end

						return
					end

					p1.BackgroundTransparency = 0.8
					p1.TextLabel.TextColor3 = Color3.fromRGB(150, 150, 150)
				end,
				ScrollFrame,
				ScrollFrame["AZ Space"],
				ScrollFrame["AA Space"]
			}

			setupDefaultToggles(t2, ScrollFrame, TextBox, t4, function(p1) --[[ Line: 1271 | Upvalues: selectToggle (copy), p3 (copy), t4 (copy), t2 (copy) ]]
				if p1.Name == "AC Server" then
					selectToggle(p1, p3.server, t4)

					return
				end

				if not t2[p1.Name] then
					return
				end

				selectToggle(p1, t2[p1.Name], t4)
			end, nil, p3.targetPlayer)

			local t5 = {
				maxSuggestions = 3,
				suggestionPos = 1,
				suggestionDisplayed = 0,
				forceExecute = false,
				currentBarCommand = nil,
				specificArg = "player",
				mainParent = MainFrame2.Parent,
				textBox = TextBox,
				rframe = SearchFrame.ResultsFrame,
				highlightColor = Color3.fromRGB(50, 50, 50),
				otherColor = Color3.fromRGB(80, 80, 80),
				suggestionLabels = {}
			}

			HDAdminMain:GetModule("CmdBar"):SetupTextbox(p2, t5)

			local message = p3.message

			if message and (message ~= "" and message ~= " ") then
				TextBox3.Text = message
			end

			TextBox2.Text = "Alert from " .. HDAdminMain.player.Name

			local FinalResult = v6.FinalResult
			local Example = FinalResult.Frame.Example

			setupFinalResult(v6, ScrollFrame["AX Submit"], ScrollFrame["AZ Loading"], function() --[[ Line: 1304 | Upvalues: TextBox2 (copy), TextBox3 (copy), t3 (copy), TextBox (copy), HDAdminMain (ref) ]]
				return HDAdminMain.signals.RetrieveAlertData:InvokeServer({
					Title = TextBox2.Text,
					Message = TextBox3.Text,
					Server = t3["AC Server"],
					PlayerArg = TextBox.Text:gsub(" ", function(p1) --[[ Line: 1308 ]]
						return ""
					end)
				})
			end, function(p1) --[[ Line: 1319 | Upvalues: Example (copy), FinalResult (copy) ]]
				Example.Title.Text = p1.Title
				Example.Message.Text = p1.Message
				FinalResult.Visible = true
			end, function() --[[ Line: 1324 | Upvalues: HDAdminMain (ref) ]]
				HDAdminMain.signals.ExecuteAlert:InvokeServer()
			end)
		end

		setupOriginalZIndex(v6, p5)

		local commandMenus = HDAdminMain.commandMenus
		local v64 = v6

		table.insert(commandMenus, v64)
		updateZIndex(HDAdminMain.commandMenus)
	end

	v6.Parent = HDAdminMain.gui
	v6.Visible = true
end
function t.GetMousePoint(p1, p2) --[[ GetMousePoint | Line: 1344 | Upvalues: HDAdminMain (copy) ]]
	local v1 = HDAdminMain.camera:ScreenPointToRay(HDAdminMain.lastHitPosition.X, HDAdminMain.lastHitPosition.Y)
	local v3, v4 = workspace:FindPartOnRay(Ray.new(v1.Origin, v1.Direction * 100), HDAdminMain.player.Character)

	return v3, v4
end
function t.GetLabelBackgroundColor(p1, p2) --[[ GetLabelBackgroundColor | Line: 1351 ]]
	if p2 % 2 == 0 then
		return Color3.fromRGB(50, 50, 50)
	end

	return Color3.fromRGB(40, 40, 40)
end
function t.GenerateTagFromId(p1, p2) --[[ GenerateTagFromId | Line: 1359 | Upvalues: HDAdminMain (copy) ]]
	local alphabet = HDAdminMain.alphabet
	local v1 = #alphabet
	local v2 = math.ceil(p2 / #alphabet)

	return (alphabet[math.ceil(p2 / (#alphabet) ^ 2) % v1] or alphabet[v1]) .. (alphabet[v2 % v1] or alphabet[v1]) .. (alphabet[p2 % v1] or alphabet[v1])
end
function t.ClearPage(p1, p2) --[[ ClearPage | Line: 1370 ]]
	for k, v in pairs(p2:GetChildren()) do
		if v.Name == "UIListLayout" then
			if v:IsA("Frame") then
				v.Visible = false
			end
		else
			if string.sub(v.Name, 1, 8) == "Template" then
				if v:IsA("Frame") then
					v.Visible = false
				end

				continue
			end

			v:Destroy()
		end
	end
end
function t.UpdateClientData(p1) --[[ UpdateClientData | Line: 1380 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain.pdata = HDAdminMain.rfunction:InvokeServer("RetrievePlayerData")
end

return t