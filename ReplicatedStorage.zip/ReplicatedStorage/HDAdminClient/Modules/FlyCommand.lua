-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain
local t = {}

local function setCollisionGroupRecursive(p1, p2) --[[ setCollisionGroupRecursive | Line: 6 | Upvalues: HDAdminMain (copy) ]]
	for k, v in pairs(p1:GetDescendants()) do
		if v:IsA("BasePart") then
			HDAdminMain.physicsService:SetPartCollisionGroup(v, p2)
		end
	end
end

function t.Fly(p1, p2, p3) --[[ Fly | Line: 15 | Upvalues: HDAdminMain (copy), setCollisionGroupRecursive (copy) ]]
	local v1 = if p2 == "fly2" then "Sit" else "PlatformStand"
	local v2 = HDAdminMain:GetModule("cf"):GetHRP()
	local v3 = HDAdminMain:GetModule("cf"):GetHumanoid()

	if v2 and v3 then
		local HDAdminFlyForce = Instance.new("BodyPosition")

		HDAdminFlyForce.MaxForce = Vector3.new(inf, inf, inf)
		HDAdminFlyForce.Position = v2.Position + Vector3.new(0, 4, 0)
		HDAdminFlyForce.Name = "HDAdminFlyForce"
		HDAdminFlyForce.Parent = v2

		local HDAdminFlyGyro = Instance.new("BodyGyro")

		HDAdminFlyGyro.D = 50
		HDAdminFlyGyro.MaxTorque = Vector3.new(inf, inf, inf)

		if p3 then
			HDAdminFlyGyro.P = 2000
		else
			HDAdminFlyGyro.P = 200
		end

		HDAdminFlyGyro.Name = "HDAdminFlyGyro"
		HDAdminFlyGyro.CFrame = v2.CFrame
		HDAdminFlyGyro.Parent = v2

		local count = 0
		local count2 = 0

		if p3 then
			setCollisionGroupRecursive(workspace, "Group1")
			setCollisionGroupRecursive(HDAdminMain.player.Character, "Group2")
		end

		local v4 = tick()
		local Position = v2.Position

		while true do
			local v5 = tick() - v4
			local v6 = HDAdminMain.commandSpeeds[p2]
			local v7, v8 = HDAdminMain:GetModule("cf"):GetNextMovement(v5, v6 * 10)
			local Position2 = v2.Position
			local v9 = CFrame.new(Position2, Position2 + (HDAdminMain.camera.Focus.p - HDAdminMain.camera.CFrame.p).unit) * v7
			local v10 = 750 + v6 * 0.2

			if p3 then
				v10 = v10 / 2
			end

			if v7.p == Vector3.new() then
				count2 = count2 + 1
				count = 1

				if (v2.Position - Position).magnitude > 6 and count2 >= 4 then
					HDAdminFlyForce.Position = v2.Position
				end
			else
				HDAdminFlyForce.D = v10
				HDAdminFlyForce.Position = v9.p
				count2 = 0
				count = count + 1
			end

			if math.abs(count) > 25 then
				count = 25
			end

			if HDAdminFlyForce.D == v10 then
				local _ = count * v8.X * -0.5

				HDAdminFlyGyro.CFrame = v9 * CFrame.Angles(math.rad(if p3 then 0 else count * v8.Z), 0, 0)
			end

			local v12 = tick()

			Position = v2.Position
			v3[v1] = true
			wait()

			if not (HDAdminMain.commandsActive[p2] and (v3 and v2)) then
				break
			end

			v4 = v12
		end

		HDAdminFlyForce:Destroy()
		HDAdminFlyGyro:Destroy()

		if v3 then
			v3[v1] = false
		end

		if p3 then
			setCollisionGroupRecursive(workspace, "Group3")
		end
	end

	HDAdminMain.commandsActive[p2] = nil
end

return t