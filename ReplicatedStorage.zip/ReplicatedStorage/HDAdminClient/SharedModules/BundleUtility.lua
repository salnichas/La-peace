-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain
local v1 = HDAdminMain.settings
local Players = game:GetService("Players")
local AssetService = game:GetService("AssetService")
local t2 = {}
local t3 = {}
local t4 = {}
local t5 = {}

function t.register(p1, p2, p3) --[[ register | Line: 16 | Upvalues: t4 (copy), t5 (copy), v1 (copy), HDAdminMain (copy), t (copy) ]]
	local t2 = { p1, p2, p3 }

	t4[p1] = t2
	t5[tostring(p2)] = t2

	local v12 = p1:sub(1, 1):lower() .. p1:sub(2)
	local v2 = p3 and p3.Rank

	local function getPrefixes() --[[ getPrefixes | Line: 22 | Upvalues: v2 (copy), v1 (ref) ]]
		if v2 then
			return { v1.Prefix }
		end

		return { v1.ChatPrefix, v1.UniversalPrefix }
	end

	local v3 = if v2 and (tonumber(v2) and v2 > 0) then false else 10
	local v4 = if v1.DisableBoosterBundles then not v2 else v1.DisableFunAndBoosterCommands and not v2
	local v5 = tostring(v12)
	local t3 = {
		RankLock = false,
		Loopable = false,
		Description = "",
		DisableChatUndo = false,
		Name = if v2 then v5 else "boosterBundle" .. v5,
		Override = if v2 then nil else "/" .. v5,
		Aliases = {}
	}

	t3.Prefixes = if v2 then { v1.Prefix } else { v1.ChatPrefix, v1.UniversalPrefix }
	t3.Rank = v2 or "Booster"
	t3.Tags = { "fun" }
	t3.Groups = { "Bundle" }
	t3.Contributors = { "ForeverHD" }
	t3.LimitGroupPerMinute = v3
	t3.DisabledByOwner = v4
	t3.Args = { "Player" }
	function t3.Function(p12, p2) --[[ Function | Line: 53 | Upvalues: v2 (copy), HDAdminMain (ref), t (ref), p1 (copy) ]]
		local v1 = p2[1]

		if not v2 then
			HDAdminMain:GetModule("cf"):CheckFirstTimeUsing(v1)
		end

		local _, _2 = t.apply(v1, p1)
	end
	function t3.UnFunction(p1, p2) --[[ UnFunction | Line: 61 | Upvalues: t (ref) ]]
		t.unapply(p2[1])
	end

	return t3
end
function t.getDetail(p1) --[[ getDetail | Line: 69 | Upvalues: t4 (copy), t5 (copy) ]]
	local v1 = tostring(p1)

	return t4[v1] or t5[v1]
end
function t.getWebsiteDescription(p1) --[[ getWebsiteDescription | Line: 78 | Upvalues: t2 (copy), Players (copy) ]]
	local v1 = p1.Name
	local Character = p1.Character
	local v2 = Character and Character:FindFirstChild("HDOriginalDescription")

	if v2 then
		task.defer(function() --[[ Line: 83 | Upvalues: v2 (copy) ]]
			v2:Destroy()
		end)

		return v2
	end

	local v3 = t2[v1]

	if not v3 then
		local ok, result = pcall(function() --[[ Line: 90 | Upvalues: Players (ref), p1 (copy) ]]
			return Players:GetHumanoidDescriptionFromUserId(p1.UserId)
		end)

		if not ok then
			return false, result
		end

		v3 = result
		t2[v1] = v3
		p1:GetPropertyChangedSignal("Parent"):Once(function() --[[ Line: 98 | Upvalues: t2 (ref), v1 (copy), v3 (ref) ]]
			t2[v1] = nil
			v3:Destroy()
		end)
	end

	return v3
end
function t.unapply(p1) --[[ unapply | Line: 106 | Upvalues: t (copy) ]]
	local v1, v2 = t.getWebsiteDescription(p1)

	if not v1 then
		return false, v2
	end

	local Character = p1.Character
	local v3 = Character and Character:FindFirstChildOfClass("Humanoid")

	if v3 then
		local ok, result = pcall(function() --[[ Line: 116 | Upvalues: v3 (copy), v1 (copy) ]]
			v3:ApplyDescriptionReset(v1, Enum.AssetTypeVerification.Always)
		end)

		return ok, result
	end

	return false, "Missing humanoid"
end
function t.getBundleDescription(p1) --[[ getBundleDescription | Line: 122 | Upvalues: t3 (copy), AssetService (copy), Players (copy) ]]
	local v1 = tostring(p1)
	local v2 = t3[v1]

	if v2 then
		return v2
	end

	local ok, result = pcall(function() --[[ Line: 128 | Upvalues: AssetService (ref), p1 (copy) ]]
		return AssetService:GetBundleDetailsAsync(p1)
	end)

	if not ok then
		return false, result
	end

	local v3 = nil

	for k, v in pairs(result.Items) do
		if v.Type == "UserOutfit" then
			v3 = v.Id

			break
		end
	end

	if not v3 then
		return false, "Missing Bundle Outfit"
	end

	local ok2, result2 = pcall(function() --[[ Line: 144 | Upvalues: Players (ref), v3 (ref) ]]
		return Players:GetHumanoidDescriptionFromOutfitId(v3)
	end)

	if ok2 then
		t3[v1] = result2

		return result2
	end

	return false, result2
end
function t.apply(p1, p2) --[[ apply | Line: 154 | Upvalues: HDAdminMain (copy), t (copy), v1 (copy) ]]
	local v12 = HDAdminMain:GetModule("cf"):GetHumanoid(p1)

	if v12 then
		v12:UnequipTools()
	end

	local v2 = t.getDetail(p2)
	local v4 = v2[3] or {}
	local IgnoreAccessories = v4.IgnoreAccessories
	local t2 = {}

	if typeof(IgnoreAccessories) == "table" then
		for k, v in pairs(IgnoreAccessories) do
			t2[v] = true
		end
	end

	local IgnoreBodyParts = v4.IgnoreBodyParts
	local t3 = {}

	if typeof(IgnoreBodyParts) == "table" then
		for k, v in pairs(IgnoreBodyParts) do
			t3[v] = true
		end
	end

	local RemoveBodyParts = v4.RemoveBodyParts
	local t4 = {}

	if typeof(RemoveBodyParts) == "table" then
		for k, v in pairs(RemoveBodyParts) do
			t4[v] = true
		end
	end

	local v5, v6 = t.getWebsiteDescription(p1)

	if not v5 then
		return false, v6
	end

	local v7, v8 = t.getBundleDescription(v2[2])

	if not v7 then
		return false, v8
	end

	local v9 = v7:Clone()

	for k, v in pairs(v5:GetChildren()) do
		if v:IsA("AccessoryDescription") then
			if IgnoreAccessories ~= true and not t2[v.AccessoryType.Name] then
				v:Clone().Parent = v9
			end

			continue
		end

		if v:IsA("BodyPartDescription") then
			local v10 = v.BodyPart.Name

			if IgnoreBodyParts ~= true and not t3[v10] then
				local v11 = nil

				for k2, v13 in pairs(v9:GetChildren()) do
					if v13:IsA("BodyPartDescription") and v13.BodyPart == v.BodyPart then
						v11 = v13
					end
				end

				if v11 then
					v11.Color = v.Color
				else
					v:Clone().Parent = v9
				end
			end

			if t4[v10] then
				v9[v10] = v5[v10]
			end
		end
	end

	for k, v in pairs({
		"ClimbAnimation",
		"FallAnimation",
		"IdleAnimation",
		"JumpAnimation",
		"MoodAnimation",
		"RunAnimation",
		"SwimAnimation",
		"WalkAnimation",
		"GraphicTShirt",
		"Pants",
		"Shirt"
	}) do
		v9[v] = v5[v]
	end

	local function splitByCapitals(p1) --[[ splitByCapitals | Line: 234 ]]
		return p1:gsub("(%u)", " %1"):gsub("^%s", ""):split(" ")
	end

	local v122 = v1.ScaleLimit or 5

	for k, v in pairs(v4) do
		if k:sub(1, 5) == "Scale" then
			if v122 < v then
				v = v122
			end

			for k2, v10 in pairs((k:sub(6):gsub("(%u)", " %1"):gsub("^%s", ""):split(" "))) do
				v9[v10 .. "Scale"] = v
			end
		end
	end

	local Character = p1.Character
	local v14 = Character and Character:FindFirstChild("Humanoid")
	local _ = if Character then Character:FindFirstChild("HDOriginalDescription") else Character
	local ok, result = pcall(function() --[[ Line: 264 | Upvalues: v14 (copy), v9 (copy) ]]
		v14:ApplyDescriptionReset(v9, Enum.AssetTypeVerification.Always)
	end)

	v9:Destroy()

	if ok then
		return true
	end

	return false, result
end

return t