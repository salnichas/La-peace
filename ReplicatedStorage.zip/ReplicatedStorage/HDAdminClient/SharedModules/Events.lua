-- https://lua.expert/
local HDAdminMain = _G.HDAdminMain

return {
	EventName = function(p1, p2, ...) --[[ Line: 10 ]] end,
	EventName = function(p1, p2, ...) --[[ Line: 18 ]] end
}