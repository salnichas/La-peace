-- https://lua.expert/
local v1 = setmetatable({}, {
	__index = function(p1, p2) --[[ __index | Line: 4 ]]
		local ok, result = pcall(game.GetService, game, p2:sub(1, 1):upper() .. p2:sub(2))

		if ok then
			p1[p2] = result

			return result
		end
	end
})

function v1.Initialize(p1, p2, p3) --[[ Initialize | Line: 15 | Upvalues: v1 (copy) ]]
	v1.rs = game:GetService("ReplicatedStorage")
	v1.ss = game:GetService("ServerStorage")
	v1.sss = game:GetService("ServerScriptService")

	local function ConvertToCamelCase(p1) --[[ ConvertToCamelCase | Line: 25 ]]
		return string.lower((string.sub(p1, 1, 1))) .. string.sub(p1, 2)
	end

	if p2 == "Server" then
		v1.mainModule = script:FindFirstAncestor("MainModule")
		v1.server = v1.mainModule.Server
		v1.client = v1.mainModule.Client
		v1.workspaceFolder = Instance.new("Folder")
		v1.workspaceFolder.Name = "HDAdminWorkspaceFolder"
		v1.workspaceFolder.Parent = workspace

		local SettingsCopy = v1.server.Assets:FindFirstChild("SettingsCopy")

		if SettingsCopy then
			v1.settings = require(SettingsCopy)
		end

		local Settings = require(p3:FindFirstChild("Settings", true))

		if Settings then
			for k, v in pairs(Settings) do
				v1.settings[k] = v
			end
		end

		local CustomFeatures = p3:FindFirstChild("CustomFeatures", true)

		local function UpdateStorageWithContents(p1, p2) --[[ UpdateStorageWithContents | Line: 56 | Upvalues: v1 (ref) ]]
			local v2 = string.lower(if p2 == "Client" and p2 then p2 else "Server")
			local v3 = p1.Name
			local v4 = v1[v2]:FindFirstChild(v3)

			if not v4 or (v3 == "client" or v3 == "server") then
				return
			end

			for k, v in pairs(p1:GetChildren()) do
				local v5 = v4:FindFirstChild(v.Name)

				if v5 and not v5:IsA("ModuleScript") then
					v5:Destroy()
				end

				v.Parent = v4
			end
		end

		if CustomFeatures then
			for k, v in pairs(CustomFeatures:GetChildren()) do
				UpdateStorageWithContents(v)

				local v12 = v.Name

				for k2, v2 in pairs(v:GetChildren()) do
					UpdateStorageWithContents(v2, v12)
				end
			end
		end

		local t = {
			Client = v1.rs,
			Server = v1.ss
		}
		local t2 = {
			HDAdminLocalFirst = v1.replicatedFirst,
			HDAdminStarterCharacter = v1.starterPlayer.StarterCharacterScripts,
			HDAdminStarterPlayer = v1.starterPlayer.StarterPlayerScripts,
			HDAdminGUIs = v1.starterGui,
			Preload = v1.replicatedFirst
		}

		local function CheckToMove(p1) --[[ CheckToMove | Line: 92 | Upvalues: t (copy), t2 (copy) ]]
			local v1 = p1.Name
			local v2 = t[v1] or t2[v1]

			if not v2 or v2:FindFirstChild(v1) then
				return
			end

			if t[v1] then
				p1.Name = "HDAdmin" .. v1
				p1.Parent = v2

				return
			end

			if not t2[v1] then
				return
			end

			local v3 = p1:Clone()

			v3.Parent = v2

			if not v3:IsA("LocalScript") then
				return
			end

			v3.Disabled = false
		end

		for k, v in pairs(v1.mainModule:GetChildren()) do
			CheckToMove(v)

			for k2, v2 in pairs(v:GetChildren()) do
				CheckToMove(v2)

				for k3, v3 in pairs(v2:GetChildren()) do
					CheckToMove(v3)
				end
			end
		end

		local SetupQuickJoiners = v1.server.Assets.SetupQuickJoiners

		for k, v in pairs(v1.players:GetChildren()) do
			SetupQuickJoiners:Clone().Parent = v.PlayerGui
		end

		coroutine.wrap(function() --[[ Line: 125 | Upvalues: v1 (ref) ]]
			local HDAdminMapBackup = Instance.new("Folder")

			HDAdminMapBackup.Name = "HDAdminMapBackup"
			HDAdminMapBackup.Parent = v1.ss
			v1.client.Signals.Initialized.Event:Wait()
			v1:GetModule("cf"):SaveMap()
		end)()
	elseif p2 == "Client" then
		v1.client = v1.rs:WaitForChild("HDAdminClient")

		for k, v in pairs(v1.client:GetChildren()) do

		end

		v1.workspaceFolder = workspace:WaitForChild("HDAdminWorkspaceFolder")
		v1.player = game.Players.LocalPlayer
		v1.playerGui = v1.player:WaitForChild("PlayerGui")
		v1.gui = v1.playerGui:WaitForChild("HDAdminGUIs")
		v1.templates = v1.gui.Templates
		v1.warnings = v1.gui.MainFrame:WaitForChild("Warnings")
		v1.camera = workspace.CurrentCamera
		v1.tablet = false

		if v1.guiService:IsTenFootInterface() then
			v1.device = "Console"
		elseif v1.userInputService.TouchEnabled and not v1.userInputService.MouseEnabled then
			v1.device = "Mobile"
		else
			v1.device = "Computer"
		end

		if v1.gui.AbsoluteSize.Y < 1 then
			repeat
				wait()
			until v1.gui.AbsoluteSize.Y > 0
		end

		if v1.device == "Mobile" and v1.gui.AbsoluteSize.Y >= 650 then
			v1.tablet = true
		end

		local v2 = nil

		for i = 1, 50 do
			local ok, result = pcall(function() --[[ Line: 172 | Upvalues: v1 (ref) ]]
				return v1.client.Signals.RetrieveData:InvokeServer()
			end)

			v2 = result

			if ok and result then
				break
			end

			wait(1)
		end

		for k, v in pairs(v2) do
			v1[k] = v
		end
	end

	os.date("*t", os.time())
	v1.hdAdminCoreName = "DELTA ADMIN"
	v1.modules = {}
	v1.coreFolder = v1[string.lower(p2)]
	v1.moduleGroup = v1.coreFolder.Modules
	v1.sharedModules = v1.client.SharedModules
	v1.signals = v1.client.Signals
	v1.audio = v1.client.Audio

	local t = {}

	function v1.GetModule(p1, p2) --[[ GetModule | Line: 200 | Upvalues: v1 (ref), t (copy) ]]
		if not v1.modules[p2] then
			local t2 = {
				name = p2,
				addedSignal = Instance.new("BindableEvent")
			}

			t[#t + 1] = t2
			t2.addedSignal.Event:Wait()
		end

		return v1.modules[p2]
	end
	function v1.loadModule(p1) --[[ loadModule | Line: 208 | Upvalues: v1 (ref), t (copy) ]]
		if not v1.modules[p1] then
			local t2 = {
				name = p1,
				addedSignal = Instance.new("BindableEvent")
			}

			t[#t + 1] = t2
			t2.addedSignal.Event:Wait()
		end

		return v1.modules[p1]
	end

	local t2 = {}

	for k, v in pairs({
		cf = { "ClientCoreFunctions", "SharedCoreFunctions", "ServerCoreFunctions" },
		API = { "ClientAPI", "ServerAPI", "SharedAPI" }
	}) do
		for k2, v2 in pairs(v) do
			t2[v2] = k
		end
	end

	local function SetupModules(p1, p2) --[[ SetupModules | Line: 228 | Upvalues: t2 (copy), t (copy) ]]
		for k, v in pairs(p1:GetDescendants()) do
			if v:IsA("ModuleScript") and v.Name ~= script.Name then
				coroutine.wrap(function() --[[ Line: 231 | Upvalues: v (copy), t2 (ref), p2 (copy), t (ref) ]]
					local v1 = v.Name
					local v2 = t2[v1]

					if v2 then
						v1 = v2
					end

					local ok, result = pcall(function() --[[ Line: 240 | Upvalues: v (ref) ]]
						if v.Parent then
							return require(v)
						end

						print("B IS MISSING:", v.Name, v, v.Parent)

						return require(v)
					end)

					if not ok then
						warn("HD Admin Module Error | " .. v.Name .. " | " .. tostring(result))

						return
					end

					if p2[v1] then
						for k, v3 in pairs(result) do
							if tonumber(k) then
								table.insert(p2[v1], v3)

								continue
							end

							p2[v1][k] = v3
						end
					else
						p2[v1] = result

						for i = #t, 1, -1 do
							local v4 = t[i]

							if v4.name == v1 then
								table.remove(t, i)
								v4.addedSignal:Fire()
							end
						end
					end
				end)()
			end
		end
	end

	require(script.MainVariables):SetupMainVariables(p2)
	SetupModules(v1.moduleGroup, v1.modules)
	SetupModules(v1.sharedModules, v1.modules)

	if p2 ~= "Server" then
		v1.initialized = true
		v1.client.Signals.Initialized:Fire()

		return
	end

	v1.server.Assets:WaitForChild("HDAdminSetup").Parent = v1.rs

	if not v1.ownerName then
		v1.ownerName = v1:GetModule("cf"):GetName(v1.ownerId)
	end

	v1:GetModule("CommandHandler"):Setup()
	v1:GetModule("LoaderHandler"):Setup()
	v1.initialized = true
	v1.client.Signals.Initialized:Fire()
end
function v1.CheckInitialized(p1) --[[ CheckInitialized | Line: 303 | Upvalues: v1 (copy) ]]
	if v1.initialized then
		return v1
	end

	script.Parent.Parent:WaitForChild("Signals"):WaitForChild("Initialized").Event:Wait()

	return v1
end
_G.HDAdminMain = v1

return v1