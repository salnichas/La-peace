-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain

function t.WaitForEvent(p1, ...) --[[ WaitForEvent | Line: 12 ]]
	local v1 = ({ ... })[1]
	local v2 = if typeof(v1) == "Instance" and v1:IsA("BindableEvent") then v1 else Instance.new("BindableEvent")
	local tbl = {}

	for k, v in pairs({ ... }) do
		if v ~= v1 then
			tbl[#tbl + 1] = v:Connect(function() --[[ Line: 23 | Upvalues: v2 (ref) ]]
				v2:Fire()
			end)
		end
	end

	v2.Event:Wait()
	v2:Destroy()

	for k, v in pairs(tbl) do
		v:Disconnect()
	end
end
function t.CreateSound(p1, p2) --[[ CreateSound | Line: 33 ]]
	local Sound = Instance.new("Sound")

	for k, v in pairs(p2) do
		if k == "SoundId" then
			v = "rbxassetid://" .. v
		end

		Sound[k] = v
	end

	return Sound
end
function t.FormatNotice2(p1, p2, p3, ...) --[[ FormatNotice2 | Line: 44 | Upvalues: HDAdminMain (copy) ]]
	local v1 = HDAdminMain:GetModule("CoreNotices"):GetNotice(p2)

	v1[2] = string.format(v1[2], ...)
	v1[3] = p3

	return v1
end
function t.FormatNotice(p1, p2, ...) --[[ FormatNotice | Line: 51 | Upvalues: HDAdminMain (copy) ]]
	local v1 = HDAdminMain:GetModule("CoreNotices"):GetNotice(p2)

	v1[2] = string.format(v1[2], ...)

	return v1
end
function t.RandomiseTable(p1, p2, p3) --[[ RandomiseTable | Line: 57 ]]
	local v1 = p3 and math.floor(os.time() / p3)
	local t = {}

	if p2[1] ~= nil then
		for i = 1, #p2 do
			if p3 then
				math.randomseed(v1 + i)
			end

			local v3 = math.random(1, #t + 1)

			table.insert(t, v3, p2[i])
		end
	end

	return t
end
function t.IsPunished(p1, p2) --[[ IsPunished | Line: 71 ]]
	return (not p2 or (not p2.Character or p2.Character.Parent ~= workspace)) and true or false
end
function t.UnSeatPlayer(p1, p2) --[[ UnSeatPlayer | Line: 79 | Upvalues: t (copy) ]]
	local v1 = t:GetHumanoid(p2)

	if not v1 then
		return
	end

	local SeatPart = v1.SeatPart

	if not SeatPart then
		return
	end

	local SeatWeld = SeatPart:FindFirstChild("SeatWeld")

	if not SeatWeld then
		return
	end

	SeatWeld:Destroy()
	wait()
end
function t.GetBanDateString(p1, p2, p3) --[[ GetBanDateString | Line: 93 | Upvalues: HDAdminMain (copy) ]]
	local v1 = p2.min or p3.min
	local v2 = p2.hour or p3.hour
	local v3 = p2.day or p3.day
	local v4 = HDAdminMain:GetModule("cf"):GetMonths()

	if v1 < 10 then
		v1 = "0" .. v1
	end

	if v2 < 10 then
		v2 = "0" .. v2
	end

	local v9 = tonumber((string.sub(v3, -1)))
	local v10 = "th"

	if (v9 < 10 or v9 > 15) and v9 == 1 then
		v10 = "st"
	elseif (v9 < 10 or v9 > 15) and v9 == 2 then
		v10 = "nd"
	elseif (v9 < 10 or v9 > 15) and v9 == 3 then
		v10 = "rd"
	end

	return v2 .. ":" .. v1 .. ", " .. v3 .. v10 .. " " .. v4[p2.month or p3.month] .. " " .. (p2.year or p3.year) .. (if p2 or not p3 then "" else " UTC")
end
function t.GetTimeAmount(p1, p2, p3) --[[ GetTimeAmount | Line: 123 ]]
	local v1 = 0
	local v2 = ""

	if p3 < 0 then
		p3 = 0
	end

	if p2 == "m" then
		if p3 > 60 then
			p3 = 60
		end

		v1 = p3 * 60
		v2 = "Minutes"
	elseif p2 == "h" then
		if p3 > 24 then
			p3 = 24
		end

		v1 = p3 * 3600
		v2 = "Hours"
	elseif p2 == "d" then
		if p3 > 100000 then
			p3 = 100000
		end

		v1 = p3 * 86400
		v2 = "Days"
	end

	return v1, v2, p3
end
function t.GetMonths(p1) --[[ GetMonths | Line: 151 ]]
	return {
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December"
	}
end
function t.AnchorModel(p1, p2, p3) --[[ AnchorModel | Line: 168 ]]
	for k, v in pairs(p2:GetDescendants()) do
		if v:IsA("BasePart") and not v.Parent:IsA("Accessory") then
			v.Anchored = p3
		end
	end
end
function t.TweenModel(p1, p2, p3, p4) --[[ TweenModel | Line: 176 | Upvalues: HDAdminMain (copy) ]]
	local CFrameValue = Instance.new("CFrameValue")

	CFrameValue.Value = p2:GetPrimaryPartCFrame()

	local v1 = nil

	v1 = CFrameValue:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 180 | Upvalues: p2 (copy), v1 (ref), CFrameValue (copy) ]]
		if p2.PrimaryPart == nil then
			v1:Disconnect()
		else
			p2:SetPrimaryPartCFrame(CFrameValue.Value)
		end
	end)

	local v2 = HDAdminMain.tweenService:Create(CFrameValue, p4, {
		Value = p3
	})

	v2:Play()
	v2.Completed:Connect(function() --[[ Line: 189 | Upvalues: CFrameValue (copy) ]]
		CFrameValue:Destroy()
	end)
end
function t.Movement(p1, p2, p3) --[[ Movement | Line: 194 | Upvalues: HDAdminMain (copy), t (copy) ]]
	if p3 == nil then
		p3 = HDAdminMain.player
	end

	local v1 = t:GetHRP(p3)
	local v2 = t:GetHumanoid(p3)

	if not (v1 and v2) then
		return
	end

	if not p2 then
		local WalkSpeed = v2.WalkSpeed

		v2.WalkSpeed = 0
		wait()
		v2.WalkSpeed = WalkSpeed
		v1.Anchored = true

		return
	end

	v1.Anchored = false
end
function t.SetFakeBodyParts(p1, p2, p3) --[[ SetFakeBodyParts | Line: 213 | Upvalues: HDAdminMain (copy) ]]
	for k, v in pairs(p2:GetChildren()) do
		if HDAdminMain:GetModule("cf"):CheckBodyPart(v) then
			local v1 = HDAdminMain:GetModule("MorphHandler"):CreateFakeBodyPart(p2, v)

			for k2, v2 in pairs(p3) do
				if k2 == "Material" then
					v1.Material = v2

					if v2 == Enum.Material.Glass then
						v1.Transparency = 0.5

						continue
					end

					v1.Transparency = 0

					continue
				end

				if k2 == "Reflectance" then
					v1.Reflectance = v2

					continue
				end

				if k2 == "Transparency" then
					v1.Transparency = v2

					continue
				end

				if k2 == "Color" then
					v1.Color = v2
				end
			end
		end
	end
end
function t.CheckBodyPart(p1, p2) --[[ CheckBodyPart | Line: 237 ]]
	if not p2:IsA("BasePart") or p2.Name == "HumanoidRootPart" then
		return false
	end

	if string.sub(p2.Name, 1, 4) == "Fake" then
		return false
	end

	return true
end
function t.CreateClone(p1, p2) --[[ CreateClone | Line: 245 | Upvalues: HDAdminMain (copy) ]]
	if p2 == nil then
		p2 = HDAdminMain.player.Character
	end

	local Humanoid = p2:FindFirstChild("Humanoid")

	if not Humanoid then
		return
	end

	p2.Archivable = true

	local v1 = p2:Clone()
	local Humanoid2 = v1.Humanoid

	v1.Name = p2.Name .. "\'s HDAdminClone"

	local v2 = v1:FindFirstChild("Chest") and true or false

	for k, v in pairs(v1:GetDescendants()) do
		if v:IsA("Humanoid") then
			v.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None

			continue
		end

		if v:IsA("BillboardGui") then
			v:Destroy()

			continue
		end

		if v:IsA("Weld") and v.Part1 ~= nil then
			v.Part0 = v.Parent

			if v1:FindFirstChild(v.Part1.Name) then
				v.Part1 = v1[v.Part1.Name]

				continue
			end

			if not v2 then
				v:Destroy()
			end
		end
	end

	v1.Parent = workspace

	local t = {}

	Humanoid:GetAppliedDescription()

	if v1:FindFirstChild("Animate") then
		for k, v in pairs(v1.Animate:GetChildren()) do
			local v3 = v:GetChildren()[1]

			if v3 then
				t[v.Name] = Humanoid2:LoadAnimation(v3)
			end
		end

		t.idle:Play()
	end

	return v1, t
end
function t.SetTransparency(p1, p2, p3, p4) --[[ SetTransparency | Line: 301 | Upvalues: HDAdminMain (copy) ]]
	local v1 = HDAdminMain.players:GetPlayerFromCharacter(p2)

	if v1 and (HDAdminMain.pd[v1] and (HDAdminMain.pd[v1].Items.UnderControl and not p4)) or not p2 then
		return
	end

	local v2 = p2:FindFirstChild("FakeHead") and true or false

	for k, v in pairs(p2:GetDescendants()) do
		local v3, OriginalTransparency

		if v:IsA("BasePart") and v.Name ~= "HumanoidRootPart" then
			v3 = v:FindFirstChild("OriginalTransparency")

			if p3 == 1 and (v.Transparency ~= 0 and not v3) then
				OriginalTransparency = Instance.new("IntValue")
				OriginalTransparency.Name = "OriginalTransparency"
				OriginalTransparency.Value = v.Transparency
				OriginalTransparency.Parent = v

				continue
			end

			if p3 == 0 and v3 then
				v.Transparency = v3.Value
				v3:Destroy()

				continue
			end

			if not v2 or p2:FindFirstChild(v.Name .. "Fake") == nil then
				v.Transparency = p3
			end
		else
			if v.Name == "face" and v:IsA("Decal") then
				v3 = v:FindFirstChild("OriginalTransparency")

				if p3 == 1 and (v.Transparency ~= 0 and not v3) then
					OriginalTransparency = Instance.new("IntValue")
					OriginalTransparency.Name = "OriginalTransparency"
					OriginalTransparency.Value = v.Transparency
					OriginalTransparency.Parent = v

					continue
				end

				if p3 == 0 and v3 then
					v.Transparency = v3.Value
					v3:Destroy()

					continue
				end

				if not v2 or p2:FindFirstChild(v.Name .. "Fake") == nil then
					v.Transparency = p3
				end

				continue
			end

			if v:IsA("ParticleEmitter") and v.Name == "BodyEffect" then
				if p3 == 1 then
					v.Enabled = false

					continue
				end

				if p3 == 0 then
					v.Enabled = true
				end
			else
				if v:IsA("PointLight") then
					if p3 == 1 then
						v.Enabled = false

						continue
					end

					if p3 == 0 then
						v.Enabled = true
					end

					continue
				end

				if v:IsA("BillboardGui") then
					if p3 == 1 then
						v.Enabled = false

						continue
					end

					if p3 == 0 then
						v.Enabled = true
					end
				end
			end
		end
	end
end
function t.GetMessageTime(p1, p2) --[[ GetMessageTime | Line: 340 ]]
	return string.len(p2) / 30 + 3
end
function t.GetProductInfo(p1, p2) --[[ GetProductInfo | Line: 344 | Upvalues: HDAdminMain (copy) ]]
	local ok, result = pcall(function() --[[ Line: 346 | Upvalues: HDAdminMain (ref), p2 (copy) ]]
		return HDAdminMain.marketplaceService:GetProductInfo(p2)
	end)

	return if ok then result else {}
end
function t.CheckIfValidSound(p1, p2) --[[ CheckIfValidSound | Line: 353 | Upvalues: t (copy) ]]
	return t:GetProductInfo(p2).AssetTypeId == 3
end
function t.GetChar(p1, p2) --[[ GetChar | Line: 362 | Upvalues: HDAdminMain (copy) ]]
	if p2 == nil then
		p2 = HDAdminMain.player
	end

	if p2 then
		return p2.Character
	end
end
function t.GetHRP(p1, p2) --[[ GetHRP | Line: 371 | Upvalues: HDAdminMain (copy) ]]
	if p2 == nil then
		p2 = HDAdminMain.player
	end

	if p2 and p2.Character then
		return p2.Character:FindFirstChild("HumanoidRootPart")
	end
end
function t.GetNeck(p1, p2) --[[ GetNeck | Line: 381 | Upvalues: HDAdminMain (copy) ]]
	if p2 == nil then
		p2 = HDAdminMain.player
	end

	if not (p2 and p2.Character) then
		return
	end

	local Head = p2.Character:FindFirstChild("Head")

	if not Head then
		return
	end

	local Neck = Head:FindFirstChild("Neck")
	local Torso = p2.Character:FindFirstChild("Torso")

	if not Neck and Torso then
		Neck = Torso:FindFirstChild("Neck")
	end

	return Neck
end
function t.GetHead(p1, p2) --[[ GetHead | Line: 398 | Upvalues: HDAdminMain (copy) ]]
	if p2 == nil then
		p2 = HDAdminMain.player
	end

	if p2 and p2.Character then
		return p2.Character:FindFirstChild("Head")
	end
end
function t.GetFace(p1, p2) --[[ GetFace | Line: 408 | Upvalues: HDAdminMain (copy) ]]
	if p2 == nil then
		p2 = HDAdminMain.player
	end

	if not (p2 and p2.Character) then
		return
	end

	local Head = p2.Character:FindFirstChild("Head")

	if Head then
		local face = Head:FindFirstChild("face")

		if face and face.ClassName == "Decal" then
			return face
		end
	end

	return Head
end
function t.GetHumanoid(p1, p2) --[[ GetHumanoid | Line: 424 | Upvalues: HDAdminMain (copy) ]]
	if p2 == nil then
		p2 = HDAdminMain.player
	end

	if p2 and p2.Character then
		return p2.Character:FindFirstChild("Humanoid")
	end
end
function t.GetProductInfo(p1, p2, p3) --[[ GetProductInfo | Line: 434 | Upvalues: HDAdminMain (copy) ]]
	local t = {}
	local _, _2 = pcall(function() --[[ Line: 436 | Upvalues: t (ref), HDAdminMain (ref), p2 (copy), p3 (copy) ]]
		t = HDAdminMain.marketplaceService:GetProductInfo(p2, p3)
	end)

	return t
end
function t.GetFriends(p1, p2) --[[ GetFriends | Line: 445 | Upvalues: HDAdminMain (copy) ]]
	local t = {}
	local ok, result = pcall(function() --[[ Line: 447 | Upvalues: HDAdminMain (ref), p2 (copy) ]]
		return HDAdminMain.players:GetFriendsAsync(p2)
	end)

	if ok then
		repeat
			for k, v in pairs((result:GetCurrentPage())) do
				t[v.Username] = v.Id
			end

			if not result.IsFinished then
				result:AdvanceToNextPageAsync()
			end
		until result.IsFinished
	end

	return t
end
function t.GetRankName(p1, p2) --[[ GetRankName | Line: 462 | Upvalues: HDAdminMain (copy) ]]
	local v1 = ""

	for k, v in pairs(HDAdminMain.settings.Ranks) do
		local v3 = v[2]

		if p2 == v[1] then
			v1 = v3

			continue
		end

		if p2 == "Donor" then
			v1 = p2
		end
	end

	return v1
end
function t.GetRankId(p1, p2) --[[ GetRankId | Line: 476 | Upvalues: HDAdminMain (copy) ]]
	local v1 = 0

	for k, v in pairs(HDAdminMain.settings.Ranks) do
		local v2 = v[1]

		if p2 == v[2] then
			v1 = v2
		end
	end

	return v1
end
function t.CheckRankExists(p1, p2) --[[ CheckRankExists | Line: 488 | Upvalues: HDAdminMain (copy) ]]
	for k, v in pairs(HDAdminMain.settings.Ranks) do
		if string.lower(v[2]) == p2 then
			return true
		end
	end

	return false
end
function t.GetUserId(p1, p2) --[[ GetUserId | Line: 497 | Upvalues: HDAdminMain (copy) ]]
	tick()

	local v1 = HDAdminMain.UserIdsFromName[p2]

	if not v1 or v1 <= 1 then
		v1 = 1

		local _, _2 = pcall(function() --[[ Line: 502 | Upvalues: v1 (ref), HDAdminMain (ref), p2 (copy) ]]
			v1 = HDAdminMain.players:GetUserIdFromNameAsync(p2)
		end)

		HDAdminMain.UserIdsFromName[p2] = v1
	end

	return v1
end
function t.GetName(p1, p2) --[[ GetName | Line: 511 | Upvalues: HDAdminMain (copy) ]]
	local v1 = tostring(p2)
	local v2 = tonumber(p2)
	local v3 = HDAdminMain.UsernamesFromUserId[v1]

	if not v3 then
		v3 = ""

		if v2 then
			local ok, _ = pcall(function() --[[ Line: 518 | Upvalues: v3 (ref), HDAdminMain (ref), v2 (copy) ]]
				v3 = HDAdminMain.players:GetNameFromUserIdAsync(v2)
			end)

			if ok then
				HDAdminMain.UsernamesFromUserId[v1] = v3
			end
		end
	end

	return v3
end
function t.FindValue(p1, p2, p3) --[[ FindValue | Line: 532 ]]
	for k, v in pairs(p2) do
		if tostring(v) == tostring(p3) then
			return true
		end
	end

	return false
end

return t