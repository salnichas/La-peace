-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain

function t.SetupMainVariables(p1, p2) --[[ SetupMainVariables | Line: 11 | Upvalues: HDAdminMain (copy) ]]
	HDAdminMain.hdAdminGroup = {
		Id = 4676369,
		Info = {}
	}
	HDAdminMain.hdAdminGroupInfo = {}
	HDAdminMain.settingsBanRecords = {}
	HDAdminMain.alphabet = {
		"a",
		"b",
		"c",
		"d",
		"e",
		"f",
		"g",
		"h",
		"i",
		"j",
		"k",
		"l",
		"m",
		"n",
		"o",
		"p",
		"q",
		"r",
		"s",
		"t",
		"u",
		"v",
		"w",
		"x",
		"y",
		"z"
	}
	HDAdminMain.UserIdsFromName = {}
	HDAdminMain.UsernamesFromUserId = {}
	HDAdminMain.validSettings = {
		"Theme",
		"NoticeSoundId",
		"NoticeVolume",
		"NoticePitch",
		"ErrorSoundId",
		"ErrorVolume",
		"ErrorPitch",
		"AlertSoundId",
		"AlertVolume",
		"AlertPitch",
		"Prefix"
	}
	HDAdminMain.commandInfoToShowOnClient = {
		"Name",
		"Contributors",
		"Prefixes",
		"Rank",
		"Aliases",
		"Tags",
		"Description",
		"Args",
		"Loopable"
	}
	HDAdminMain.products = {
		Donor = 1930752254,
		OldDonor = 1930752254
	}
	HDAdminMain.materials = {
		"Plastic",
		"Wood",
		"Concrete",
		"CorrodedMetal",
		"DiamondPlate",
		"Foil",
		"Grass",
		"Ice",
		"Marble",
		"Granite",
		"Brick",
		"Pebble",
		"Sand",
		"Fabric",
		"SmoothPlastic",
		"Metal",
		"WoodPlanks",
		"Cobblestone",
		"Neon",
		"Glass"
	}
	HDAdminMain.rankTypes = {
		Auto = 4,
		Perm = 3,
		Server = 2,
		Temp = 1
	}

	if p2 == "Server" then
		HDAdminMain.pd = {}
		HDAdminMain.sd = {}
		HDAdminMain.permissions = {
			friends = 0,
			freeAdmin = 0,
			vipServerOwner = 0,
			vipServerPlayer = 0,
			owner = true,
			specificUsers = {},
			gamepasses = {},
			assets = {},
			groups = {}
		}
		HDAdminMain.commandInfo = {}
		HDAdminMain.commandRanks = {}
		HDAdminMain.infoOnAllCommands = {
			Contributors = {},
			Tags = {},
			Prefixes = {},
			Aliases = {}
		}
		HDAdminMain.morphNames = {}
		HDAdminMain.toolNames = {}
		HDAdminMain.commands = {}
		HDAdminMain.playersRanked = {}
		HDAdminMain.playersUnranked = {}
		HDAdminMain.settings.UniversalPrefix = "!"
		HDAdminMain.serverAdmins = {}
		HDAdminMain.owner = {}
		HDAdminMain.ownerId = game.CreatorId

		if game.CreatorType == Enum.CreatorType.Group then
			local v1 = nil
			local v2 = nil

			for i = 1, 10 do
				local ok, result = pcall(function() --[[ Line: 74 | Upvalues: HDAdminMain (ref) ]]
					return HDAdminMain.groupService:GetGroupInfoAsync(game.CreatorId).Owner
				end)

				if ok then
					v1 = ok
					v2 = result

					break
				end

				task.wait(1)
				v1 = ok
				v2 = result
			end

			if v1 then
				HDAdminMain.ownerId = v2.Id
				HDAdminMain.ownerName = v2.Name
			end
		end

		local ok, result = pcall(function() --[[ Line: 85 | Upvalues: HDAdminMain (ref) ]]
			return HDAdminMain.marketplaceService:GetProductInfo(game.PlaceId, Enum.InfoType.Asset)
		end)
		local v3 = if ok then result else {
	Name = "GameNameFailedToLoad"
}

		HDAdminMain.gameInfo = v3
		HDAdminMain.gameName = v3.Name
		HDAdminMain.listOfTools = {}
		HDAdminMain.ranksAllowedToJoin = 0
		HDAdminMain.permissionToReplyToPrivateMessage = {}
		HDAdminMain.logs = {
			command = {},
			chat = {}
		}
		HDAdminMain.isStudio = HDAdminMain.runService:IsStudio()
		HDAdminMain.serverBans = {}
		HDAdminMain.blacklistedVipServerCommands = {}
		HDAdminMain.banned = {}
		HDAdminMain.commandBlocks = {}

		for j = 1, 3 do
			pcall(function() --[[ Line: 111 | Upvalues: HDAdminMain (ref), j (copy) ]]
				HDAdminMain.physicsService:RegisterCollisionGroup("Group" .. j)
			end)
		end

		HDAdminMain.physicsService:CollisionGroupSetCollidable("Group1", "Group2", false)
	else
		if p2 ~= "Client" then
			table.sort(HDAdminMain.settings.Ranks, function(p13, p23) --[[ Line: 165 ]]
				return p13[1] < p23[1]
			end)

			return
		end

		HDAdminMain.qualifiers = {
			"me",
			"all",
			"others",
			"random",
			"admins",
			"nonAdmins",
			"friends",
			"nonFriends",
			"NBC",
			"BC",
			"TBC",
			"OBC",
			"R6",
			"R15",
			"rthro",
			"nonRthro"
		}
		HDAdminMain.colors = {}
		HDAdminMain.topbarEnabled = true
		HDAdminMain.blur = Instance.new("BlurEffect", HDAdminMain.camera)
		HDAdminMain.blur.Size = 0
		HDAdminMain.commandMenus = {}
		HDAdminMain.commandsToDisableCompletely = {
			laserEyes = true
		}
		HDAdminMain.commandsActive = {}
		HDAdminMain.commandsAllowedToUse = {}
		HDAdminMain.commandsWithMenus = {
			Type1 = {
				laserEyes = { "Info", "Press and hold to activate." },
				fly = { "Input", "Speed" },
				fly2 = { "Input", "Speed" },
				noclip = { "Input", "Speed" },
				noclip2 = { "Input", "Speed" }
			},
			Type2 = {
				cmdbar2 = {}
			},
			Type3 = {
				bubbleChat = {}
			}
		}
		HDAdminMain.commandSpeeds = {
			fly = 50,
			fly2 = 50,
			noclip = 100,
			noclip2 = 25
		}

		for k, v in pairs(HDAdminMain.commandSpeeds) do
			local v4 = HDAdminMain.settings.CommandLimits[k]

			if v4 then
				local Limit = v4.Limit

				if Limit < v then
					HDAdminMain.commandSpeeds[k] = Limit
				end
			end
		end

		HDAdminMain.infoFramesViewed = {
			Speed = true
		}
	end

	table.sort(HDAdminMain.settings.Ranks, function(p13, p23) --[[ Line: 165 ]]
		return p13[1] < p23[1]
	end)
end

return t