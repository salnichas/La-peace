-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain

function t.GetRankName(p1, p2) --[[ GetRankName | Line: 12 | Upvalues: HDAdminMain (copy) ]]
	return HDAdminMain:GetModule("cf"):GetRankName(p2)
end
function t.GetRankId(p1, p2) --[[ GetRankId | Line: 16 | Upvalues: HDAdminMain (copy) ]]
	return HDAdminMain:GetModule("cf"):GetRankId(p2)
end
function t.Notice(p1, p2, p3) --[[ Notice | Line: 20 | Upvalues: HDAdminMain (copy) ]]
	if HDAdminMain.player then
		if p3 then
			HDAdminMain:GetModule("Notices"):Notice("Notice", "Game Notice", p3)
		end
	else
		HDAdminMain:GetModule("cf"):Notice(p2, "Game Notice", p3)
	end
end
function t.Error(p1, p2, p3) --[[ Error | Line: 30 | Upvalues: HDAdminMain (copy) ]]
	if HDAdminMain.player then
		if p3 then
			HDAdminMain:GetModule("Notices"):Notice("Error", "Game Notice", p3)
		end
	else
		HDAdminMain.signals.Error:FireClient(p2, { "Game Notice", p3 })
	end
end

return t