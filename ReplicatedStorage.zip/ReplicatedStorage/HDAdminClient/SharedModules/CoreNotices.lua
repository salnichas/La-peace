-- https://lua.expert/
local t = {}
local HDAdminMain = _G.HDAdminMain

function t.GetNotice(p1, p2) --[[ GetNotice | Line: 5 | Upvalues: HDAdminMain (copy) ]]
	return ({
		WelcomeRank = {
			HDAdminMain.hdAdminCoreName,
			"Seu rank \195\169 \'%s\'! Clique para ver comandos",
			{ "ShowSpecificPage", "Commands", "Commands" }
		},
		WelcomeDonor = {
			HDAdminMain.hdAdminCoreName,
			"Voc\195\170 \195\169 membro da Vice Club! Clique aqui para ver seus comandos especiais",
			{ "ShowSpecificPage", "Special", "Donor" }
		},
		SetRank = { HDAdminMain.hdAdminCoreName, "Voc\195\170 foi %sed para \'%s\'!" },
		UnlockRank = { HDAdminMain.hdAdminCoreName, "Voc\195\170 desbloqueou \'%s\'!" },
		UnRank = { HDAdminMain.hdAdminCoreName, "Retiraram o seu rank!" },
		ParserInvalidCommandRank = { HDAdminMain.hdAdminCoreName, "\'%s\' n\195\163o \195\169 um comando v\195\161lido! tente \'%srank jogador %s\' ao inv\195\169s disso." },
		ParserInvalidCommandNormal = { HDAdminMain.hdAdminCoreName, "\'%s\' n\195\163o \195\169 um comando v\195\161lido", "" },
		ParserInvalidPrefix = { HDAdminMain.hdAdminCoreName, "Prefixo errado! Tente trocar seu Prefixo nas configura\195\167\195\181es do seu Delta Admin." },
		ParserInvalidVipServer = { HDAdminMain.hdAdminCoreName, "Voc\195\170 n\195\163o pode usar \'%s\' em servidores privados." },
		ParserInvalidDonor = { HDAdminMain.hdAdminCoreName, "Voc\195\170 precisa ser membro da Vice Club para usar este comando" },
		ParserInvalidLoop = { HDAdminMain.hdAdminCoreName, "Voc\195\170 n\195\163o tem permiss\195\163o para usar comandos infinitos!" },
		ParserInvalidRank = { HDAdminMain.hdAdminCoreName, "Voc\195\170 n\195\163o pode usar \'%s\'" },
		ParserCommandBlock = { HDAdminMain.hdAdminCoreName, "Comandos est\195\163o tempor\195\161riamente desativados\'" },
		ParserInvalidRigType = { HDAdminMain.hdAdminCoreName, "%s precisar ser %s para usar este comando" },
		ParserPlayerRankBlocked = { HDAdminMain.hdAdminCoreName, "Voc\195\170 n\195\163o tem permis\195\163o de usar o comando \'%s\' em %s!" },
		ParserSpeakerRank = { HDAdminMain.hdAdminCoreName, "Voc\195\170 %sed %s para \'%s\'" },
		ParserSpeakerUnrank = { HDAdminMain.hdAdminCoreName, "Voc\195\170 tirou o rank de %s" },
		ParserPlrPunished = { HDAdminMain.hdAdminCoreName, "%s precisa ser despunido para usar este comando." },
		ReceivedPM = { HDAdminMain.hdAdminCoreName, "Voc\195\170 recebeu uma mensagem de %s! Clique para abrir." },
		RemovePermRank = { HDAdminMain.hdAdminCoreName, "Retirou o rank com sucesso de %s!" },
		BroadcastSuccessful = { HDAdminMain.hdAdminCoreName, "Voc\195\170 enviou um aviso! Seu aviso ir\195\161 aparecer em instantes." },
		BroadcastFailed = { HDAdminMain.hdAdminCoreName, "Aviso falhou ao ser enviado." },
		InformPrefix = { HDAdminMain.hdAdminCoreName, "O prefixo do servidor \195\169 \'%s\'" },
		GetSoundSuccess = { HDAdminMain.hdAdminCoreName, "O id do som tocando \195\169: %s" },
		GetSoundFail = { HDAdminMain.hdAdminCoreName, "Nenhum som est\195\161 tocando!" },
		UnderControl = { HDAdminMain.hdAdminCoreName, "Voc\195\170 est\195\161 sendo controlado por %s!" },
		ClickToTeleport = { "Teleportar", "Clique para teleportar para \'%s\' [%s]" },
		BanSuccess = {
			HDAdminMain.hdAdminCoreName,
			"Voc\195\170 baniu %s com sucesso! Clique para ver banimentos.",
			{ "ShowSpecificPage", "Admin", "Banland" }
		},
		UnBanSuccess = { HDAdminMain.hdAdminCoreName, "Voc\195\170 desbaniu %s!" },
		QualifierLimitToSelf = { HDAdminMain.hdAdminCoreName, "\'%ss\' s\195\179 pode usar comandos em s\195\173 mesmo!" },
		QualifierLimitToOnePerson = { HDAdminMain.hdAdminCoreName, "\'%ss\' s\195\179 poe usar comando em uma pessoa!" },
		ScaleLimit = { HDAdminMain.hdAdminCoreName, "O limite \195\169 de %s para ranks abaixo de \'%s\'" },
		RequestsLimit = { HDAdminMain.hdAdminCoreName, "Voc\195\170 est\195\161 enviando muitos pedidos!" },
		AlertFail = { HDAdminMain.hdAdminCoreName, "Alerta falhou em ser enviado." },
		PollFail = { HDAdminMain.hdAdminCoreName, "Pesquisa falhou em ser enviada." },
		GearBlacklist = { HDAdminMain.hdAdminCoreName, "N\195\163o pode usar gear: %s. Esse item foi banido." },
		BanFailLength = { HDAdminMain.hdAdminCoreName, "%s o tempo de banimento deve ser maior que 0!" },
		BanFailVIPServer = { HDAdminMain.hdAdminCoreName, "%s\'permBan\' \195\169 proibido em servidores privados!" },
		BanFailAllServers = { HDAdminMain.hdAdminCoreName, "Voc\195\170 n\195\163o tem permiss\195\163o para banir jogadores \'todos os servidores\'." },
		BanFailAlreadyBanned = { HDAdminMain.hdAdminCoreName, "%s j\195\161 foi banido!" },
		BanFailRobloxRejected = { HDAdminMain.hdAdminCoreName, "%s%s" },
		BanFailPermission = { HDAdminMain.hdAdminCoreName, "Voc\195\170 n\195\163o pode banir %s" },
		BanFailDataNotFound = { HDAdminMain.hdAdminCoreName, "%s dados n\195\163o encontrados." },
		RestoreDefaultSettings = { "Settings", "Voc\195\170 reiniciou todas as configura\195\167\195\181es!" },
		CommandBarLocked = { HDAdminMain.hdAdminCoreName, "Voc\195\170 n\195\163o tem permiss\195\163o para usar a cmdbar%s! rank permitido: \'%s\'" },
		FollowFail = { HDAdminMain.hdAdminCoreName, "Falhou em teleportar. %s n\195\163o est\195\161 no jogo." },
		SaveMap1 = { HDAdminMain.hdAdminCoreName, "Salvando c\195\179pia do mapa..." },
		SaveMap2 = { HDAdminMain.hdAdminCoreName, "Mapa salvado!" },
		CommandLimit = { HDAdminMain.hdAdminCoreName, "O %s limite \195\169 %s para ranks abaixo de \'%s\'" },
		CommandLimitPerMinute = { HDAdminMain.hdAdminCoreName, "Enviando comandos muito rapidamente, o limite por minuto foi atingido." },
		template = { HDAdminMain.hdAdminCoreName, "" }
	})[p2]
end

return t