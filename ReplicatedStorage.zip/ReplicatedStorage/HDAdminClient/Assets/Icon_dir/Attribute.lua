-- https://lua.expert/
local RunService = game:GetService("RunService")

game:GetService("GroupService")
game:GetService("Players")
RunService:IsStudio()

return {}