-- https://lua.expert/
local GamepadService = game:GetService("GamepadService")
local UserInputService = game:GetService("UserInputService")
local GuiService = game:GetService("GuiService")
local t = {}
local v1 = nil

function t.start(p1) --[[ start | Line: 24 | Upvalues: v1 (ref), GuiService (copy), UserInputService (copy), t (copy), GamepadService (copy) ]]
	v1 = p1
	v1.highlightKey = Enum.KeyCode.DPadUp
	v1.highlightIcon = false
	task.delay(1, function() --[[ Line: 33 | Upvalues: v1 (ref), GuiService (ref), UserInputService (ref), t (ref), GamepadService (ref) ]]
		local iconsDictionary = v1.iconsDictionary

		local function getIconFromSelectedObject() --[[ getIconFromSelectedObject | Line: 36 | Upvalues: GuiService (ref), iconsDictionary (copy) ]]
			local SelectedObject = GuiService.SelectedObject
			local v1 = if SelectedObject then SelectedObject:GetAttribute("CorrespondingIconUID") else SelectedObject

			return if v1 then iconsDictionary[v1] else v1
		end

		local v12 = nil
		local v2 = false
		local RunService = game:GetService("RunService")
		local v3 = false

		require(script.Parent.Parent.Utility)

		local Selection = require(script.Parent.Parent.Elements.Selection)

		local function updateSelectedObject() --[[ updateSelectedObject | Line: 51 | Upvalues: GuiService (ref), iconsDictionary (copy), UserInputService (ref), RunService (copy), Selection (copy), v1 (ref), v12 (ref), v3 (ref), v2 (ref), t (ref) ]]
			local SelectedObject = GuiService.SelectedObject
			local v13 = if SelectedObject then SelectedObject:GetAttribute("CorrespondingIconUID") else SelectedObject
			local v22 = if v13 then iconsDictionary[v13] else v13
			local v32 = UserInputService.GamepadEnabled and not RunService:IsStudio()

			if v22 then
				local v4

				if v32 then
					local v5 = v22:getInstance("ClickRegion")
					local selection = v22.selection

					if selection then
						v4 = v22
					else
						local v6 = v22.janitor:add(Selection(v1))

						v6:SetAttribute("IgnoreVisibilityUpdater", true)
						v6.Parent = v22.widget
						v22.selection = v6
						v22:refreshAppearance(v6)
						selection = v6
						v4 = v22
					end

					v5.SelectionImageObject = selection.Selection
				else
					v4 = v22
				end

				if v12 and v12 ~= v4 then
					v12:setIndicator()
				end

				local v7 = if v32 and not (v3 or v4.parentIconUID) then Enum.KeyCode.ButtonB else nil

				v12 = v4
				v1.lastHighlightedIcon = v4
				v4:setIndicator(v7)
			else
				local v8 = if v32 and not v2 then v1.highlightKey else nil

				if not v12 then
					v12 = t.getIconToHighlight()
				end

				if v8 == v1.highlightKey then
					v2 = true
				end

				if not v12 then
					return
				end

				v12:setIndicator(v8)
			end
		end

		GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(updateSelectedObject)

		local function checkGamepadEnabled() --[[ checkGamepadEnabled | Line: 94 | Upvalues: UserInputService (ref), RunService (copy), v2 (ref), v3 (ref), updateSelectedObject (copy) ]]
			if UserInputService.GamepadEnabled and not RunService:IsStudio() then
				updateSelectedObject()

				return
			end

			v2 = false
			v3 = false
			updateSelectedObject()
		end

		UserInputService:GetPropertyChangedSignal("GamepadEnabled"):Connect(checkGamepadEnabled)

		local v4 = UserInputService.GamepadEnabled and not RunService:IsStudio()

		if not v4 then
			v2 = false
			v3 = false
		end

		updateSelectedObject()
		UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 108 | Upvalues: GuiService (ref), iconsDictionary (copy), v1 (ref), t (ref), GamepadService (ref) ]]
			if p1.UserInputType == Enum.UserInputType.MouseButton1 then
				local SelectedObject = GuiService.SelectedObject
				local v12 = if SelectedObject then SelectedObject:GetAttribute("CorrespondingIconUID") else SelectedObject

				if not (if v12 then iconsDictionary[v12] else v12) then
					return
				end

				GuiService.SelectedObject = nil
			else
				if p1.KeyCode ~= v1.highlightKey then
					return
				end

				local v3 = t.getIconToHighlight()

				if not v3 then
					return
				end

				if GamepadService.GamepadCursorEnabled then
					task.wait(0.2)
					GamepadService:DisableGamepadCursor()
				end

				GuiService.SelectedObject = v3:getInstance("ClickRegion")
			end
		end)
	end)
end
function t.getIconToHighlight() --[[ getIconToHighlight | Line: 135 | Upvalues: v1 (ref) ]]
	local iconsDictionary = v1.iconsDictionary
	local v12 = v1.highlightIcon or v1.lastHighlightedIcon

	if not v12 then
		local v2 = nil

		for k, v in pairs(iconsDictionary) do
			if not v.parentIconUID and (not v2 or v.widget.AbsolutePosition.X < v2) then
				v2 = v.widget.AbsolutePosition.X
				v12 = v
			end
		end
	end

	return v12
end
function t.registerButton(p1) --[[ registerButton | Line: 157 | Upvalues: UserInputService (copy), GamepadService (copy), GuiService (copy) ]]
	local v1 = false

	p1.InputBegan:Connect(function(p1) --[[ Line: 163 | Upvalues: v1 (ref) ]]
		v1 = true
		task.wait()
		task.wait()
		v1 = false
	end)

	local v2 = UserInputService.InputBegan:Connect(function(p12) --[[ Line: 172 | Upvalues: v1 (ref), GamepadService (ref), GuiService (ref), p1 (copy) ]]
		task.wait()

		if p12.KeyCode == Enum.KeyCode.ButtonA and v1 then
			task.wait(0.2)
			GamepadService:DisableGamepadCursor()
			GuiService.SelectedObject = p1

			return
		end

		local v12 = if GuiService.SelectedObject == p1 then true else false
		local v2 = p12.KeyCode.Name

		if not table.find({ "ButtonB", "ButtonSelect" }, v2) or (not v12 or v2 == "ButtonSelect" and not GamepadService.GamepadCursorEnabled) then
			return
		end

		GuiService.SelectedObject = nil
	end)

	p1.Destroying:Once(function() --[[ Line: 193 | Upvalues: v2 (copy) ]]
		v2:Disconnect()
	end)
end

return t